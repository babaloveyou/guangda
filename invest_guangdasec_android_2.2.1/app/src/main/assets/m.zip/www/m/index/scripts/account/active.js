/**
 * 手机激活
 */
define(function(require, exports, module){
	/*模块内部全局变量*/
	var appUtils = require("appUtils"),
		layerUtils = require("layerUtils"),
		gconfig = require("gconfig"),
		global = gconfig.global,
		validatorUtil = require("validatorUtil"),
		service = require("serviceImp"),  //业务层接口，请求数据
		_pageId = "#account_active ";
	
	/*页面初始化方法*/
	function init(){}
	
	/*绑定页面事件的方法*/
	function bindPageEvent()
	{
		/* 点击获取验证码 */
		appUtils.bindEvent($(_pageId+" .getmsg"), function(e){
			var phoneNum = $(_pageId+" .phoneNum").val();
			getMsg(phoneNum); // 获取验证码
			e.stopPropagation();
		});
		
		/* 先不激活，随便看看 */
		appUtils.bindEvent($(_pageId+" .noactivate"), function(e){
			// 调插件返回到原生主页
			var param_index = {"funcNo":"50101","moduleName":"user-center"};
			require("external").callMessage(param_index); 
			e.stopPropagation();
		});
		
		/* 激活 */
		appUtils.bindEvent($(_pageId+" .activate") ,function(){
		   var phoneNum =  $(_pageId+" .phoneNum").val();
		   var msgNum =  $(_pageId+" .msgNum").val();
		    if(phoneNum.length == 0)
			{
				layerUtils.iMsg(-1,"手机号不能为空");
				return;
			}
		    if(msgNum.length == 0)
		    {
		    	layerUtils.iMsg(-1,"验证码不能为空");
		    	return;
		    }
		    if(!validatorUtil.isMobile(phoneNum))
		    {
		    	layerUtils.iMsg(-1,"手机号码输入有误！");
				return;
		    }
		    startActived(); // 提交激活
		});
	}
	/*页面销毁方法*/
	function destroy()
	{
		service.destroy();
	}
	
	/* 获取验证码 */
	function getMsg(phoneNum)
	{
		if(validatorUtil.isMobile(phoneNum))
		{
			var param_ip = {"funcNo": "50023"};
			var param_mac = {"funcNo": "50024"};
			var ip = require("external").callMessage(param_ip);
			var mac = require("external").callMessage(param_mac);
			sendmsg(phoneNum,mac,ip); // 发送验证码
		}
		else
		{
			layerUtils.iAlert("您输入的手机号码格式不正确，请重新输入");
		}
	}
	
	/* 发送验证码 */
	function sendmsg(phoneNum,mac,ip)
	{
		var param = {
			// 访问接口来源标识，访问来源(默认PC) 0：pc， 2：pad， 3：手机 
			"op_way" : iBrowser.pc ? 0 : 3,
			"mobile_no" : phoneNum,
			"ip" : ip, 
			"mac" : mac
		};
		//请求获取验证码接口
		service.getSmsCode(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result = data.results;
			if(error_no == "0")
			{
		        //后台如果返回ip地址，则本地存储用户ip地址
			    if(result[0] && result[0].ip)
			    {
				    appUtils.setSStorageInfo("ip",result[0].ip);
			    }
				// 计时器
				var sumTime = 120;
				//处理获取验证码时发生的动作
				var handleCount = function(){
					// 获取验证码之后按钮隐藏
					$(_pageId+" .getmsg").hide();
					// 显示倒计时
					$(_pageId+" .time").show();
					$(_pageId+" .time").text(sumTime--+"秒后重发");
				};
				handleCount();
				startCountDown = window.setInterval(function(){
				handleCount();
				}, 1000);
				// 120 秒之后清除计时器
			    var clearCountDown = setTimeout(function(){
					// 显示按钮
					$(_pageId+" .getmsg").show();
					// 隐藏倒计时
					$(_pageId+" .time").hide();
					$(_pageId+" .time").text(120);
					window.clearInterval(startCountDown);
				},121000);
				 //发送完验证码后，通过判断输入手机号是否一致，否则重新发送验证码
				 var c_phoneNum =phoneNum;
				 appUtils.bindEvent($(_pageId+" .phoneNum"),function(){
					c_phoneNum =$(_pageId+" .phoneNum").val();
				 	if(validatorUtil.isMobile(phoneNum)&&validatorUtil.isMobile(c_phoneNum))
				 	{
				 		//用户两次输入的手机号不同，重新获取验证码
				 		if(c_phoneNum!=phoneNum)
				 		{
				 			clearInterval(startCountDown);   //清除定时器
				 			clearTimeout(clearCountDown);
							$(_pageId+" .getmsg").show();  // 显示按钮
							$(_pageId+" .time").hide();  // 隐藏倒计时
				 		}
				 	}
				 },"input");
			}
			else
			{
				layerUtils.iAlert(error_info,-1);
				return false;
			}
		});
	}
	
	/* 提交激活 */
	function startActived()
	{
		var param = {	
			"mobile_no" : $(_pageId+" .phoneNum").val(),
			"mobile_code" : $(_pageId+" .msgNum").val(),
			"login_flag":"0"
		};	
		/*调用验证码校验接口*/
		service.checkSmsCode(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result = data.results;
			if(error_no == "0" && result.length != 0)
			{
				var doActive = function(){
					var param = {
						"hardsn" : global.hardId, // 硬件信息
						"phone" : $(_pageId+" .phoneNum").val() // 电话号码
					};
					var getHardIdCallback = function(){
						param.hardsn = global.hardId;
						service.bindMobile(param,function(data){
							if (data.error_no == 0)
							{
								var param_active = {"funcNo":"50042", "key": "isActived", "value": "1"};
								var param_phone = {"funcNo":"50042", "key": "phone", "value": $(_pageId+" .phoneNum").val()};
								require("external").callMessage(param_active); //保存激活状态
								require("external").callMessage(param_phone); // 保存手机号
								appUtils.pageInit("account/active","account/userCenter");
							}
							else
							{
								layerUtils.iAlert(data.error_info);
							}
						});
					};
					if(global.hardId)
					{
						getHardIdCallback();
					}
					else
					{
						getHardId(getHardIdCallback); // 获取硬件 id
					}
				};
				doActive(); // 调用激活接口
			}
			else{
				layerUtils.iAlert(error_info);
			}
		});
	}
	
	/**
	 * 获取硬件 id
	 * @param getHardIdCallback
	 */
	function getHardId(getHardIdCallback)
	{
		var param_hardId = {"funcNo": "50022"};
		var hardId = require("external").callMessage(param_hardId);
        global.hardId = hardId;
	    if(getHardIdCallback)
		{
			getHardIdCallback();	
		}
		else
		{
			layerUtils.iLoading(false);
		}
	}
	
	
	/*向外暴露的 JSON 对象*/
	var active = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	
	/*对外暴露 JSON 对象*/
	module.exports = active;
});
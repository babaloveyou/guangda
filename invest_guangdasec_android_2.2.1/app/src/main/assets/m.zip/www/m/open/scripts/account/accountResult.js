/**
 * 开|转|理财户结果
 */
define(function(require,exports,module){
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
		  gconfig = require("gconfig"),
		  layerUtils = require("layerUtils"),
		  global = gconfig.global,
		  service = require("investService").getInstance(),  //业务层接口，请求数据
		  _pageId = "#account_accountResult";
		  
	var external = require("external");
		  
   var channelInfo = global.channelInfo;
	/* 私有业务模块的全局变量 end */
	
	function init()
	{
		$(_pageId+" .order_succes p:eq(2)").html("如有疑问，您可以拨打光大证券客服热线95525咨询，或联系营业部。您可以点击下方链接，查询光大证券各营业部详细信息。" +
		"<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='javascript:void(0);' id='branchInfo'>光大证券营业网点及联系方式</a>");
		
		initPage();
	}
	
	function bindPageEvent()
	{
		
		/* 查看营业部信息 */
		appUtils.bindEvent($(_pageId+" #branchInfo"),function(){
			
			var param = {
					"funcNo":"60009",
					"url" : "http://www.ebscn.com/main/hall/outlets/index.shtml?isLink#fastSearch"
				};
				
			var result = external.callMessage(param);
//			require("shellPlugin").callShellMethod("webViewPlugin", null, null, param);
		});
		
		/* 返回首页 */
		appUtils.bindEvent($(_pageId+" .share_btn"),function(){
			appUtils.clearSStorage();  // 清空所有的session
			$("#afui #content .page").each(function(){
				$(this).remove();
			});
			appUtils.pageInit("account/accountResult","business/index");
		});
		
		/* 银证入口 */
		appUtils.bindEvent($(_pageId+" .share_btn:eq(1)"),function(){
			
			var param = {
					"funcNo" : "60009",
					"url" : "https://mywap2.icbc.com.cn/ICBCWAPBank/servlet/PortalInject?inject=conformity%7CX2p1bXBCcmFuY2hBcmVhQ29kZT0xMDAxJl9qdW1wQnJhbmNoUGFyYW1zPXVybEZsYWd8MzAwMA=="	
				};
				var result = external.callMessage(param);
//			require("shellPlugin").callShellMethod("webViewPlugin", null, null, param);
		});

		
	}
	
	function destroy()
	{
		$(_pageId+" order_succes p:eq(3)").html("");
		$(_pageId+" .order_succes p:eq(2)").html("");
		$(_pageId+" #gdzh").html("");
	}
	
    /* 初始化页面 */	
	function initPage()
	{
		//工商银行提示
		if(channelInfo == "9" || channelInfo == "6" ){
			
			if(channelInfo == "6"){
				$(_pageId+" .share_btn:eq(0)").hide();
				$(_pageId+" .share_btn:eq(1)").show();
			}else{
				$(_pageId+" .share_btn:eq(1)").hide();
				$(_pageId+" .share_btn:eq(0)").show();
			}
			
		}else{
			$(_pageId+" .share_btn:eq(1)").hide();
			$(_pageId+" .share_btn:eq(0)").show();
		}
		
		
		if(appUtils.getSStorageInfo("openChannel") == "change")
		{
			// 理财户
			if(appUtils.getSStorageInfo("finance") == "finance")  
			{
				$(_pageId+" .header h3").html("开户结果");
				$(_pageId+" .order_succes h5:eq(0)").text("开户申请成功！");
				$(_pageId+" .order_succes p:eq(0)").html("您的开户申请我们已经收到并正在受理中。");
				$(_pageId+" .order_succes dl:eq(1)").hide();
				$(_pageId+" .order_succes dl:eq(2)").hide();
			}
			// 转户
			else 
			{
				$(_pageId+" .header h3").html("开户结果");
				$(_pageId+" .order_succes h5:eq(0)").text("开户申请成功！");
				$(_pageId+" .order_succes p:eq(0)").html("您的开户申请我们已经收到并正在受理中。");
				$(_pageId+" .order_succes dl:eq(3)").hide();
				$(_pageId+" .order_succes dl:eq(4)").hide();
			}
		}
		// 新开户
		else  
		{
			$(_pageId+" .header h3").html("开户结果");
			$(_pageId+" .order_succes h5:eq(0)").text("开户申请成功！");
			$(_pageId+" .order_succes p:eq(0)").html("您的开户申请我们已经收到并正在受理中。");
		}
		// 驳回后重新提交
		if(appUtils.getSStorageInfo("isBack") == "backInfo")
		{
			$(_pageId+" .header h3").html("开户进度");
			$(_pageId+" .order_succes h5:eq(0)").text("重新提交资料成功！");
		}
		$(_pageId+" .order_succes p:eq(0)").hide();  
		$(_pageId+" .order_succes p:eq(1)").hide();
		queryAccount(); // 查询用户信息
	}
	
	/* 查询用户信息 */
	function queryAccount()
	{
		var param = {"user_id" : appUtils.getSStorageInfo("user_id")};
		service.queryUserInfo(param, function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			if(error_no == 0)
			{
				var res = data.results[0];
				appUtils.setSStorageInfo("fund_account",res.fund_account);  // 资金账号
				appUtils.setSStorageInfo("shfund_select",res.shfund_select);  // 沪基金状态
				appUtils.setSStorageInfo("szfund_select",res.szfund_select); // 深基金状态 
				appUtils.setSStorageInfo("szaselect",res.szaselect); // 深A状态
				appUtils.setSStorageInfo("shaselect",res.shaselect); // 沪A状态
				appUtils.setSStorageInfo("szaaccount",res.szaaccount); // 深A账号
				appUtils.setSStorageInfo("shaaccount",res.shaaccount); // 沪A账号
				appUtils.setSStorageInfo("szfund_account",res.zacn_account); // 深基金账号
				appUtils.setSStorageInfo("shfund_account",res.hacn_account); //沪基金账号
				
				appUtils.setSStorageInfo("hacnselect",res.hacnselect); // 沪基金账户 判断是否选择
				appUtils.setSStorageInfo("zacnselect",res.zacnselect); // 深基金账户
				appUtils.setSStorageInfo("hacn_account",res.hacn_account); // 沪基金账户
				appUtils.setSStorageInfo("zacn_account",res.zacn_account); // 深基金账户
				showOpenAccount();  // 显示开户结果
			}
			else
			{
				layerUtils.iMsg(-1, error_info);
			}
		});
	}
	
	/* 显示新开户结果 */
	function showOpenAccount()
	{
		// 从 session 中取资金账号和股东账号
		var shaselect = appUtils.getSStorageInfo("shaselect"),  // 是否选择沪A
			  szaselect = appUtils.getSStorageInfo("szaselect"),  // 是否选择深A
			  shfund_select = appUtils.getSStorageInfo("shfund_select"),  // 是否选择沪基金
			  szfund_select = appUtils.getSStorageInfo("szfund_select"),  // 是否选择深基金
		      fund_account = appUtils.getSStorageInfo("fund_account"),  // 资金账号
			  shaaccount = appUtils.getSStorageInfo("shaaccount"), // 沪A股东账户
			  szaaccount = appUtils.getSStorageInfo("szaaccount"),  // 深A股东账户
			  shfund_account = appUtils.getSStorageInfo("shfund_account"),  // 沪基金账户
			  szfund_account = appUtils.getSStorageInfo("szfund_account"); // 深基金账户
		
			hacnselect = appUtils.getSStorageInfo("hacnselect"); // 沪基金账户  判断是否选择
			zacnselect = appUtils.getSStorageInfo("zacnselect"); // 深基金账户
			hacn_account = appUtils.getSStorageInfo("hacn_account"); // 沪基金账户
			zacn_account = appUtils.getSStorageInfo("zacn_account"); // 深基金账户
		// 判断资金账户是否开出
		if(fund_account != null)
		{
			//设置按钮显示提示文字
			if(appUtils.getSStorageInfo("openChannel") == "change")
			{
				if(appUtils.getSStorageInfo("finance") == "finance")
				{
					$(_pageId+" .order_succes h5:eq(0)").text("恭喜开户成功！");
				}
				else
				{
					$(_pageId+" .order_succes h5:eq(0)").text("恭喜开户成功！");
				}
			}
			else
			{
				$(_pageId+" .order_succes h5:eq(0)").text("恭喜开户成功！");
			}
			$(_pageId+" .order_succes p:eq(0)").hide();
			$(_pageId+" .order_succes p:eq(1)").hide();
			// 显示资金账户、股东账号的信息
			$(_pageId+" #zjzh").html("<a href='javascript:void(0)' class='copy'></a>&nbsp;"+fund_account);
		}
		else
		{
			$(_pageId+" .order_succes p:eq(0)").show();
			$(_pageId+" .order_succes p:eq(1)").show();
			$(_pageId+" #zjzh").html("&nbsp;办理中...");
		}
		// 未开通深A
		if(szaselect == null)
		{
			$(_pageId+" .order_info dl:eq(1) dd").html("&nbsp;未申请");
			$(_pageId+" .order_info dl:eq(1)").hide();
		}
		// 未开通沪A
		if(shaselect == null)
		{
			$(_pageId+" .order_info dl:eq(2) dd").html("&nbsp;未申请");
			$(_pageId+" .order_info dl:eq(2)").hide();
		}
		// 未开通深开放式基金
		if(szfund_select == null)
		{
			$(_pageId+" .order_info dl:eq(3) dd").html("&nbsp;未申请");
			$(_pageId+" .order_info dl:eq(3)").hide();
		}
		// 未开通沪开放式基金
		if(shfund_select == null)
		{
			$(_pageId+" .order_info dl:eq(4) dd").html("&nbsp;未申请");
			$(_pageId+" .order_info dl:eq(4)").hide();
		}
		// 开通了深A
		if(szaselect != null)
		{
			// 深A已经开出账号
			if(szaaccount != null)
			{
				$(_pageId+" .order_succes p:eq(0)").hide();
				$(_pageId+" .order_succes p:eq(1)").hide();
				$(_pageId+" .order_info dl:eq(1) dd").html("&nbsp;"+szaaccount);
			}
			else
			{
				$(_pageId+" .order_succes p:eq(0)").show();
				$(_pageId+" .order_succes p:eq(1)").show();
				$(_pageId+" .order_info dl:eq(1) dd").html("&nbsp;办理中...");
				$(_pageId+" .order_info dl:eq(1)").show();
			}
		}
		// 开通了沪A
		if(shaselect != null)
		{
			// 沪A已经开出账号
			if(shaaccount != null)
			{
				$(_pageId+" .order_info dl:eq(2) dd").html("&nbsp;"+shaaccount);
				$(_pageId+" .order_succes p:eq(0)").hide();
				$(_pageId+" .order_succes p:eq(1)").hide();
			}
			else
			{
				$(_pageId+" .order_succes p:eq(0)").show();
				$(_pageId+" .order_succes p:eq(1)").show();
				$(_pageId+" .order_info dl:eq(2) dd").html("&nbsp;办理中...");
				$(_pageId+" .order_info dl:eq(2)").show();
			}
		}
		// 开通了深开放式基金
		if(zacnselect != null)
		{
			// 深开放式基金已经开出账号
			if(zacn_account != null)
			{
				$(_pageId+" .order_succes p:eq(0)").hide();
				$(_pageId+" .order_succes p:eq(1)").hide();
				$(_pageId+" .order_info dl:eq(3) dd").html("&nbsp;"+zacn_account);
			}
			else
			{
				$(_pageId+" .order_succes p:eq(0)").show();
				$(_pageId+" .order_succes p:eq(1)").show();
				$(_pageId+" .order_info dl:eq(3) dd").html("&nbsp;办理中...");
				$(_pageId+" .order_info dl:eq(3)").show();
			}
		}
		// 开通了沪开放式基金
		if(hacnselect != null)
		{
			// 沪开放式基金已经开出账号
			if(hacn_account != null)
			{
				$(_pageId+" .order_succes p:eq(0)").hide();
				$(_pageId+" .order_succes p:eq(1)").hide();
				$(_pageId+" .order_info dl:eq(4) dd").html("&nbsp;"+hacn_account);
			}
			else
			{
				$(_pageId+" .order_succes p:eq(0)").show();
				$(_pageId+" .order_succes p:eq(1)").show();
				$(_pageId+" .order_info dl:eq(4) dd").html("&nbsp;办理中...");
				$(_pageId+" .order_info dl:eq(4)").show();
			}
		}
		// 如果开出了上海账号，显示提示信息
		if(($(_pageId+" .order_info").html()).indexOf("沪") != -1)
		{
			$(_pageId+" .order_succes p:eq(3)").html("注意：请登录交易系统进行上海账户的指定交易：点击\"买入\"，输入证券代码\"799999\"，价格\"1\"，股数\"1\"。");
		}
		$(_pageId+" .order_succes .mt15").show();
		
		
		//工商银行版本时，只显示资金账户
//		if(channelInfo == "6" || channelInfo == "9"){
//			
//			$(_pageId + " .order_info dl").hide();
//			$(_pageId + " .order_info dl:eq(0)").show();
//		}

		$(_pageId + " .order_info dl").hide();
		$(_pageId + " .order_info dl:eq(0)").show();
	}
	
	var accountResult = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	
	module.exports = accountResult;
});
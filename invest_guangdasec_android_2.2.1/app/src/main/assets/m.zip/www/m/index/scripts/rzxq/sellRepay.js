/**
 * 卖券还款
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils");
	var layerUtils = require("layerUtils");
	var validatorUtil = require("validatorUtil");
	var putils = require("putils");
	var gconfig = require("gconfig");
	var global = gconfig.global;
	var service = require("serviceImp");  // 业务层接口，请求数据
	var _pageId = "#rzxq_sellRepay ";
	var userInfo = null;
    
    /**
     * 初始化
     */
	function init() {
		userInfo =  JSON.parse(appUtils.getSStorageInfo("userinfo"));
		var market = appUtils.getSStorageInfo("market");
		if(market){
			queryCanSell(market); // 查询可卖证券
		}
		$(_pageId+".data").scrollTop(0);
		$(_pageId+".data").css("overflow-y","auto");
		$(_pageId+".data").height(150); //查询目录添加高度
		
    }
	
	/**
	 * 事件绑定
	 */
	function bindPageEvent() {
		// 返回按钮
		appUtils.bindEvent($(_pageId + ".top_title .icon_back"), function(e){
			pageBack();
		});
		// 切换按钮
		appUtils.bindEvent($(_pageId + ".top_nav ul li:eq(1)"), function(e){
			appUtils.pageInit("rzxq/sellRepay","rzxq/sellRepayCancel");
		});
		// 股票代码
		appUtils.bindEvent($(_pageId + "#stockCode"), function(e){
			var stockCode = $(this).val();
			if(stockCode.length==6){
				queryStockInterceptor(stockCode);
			}
		},"keyup");
		// 委托下单
		appUtils.bindEvent($(_pageId + ".mn_btn .btn"), function(e){
            sumbmitEntrust(); // 委托下单
		});

	}
	// 查询可卖证券
	function queryCanSell(market){
		var ip="--";
		if(gconfig.platform != "0"){ 
			ip = external.callMessage({"funcNo": "50023"}).results[0].ip; //设备IP地址
		}
		var account = userInfo.client_no;
		var branch_no = userInfo.branch_no;
		var market_code = market;
		var param = {
			"account":account,
			"branch_no":branch_no,
			"ip":ip,
			"market_code":market_code
		};	
		service.query696(param,function(data){
			if(data.error_no == "0"){  
				var result = data.results;
				$(_pageId + ".mn_count b").text(result.length);
				if(result && result.length>0){
					var data = "";
                    for(var i=0,len=result.length;i<len;i++){
                    	data += queryHTML(result[i],i+1);
                    }
                	$(_pageId + "#conList").html(data);
                	appUtils.bindEvent($(_pageId+".mn_bond"), function(e){
                		var stockCode = $(this).attr("data-code");
                		queryStockInterceptor(stockCode);
                	});
				}else{
					$(_pageId + ".no_data").show(); // 没有数据时显示的暂无数据图标
				}
			}else{
				layerUtils.iAlert(data.error_info,-1);
			}
		});
	}
	function queryHTML(element,index){
		var eleHTML = "";
	    	eleHTML += "<div class=\"mn_bond\" data-code="+element.zq_code+">";
	    	eleHTML += "<div class=\"top_bond\">";
			eleHTML += "	<em class=\"bg_icon\"></em><h3>"+element.product_code+"</h3>";
			eleHTML += "</div>";	
			eleHTML += "<table>";
			eleHTML += "	<tr>";
			eleHTML += "		<th width=\"20%\">证券代码</th>";
			eleHTML += "		<td width=\"20%\">"+element.zq_code+"</td>";
			eleHTML += "		<th width=\"20%\">持有数量</th>";
			eleHTML += "		<td width=\"20%\">"+element.balance+"</td>";
			eleHTML += "	</tr>";
			eleHTML += "	<tr>";
			eleHTML += "		<th>可卖数量</th>";
			eleHTML += "		<td>"+element.use_balance+"</td>";
			eleHTML += "		<th>股东账号</th>";
			eleHTML += "		<td>"+element.gdzh+"</td>";
			eleHTML += "	</tr>";
			eleHTML += "	<tr>";
			eleHTML += "		<th>市&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;值</th>";
			eleHTML += "		<td>"+element.markt_value+"</td>";
			eleHTML += "	</tr>";
			eleHTML += "</table>";
			eleHTML += "</div>";
	    return eleHTML;
	}
	//行情列表查询
	function queryStockInterceptor(stockCode){
		var param = {
			"q":stockCode
		};	
		service.queryStockInterceptor(param,function(data){
			if(data.error_no == "0"){  
				var result = data.results;
				if(result && result.length>0){
					var stock_code =result[0].stock_code;
					var market =result[0].market;
					var stock_type =result[0].stock_type;
					queryStandardMarket(market,stock_code,stock_type);
				}else{
					layerUtils.iAlert("暂无此代码股票",-1);
				}
			}else{
				layerUtils.iAlert(data.error_info,-1);
			}
		});
	}
 	// 行情五档查询
	function queryStandardMarket(market,stockCode,stockType){
		var param = {
			"stockcode":stockCode,
			"market":market,
			"count":11
		};	
		service.queryStandardMarket(param,function(data){
			if(data.error_no == "0"){  
				var result = data.stockHq;
				var stock_code = result[0].stock_code; //股票代码
				var stock_name = result[0].stock_name; //股票名称
				$(_pageId + "#stockCode").val(stock_code);
				$(_pageId + "#stockName").val(stock_name);
				var WS =2; //小数位数
				var stock_type = stockType;
				if(stock_type=="3"||stock_type=="4"||stock_type=="5"||stock_type=="6"||
					stock_type=="8"||stock_type=="11"||stock_type=="12"||stock_type=="13"||stock_type=="14"||
				stock_type=="16"||stock_type=="19"||stock_type=="20"){
					WS=3;
				}
				for(var i=0; i < 5; i++){
					var buy_price =  result[0]["buy_price"+(i+1)];
					var buy_vol =  result[0]["buy_vol"+(i+1)];
					var sell_price =  result[0]["sell_price"+(i+1)];
					var sell_vol =  result[0]["sell_vol"+(i+1)];
					$(_pageId + ".table_index table tr:eq("+(i+1)+") th .lt").html("<em>"+(5-i)+"</em>"+sell_vol);
					$(_pageId + ".table_index table tr:eq("+(i+1)+") th .rt").html(Number(sell_price).toFixed(WS));
					$(_pageId + ".table_index table tr:eq("+(i+1)+") td .lt").html("<em>"+(i+1)+"</em>"+buy_vol);
					$(_pageId + ".table_index table tr:eq("+(i+1)+") td .rt").html(Number(buy_price).toFixed(WS));
				}
			}else {
				layerUtils.iAlert(data.error_info,-1);
			}
		});
	}
	
	/**
	 * 委托下单
	 */
	function sumbmitEntrust(){
		var stockCode = $(_pageId + "#stockCode").val();
		var stockPrice = $(_pageId + "#stockPrice").val();
		var stockNum = $(_pageId + "#stockNum").val();
		var stockName = $(_pageId + "#stockName").val();
		if(validatorUtil.isEmpty(stockCode)){
			layerUtils.iMsg(-1,"请输入股票代码");
			return false;
		}
		if(validatorUtil.isEmpty(stockPrice)){
			layerUtils.iMsg(-1,"请输入委托价格");
			return false;
		}
		if(validatorUtil.isEmpty(stockNum)){
			layerUtils.iMsg(-1,"请输入委托数量");
			return false;
		}
		var account = userInfo.client_no;
		var branch_no = userInfo.branch_no;
		var market_code = "2";
		var param = {
			"account":account,
			"branch_no":branch_no,
			"wt_mount":stockNum,
			"wt_price":stockPrice,
			"zq_code":stockCode,
			"market_code":market_code
		};	
		var tipStr ="<div class=\"pop_header\">";
		tipStr+="<h3>委托确认</h3>";
		tipStr+="</div>";
		tipStr+="<div class=\"pop_main\">";
		tipStr+="<ul>";
		tipStr+="    <li>证券名称: <em>"+stockName+"</em></li>";
		tipStr+="    <li>证券代码: <em>"+stockCode+"</em></li>";
		tipStr+="    <li>委托价格: <em>"+stockPrice+"</em></li>";
		tipStr+="    <li>委托数量: <em>"+stockNum+"</em></li>";
		tipStr+="</ul>";
		tipStr+="  </div>";
		putils.btnConfirm(tipStr,function success(){
			service.mqhk_wt(param,function(data){
				if(data.error_no == "0"){  
					var result = data.results;
					if(result && result.length>0){
						clearMSG();
						layerUtils.iAlert("委托成功",-1);
					}
				}else{
					clearMSG();
					layerUtils.iAlert(data.error_info,-1);
				}
			});
		},function fail(){
		});
	}
	
	function clearMSG(){
		for(var i=0; i < 5; i++){
			$(_pageId + ".table_index table tr:eq("+(i+1)+") th .lt").html("<em>"+(5-i)+"</em>"+"--");
			$(_pageId + ".table_index table tr:eq("+(i+1)+") th .rt").html("--");
			$(_pageId + ".table_index table tr:eq("+(i+1)+") td .lt").html("<em>"+(i+1)+"</em>"+"--");
			$(_pageId + ".table_index table tr:eq("+(i+1)+") td .rt").html("--");
		}
		$(_pageId + "#stockCode").val("");
		$(_pageId + "#stockPrice").val("");
		$(_pageId + "#stockNum").val("");
		$(_pageId + "#stockName").val("");
	}
	
	function destroy(){
		clearMSG();
	}
	
	/**
	 * 重写框架里面的pageBack方法
	 */
	function pageBack(){
		appUtils.pageInit("rzxq/sellRepay","rzxq/stockRepay");
	}
	
	var base = {
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy,
		"pageBack": pageBack
	};
	module.exports = base;
});
/**
 * 服务列表
 */
define(function(require, exports, module)
	{	
	var service = require("mobileService"); //业务层接口，请求数据
	var appUtils = require('appUtils'),
	putils = require("putils"),
	layerUtils = require("layerUtils"),
	gconfig = require("gconfig"),
	global = gconfig.global,
	convDict = require("convDict"),
	VIscroll = require("vIscroll");
	var _pageId ="#mall_itemsServ";
	var constants=require("constants");//常量类
	var pagingObjArr = [{"total_pages":0,"curr_page":0}]; //消息分页对象数组，这个页面只有一个分页，简单分页

	//1、初始化
	function init() 
	{
		configServ();
	}

	//初始化服务产品
	function configServ()
	{
		var param=
		{
			"product_shelf":constants.product_shelf.SHELF_ON,//上架状态
			"page":"1",
			"numPerPage":"4",
			"recommend_type":"",//推荐属性
			"is_hot_sale":""//是否按照热销排序  1排序 0或其他不排
		}
		service.findServ(param,function(data){

			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
			servItems(data);
		})
	}

	//处理服务产品
	function servItems(data)
	{
		var total_pages = data.DataSet1[0].total_pages;
		var curr_page = data.DataSet1[0].curr_page;
		var total_rows= data.DataSet1[0].total_rows;
		total_pages = total_pages ? total_pages:0;
		curr_page = curr_page ? curr_page:0;
		total_rows=total_rows?total_rows:0;
		pagingObjArr[0].total_pages=total_pages;
		$(_pageId+" em[name='totalPage']").html(total_pages);
		pagingObjArr[0].curr_page=curr_page;
		$(_pageId+" em[name='curPage']").html(curr_page);
		//显示多少条数据
		$(_pageId+" em[name='total_rows']").html(total_rows);

		var allRecommendStr =  "";
		var list =  data.DataSet0;
		var len = list.length;
		for( var i = 0; i<len ; i++)
		{
			var perData = list[i];
			allRecommendStr += handlePerItem(perData,i);
		}
		$(_pageId+" .pro_list02").html(allRecommendStr);

		//绑定跳转详情事件
		appUtils.bindEvent($(_pageId+" .pro_list02  li[product_id]"),function()
			{
			var pageInParam=
			{
				"product_id" : $(this).attr("product_id")
			}
			appUtils.pageInit("mall/itemsServ", "mall/itemsServInfo", pageInParam);
			});


		//上一页、下一页disabled效果
		if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
			$(_pageId + " span[name='aNextPage']").removeClass("blue");
			$(_pageId + " span[name='aPrePage']").addClass("blue");
		}
		else if (pagingObjArr[0].curr_page == 1) {
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + " span[name='aNextPage']").addClass("blue");
		}
		else {
			$(_pageId + " span[name='aPrePage']").addClass("blue");
			$(_pageId + " span[name='aNextPage']").addClass("blue");
		}

		if (pagingObjArr[0].total_pages<2) {
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + "  span[name='aNextPage']").removeClass("blue");
		}

		if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
			$(_pageId+" #isNull").html("暂无数据");
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + " span[name='aNextPage']").removeClass("blue");
		}
	}


	//显示服务产品  
	function handlePerItem(perData, idx)
	{
		var product_id = perData.product_id;//ID
		var product_name= perData.product_name;//产品名称
		var product_description=perData.product_description; //产品详情
		var product_price=perData.rules_price;			//产品价格数量
		var product_pricenum=perData.rules_explanation;//产品价格单位

		var oneRecommendStr="<li class='pro_list_item' product_id="+product_id+"><i class='new'>热销</i><!--这是新品标志--> "+
		"<div class='pic'><a href='javascript:;'> <img src='images/pro/n1.jpg' />"+
		" <p class='p5-0-0-15'><span class='star'><em class='level level4'></em></span></p>"+
		"</a>  </div> <div class='text' style='border:none;height:auto;line-height:22px;'><a href='javascript:;'>  <h2>"+product_name+"</h2> <span><em>"+product_price+"</em>"+product_pricenum+"</span>"+
		"<p>"+product_description+"</p>  </a>  </div>";
		return oneRecommendStr;
	}

	//处理上一页，下一页
	function handlePreNextPage(direction)
	{	
		var total_pages = pagingObjArr[0].total_pages;
		var   curr_page = pagingObjArr[0].curr_page;
		var   curPageNo = parseInt(curr_page) + direction ;
		if(curPageNo>0 && curPageNo <= total_pages && curPageNo != curr_page) //有效执行跳转页面条件
		{
			var param=
			{
				"product_shelf":constants.product_shelf.SHELF_ON,
				"page":curPageNo,
				"numPerPage":"4",
				"recommend_type":"",//推荐属性   1首页推荐 2购买推荐 
				"is_hot_sale":""//是否按照热销排序  1排序 0或其他不排
			}
			service.findServ(param,function(data)
				{
				if(data.error_no!="0")
				{
					layerUtils.iAlert(data.error_info);
					layerUtils.iLoading(false);
					return false;
				}
				servItems(data);

				});
		}
		else
		{	 
			return false;
			customVIscroll.scroll.refresh();
		}
	}


	//2、事件绑定
	function bindPageEvent()
	{

		// 点击上一页、下一页 
		appUtils.bindEvent($(_pageId+" span[name='aPrePage']"),function(){	handlePreNextPage(-1);});
		appUtils.bindEvent($(_pageId+" span[name='aNextPage']"),function(){handlePreNextPage(1);});

		// 点击首页 
		appUtils.bindEvent($(_pageId+" #mainPage"),function(){appUtils.pageInit("mall/itemsServ","account/mainPage",{});});

		// 点击理财
		appUtils.bindEvent($(_pageId+" #finan"),function(){appUtils.pageInit("mall/itemsServ","mall/itemsFinan",{});});

		//点击资讯
		appUtils.bindEvent($(_pageId+" #info"),function()	{appUtils.pageInit("mall/itemsServ","mall/itemsInfo",{});});

		// 点击基金 
		appUtils.bindEvent($(_pageId+" #fund"),function(){appUtils.pageInit("mall/itemsServ","mall/itemsFund",{});});

		// 点击服务 
		appUtils.bindEvent($(_pageId+" #serv"),function(){appUtils.pageInit("mall/itemsServ","mall/itemsServ",{});});

		//点击 LOGO 
		appUtils.bindEvent($(_pageId+" .logo"),function(){appUtils.pageInit("mall/itemsServ","account/mainPage")});

		//点击 返回顶部
		appUtils.bindEvent($(_pageId+" .back_btn"),function(){$('body,html').animate({scrollTop:0},1000);return false;});


		//点击 个人中心 
		appUtils.bindEvent($(_pageId+"  .icon_info"),function(){
			appUtils.pageInit("mall/itemsServ","account/userCenter",{});
		});

		/*点击登录*/
		appUtils.bindEvent($(_pageId+" .u_stat"),function(){
			appUtils.pageInit("mall/itemsServ","account/userCenter",{});
		});
	}

	//3、销毁
	function destroy()
	{

	} 

	var itemsServ =
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = itemsServ;

	});
/**
 * 理财--阅读协议
 */
define( function(require, exports, module)
	{	
	var service = require("mobileService"); //业务层接口，请求数据
	var appUtils = require('appUtils'),
	putils = require("putils"),
	layerUtils = require("layerUtils"),
	gconfig = require("gconfig"),
	global = gconfig.global;
	var _pageId ="#otc_protocol ";

	//1、初始化
	function init() 
	{	
		$(_pageId+".main").css("overflow-y","auto");
        var height_meau = $(window).height() - $(_pageId+".header").height() -10;
		$(_pageId+".main").height(height_meau); //查询目录添加高度
		
		var pageInParam=appUtils.getPageParam();
		var agreement_title=pageInParam.agreement_title;      //协议标题
		var agreement_id=pageInParam.agreement_id;      //协议标题
		var results=pageInParam.results;
		for (var i  =0; i < results.length; i++)
		{
			if(results[i].agreement_id==agreement_id)
			{
				$(_pageId+" .agreem_title").html(results[i].agreement_title); //展示协议标题
				$(_pageId+" .agreem_text").html(results[i].agreement_content);//展示协议内容
			}

		} 


	}
	//2、事件绑定
	function bindPageEvent()
	{	
		//点击 返回事件
		appUtils.bindEvent($(_pageId+" .icon_back"),function(){
			appUtils.pageBack();
		});

		//点击 关闭
		appUtils.bindEvent($(_pageId+" .login_btn_ok"),function(){	
			appUtils.pageBack();
		});
	}



	//3、销毁
	function destroy()
	{
		 
	}

	var protocol =
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = protocol;

	});
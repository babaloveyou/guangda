define(function(require, exports, module) {
	var appUtils = require('appUtils');
	var layerUtils = require("layerUtils");
	var gconfig = require("gconfig");
	var global = gconfig.global;
	var validatorUtil = require("validatorUtil");

	function filterLoginOut(data){
		if(data.error_no == "-999"){
			layerUtils.iMsg(-1,"由于长时间未操作，系统自动跳转到登入前首页！");
			appUtils.clearSStorage("_loginInPageCode");
			appUtils.clearSStorage("_loginInPageParam");
			appUtils.clearSStorage("_isLoginIn");
			appUtils.clearSStorage();
			$("#account_userLogin #trade_pwd").val('');//清除密码
			$("#account_userLogin #password em").html('');//清除密码
			
			appUtils.pageInit(appUtils.getSStorageInfo("_curPageCode"), "account/mainPage", {});
		}
	}

	//输入金额转化为中文大写
	function number2num1(strg)
	{
	   var number = Math.round(strg*100)/100;
	   number = number.toString(10).split('.');
	   var a = number[0];
	   if (a.length > 12)
	     return "数值超出范围！支持的最大数值为 999999999999.99";
	   var e = "零壹贰叁肆伍陆柒捌玖";
	   var num1 = "";
	   var len = a.length-1;
	   for (var i=0 ; i<=len; i++)
	    num1 += e.charAt(parseInt(a.charAt(i))) + [["圆","万","亿"][Math.floor((len-i)/4)],"拾","佰","仟"][(len-i)%4];
	   if(number.length==2 && number[1]!="")
	   {
	     var a = number[1];
	     for (var i=0 ; i<a.length; i++)
	      num1 += e.charAt(parseInt(a.charAt(i))) + ["角","分"][i]; 
	   }
	   num1 = num1.replace(/零佰|零拾|零仟|零角/g,"零");
	   num1 = num1.replace(/零{2,}/g,"零");
	   num1 = num1.replace(/零(?=圆|万|亿)/g,"");
	   num1 = num1.replace(/亿万/,"亿");
	   num1 = num1.replace(/^圆零?/,"");
	   if(num1!="" && !/分$/.test(num1))
	     num1 += "整";
	   return num1;
	}

	//判断输入的值是否合法
	function numberLimit(id){
		// 先把非数字的都替换掉，除了数字和.
		$(id).val($(id).val().replace(/[^\d.]/g, ""));
		// 必须保证第一个为数字而不是.
		$(id).val($(id).val().replace(/^\./g, ""));
		$(id).val($(id).val().replace(/^0+([1-9])/,"$1"));
		$(id).val($(id).val().replace(/^0+$/,"0"));
		// 保证只有出现一个.而没有多个.
		$(id).val($(id).val().replace(/\.{2,}/g, "."));
		// 保证.只出现一次，而不能出现两次以上
		$(id).val($(id).val().replace(".", "$#$").replace(/\./g, "").replace("$#$","."));
		//只能输入两个小数  
		$(id).val($(id).val().replace(/^(\-)*(\d+)\.(\d\d).*$/,'$1$2.$3'));
	}	
	function moneyFormat(mStr){//
		// 1先把非数字的都替换掉，除了数字和.2保证只有出现一个.而没有多个.3保证.只出现一次，而不能出现两次以上 4只能输入两个小数  
//		mStr = mStr.replace(/[^\d\.]/g,"").replace(/(\.\d{2}).+$/,"$1").replace(/^0+([1-9])/,"$1").replace(/^0+$/,"0");
		mStr = mStr.replace(/[^\d.]/g, "").replace(/^\./g, "").replace(/\.{2,}/g, ".").replace(/^0+([1-9])/,"$1").replace(/^0+$/,"0").replace(".", "$#$").replace(/\./g, "").replace("$#$",".").replace(/^(\-)*(\d+)\.(\d\d).*$/,'$1$2.$3');
		if(mStr=="0.00" || mStr==""){
			mStr = "0" ;
		}
		/*if(mStr.indexOf(".") < 0){
			return (mStr+".00") ;
		}else{
		}*/
		return mStr;
	}

	
	//判断风险等级
	function risk_level(pa)
	{
		var level=null;
		if(pa=="5")
		{
			return level="高";
		}else if(pa=="4")
		{
			return level="中高";
		}
		else if(pa=="3")
		{
			return level="中";
		}
		else if(pa=="2")
		{
			return level="中低";
		}
		else if(pa=="1")
		{
			return level="低";
		}
		
		else
		{
			return level="默认"	;
		}
	}


	// 判断开放状态
	function prstor(pa)
	{
		var c=null;

		if(pa=="0")
		{

			return  c="正常交易";
		}
		else if (pa=="1")
		{

			return  c="发行";
		}
		else  if(pa=="2")
		{

			return  c="发行成功";
		}
		else  if(pa=="3")
		{

			return c="发行失败";
		}
		else  if(pa=="4")
		{

			return c="停止交易";
		}
		else  if(pa=="5")
		{

			return c="停止申购";
		}

		else  if(pa=="6")
		{

			return c="停止赎回";
		}
		else if(pa=="7")
		{

			return c="权益登记";
		}
		else if(pa=="8")
		{

			return c="红利发放";
		}
		else if(pa=="9")
		{

			return c="基金封闭";
		}
		else if(pa=="10")
		{

			return c="基金终止";
		}

	}

	// 判断理财目标
	function  geuid (rt)
	{
		var t =null;
		if(rt=="1")
		{
			return  t="投资理财";

		}
		if(rt=="2")
		{
			return t="资产增值";
		}
		if(rt=="3")
		{
			return  t="投资理财&nbsp;资产增值";
		}

	}




	/**
	 * car 是否开放期
	 * @param product_status
	 */
	function checkProdStatus(product_status)
	{
		var flag = true;
		if(product_status=="3")
		{
			flag = false;
		}
		return flag;
	}


	/**
	 * car投资类型
	 * @param fund_type
	 */
	function tz_fund_type(rt)
	{
		var t =null;
		if(rt=="0")
		{
			return  t="股票型";

		}
		if(rt=="1")
		{
			return  t="混合型";

		}
		if(rt=="2")
		{
			return t="债券型";
		}
		if(rt=="3")
		{
			return  t="货币型";
		}
		if(rt=="4")
		{
			return t="保本型";
		}
		if(rt=="5")
		{
			return   t="QDII型";
		}
		else
		{
			return t="其他类型";
		}

	}
	/*产品订单状态*/
	function order_state(order_state)
	{
		var order_stateLabel =null;
		if(order_state == "1")
		{
			order_stateLabel ="已报";
		}
		else if(order_state == "0")
		{
			order_stateLabel ="未报";
		}else if(order_state == "2")
		{
			order_stateLabel ="确认";
		}
		else if(order_state == "3")
		{
			order_stateLabel ="部撤";
		}
		else if(order_state == "4")
		{
			order_stateLabel ="全撤";
		}
		else if(order_state == "5")
		{
			order_stateLabel ="部成";
		}
		else  if(order_state == "6")
		{
			order_stateLabel ="全成";
		}
		else  if(order_state == "7")
		{
			order_stateLabel ="废单";
		}else  if(order_state == "8")
		{
			order_stateLabel ="已报待撤";
		}else  if(order_state == "9")
		{
			order_stateLabel ="部成待撤";
		}else  if(order_state == "A")
		{
			order_stateLabel ="待撤销";
		}else  if(order_state == "B")
		{
			order_stateLabel ="TA确认";
		}else  if(order_state == "C")
		{
			order_stateLabel ="TA失败";
		}else  if(order_state == "D")
		{
			order_stateLabel ="待申报";
		}else  if(order_state == "E")
		{
			order_stateLabel ="对手拒绝";
		}else  if(order_state == "N")
		{
			order_stateLabel ="新建";
		}else  if(order_state == "S")
		{
			order_stateLabel ="提交成功";
		}else  if(order_state == "Q")
		{
			order_stateLabel ="取消支付";
		}else  if(order_state == "L")
		{
			order_stateLabel ="提交失败";
		}
		return order_stateLabel;
	}
	
	/*产品订单状态*/
	function product_type(inst_type)
	{
		var inst_typeLabel =null;
		if(inst_type == "1")
		{
			inst_typeLabel ="股票";
		}
		else if(inst_type == "2")
		{
			inst_typeLabel ="衍生品";
		}
		else if(inst_type == "3")
		{
			inst_typeLabel ="商品";
		}
		else if(inst_type == "4")
		{
			inst_typeLabel ="外汇";
		}
		else if(inst_type == "5")
		{
			inst_typeLabel ="信托";
		}
		else  if(inst_type == "6")
		{
			inst_typeLabel ="券商理财";
		}
		else  if(inst_type == "7")
		{
			inst_typeLabel ="公募基金";
		}else  if(inst_type == "8")
		{
			inst_typeLabel ="有限合伙基金";
		}else  if(inst_type == "9")
		{
			inst_typeLabel ="银行理财";
		}else  if(inst_type == "A")
		{
			inst_typeLabel ="保险理财";
		}else  if(inst_type == "B")
		{
			inst_typeLabel ="债券";
		}else  if(inst_type == "C")
		{
			inst_typeLabel ="基金子公司专户";
		}else  if(inst_type == "D")
		{
			inst_typeLabel ="资讯产品";
		}else  if(inst_type == "E")
		{
			inst_typeLabel ="收益凭证";
		}
		
		return inst_typeLabel;
	}
	
	
	/**
	 * 自定义确认框
	 * @param layerMsg 确认框的内容
	 * @param oneText 第一个按钮按钮的文本内容
	 * @param twoText 第二个按钮的文本内容
	 * @param funcOne 第一个按钮的回调函数
	 * @param funcTwo 第二个按钮的回调函数
	 */
	function layerTwoButton(layerMsg,oneText,twoText,funcOne,funcTwo){
		var viewContent = '<div class="pop_tip notice" id="utils_confirm"><span class="icon"></span><p style="text-align:left">'+layerMsg+'</p><div class="btn"><a href="javascript:void(0);" id="utils_confirm_one">'+oneText+'</a><a href="javascript:void(0);" id="utils_confirm_two">'+twoText+'</a></div></div>';
		var iConfirm = layerUtils.layerCustom(viewContent);
		appUtils.preBindEvent($("#utils_confirm")," #utils_confirm_one",function(){
			if(funcOne)
			{
				funcOne();
			}
			layerUtils.iCustomClose();
		});
		appUtils.preBindEvent($("#utils_confirm")," #utils_confirm_two",function(){
			if(funcTwo)
			{
				funcTwo();
			}
			layerUtils.iCustomClose();
		});
	}



	var putils = {
		"layerTwoButton" : layerTwoButton,
		"checkProdStatus": checkProdStatus,
		"prstor":prstor,
		"geuid":geuid,
		"order_state":order_state,
		"risk_level":risk_level,
		"numberLimit":numberLimit,
		"tz_fund_type":tz_fund_type,
		"moneyFormat":moneyFormat,
		"product_type":product_type,
		"number2num1":number2num1,
		"filterLoginOut": filterLoginOut
	};


	//暴露对外的接口
	module.exports = putils;
});
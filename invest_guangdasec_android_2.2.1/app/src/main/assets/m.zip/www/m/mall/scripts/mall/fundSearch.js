/**
 * 资讯详情
 */
define(function(require, exports, module)
	{	
	var service = require("mobileService"); //业务层接口，请求数据
	var appUtils = require('appUtils');
	var putils = require("putils");
	var layerUtils = require("layerUtils");
	var gconfig = require("gconfig");
	var global = gconfig.global;
	var _pageId ="#mall_fundSearch";
	var product_id=null;
	var product_status="";
	var  product_sub_type="" ; // 0 基金 1理财 2咨询
	
	//1、初始化
	function init() 
	{
		product_sub_type=appUtils.getPageParam("product_sub_type");
		$(_pageId+" .search_txt").val("");
		$(_pageId+" .search_list ul").html("");
	}
	
	//2、事件绑定
	function bindPageEvent()
	{
		//点击 返回
		appUtils.bindEvent($(_pageId+" .icon_back"),function(){
			appUtils.pageBack();
			});
		
		//点击 删除
		appUtils.bindEvent($(_pageId+" .close-btn"),function(){
			$(_pageId+" .search_txt").val("");
			$(_pageId+" .search_list ul").html("");
			});
		
		//产品搜索 获取光标和输入发生改变的时候处理事件 
		appUtils.bindEvent(_pageId+" .search_txt",function(){
			var key = $(_pageId+" .search_txt").val();
			// 当搜索框里面有值的时候然后去查询产品
			if(key){
				// 不为空时进行搜索   不显示加载圈
				fundSearch(false,key);	
			}else{
				// 为空时清除搜索结果
				$(_pageId+" .search_list ul").html("");
			}	
		},"input");
		
		//点击搜索图标  进行搜索处理
		appUtils.bindEvent($(_pageId+" .icon_search"),function(){
			if(($(_pageId+" .search_txt").val())){
				var key = $(_pageId+" .search_txt").val();
				// 不为空时进行搜索 显示加载圈
				fundSearch(true,key); //false
			}
		});
	}
	
	//搜索接口  搜索对应模糊匹配产品
	function  fundSearch(isShowWait,key){
		// 取到文本搜索值 key
		var productCode = "";
		var productName = "";
		// 纯数字就是code 搜索 否则名称搜索
		if(isNaN(key)){
		    productName =key;
		}else{
			productCode =key;
		}
		// 接受参数
		var param={
				"product_code":productCode,
				"product_name":productName,
				"product_shelf":"",
				"product_sub_type":product_sub_type
		};
		service.queryFundList(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result = data.results;
			if(key != ($(_pageId+" .search_txt").val()))  return ; // 保证搜索为最新结果集
			if(error_no == "0")
			{
				// 搜索结果 展示
				fundListData = result;
				// 拼接展示页面结果集
				var fundListDataStr = "";
				// 搜索结果集有值时 循环取值
				if(fundListData.length > 0 && fundListData){
					for(var i=0,len=fundListData.length; i<len; i++)
					{
						var item = fundListData[i];
						var product_code = item.product_code;
						var product_name = item.product_name;
						fundListDataStr += '<li><a href="javascript:void(0);"  product_name='+item.product_name+' product_id='+item.product_id+'>'+item.product_code+'<em>'+item.product_name+'</em></a></li>';
					}
				}else{
					fundListDataStr += '<li><a href="javascript:void(0);" product_type="false"> <em>很抱歉!没有搜索到您想要的产品</em></a></li>';
				}
				// 页面添加搜索结果
				$(_pageId+" .search_list ul").html(fundListDataStr);
				
				/*选中值赋给选择框*/
				appUtils.bindEvent($(_pageId+" .search_list ul li a"),function(){
				    var product_id = $(this).attr("product_id");
				    var product_name = $(this).attr("product_name");
				    var product_type = $(this).attr("product_type");
				    // 当结果为空时 点击无效
				    if(product_type == "false") return ;
					$(_pageId+" .search_txt").val(product_name);	  //选中值赋给选择框
					var pageInParam = {
							"product_id" :product_id,
							"product_status":product_status,
					};
					if(product_sub_type == "1"){
						appUtils.pageInit("mall/fundSearch", "mall/itemsFinanInfo",pageInParam);	
					}else if(product_sub_type == "0"){
						appUtils.pageInit("mall/fundSearch", "mall/itemsFundInfo",pageInParam);	
					}else if(product_sub_type == "2"){
						appUtils.pageInit("mall/fundSearch", "mall/itemsInfoDetail",pageInParam);	
					}
				});
			
			}
			else
			{
				layerUtils.iAlert(error_info);
			}
		},{"isShowWait" : isShowWait});// 不显示加载圈
	
	}
	
	//3、销毁
	function destroy()
	{
		
	}

	var fundSearchInfo =
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = fundSearchInfo;

	});
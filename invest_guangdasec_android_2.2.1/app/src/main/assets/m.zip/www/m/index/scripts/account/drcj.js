/**
 * 当日成交金额查询
 */
define(function(require, exports, module){
	/*模块内部全局变量*/
	var appUtils = require("appUtils"),
		layerUtils = require("layerUtils"),
		gconfig = require("gconfig"),
		global = gconfig.global,
		service = require("serviceImp"),  //业务层接口，请求数据
		_pageId = "#account_drcj ";
	
	/*页面初始化方法*/
	function init()
	{
		$(_pageId+" .hold_main").html("");
		todayTrade(); // 查询我的今日成交
	}
	
	/*绑定页面事件的方法*/
	function bindPageEvent()
	{
		/*返回*/
		appUtils.bindEvent($(_pageId+" .icon_back"), function(e){
			appUtils.pageBack();
			e.stopPropagation();
		});
	}
	/*页面销毁方法*/
	function destroy()
	{
		service.destroy();
	}
	
	/* 查询当日成交 */
	function todayTrade()
	{
		var entrust_way = "SJWT";
		var branch_no = appUtils.getSStorageInfo("branch_no");
		var fund_account = appUtils.getSStorageInfo("fund_account");
		var cust_code = appUtils.getSStorageInfo("client_no");
		var param = {
			"entrust_way":entrust_way,
			"branch_no":branch_no,
			"fund_account":fund_account,
			"cust_code":cust_code,
		};
		service.queryTodayTrade(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var res = data.results;
			if(error_no == "0" && res != undefined)
			{
				var len = res.length;
				$(_pageId+".len").html("("+len+")");
				var shtml = "";
				if(len == 0){
					shtml = "<ul class='hold_info clearfix'><li style='width:100%;text-align:center'>暂无数据</li></ul>";
				}
				for(var i = 0; i<len; i++)
				{
					var stock_name = res[i].stock_name; // 股票名
					var stock_code = res[i].stock_code; // 股票代码
					var entrust_no = res[i].entrust_no; // 成交编号
					var business_date = res[i].business_date; // 成交日期
					var business_time = res[i].business_time; // 成交时间
					var business_price = Number(res[i].business_price).toFixed(2); // 成交价格
					var business_amount = res[i].business_amount; // 成交数量
					var business_balance = Number(res[i].business_balance).toFixed(2); // 成交金额
					var entrust_type = res[i].entrust_type; // 成交状态
					var entrust_bs = res[i].entrust_bs == 0?"买入":"卖出"; // 买卖标志
					shtml += "<ul class='hold_info clearfix'>";
					shtml += "<li><strong>"+stock_name+"<small>（"+stock_code+"）</small></strong></li>";
					shtml += "<li><span>成交编号：</span>"+entrust_no+"</li>";
					shtml += "<li><span>成交日期：</span>"+business_date+"</li>";
					shtml += "<li><span>成交时间：</span>"+business_time+"</li>";
					shtml += "<li><span>成交价格：</span>"+business_price+"</li>";
					shtml += "<li><span>成交数量：</span>"+business_amount+"</li>";
					shtml += "<li><span>成交金额：</span>"+business_balance+"</li>";
					shtml += "<li><span>成交状态：</span>"+entrust_type+"</li>";
					shtml += "<li><span>买卖标志：</span>"+entrust_bs+"</li>";
					shtml += "</ul>";
				}
				$(_pageId+" .hold_main").html(shtml);
			}
			else
			{
				layerUtils.iAlert(error_info);
			}
		});
	}
	
	/*向外暴露的 JSON 对象*/
	var drcj = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	
	/*对外暴露 JSON 对象*/
	module.exports = drcj;
});
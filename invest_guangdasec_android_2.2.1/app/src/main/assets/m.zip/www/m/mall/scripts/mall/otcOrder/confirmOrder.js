/**
 *OTC--确认订单
 */
define(function(require, exports, module)
	{	
	var service = require("mobileService");//业务层接口，请求数据
	var appUtils = require('appUtils'),
//	var orderUtil = require('orderUtil'),
	putils = require("putils"),
	dics = require("dics"),
	layerUtils = require("layerUtils"),
	constants=require("constants");//常量类
	var gconfig = require("gconfig");
    var global = gconfig.global;
    platform=gconfig.platform;
	var save_value= null;
	var save_Agreement=null;
	var _pageId ="#mall_otcOrder_confirmOrder ";
	var risk_level=null;//保存产品风险等级
	var product_code=""; 
	var fund_result=null; 
	var buy_limit = 0 ;  //限购起点
	var URL=global.url;
	var contractFlag = true;
	nativePluginService = require("nativePluginService");
	var product_status = "0"; // 产品状态测试赋值0.之后删除
	var entrust_way="";//委托方式
	var tran_type="";//类别
	var ec_effect_flag="";
	var inst_id="";//产品ID
	var is_buysuperrisk="";//是否可以超风险购买
	var trd_amt="";//购买金额
	var url="";//协议地址
	var contract_not=[];//未签署协议
	var paramConfirmOrder = null;
	var _ta_name="";
	var _ta_code="";
	var _length="";
	var jg_org="";
	var pro_code_xjb="";

	//1、初始化
	function init() 
	{	
		jg_org=appUtils.getSStorageInfo("int_org");
		contractFlag = true;
		contract_not=[];//未签署协议
		$(_pageId+" #buyMoney").focus();
		paramConfirmOrder = JSON.parse(appUtils.getSStorageInfo("paramConfirmOrder"));
		appUtils.clearSStorage("paramConfirmOrder");
		var pageInParam  = appUtils.getPageParam();
		var product_name = "";
		var product_id = "";
		var tot_price = "";
		var product_code = "";
		if(pageInParam != null && pageInParam != ""){
			product_name= pageInParam.product_name;
			product_id=pageInParam.product_id;
			tot_price=pageInParam.tot_price;
			product_code=pageInParam.product_code;
		}else if(paramConfirmOrder != null && paramConfirmOrder != ""){
			product_name= paramConfirmOrder.product_name;
			product_id=paramConfirmOrder.product_id;
			tot_price=paramConfirmOrder.tot_price;
			product_code=paramConfirmOrder.product_code;
		}else{
			layerUtils.iAlert("未获取到相应的产品信息!");
			layerUtils.iLoading(false);
			return;
		}
		
		
		var product_id=pageInParam.product_id;
		//防止直接到该页面
		if(product_id==null)
		{
			layerUtils.iMsg(1, "数据加载错误！");
			appUtils.pageInit("mall/otcOrder/confirmOrder","account/mainPage",{});
			return false;
		}
		//查询otc单个信息
	    findByid();
	    //查询现金宝电子合同
	    queryxjb_pro();
	    	
	}
	//查询现金宝电子合同
	function queryxjb_pro(){
		var param={};
		service.queryxjb_pros(param,function(data){
		var error_no = data.error_no;
		if(error_no == "0"){
			var results = data.results;
			pro_code_xjb=results[0].pro_code_ht;
		}else{
			//未查询到则不会影响购买
			pro_code_xjb="863001";
		}
	});
	}
	
	// 200003：OTC交易账户信息查询
	function otcTradeAccoInfo(){
		var cust_code=appUtils.getSStorageInfo("cust_code");
		var ta_code =$(_pageId+" #ta_code").val();
		var ticket=appUtils.getSStorageInfo("ticket");
		var param={
			"cust_code" : cust_code,
			"ta_code" : ta_code,
			"ticket" : ticket
		};

		/*查询是否有交易账户*/
		service.otcTradeAccoInfo(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			if(error_no == "0"){
				var results = data.results;
//				var int_org=results[0].results;
				
//				var pageInParam  = appUtils.getPageParam();
//				var int_org="";
//			    int_org=pageInParam.int_org;
				if (results && results.length > 0) {
					is_buysuperrisk = results[0].is_buysuperrisk;//是否允许超风险购买。。。0表示不允许，1表示允许
					ec_effect_flag = results[0].ec_effect_flag;//0电子合同只需要签署一次,1每次都签署
					var otctradeflag = results[0].otctradeflag;
					if(otctradeflag == "1"){//这是有交易账户的逻辑
						if (contract_not.length > 0) {
							//500005签署未签合同
							signUndoneAgreement();
						} else { 
							appropriateMatch();//第二次匹配
						}
					}else{
						/*if(ta_code == 'EB'){
							layerUtils.iConfirm("此产品是光行产品，您需先临柜办理开户业务!",function(){
								layerUtils.iLoading(false);
							},function(){
								layerUtils.iLoading(false);
							});	
							//光行产品	
							$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
					     }else if(ta_code == 'CIB'){
					    	 layerUtils.iConfirm("此产品是兴业银行产品，您需先临柜办理开户业务!",function(){
									layerUtils.iLoading(false);
								},function(){
									layerUtils.iLoading(false);
								});	
								//光行产品	
								$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
*/								
								
								var flag=true;
//								var _ta_name=configuration.ta_name;
//								var _ta_code=configuration.ta_code;
//									_ta_name=_ta_name.split("|");
//									_ta_code=_ta_code.split("|");
								var length=_ta_code.length;
									for(var i=0; i<length;i++){
										if(ta_code==_ta_code[i]){
											flag=false;
											layerUtils.iLoading(false);
											$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
											layerUtils.iConfirm("此产品是"+_ta_name[i]+"产品，您需要临柜办理开户业务", function(){
											});
										}
									}
					     } 
					if(flag){
					    	 newRiskResult(function(data){
					    		 var results = data.results;
					    		 if (!results || results[0].is_overtime == "1") {
					    			 layerUtils.iAlert("您未做风险测评或风险测评过期!");
					    			 layerUtils.iLoading(false);
					    		 } else {
					    			 var user_type = appUtils.getSStorageInfo("user_type");
					    			 if (user_type == "1") {
					    				 layerUtils.iAlert("您还未开通产品账户，请先临柜办理账户开通业务");
					    				 layerUtils.iLoading(false);
					    			 } else {
					    				 otcTradeOpenAcco();//区开交易户
					    			 }
					    		 }
					    	 }, {"isLastReq" : false});
					     }			
				
				} else {
					layerUtils.iLoading(false);
					return false;
				}
			}else{
				layerUtils.iAlert(error_info);
				layerUtils.iLoading(false);
				return false;
			}
		}, {"isLastReq" : false});
	}
	
	
	//开通OTC交易账户(300025)	
	function otcTradeOpenAcco(){
		var pageInParam  = appUtils.getPageParam();
		var cust_code=appUtils.getSStorageInfo("cust_code");
		var ticket=appUtils.getSStorageInfo("ticket");
		var ta_code =$(_pageId+" #ta_code").val();
		var pageInParam  = appUtils.getPageParam();
		var cuacct_code = "";
		var pageInParam  = appUtils.getPageParam();
		if(pageInParam != null && pageInParam != ""){
			cuacct_code=pageInParam.cuacct_code;
		}else if(paramConfirmOrder != null && paramConfirmOrder != ""){
			cuacct_code=paramConfirmOrder.cuacct_code;
		}
		var param={
				"cust_code" : cust_code,
				"dft_cuacct_code" : cuacct_code,
				"int_org" : jg_org,
				"ta_code" : ta_code,
				"ticket" : ticket
		};
		service.otcTradeOpenAcco(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var results = data.results;
			if(error_no == "0" && results.length != 0){
				if (contract_not.length > 0) {
					//500005签署未签合同
					signUndoneAgreement();
				} else { 
					appropriateMatch();//第二次匹配
				}
			}else{
				layerUtils.iAlert(error_info);
				layerUtils.iLoading(false);
				return false;
			}
		}, {"isLastReq" : false});
	}

	//查询otc单个信息
	function findByid()
	{
//		var pageInParam  = appUtils.getPageParam();
//		var product_id=pageInParam.product_id;
		var product_id = "";
		var pageInParam  = appUtils.getPageParam();
		if(pageInParam != null && pageInParam != ""){
			product_id=pageInParam.product_id;
		}else if(paramConfirmOrder != null && paramConfirmOrder != ""){
			product_id= paramConfirmOrder.product_id;
		}
		var param  ={
			"product_id":product_id
		};
		service.OTCInfo(param,function(data){//2000003：根据产品id查询otc理财产品信息
			if(data.error_no=="0")
			{
				var result = data.results[0];
				var ta_code = result.ta_code;//登记机构
				 inst_id = result.inst_id;//产品编码
				var iss_code = result.iss_code;//发行人代码
				var inst_code = result.inst_code;//产品代码
				var inst_sname= result.inst_sname;//产品名称
				var ent_buy_limit=result.ent_buy_limit; //起投金额
				var risk_lvl=result.risk_lvl;//风险等级
				var last_net=result.last_net;//最新净值
				var ent_add_buy=result.ent_add_buy;//追加金额
				var ec_effect_flag = result.ec_effect_flag; 
				
				if(ent_add_buy == ""){
					ent_add_buy = "0";
				}
				if(inst_sname.length > 12){
					$(_pageId+" #product_name").css("font-size","12px");
				}
				$(_pageId+" #ta_code").val(ta_code);
				$(_pageId+" #inst_id").val(inst_id);
				$(_pageId+" #inst_code").val(inst_code);
				$(_pageId+" #iss_code").val(iss_code);
				$(_pageId+" #add_buy").val(ent_add_buy);
				$(_pageId+" #product_name").html(inst_sname);
				$(_pageId+" #last_net").html(last_net);
				$(_pageId+" #ent_add_buy").html("￥"+ent_add_buy);
//				$(_pageId+" #buyMoney").val(ent_buy_limit);
//				$(_pageId+" #payMoney").html("￥"+ent_buy_limit);
//				$(_pageId+" #maxMoney").html(putils.number2num1(ent_buy_limit));
				otcTrdId();
				bank_pro();//查兴业银行
			}else{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
		},{"isLastReq":false});
	}
	//得到产品trans_type(300041)
	function otcTrdId(){
//		var pageInParam  = appUtils.getPageParam();
//		var product_id=pageInParam.product_id;
		var product_id = "";
		var pageInParam  = appUtils.getPageParam();
		if(pageInParam != null && pageInParam != ""){
			product_id=pageInParam.product_id;
		}else if(paramConfirmOrder != null && paramConfirmOrder != ""){
			product_id= paramConfirmOrder.product_id;
		}
		var ticket = appUtils.getSStorageInfo("ticket");
		var param =
		{
			"product_id" : product_id,
			"ticket" : ticket
		}
		service.buyRight(param,function(data)
		{
			if(data.error_no != "0") 
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
			var perData=data.results;
			var	trd_id=perData[0].trd_id;
			tran_type=trd_id;
	
			otcfindAgreement(tran_type);//展示协议
			return false;
		},{"isLastReq":false});
	}
	//产品所属协议查询展示(1有 0没有)(500011)
	function  otcfindAgreement(tran_type)
	{
//		var pageInParam  = appUtils.getPageParam();
//		var product_id=pageInParam.product_id;
		
		var flag = true ;		  // 签署协议标识，true 为已签署
		var _agreement_id;
		var _agreement_title;
		var results=null; //保存结果集
		
		var param =
		{
			//"product_id":product_id
			"tran_type" : tran_type,
			"inst_id" : inst_id,
			"entrust_way" : entrust_way
		};

		service.showSign(param,function(data)
		{
			if(data.error_no != "0") 
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
			var results= data.results;
			allProtocolStr = ""; // 所有协议字符串
			var flag = false;
			if (results.length > 0) {
				var perData=data.results;
				var pro_code = perData[0].pro_code;
				var count = 0;//检查是否设置有多条电子合同
				var attach_type = "";
				var pro_code_ht="";
				for (var i = 0; i < results.length; i++) {
					var item  = results[i];
					pro_code = item.pro_code; // 协议编号
					allProtocolStr += '<li id="agreement_id"><a file_name="'+item.file_name+'" pro_code="'+pro_code+'" href="javascript:void(0);" agreement_id='+item.file_id+  ' pro_code='+item.pro_code+'>'+item.pro_title+'</a></li>';
					$(_pageId+" #agreement").html(allProtocolStr);
					if(results[i].pro_type === '3'){//电子合同  
						if(results[i].pro_code !==pro_code_xjb ){//剔除现金宝合同
						count++;
						pro_code_ht = results[i].pro_code;
						attach_type = results[i].attach_type;
						}
					}
				}
				if(count !== 1){
					$(".c1").removeAttr("checked");
					$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
					layerUtils.iAlert("电子合同配置有误("+count+"条)");
					layerUtils.iLoading(false);
				} else {
					newRiskResult(function(data){
						var results = data.results;
						//!results || results[0].is_overtime == "1"
						if(!results || results[0].is_overtime == "1"){
//							var pageInParam  = appUtils.getPageParam();
							var product_id = "";
							var tot_price = "";
							var product_name = "";
							var pageInParam  = appUtils.getPageParam();
							if(pageInParam != null && pageInParam != ""){
								tot_price=pageInParam.tot_price;
								product_name=pageInParam.product_name;
								product_id=pageInParam.product_id;
							}else if(paramConfirmOrder != null && paramConfirmOrder != ""){
								tot_price=paramConfirmOrder.tot_price;
								product_name=paramConfirmOrder.product_name;
								product_id=paramConfirmOrder.product_id;
							}
					    	var product_name= pageInParam.product_name;
						    var product_id=pageInParam.product_id;
						    var tot_price=pageInParam.tot_price;
						    pageInParam.inst_id = inst_id;
						    pageInParam.product_code = product_code;
							
							var tipMsg = "您还未做风险测评，请进行风险测评";
							if (results) {
								tipMsg = "您的风险测评已过期，请重新测评";
							}
							layerUtils.iConfirm(tipMsg, function(){
								appUtils.pageInit("mall/otcOrder/confirmOrder","otc/riskAssessment", pageInParam);
							},function(){});
						} else {
							// 第一次适当性匹配
							checkOrderSubmit(pro_code_ht,attach_type,results);
						}
					}, {"isLastReq" : false});
				}
				
				//绑定协议事件
				appUtils.bindEvent($(_pageId+" #agreement_id a"),function(){
					var perData=data.results;
					var pro_content = $(this).attr("agreement_id"); // 协议ID
					pro_code = $(this).attr("pro_code"); // 协议编号					
					var pro_title= $(this).attr("file_name"); // 协议名称	
					// 调用查询协议内容500009
					var reqParam = {
						"pro_content" : pro_content,
						"pro_code" : pro_code,
						"file_name" : pro_title,
						"entrust_way" : entrust_way
					};
					service.agreementContent(reqParam,function(data){
						if(data.error_no!="0")
						{
							layerUtils.iAlert(data.error_info);
							layerUtils.iLoading(false);
							return false;
						}
						var perData=data.results;
						if(perData){
							var pdf_url = perData[0].pdf_url; // 协议地址
							url=pdf_url;//
							var param = {
								"url" : pdf_url
							}
							lookContract(param);
							return false;
						}
					});
				});
			}else {
				$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
				layerUtils.iMsg(-1,"该产品还未配置协议");
				$(".c1").removeAttr("checked");
				layerUtils.iLoading(false);
			}
		},{"isLastReq":false});
	}

	
	/**
	 * 查看协议(文本，pdf)
	 * 1、查看存在文件路径的协议时，调用原生接口，如pdf协议。
	 * 2、查看不存在文件路径且指定了目标页面的协议时，跳转到指定页面并把相关协议内容在参数中传递过去。
	 */
	function lookContract(param, targetPage){
		var _curPageCode = appUtils.getSStorageInfo("_curPageCode"); //当前页 pageCode
		if(param.url == ""){
			var pageInParam = {
				"data" : param.result
			};
			if (targetPage) {
				appUtils.pageInit(_curPageCode, targetPage, pageInParam);
			}
		}else{
			var path = gconfig.global.url + "/" + param.url;
			var invokeParam = {
				"funcNo" : "50240",
				"url" : path
		    };
			var result = nativePluginService.function50240(invokeParam);
		}
	}
	/**
     * 500004：客户已经签署的协议查询
     * 
     */
	function querySingedAgreement(pro_code,attach_type){	
		var checkType="";
		var cust_code=appUtils.getSStorageInfo("cust_code");
		var ticket=appUtils.getSStorageInfo("ticket");
		var param = {
			"cust_code":cust_code,
			"pro_type":"3",
			"pro_code":pro_code,
			"ticket":ticket
		};
		service.querySingedAgreement(param, function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			if (error_no == "0") {
				var results = data.results;
				if(attach_type == "0"){//临柜
					if (results.length == 0) {
						$(_pageId+" #tjdd").attr("style","background-color:#cfcfcf").unbind();
						layerUtils.iAlert("尊敬的投资者：该产品仅限临柜签署产品相关文件后购买，详请咨询您开户营业部。");
						contractFlag = false;
						$(_pageId+" .icon_check2 .c1").removeAttr("checked");
						layerUtils.iLoading(false);
					}else{
						for (var i = 0; i < results.length; i++) {
							var the_type = [];
							the_type.push(results[i].sign_type);
							if((the_type.join(",")).indexOf("0") == -1){//不包含
								layerUtils.iAlert("尊敬的投资者：该产品仅限临柜签署产品相关文件后购买，详请咨询您开户营业部。");
								$(_pageId+" #tjdd").attr("style","background-color:#cfcfcf").unbind();
								layerUtils.iLoading(false);
								return;
							}else{
								if(results[0].over_date == "1"){ //表示已经过期
									layerUtils.iAlert("尊敬的投资者：该产品仅限临柜签署产品相关文件后购买，详请咨询您开户营业部。");
									$(_pageId+" #tjdd").attr("style","background-color:#cfcfcf").unbind();
									layerUtils.iLoading(false);
									return;
								}
							}
						}
						
						var over_date=results[0].over_date;
						if(over_date=="0"){
							if(ec_effect_flag=="1"){
								$(_pageId+" .icon_check2 .c1").removeAttr("checked");
							}else{
								$(_pageId+" .icon_check2 .c1").attr("checked", "checked");//电子合同签署且一次签署下次不再签勾上协议
							}
						}else{
							$(_pageId+" .icon_check2 .c1").removeAttr("checked");	
						}
					}
				} else {
					if (results.length == 0) {
						$(_pageId+" .icon_check2 .c1").removeAttr("checked");
					}else{
						var over_date=results[0].over_date;
						if(over_date=="0"){
							if(ec_effect_flag=="1"){
								$(_pageId+" .icon_check2 .c1").removeAttr("checked");
							}else{
								$(_pageId+" .icon_check2 .c1").attr("checked", "checked");//电子合同签署且一次签署下次不再签勾上协议
							}
						}else{
							$(_pageId+" .icon_check2 .c1").removeAttr("checked");	
						}
					}
				}
			} else {
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
			}
		});
	}
	//客户风险查询(500003)
	function newRiskResult(callBack, reqParam){
		var cust_code = appUtils.getSStorageInfo("cust_code");
		var user_type=appUtils.getSStorageInfo("user_type");
		var ticket = appUtils.getSStorageInfo("ticket");
		//survey_sn 个人是1001机构是1002
		var survey_sn = user_type == "1" ? "1002" : "1001";
		var param = {
			"cust_code":cust_code,
			"survey_sn":survey_sn,
			"ticket":ticket
		};  		
		service.newRiskResult(param, function(data){
			if (data.error_no == "0") {
				callBack(data);
			} else {
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
			}
		}, reqParam);		
	}
	
	/*
	 *第一次适当性匹配(500006)
	 */
	function checkOrderSubmit(pro_code,attach_type,results){
		var cust_code = appUtils.getSStorageInfo("cust_code");
		var fund_account  = appUtils.getSStorageInfo("fund_account");
		var pageInParam  = appUtils.getPageParam();
		var order_id=null;
		var ticket = appUtils.getSStorageInfo("ticket");
		var param =
		{
			"cust_code":cust_code,
			"tran_type":tran_type,   
			"ticket":ticket,
			"inst_id" : inst_id,
//			"fund_account" : fund_account,
			"entrust_way" : entrust_way
		};
		service.appropriateMatch(param,function(data){
			if(data.error_no!="0") {
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
			var perData = data.results;
			if(perData.length != 0){
				var match_rs = perData[0].match_rs; //匹配结果集
				match_rs = $.parseJSON(match_rs);
				var not_match_rs = perData[0].not_match_rs; // 不匹配结果集
				not_match_rs = $.parseJSON(not_match_rs);
	//			console.log(not_match_rs);
				var leng = not_match_rs.length;	
				var flagPersonOrOrgan=true;//判断本产品是否匹配购买类型,个人或机构
				var flagRisk=false;//判断是否风测
				var flagProduct=false;//是否需要做产品问卷标识
				var product_survey = "";//产品问卷调查编码
				var flagAppend=false;//是否需要做附加题标识
				var _otherQuestion=[];//其他类型问卷调查的编码集
				if(perData[0].rs_code == '0'){//0不匹配,1匹配
					for (var l = 0; l < not_match_rs.length; l++) {
						//表明是客户类型参数,并且客户的类型和产品的购买类型不匹配,如果不匹配,则程序不需要再继续
						var item = not_match_rs[l];
						if(item.FLD_NAME == "CUST_TYPE" && item.FUND_NO == global.appro_cust){
							flagPersonOrOrgan=false;
							break;
						}
					}
					if(flagPersonOrOrgan){
					var user_type = appUtils.getSStorageInfo("user_type");
	                    for(var i=0;i<leng;i++){
	                    	//2016年6月25日增加登记机构交易状态不正常或未开户
	                    	if(not_match_rs[i].FUND_NO === global.organization_mark){
	                    		var organization=not_match_rs[i].FLD_VAL;
	                    		layerUtils.iConfirm(organization+"登记机构交易状态不正常或未开户",function() {
	                    			layerUtils.iLoading(false);
                					$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
	            				});
	                			return;
	                    	}else if(not_match_rs[i].FUND_NO === global.contract_mark_xjb &&not_match_rs[i].FLD_VAL === pro_code_xjb ){
	                    		layerUtils.iConfirm("请先签署光大阳光现金宝集合资产管理计划合同",function() {
	                    			layerUtils.iLoading(false);
                					$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
	            				});
	                			return;
	                    	}
	                        //判断有没有调查问卷
	                        if(not_match_rs[i].SURVEY_CODE && (not_match_rs[i].SURVEY_CODE).indexOf("205") > -1){//问卷调查
	                            if(not_match_rs[i].FUND_NO == global.appro_risk || not_match_rs[i].FUND_NO == global.appro_ques){//需要问卷调查
                    				var param = appUtils.getPageParam() || {};
                    				param.survey_sn = not_match_rs[i].FLD_NAME;
	                            	if(user_type === '0' && not_match_rs[i].CUST_TYPE === '0'){//个人问卷调查
	                    				layerUtils.iConfirm("您未做调查问卷，请做调查问卷!",function() {
	                    					appUtils.pageInit("mall/otcOrder/confirmOrder","mall/otcOrder/knowledgeQuestionnaire",param);
	                    				},function(){
	                    					layerUtils.iLoading(false);
	                    					$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
	                    				})
	                                	return false;
	                                }else if(user_type == '1' && not_match_rs[i].CUST_TYPE == '1'){//机构问卷调查
	                    				layerUtils.iConfirm("您未做调查问卷，请做调查问卷!",function() {
	                    					appUtils.pageInit("mall/otcOrder/confirmOrder","mall/otcOrder/knowledgeQuestionnaire",param);
	                    				},function(){
	                    					layerUtils.iLoading(false);
	                    					$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
	                    				})
	                                	return false;
	                                }else if(not_match_rs[i].CUST_TYPE==""){//通用问卷调查,值为空
	                    				layerUtils.iConfirm("您未做调查问卷，请做调查问卷!",function() {
	                    					appUtils.pageInit("mall/otcOrder/confirmOrder","mall/otcOrder/knowledgeQuestionnaire",param);
	                    				},function(){
	                    					layerUtils.iLoading(false);
	                    					$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
	                    				})
	                                	return false;
	                                }
	                            }
	                        }//附加題
							else if(not_match_rs[i].FUND_NO === global.appro_append && not_match_rs[i].REL_OPERATOR == 'AND'){//完全匹配
								flagAppend=true;
								
	                        }else if(not_match_rs[i].FUND_NO === global.appro_append && not_match_rs[i].REL_OPERATOR == 'OR'){//做过就可以
	                        	if(not_match_rs[i].CUST_RS==""){
	                        		flagAppend=true;
	                        	}
	                      
	                        //外部其他问卷
	                        }else if(not_match_rs[i].FUND_NO == global.appro_risk || not_match_rs[i].FUND_NO == global.appro_ques){
	                        	var survey_attr = (not_match_rs[i].SURVEY_CODE).substring(0,3) ;
	                        	//剔除附加题,风测,产品问卷的其他问卷
	                        	if(survey_attr && survey_attr !== "201" && survey_attr !== "205"){
	                                if(user_type === '0' && not_match_rs[i].CUST_TYPE === '0'){//个人问卷调查
	                                	_otherQuestion.push(not_match_rs[i].FLD_NAME);
	                                }else if(user_type === '1' && not_match_rs[i].CUST_TYPE === '1'){//机构问卷调查
	                                	_otherQuestion.push(not_match_rs[i].FLD_NAME);
	                                }else if(not_match_rs[i].CUST_TYPE===""){//通用问卷调查,值为空
	                                	_otherQuestion.push(not_match_rs[i].FLD_NAME);
	                                }
	                        	}
	                        }
	                        //判断协议是否签署
	                        else if(not_match_rs[i].FUND_NO === global.contract_mark){
	                        	contract_not.push(not_match_rs[i].FLD_VAL);//还没有签署的协议
							}
					}
	                    //先弹产品问卷,再弹附加题;此处survey_sn是固定的,无法从数据里获取
	                    if(flagAppend){
	                    	var param = appUtils.getPageParam() || {};
	                    	if(user_type == '0'){//个人附加问卷
	                    		param.survey_sn = global.append_single;
	                    		layerUtils.iConfirm("您未做附加问卷，请做附加问卷!",function() {
                					appUtils.pageInit("mall/otcOrder/confirmOrder","mall/otcOrder/extraKnowledgeQuestionnaire",param);
                				},function(){
                					layerUtils.iLoading(false);
                					$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
                				})
	                			return;
	                		}else if(user_type === '1'){
	                			param.survey_sn = global.append_org;
	                    		layerUtils.iConfirm("您未做附加问卷，请做附加问卷!",function() {
                					appUtils.pageInit("mall/otcOrder/confirmOrder","mall/otcOrder/extraKnowledgeQuestionnaire",param);
                				},function(){
                					layerUtils.iLoading(false);
                					$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
                				})
	                			return;
	                		}
	                    }
	                    //循环调用做其他问卷
	                    if(_otherQuestion.length>0){
	                    	var param = appUtils.getPageParam() || {};
		            		for(var h =0;h<_otherQuestion.length;h++){
		            			param.survey_sn = _otherQuestion[h];
		            			layerUtils.iConfirm("您未做其他问卷，请做其他问卷!",function() {
		            				appUtils.pageInit("mall/otcOrder/confirmOrder","mall/otcOrder/knowledgeQuestionnaire",param);
		            			},function(){
                					layerUtils.iLoading(false);
                					$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
                				})
		          				return false;
		            		}
	                    }
	            		if(ec_effect_flag == '1'){//即使签署过一次,但是还是每次都要签署协议属性
	            			for(var t=0;t<data.length;t++){
	            				if(data[t].pro_type === '3' && (contract_not.indexOf(data[t].pro_code) === -1)){
	            					contract_not.push(data[t].FLD_VAL);
	            				}
	            			}
	            		}
	            		querySingedAgreement(pro_code,attach_type); //去500004判断是否签署，是否每次要签	3电子合同
	            		$(_pageId+" #tjdd").text("提交订单"); 
	            		$(_pageId+" #tjdd").attr('style',"background-color:#19e;float: none; display: inline-block;");
						bindOrder();
					}else{
						var user_type = appUtils.getSStorageInfo("user_type");
						if(user_type === '0'){
							layerUtils.iMsg(-1,"该产品允许购买的客户类型是机构");
							$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
							return false;
						}else{
							layerUtils.iMsg(-1,"该产品允许购买的客户类型是个人");
							$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
							return false;
						}
					}
	            }else{
	            	if(ec_effect_flag==='1'){//即使签署过一次,但是还是每次都要签署协议属性
	            		contract_not.push(pro_code);
	            	}
	            	querySingedAgreement(pro_code,attach_type); //去500004判断是否签署，是否每次要签	3电子合同
	            	for(var k=0;k<leng;k++){
	            		if(not_match_rs[k].FUND_NO === global.contract_mark){
	                    	contract_not.push(not_match_rs[k].FLD_VAL);//还没有签署的协议
						}else if(not_match_rs[k].FUND_NO === global.appro_append && not_match_rs[k].CUST_RS==""){
							var param = appUtils.getPageParam() || {};
	                    	if(user_type == '0'){//个人附加问卷
	                    		param.survey_sn = global.append_single;
	                    		layerUtils.iConfirm("您未做附加问卷，请做附加问卷!",function() {
                					appUtils.pageInit("mall/otcOrder/confirmOrder","mall/otcOrder/extraKnowledgeQuestionnaire",param);
                				},function(){
                					layerUtils.iLoading(false);
                					$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
                				})
	                			return;
	                		}else if(user_type === '1'){
	                			param.survey_sn = global.append_org;
	                    		layerUtils.iConfirm("您未做附加问卷，请做附加问卷!",function() {
                					appUtils.pageInit("mall/otcOrder/confirmOrder","mall/otcOrder/extraKnowledgeQuestionnaire",param);
                				},function(){
                					layerUtils.iLoading(false);
                					$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
                				})
	                			return;
	                		}
						}
	            	}
	            	$(_pageId+" #tjdd").text("提交订单"); 
	        		$(_pageId+" #tjdd").attr('style',"background-color:#19e;float: none; display: inline-block;");
	            	bindOrder();
	            }
			}else{
				$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
				layerUtils.iMsg(-1,"该产品还未配置协议");
			}
		});
	}
	/*
	/**
	 * (300046)
	 */
	function bank_pro(){
		var param={
				
		};
		service.bankXing(param,function(data){
			var perData=data.results;
			_ta_code=perData[0].ta_code;
			_ta_name=perData[0].ta_name;
			_ta_name=_ta_name.split("|");
			_ta_code=_ta_code.split("|");
			_length=_ta_code.length;
		});
		
	}
	/**
	 * 签署未签署的协议(500005)
	 */
	//点击事件
	function signUndoneAgreement(){
		var ticket=appUtils.getSStorageInfo("ticket"); 
		var cust_code=appUtils.getSStorageInfo("cust_code");
		var fund_account= appUtils.getSStorageInfo("fund_account");
		
		var mobilePhone = require("external").callMessage({
			"funcNo" : "50043",
			"key" : "mobilePhone"
		}).results[0].value;
		
		if (contract_not.length > 0) {
			var param = {           			
				"cust_code":cust_code,
				"ticket":ticket,
//				"sign_mode" : 1,
				"mobile" : mobilePhone,
				"com_sign":"0",
				"risk_uncover":"0",
				"mobile_channel":platform,
				"pro_code":contract_not.join(","),
				"entrust_way":entrust_way
			};
			
			var callBack = function(data){
				if(data.error_no!="0") {
					layerUtils.iAlert(data.error_info);
					layerUtils.iLoading(false);
					return false;
				};
				var contract_force = [];//需强制签署的协议
				var perData = data.results;
				if(perData.length > 0){
					for (var i=0; i < perData.length; i++){
						if(perData[i].sign_status=="9"){//9接口调用异常
							layerUtils.iLoading(false);
							$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
							layerUtils.iMsg(-1,"接口调用异常");
							return false;	
						}else if(perData[i].sign_status=="1"){//1需要强制签署
							contract_force.push(perData[i].pro_code);
						}else if(perData[i].sign_status == "2"){//2不能签署
							layerUtils.iLoading(false);
							$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
							layerUtils.iAlert("不符合签署条件");
							return false;
						}
					}
					if (contract_force.length > 0) {
						layerUtils.iConfirm("您的风险等级与产品等级不匹配,是否强制签署协议?", function(){
							var reqParam = {
								"cust_code":cust_code,
								"ticket":ticket,
								"pro_code":contract_force.join(","),
//								"sign_mode" : 1,
								"mobile" : mobilePhone,
								"com_sign":"0",
								"risk_uncover":"0",
								"mobile_channel":platform,
								"entrust_way":entrust_way
							}
							service.signAgreement(reqParam, callBack,{"isLastReq" : false});
						},function(){
							appUtils.pageBack();
							$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
						},"确定","取消");
					} else {
//						// 查交易账户
//						otcTradeAccoInfo();
						appropriateMatch();//二次匹配
					}
				} else {
					layerUtils.iLoading(false);
				}
			}
			service.signAgreement(param,callBack,{"isLastReq" : false});
		}else{// 查交易账户
			otcTradeAccoInfo();
		}
	}
	
	//适当性匹配(第二次匹配500006)
	function appropriateMatch()
	{
		var cust_code = appUtils.getSStorageInfo("cust_code");
		var fund_account  = appUtils.getSStorageInfo("fund_account");
		var pageInParam  = appUtils.getPageParam();
		var product_id = "";
		var pageInParam  = appUtils.getPageParam();
		if(pageInParam != null && pageInParam != ""){
			product_id=pageInParam.product_id;
		}else if(paramConfirmOrder != null && paramConfirmOrder != ""){
			product_id= paramConfirmOrder.product_id;
		}
		var order_id=null;
		var ticket = appUtils.getSStorageInfo("ticket");
		var param = {
			"cust_code":cust_code,
			"tran_type":tran_type,
			"ticket":ticket,
			"inst_id" : inst_id,
	//		"fund_account" : fund_account,
			"entrust_way" : entrust_way
		};
		service.appropriateMatch(param,function(data){
			if(data.error_no!="0") {
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
			var perData = data.results;
			if (!perData || perData.length == 0) {
				layerUtils.iMsg(-2,"未能获取到该产品的匹配信息");
				layerUtils.iLoading(false);
				return false;
			}
			var is_risk = perData[0].rs_code;
			var not_match_rs = $.parseJSON(perData[0].not_match_rs); // 不匹配结果集
			var leng = not_match_rs.length;
			for(var j=0; j<leng; j++){//大的部分匹配,检测不匹配中的其他值,若是有值则仍为不匹配,否则匹配
				if(not_match_rs[j].CUST_RS !== ""){//CUST_RS表示客户有实际值,但是不匹配
					is_risk="0";
					break;
				}
			}
			if(is_risk == "1"){ //风测匹配
				newRiskResult(function(data){
					var results = data.results;
					if(results && results.length > 0){
						//跳到适当匹配书
						var pageInParam = appUtils.getPageParam() || {};
						pageInParam.trd_amt = trd_amt;
						pageInParam.risk_name = results[0].risk_name;
						appUtils.pageInit("mall/otcOrder/confirmOrder", "mall/otcOrder/riskSuccess", pageInParam);
						return false;
					}
				});
			} else if(is_risk == '0'){//不匹配      弹不适当匹配书
				newRiskResult(function(data){
					var results = data.results;
					if(results && results.length > 0){
						var invest_variety = "";
						var invest_deadline = "";
						var risk_not = false;
						for(var i=0;i<leng;i++){
							if (not_match_rs[i].FUND_NO===global.appro_append) {
								if(not_match_rs[i].FLD_NAME==="INVE_VARI"){//客户投资品种
									invest_variety = dicInvestVaritey(not_match_rs[i].CUST_RS);
								}
								if(not_match_rs[i].FLD_NAME==="INVE_PERI"){//客户投资期限
									invest_deadline = dicInvestDeadline(not_match_rs[i].CUST_RS);
								}
							}
							var user_type = appUtils.getSStorageInfo("user_type");
							if(user_type == "0" && not_match_rs[i].FLD_NAME == "1001" && not_match_rs[i].FUND_NO =="S0014027"){
								risk_not = true;
							}else if(user_type == "1" && not_match_rs[i].FLD_NAME == "1002" && not_match_rs[i].FUND_NO =="S0014027"){
								risk_not = true;
							}
						}
						var pageInParam  = appUtils.getPageParam() || {};
						pageInParam.trd_amt = trd_amt;
						pageInParam.invest_variety = invest_deadline;//riskFailure.js中定义  invest_deadline是投资品种
						pageInParam.invest_deadline = invest_variety;
						pageInParam.risk_not = risk_not;
						pageInParam.risk_name = results[0].risk_name;
						//跳到不适当匹配书
						appUtils.pageInit("mall/otcOrder/confirmOrder", "mall/otcOrder/riskFailure", pageInParam);
						return false;
					}
				});
			}
		}, {"isLastReq" : false});
	}
	
	//投资期限字典
	function dicInvestDeadline(inve_peri){
		switch(inve_peri) {
			case "1":
				return "短期-0到1年";
			case "2":
				return "中期-1到5年";
			case "3":
				return "长期-5年以上";
			case "4":
				return "无固定期限";
			default: return "--";
		}
	}
	//投资品种字典
	function dicInvestVaritey(inve_vari){
		switch(inve_vari) {
			case "1":
				return "债券、货币市场基金、债券基金、信托等固定收益类投资品种";
			case "2":
				return "股票、混合型基金、偏股型基金、股票型基金、信托等权益类投资品种";
			case "3":
				return "期货、融资融券";
			case "4":
				return "复杂或高金融产品";
			case "5":
				return "其他产品";
			default: return "--";
		}
	}
	
	//判断是否是交易日
	function dealTimeSyn()
	{
		var param={
			"date":""
		};
		service.dealTimeSyn(param,function(data){
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			} 
			else if(data.results[0].is_trade=='0')
			{
				layerUtils.iAlert("当前是非交易时间，理财和基金产品暂停交易。");
				layerUtils.iLoading(false);
				return false;
			}
			else{
/*				if (contract_not.length > 0) {
					//500005签署未签合同
					signUndoneAgreement();
				} else { 
					// 查询交易账户
					otcTradeAccoInfo();
				}*/
				// 查询交易账户
				otcTradeAccoInfo();
			}
		},{"isLastReq":false});
	}
	
	//2、事件绑定
	function bindPageEvent()
	{	
		/* 勾选协议 */
		appUtils.bindEvent($(_pageId+" #signProtocol"),function(){
			if($(_pageId+" .icon_check2 .c1").prop("checked"))
			{
				$(_pageId+" .icon_check2 .c1").removeAttr("checked");
			}
			else
			{
				$(_pageId+" .icon_check2 .c1").attr("checked","checked");
			}
		});
		
		//点击 返回
		appUtils.bindEvent($(_pageId+" .icon_back"),function(){
			appUtils.pageBack();
		});
		
		//判断输入是否合法
		appUtils.bindEvent($(_pageId+" #buyMoney"),function(){
			putils.numberLimit($(this));
			$(_pageId+" #maxMoney").html(putils.number2num1($(this).val()));
			$(_pageId+" #payMoney").html("￥"+$(_pageId+" #buyMoney").val());
		},"keyup");

		//控制输入不能为空
		appUtils.bindEvent($(_pageId+" #buyMoney"),function(){

			if($(this).val()==null||$(this).val()==""){
				$(this).val(0);
			}
			$(this).val(putils.moneyFormat($(this).val()));
			$(_pageId+" #maxMoney").html(putils.number2num1($(this).val()));
			$(_pageId+" #payMoney").html("￥"+$(_pageId+" #buyMoney").val());
		},"blur");

	}
	
	/**
	 * 绑定订单提交事件
	 */
	function bindOrder(){
		//立即提交
		appUtils.bindEvent($(_pageId+" #tjdd"),function(){
			
			if(!contractFlag){
				//layerUtils.iAlert("尊敬的投资者：该产品仅限临柜签署产品相关文件后购买，详请咨询您开户营业部！");
				return false;
			}
			if(!$(_pageId+" .icon_check2 .c1").prop("checked")){
				layerUtils.iAlert("请阅读并同意签署以下协议、合同！");
				return false;
			}
			var buyMoney = $(_pageId+" #buyMoney").val();
			if(buyMoney == ""){
				layerUtils.iAlert("请输入购买金额！");
				return false;
			}
			if(parseFloat(buyMoney) <= 0){
				layerUtils.iAlert("购买金额必须大于0！");
				return false;
			}
			trd_amt = parseFloat($(_pageId+" #buyMoney").val());//购买值
			dealTimeSyn();//判断是否是交易日
			$(_pageId + " #tjdd").html("提交中...").unbind(); // 解绑提交订单按钮
		});
	}

	//3、销毁
	function destroy()
	{    
		product_id="";//销毁product_id 
		jg_org="";
		$(_pageId+" #maxMoney").html("");
		$(_pageId+" #payMoney").html("");
		$(_pageId+" #buyMoney").val("");
		$(_pageId+" #tjdd").text("提交订单"); 
		$(_pageId+" #tjdd").attr('style',"background-color:#19e;float: none; display: inline-block;");
	}

	var confirmOrder =
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = confirmOrder;

	});

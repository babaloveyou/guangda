/*
 * 现金宝份额查询
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	_pageId = "#xjb_navigation_queryQuotient ";
	
	/*
	 * 页面初始化
	 */
	function init(){
		//设置页面高度
		$(_pageId + " .main").height($(window).height() - $(_pageId + " .header").height());
		$(_pageId + " .main").css("overflow-y","auto");
		
		var par = {
			"branch_no":appUtils.getSStorageInfo("branch_no"),
			"fund_account":appUtils.getSStorageInfo("fund_account"),
			"market":"1",
			"fund_code":"270004"
		};
		service.queryFe(par,function(data){
			$(_pageId + ".sharepad").html("");
			if(data.error_no == 0){
				var results = data.results[0].data;
				if(results.length == 0){
				//	layerUtils.iAlert("无返回数据");
					var strHTML = "";
					strHTML += "<div class='no_data' style='margin:50% auto;'>";
					strHTML += "<span class='icon'></span>";
					strHTML += "<p style='text-align:center;'>暂无相关数据</p>";
					strHTML += "</div>";
					$(_pageId + ".sharepad").html(strHTML).css("background-color","#F4F4F4");
					return ;
				}
				var html = creatHTML(results);
				$(_pageId + " .sharepad").append(html);
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		});

	}
	
	function creatHTML(results){
		var str = "";
		for(var i = 0;i<results.length;i++){
			str += '<div class="sharebox">';
			str += '<div class="row_01"><img src="images/zshi.png"><p>'+results[i].product_name+'</p>'+results[i].product_code+'</div>';
			str += '<div class="row_02 clearfix">';
			str += '<div class="col_01">';
			str += '<p><span>当前份额</span>'+parseFloat(results[i].share_amount).toFixed(2)+'</p>';
			str += '<p><span>筹码原值</span>'+parseFloat(results[i].cost_price).toFixed(2)+'</p>';
			str += '<p><span>盈&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;利</span>'+parseFloat(results[i].income_balance).toFixed(2)+'</p>';
			str += '</div>';
			str += '<div class="col_01">';
			str += '<p><span>基金公司</span>'+results[i].ta_code_txt+'</p>';
			str += '<p><span>可用数量</span>'+parseFloat(results[i].fund_avl).toFixed(2)+'</p>';
			str += '<p><span>市&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;值</span>'+parseFloat(results[i].total_money).toFixed(2)+'</p>';
			str += '</div>';
			str += '</div>';
			str += '</div>';
		}
		return str;
	}
	
	/*
	 * 绑定页面事件
	 */
	function bindPageEvent(){
		
		//返回
		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(e){
			pageBack();
			e.stopPropagation();
		});
	}
	
	/*
	 * 销毁页面
	 */
	function destroy(){
		$(_pageId + " .sharepad").html("");
	}
	
	function pageBack(){
		appUtils.pageInit("xjb/navigation/queryQuotient","xjb/navigation/index",{});
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy,
			"pageBack":pageBack
	};
	//暴露方法
	module.exports = base;
});
/**
 * 风险测评结果
 */
define(function(require, exports, module) 
	{
	var appUtils = require("appUtils");
	var gconfig = require("gconfig");
	var service = require("mobileService");//业务层接口，请求数据
	var global = gconfig.global;
	var layerUtils = require("layerUtils");
	var _pageId ="#otc_riskResult ";

	/*初始化*/
	function init()
	{
		otcRiskResult();
	}

	function bindPageEvent() 
	{

		/* 绑定返回事件 */
		appUtils.bindEvent($(_pageId+" .top_title .icon_back"),function(){
			appUtils.pageBack();
		});
		
		/* 重新测评 */
		appUtils.bindEvent($(_pageId+" #redoRisk"),function(){
			appUtils.pageInit("otc/riskResult","otc/riskAssessment",{});
		});
		
		/*下一步 */
		appUtils.bindEvent($(_pageId+" #next_step"),function(){
			appUtils.pageInit("otc/riskResult","otc/otcFundAcco",{});
		});
	}

	function otcRiskResult(){
		var cust_code=appUtils.getSStorageInfo("cust_code");
		var ticket=appUtils.getSStorageInfo("ticket");
		var cust_type=appUtils.getSStorageInfo("cust_type");
		var survey_sn = "";
		if(cust_type == "0"){
			survey_sn = "1001";
		}else if(cust_type == "1"){
			survey_sn = "1002";
		}else{
			survey_sn = "1001";
		}
		var param={
				"cust_code" : cust_code,
				"survey_sn": survey_sn,
				"ticket" : ticket
		};

		/*调用查询资金接口*/
		service.newRiskResult(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result = data.results;
			if(error_no == "0" && result.length != 0){
				var risk_name = result[0].risk_name;
				var risk_fraction = result[0].risk_fraction;
				$(_pageId+" #riskGrades").html(risk_fraction+"<span>分</span>");
				$(_pageId+" .inner p").html(risk_name);
				$(_pageId+" #risk_text").html("您的当前风险等级为"+risk_name);
			}else{
				layerUtils.iAlert(error_info);
			}
		});
	}

	function destroy()
	{
		service.destroy();
	}

	var riskResult = 
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = riskResult;

	});
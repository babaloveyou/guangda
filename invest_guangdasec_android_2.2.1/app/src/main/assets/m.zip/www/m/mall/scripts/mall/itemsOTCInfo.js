/**
 * OTC详情
 */
define(function(require, exports, module)
	{	
	var service = require("mobileService"); //业务层接口，请求数据
	var appUtils = require('appUtils'),
	putils = require("putils"),
	layerUtils = require("layerUtils"),
	gconfig = require("gconfig"),
	global = gconfig.global;
	var _pageId ="#mall_itemsOTCInfo ";
	var buy_limit = 0 ;  //限购起点
	var URL=global.url;
	var product_id = "";
	var canBuyFlag = true;
	var pro_state="";
	
	//1、初始化
	function init() 
	{
//		var is_buy = appUtils.getPageParam("is_buy");
//		if (is_buy == "false") {
//			$(_pageId + "#otcBuy").css("background","#CFCFCF");
//		} else {
//			$(_pageId + "#otcBuy").css("background","");
//		}
		/*把product_id存到session*/
/*		if(product_id)
		{
			appUtils.setSStorageInfo("product_id",product_id);
		}else{
			product_id = appUtils.getPageParam("product_id");//页面跳转传过来的id
		}*/
		OTCinfo();
	}
	
	function mlLogin(callBack){
		if(gconfig.platform == "0"){
			return false;
		}
		var func_login = function(token){
	        var flag = true;
			var loginPath = gconfig.global.loginPath+"&token="+encodeURIComponent(token); // 商城统一登录链接
			// 发送请求模拟登陆
			appUtils.invokeServer(loginPath, {}, function(data){
				var error_no = data.err_no;
				var error_info = data.err_info;
				var result = data.data;//验证码输入错误
				if(error_no == "0" && result.length != 0){
					var param_data = {"funcNo":"50040","key":"mall_data","value":JSON.stringify(result)};
					require("external").callMessage(param_data); //把result存在原生壳子 
					var param_token = {"funcNo":"50040","key":"mall_token","value":token};
					require("external").callMessage(param_token); //保存token值
					saveData_mall(result,token,callBack); // 保存数据
					//这里账号切换 重置资金账号
					var param_login = {"funcNo":"50041", "key":"switchAccountResults"};
					resultVo = require("external").callMessage(param_login);
					var result = resultVo.results[0].value;
					//如果从壳子里面获取的 资金账号不为空，那么说明客户通过原生切换了账户
					if(result != null && result != ""){
						switchInfo_mall(result[0].fund_account,token, callBack); // 调用切换资金账号接口，重置用户信息
						appUtils.setSStorageInfo("fund_account",result[0].fund_account);
						appUtils.setSStorageInfo("client_no",result[0].client_no);
					}
					appUtils.setSStorageInfo("_isLoginIn","true");
					var param_lg = {"funcNo":"50040","key":"login_mall","value":true};
                    require("external").callMessage(param_lg); //保存登录状态
				}
				else{
					layerUtils.iAlert(error_info);
				}
			},true,true);
		};
		
		// 获取壳子里的全局登陆状态，1:已经登陆； 0:代表退出
		product_id = appUtils.getPageParam("product_id");//页面跳转传过来的id
		var param_login = {"funcNo":"50041", "key":"login_state"};
		resultVo = require("external").callMessage(param_login);
		var login_state = resultVo.results[0].value;
		// 已经统一登陆
		if(login_state == "1"){
		    var param_lg= {"funcNo":"50041","key":"login_mall","product_id":product_id};
            var _isLoginIn =  require("external").callMessage(param_lg).results[0].value;
            if(!_isLoginIn){
			    _isLoginIn = appUtils.getSStorageInfo("_isLoginIn");
            }
			var param_mall = {"funcNo":"50041", "key":"APP_SC"};
			resultVo = require("external").callMessage(param_mall);
			var token = resultVo.results[0].value;
			var param_token = {"funcNo":"50041","key":"mall_token","product_id":product_id};
			resultVo =  require("external").callMessage(param_token);
			var session_token = resultVo.results[0].value;
			if(!session_token){
				session_token = appUtils.getSStorageInfo("login_token") || "";
			}
			// 本地session为空，需要进行模拟登陆
			if(!_isLoginIn){
				func_login(token); // 模拟登陆
			}
			else{
				// 比较本地token值与壳子token值是否相同
				if(token == session_token){
					//从原生壳子获取用户缓存
					var param_data = {"funcNo":"50041","key":"mall_data"};
					resultVo =  require("external").callMessage(param_data);
					var res = resultVo.results[0].value;
					//ios 返回的是字符串  android 返回json
					if(res && typeof res === "string"){
						res = JSON.parse(res);
					}
					//将用户缓存存在session中
					saveData_mall(res,session_token,callBack);
					//这里账号切换 重置资金账号
					var param_login = {"funcNo":"50041", "key":"switchAccountResults"};
					resultVo = require("external").callMessage(param_login);
					var result = resultVo.results[0].value;
					//如果从壳子里面获取的 资金账号不为空，那么说明客户通过原生切换了账户
					if(result != null && result != ""){
						var naccount = appUtils.getSStorageInfo("naccount");
						var account = result[0].fund_account; // 临时资金账号 
						if(naccount != account){
							appUtils.setSStorageInfo("naccount", account);
							switchInfo_mall(account, token, callBack); // 调用切换资金账号接口，重置用户信息
						}
						appUtils.setSStorageInfo("fund_account",result[0].fund_account);
						appUtils.setSStorageInfo("client_no",result[0].client_no);
					}
				}
				else{
					func_login(token); // 模拟登陆
				}
			}
		} else {
			var toPage =  appUtils.getSStorageInfo("_curPageCode");//当前页 pageCode
			var  product_id=appUtils.getPageParam("product_id");
			if(gconfig.platform == "2"){
				toPage={"prefix":"www/m/mall","suffix":toPage,"productID":product_id};
			}else{
				toPage = "/mall/index.html#!/"+toPage+".html?product_id="+product_id;
			}
			var param_login = {"funcNo":"50101", "moduleName":"login", "params":{"moduleName":"financial-mall","toPage":toPage}};
            require("external").callMessage(param_login);
		}
	}
	
	/* 调用切换资金账号接口，重置用户信息 */
	function switchInfo_mall(account,token, callBack){
		var loginPath = gconfig.global.switchPath+"&fund_account="+account;
		// 发送请求模拟登陆
		appUtils.invokeServer(loginPath, {}, function(data){
			var error_no = data.err_no;
			var error_info = data.err_info;
			var result = data.data;//验证码输入错误
			if(error_no == "0" && result.length != 0){
			    var param_data = {"funcNo":"50040","key":"mall_data","value":JSON.stringify(result)};
                require("external").callMessage(param_data); //把result存在原生壳子
                saveData_mall(result, token, callBack);  // 将数据保存到 session 中
			}else{
				layerUtils.iAlert(error_info);
			}
		},true,false,true);
	}
	
	/*保存商城统一登陆信息*/
	function saveData_mall(result,token, callBack){
		//保存用户信息对象
		appUtils.setSStorageInfo("stock_userInfo", JSON.stringify(result),true);
		appUtils.setSStorageInfo("login_token",token);
		
		/*把用户编号存到session*/
		if(result.user_id){
			appUtils.setSStorageInfo("user_id",result.user_id);
		}
		/*把jsessionid存到session*/
		if(result.jsessionid){
			appUtils.setSStorageInfo("jsessionid",result.jsessionid);
		}
		/*把用户名存到session*/
		if(result.user_name){
			appUtils.setSStorageInfo("user_name",result.user_name);
		}
		/*把账户名存到session*/
		if(result.account_name){
			appUtils.setSStorageInfo("account_name",result.account_name);
		}
		/*把资金账号存到session*/
		if(result.fund_account){
			appUtils.setSStorageInfo("fund_account",result.fund_account);
		}
		/*把风险承受能力等级存到session*/
		if(result.risk_level){
			appUtils.setSStorageInfo("risk_level",result.risk_level);
		}
		/*把风险承受能力存到session*/
		if(result.risk_level_txt){
			appUtils.setSStorageInfo("risk_level_txt",result.risk_level_txt);
		}
		/*把手机号码存到session*/
		if(result.mobile_phone){
			appUtils.setSStorageInfo("mobile_phone",result.mobile_phone);
		}
		/*把邮箱地址存到session*/
		if(result.user_mail){
			appUtils.setSStorageInfo("user_mail",result.user_mail);
		}
		/*存user_code到session*/
		if(result.cust_code){
			appUtils.setSStorageInfo("cust_code",result.cust_code);
//			appUtils.setSStorageInfo("custCode",result.cust_code,true);
			var par_custCode = {"funcNo":"50040","key":"custCode","value":result.cust_code};
			require("external").callMessage(par_custCode); //把user_code存在原生壳子 
		}
		/*存fund_list到session*/
			appUtils.setSStorageInfo("fund_list",result.fund_list);
		/*存ticket到session*/
		if(result.ticket){
			appUtils.setSStorageInfo("ticket",result.ticket);
		}
		if(result.product_id){
			appUtils.setSStorageInfo("product_id",result.product_id);
		}
		/*存cust_type到session*/
		if(result.cust_type){
			appUtils.setSStorageInfo("cust_type",result.cust_type);
			var par_custType = {"funcNo":"50040","key":"custType","value":result.cust_type};
			require("external").callMessage(par_custType); //把cust_type存在原生壳子 
		}
		/*存user_type到session*/
		if(result.user_type){
			appUtils.setSStorageInfo("user_type",result.user_type);
		}
		
		callBack();
	}

	function OTCinfo(){
		product_id = appUtils.getPageParam("product_id");//页面跳转传过来的id
		if(product_id)
		{
			appUtils.setSStorageInfo("product_id",product_id);
		}else{
			product_id=appUtils.getSStorageInfo("product_id");
		}
		if(product_id==null){
			layerUtils.iMsg(1, "数据加载错误！");
			appUtils.pageInit("mall/itemsOTCInfo","account/mainPage",{});
			return false;
		}
		var param = {
			"product_id":product_id
		};
		service.OTCInfo(param,function(data){
			if(data.error_no=="0")
			{
				var result = data.results[0];
				var product_id = result.product_id;//ID
				var suit_investors= result.suit_investors;//适合投资者
				var trust_org_sname= result.trust_org_sname;//托管人
				var inst_sname= result.inst_sname;//产品名称
				var inst_code= result.inst_code;//产品代码
				var ent_buy_limit=result.ent_buy_limit; //起投金额
				var mgr_org_sname=result.mgr_org_sname;//管理人名称
				var risk_lvl=result.risk_lvl;//风险等级
				var pro_deadline=result.pro_deadline;//投资期限
				var est_yield=result.est_yield;//约定收益率
				var iss_bgn_date=result.iss_bgn_date;//发行日期
				var inst_type=result.inst_type;//产品类型
				var invest_target=result.invest_target;//投资目标
				var invest_scope=result.invest_scope;//投资范围
				var promotion_agency=result.promotion_agency;//推广机构
				var product_cost=result.product_cost;//产品费用wj_flag
				var isss=result.isss;//申购赎回 Y支持 N不支持
				var istrdturn=result.istrdturn;//交易转让 Y支持 N不支持
				var iscontrol=result.iscontrol;//1 名单限制 0不限制
				var iss_state=result.iss_stat;//产品状态
				var wj_flag=result.wj_flag;
				var wj_survey_sn=result.wj_survey_sn;
				$(_pageId+" #mgr_org_sname").html(mgr_org_sname);
				
				if(iss_state=="0"){
					pro_state="募集前状态 ";
				}else if(iss_state=="1"){
					pro_state="募集期 ";
				}else if(iss_state=="2"){
					pro_state="开放期";
				}else if(iss_state=="3"){
					pro_state="封闭期";
				}else if(iss_state=="4"){
					pro_state="清盘";
				}

				/*if(parseFloat(est_yield).toFixed(2) == "0.00"){
					est_yield = "--";
				}else{
					est_yield = parseFloat(est_yield).toFixed(2);
				}*/
//				if(est_yield.indexOf(".") > 0){
//					est_yield = est_yield.replaceAll("0+?$", "");//去掉多余的0    
//					est_yield = est_yield.replaceAll("[.]$", "");//如最后一位是.则去掉
//					if(est_yield.length > 1 && est_yield.length <4){
//						est_yield =  parseFloat(est_yield).toFixed(2);
//					}else if(est_yield.length >= 4){
//						est_yield = est_yield;
//					}else{
//						est_yield = "--";
//						$(_pageId+" .annual_earning p em").empty();
//						$(_pageId+" #str").empty();
//					}
//			     }
				if(parseFloat(est_yield)==0){
					est_yield="--";
				}
				if(est_yield.length< 1){
					est_yield="--";
				}
//				est_yield = est_yield.replaceAll("%", "");
				$(_pageId+" #est_yield").html(est_yield);
				$(_pageId+" #shouyi").html(est_yield);
				if(inst_sname.length > 15){
					$(_pageId+" #inst_sname").css("font-size","13px");
				}
				if(risk_lvl == "5" || risk_lvl == "4"){
					$(_pageId+" #risk_lvl").attr("class","high_risk");
					$(_pageId+" #risk_lvl").html("高风险");
				}else if(risk_lvl == "3" || risk_lvl == "2"){
					$(_pageId+" #risk_lvl").attr("class","medium_risk");
					$(_pageId+" #risk_lvl").html("中风险");
				}else{
					$(_pageId+" #risk_lvl").attr("class","low_risk");
					$(_pageId+" #risk_lvl").html("低风险");
				}
				var isssLable = "";
				var istrdturnLable = "";
				if(isss == "Y"){
					isssLable = "支持";
				}else{
					isssLable = "不支持";
				}
               if(istrdturn == "Y"){
            	   istrdturnLable = "支持";
				}else{
					istrdturnLable = "不支持";
				}
               $(_pageId+" #pro_staust").html(pro_state);//产品状态
				$(_pageId+" #product_sname").val(inst_sname);//隐藏域赋值
				$(_pageId+" #buy_limit").val(ent_buy_limit);//隐藏域赋值
				$(_pageId+" #product_id").val(product_id);//隐藏域赋值
				$(_pageId+" #last_net").val(last_net);//隐藏域赋值
				$(_pageId+" #wj_flag").val(wj_flag);//隐藏域赋值
				$(_pageId+" #wj_survey_sn").val(wj_survey_sn);//隐藏域赋值
				$(_pageId+" #iscontrol").val(iscontrol);//隐藏域赋值
				$(_pageId+" #product_type").html(putils.product_type(inst_type));
				$(_pageId+" #inst_sname").html(inst_sname);
				$(_pageId+" #trust_org_sname").html(trust_org_sname);
				$(_pageId+" #suit_investors").html(suit_investors);
				$(_pageId+" #ent_buy_limit").html(ent_buy_limit);
				$(_pageId+" #pro_deadline").html(pro_deadline);
				$(_pageId+" #iss_bgn_date").html(iss_bgn_date);
				$(_pageId+" .overview_box h4").html(inst_sname+"概况");
				$(_pageId+" .overview_inner dl:eq(0) dd").html(inst_sname);
				$(_pageId+" .overview_inner dl:eq(1) dd").html(inst_code);
				$(_pageId+" .overview_inner dl:eq(2) dd").html(putils.product_type(inst_type));
				$(_pageId+" .overview_inner dl:eq(3) dd").html(trust_org_sname?trust_org_sname:"---");
				$(_pageId+" .overview_inner dl:eq(4) dd").html(suit_investors?suit_investors:"---");
				$(_pageId+" .overview_inner dl:eq(5) dd").html(promotion_agency?promotion_agency:"---");
				$(_pageId+" .overview_inner dl:eq(6) dd").html(isssLable);
				$(_pageId+" .overview_inner dl:eq(7) dd").html(istrdturnLable);
				$(_pageId+" .overview_inner dl:eq(8) dd").html(product_cost?product_cost:"---");
				$(_pageId+" .overview_inner dl:eq(9) dd").html(invest_target?invest_target:"---");
				$(_pageId+" .overview_inner dl:eq(10) dd").html(invest_scope?invest_scope:"---");
			}else{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
		});
	}

	//otc产品购买
	function otcbuy(cuacct_code,int_org)
	{
		//检查是否可购买
//		var product_id= appUtils.getSStorageInfo("product_id");
		var product_id= $(_pageId+" #product_id").val();  //产品ID
		var wj_flag = $(_pageId+" #wj_flag").val();
		if(wj_flag == "0"){
			var wj_survey_sn = $(_pageId+" #wj_survey_sn").val();
			var product_sname = $(_pageId+" #product_sname").val();
			var param = {
					"product_sname" : product_sname,
					"survey_sn" : wj_survey_sn,
					"product_id":product_id,
					"cuacct_code" :cuacct_code,
					"int_org" :int_org
			};
	//		appUtils.setSStorageInfo("paramConfirmOrder",JSON.stringify(param));
			appUtils.pageInit("mall/itemsOTCInfo","mall/otcOrder/confirmOrder",param);
		}else{
			var param=
			{
					"product_id":product_id,
					"cuacct_code" :cuacct_code,
					"int_org" :int_org
			};
//			appUtils.setSStorageInfo("paramConfirmOrder",JSON.stringify(param));
			appUtils.pageInit("mall/itemsOTCInfo","mall/otcOrder/confirmOrder",param);
		}
	}
	
	function ifCanBuy(cuacct_code,int_org){
		var product_id = $(_pageId+" #product_id").val();//产品id
		var ticket=appUtils.getSStorageInfo("ticket");
		var param=
		{
			"product_id":product_id,
			"int_org":int_org,
			"ticket" : ticket
		};
		service.buyRight(param,function(data){
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			} 
			else{
				otcbuy(cuacct_code,int_org);
				var result = data.results[0];
				var trd_id = result.trd_id; // 交易类别
			}
		});
	}
	
	//判断是否是交易日
	function dealTimeSyn()
	{
		var param=
		{
			"date":""
		};
		service.dealTimeSyn(param,function(data){
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			} 
			else if(data.results[0].is_trade=='0')
			{
				layerUtils.iAlert("当前是非交易时间，理财和基金产品暂停交易。");
				return false;
			}
			else
			{
				if(gconfig.platform == "0"){
					var fund_list=appUtils.getSStorageInfo("fund_list");
					if(fund_list ==""|| fund_list == null || fund_list==undefined){
						layerUtils.iAlert("请用E帐号登录！！！");
					}else{
						otcAccoInfo();//判断支付账户
					}
				} else {
					mlLogin(function(){
						var fund_list=appUtils.getSStorageInfo("fund_list");
						//		var fund_list=appUtils.getSStorageInfo("user.fund_list");
						if(fund_list ==""|| fund_list == null || fund_list==undefined){
						//if( fund_list == null ){
							layerUtils.iAlert("请用E帐号登录！！！");
						}else{
							otcAccoInfo();//判断支付账户
						}
					});
				}
			}

		});
	}
	
	function otcAccoInfo(){
		var cust_code=appUtils.getSStorageInfo("cust_code");
//		var fund_account=appUtils.getSStorageInfo("fund_account");
		var fund_list=appUtils.getSStorageInfo("fund_list");
		var ticket=appUtils.getSStorageInfo("ticket");
//		console.log(fund_list);
		var param={
				"cust_code" : cust_code,
				"cuacct_code" : fund_list,
//			"cuacct_code" : "40636115",//调试代码
				"ticket" : ticket
		};

		/*查询是否有支付账户*/
		service.otcAccoInfo(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var results = data.results;
			if(error_no == "0" && results.length != 0){
				var otcflag = results[0].otcflag;
				if(otcflag == "1"){
					var cuacct_code = results[0].cuacct_code;
					var int_org = results[0].int_org;
					appUtils.setSStorageInfo("int_org",int_org);//存
					ifCanBuy(cuacct_code,int_org);//是否有权限购买
				}else{
					//layerUtils.iConfirm("您还未开通OTC支付账户，是否开通！",function(){});
					layerUtils.iConfirm("您还没有开通otc账户不能进行此操作", function(){
						var toPage = "";
						if(gconfig.platform == "2"){
							toPage={"prefix":"www/m/index","suffix":"otc/riskDisclosure","prePage":"mall_itemsOTCInfo","product_id":product_id};
						}else{
							toPage = "/index/index.html#!/otc/riskDisclosure.html?prePage=mall_itemsOTCInfo&product_id="+product_id;
						}
						var param = {"funcNo":"50101","moduleName":"financial-mall","params":{"moduleName":"user-center","toPage":toPage}};
						require("external").callMessage(param);
					});
				}
			}else{
				layerUtils.iAlert(error_info);
				layerUtils.iLoading(false);
				return false;
			}
		});
	}
	
	/**
     * 300039：理财产品白名单
     * 
     */
	function whiteList(){
		var cust_code=appUtils.getSStorageInfo("cust_code");
		var inst_code = $(_pageId+" .overview_inner dl:eq(1) dd").html();
		var param={
				"cust_code" : cust_code,
				"inst_code" : inst_code
		};
		/*查询理财产品白名单*/
		service.whiteList(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var results = data.results;
			if(error_no == "0"){
				var can_buy = results[0].can_buy;
				if(can_buy == "1"){
					dealTimeSyn();
				}else{
					canBuyFlag = false;//下次再次点击购买的时候就无效
					layerUtils.iAlert("该产品为定向发行产品，您不能购买！");
				}
			}else{
				layerUtils.iAlert(error_info);
				layerUtils.iLoading(false);
				return false;
			}
		});
	}

	//2、事件绑定
	function bindPageEvent()
	{
		//点击 立即购买
		appUtils.bindEvent($(_pageId+" #otcBuy"),function(){
			var is_buy = appUtils.getPageParam("is_buy");
//			if (is_buy != "false") {
				var iscontrol = $(_pageId+" #iscontrol").val();
				if(canBuyFlag){
					if(iscontrol == "1"){
						whiteList();
					}else{
						dealTimeSyn();
					}
				}
//			}
		});

		// 点击返回 
		appUtils.bindEvent($(_pageId+"  .icon_back"),function(){
			appUtils.pageInit("mall/itemsOTCInfo","mall/itemsOTC",{});
		});

		//点击 返回顶部
		appUtils.bindEvent($(_pageId+" .back_top .back_btn"),function(){
			$(document.body).ScrollTo(0);
			return false;
		});
		
		$(window).scroll(function(){  //只要窗口滚动,就触发下面代码 
			var scrollt = document.documentElement.scrollTop + document.body.scrollTop; //获取滚动后的高度 
			if( scrollt >200 ){  //判断滚动后高度超过200px,就显示  
			       $(_pageId+" .back_top .back_btn").fadeIn(400); //淡出     
			}else{      
			       $(_pageId+" .back_top .back_btn").stop().fadeOut(400); //如果返回或者没有超过,就淡入.必须加上stop()停止之前动画,否则会出现闪动   
			}
		});
		
		//点击 LOGO 
		appUtils.bindEvent($(_pageId+" .logo"),function(){appUtils.pageInit("mall/itemsOTCInfo","account/mainPage");});

		// 点击 个人中心 
		appUtils.bindEvent($(_pageId+" .icon_info"),function(){
			appUtils.pageInit("mall/itemsOTCInfo","account/userCenter",{});
		});
	}

	//3、销毁
	function destroy()
	{
		product_id="";
		$(_pageId+" .annual_earning p em").html("%");
		$(_pageId+" #str").html("");
		canBuyFlag = true;
	}
	var itemsOTCInfo =
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = itemsOTCInfo;

	});
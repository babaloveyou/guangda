/*
 * 风险等级适当
 * */
define(function(require, exports, module)
	{
	var service = require("mobileService");//业务层接口，请求数据
	var appUtils = require('appUtils'),
	putils = require("putils"),
	constants=require("constants");//常量类
	layerUtils = require("layerUtils"),
	gconfig = require("gconfig"),
	global = gconfig.global;
	var _pageId ="#mall_otcOrder_riskSuccess";

	//1、初始化
	function init()
	{	
		$(_pageId+" #presonRiskLevel").html(appUtils.getPageParam("risk_name"));
		
		OTCinfo();
//		otcRiskResult();
	}
	
	function otcRiskResult(){
		var cust_code=appUtils.getSStorageInfo("cust_code");
		var ticket=appUtils.getSStorageInfo("ticket");
		var user_type=appUtils.getSStorageInfo("user_type");
		var survey_sn = "";
		if(user_type == "0"){
			survey_sn = "1001";
		}else if(user_type == "1"){
			survey_sn = "1002";
		}else{
			survey_sn = "1001";
		}
		var param={
				"cust_code" : cust_code,
				"survey_sn": survey_sn,
				"ticket" : ticket
		};
		service.newRiskResult(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			if(error_no == 0){
				var risk_name = data.results[0].risk_name;
				$(_pageId+" #presonRiskLevel").html(risk_name);
				$(_pageId+" #presonRiskLevel1").html(risk_name);
			}else{
				layerUtils.iAlert(error_info);
				layerUtils.iLoading(false);
				return false;
			}
		},{});
	}
	
	function OTCinfo(){
		var product_id = appUtils.getPageParam("product_id");//页面跳转传过来的id
		if(product_id==null){
			layerUtils.iMsg(1, "数据加载错误！");
			appUtils.pageInit("mall/otcOrder/riskSuccess","account/mainPage",{});
			return false;
		}
		var param = {
			"product_id":product_id
		};
		service.OTCInfo(param,function(data){
			if(data.error_no=="0")
			{
				var result = data.results[0];
				var risk_lvl=result.risk_lvl;//风险等级
				var pro_deadline=result.pro_deadline;//投资期限
				var belongs_invtype=result.belongs_invtype;//投资类型
				var risk_level_name="";
				switch (risk_lvl){
				 case "1":
					 risk_level_name="低风险";
				    break;
				  case "2":
					  risk_level_name="中低风险";
				    break;
				  case "3":
					  risk_level_name="中风险";
				    break;
				  case "4":
					  risk_level_name="中高风险";
				    break;
				  case "5":
					  risk_level_name="高风险";
				    break;
				}
				if(pro_deadline == ""){
					pro_deadline = "---";
				}
				if(belongs_invtype == ""){
					belongs_invtype = "---";
				}
				$(_pageId+" #risk_level").html(risk_level_name);
				$(_pageId+" #risk_level1").html(risk_level_name);
				$(_pageId+" #deadline").html(pro_deadline);
				$(_pageId+" #belongs_invtype").html(belongs_invtype);
			}else{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
		});
	}


	//2、事件 绑定
	function bindPageEvent(){
		// 点击返回
		appUtils.bindEvent($(_pageId+"  .close"),function(){
				appUtils.pageBack();
		});

		//确定购买
		appUtils.bindEvent($(_pageId+" #goumai"),function(){
			otcBuy();
			//signOTCAgreement();
		});
		
	 }
	
	//签署协议
	function signOTCAgreement()
	{
		var cust_code=appUtils.getSStorageInfo("cust_code");
		var ticket=appUtils.getSStorageInfo("ticket");
		var pageInParam  = appUtils.getPageParam();
		var product_id=pageInParam.product_id;
		var param =
		{
			"cust_code":cust_code,
			"query_type": "otclc",
			"product_id":product_id,
			"ticket" : ticket
		};
		service.signNewAgreement(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			if(error_no < 0){
				layerUtils.iAlert(error_info);
				layerUtils.iLoading(false);
				return false;
			}else{
				otcBuy();
			}
		},{"isLastReq":false});
	}
	
	/**
     * 2000004：购买OTC理财产品（下订单）
     */
	function otcBuy(){
		var cust_code=appUtils.getSStorageInfo("cust_code");
		var ticket = appUtils.getSStorageInfo("ticket");
		var cuacct_code = appUtils.getPageParam("cuacct_code"); //appUtils.getSStorageInfo("fund_list"); //"40636115";//测试用
		var pageInParam  = appUtils.getPageParam();
		var product_id=pageInParam.product_id;
		var trd_amt = pageInParam.trd_amt;
		var product_name = pageInParam.product_name;
		var param =
		{
			"cust_code":cust_code,
			"cuacct_code":cuacct_code,
			"product_id" :product_id,
			"trd_amt" :trd_amt,
			"risk_reveal_method" :"0",
			"order_channel" : "7",
			"ticket":ticket
		};
		service.otcBuy(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result = data.results[0];
			if(error_no == 0){
				var order_id=result.order_id;//订单编号
				var pageParam  = appUtils.getPageParam();
				pageParam.order_id = order_id;
				appUtils.pageInit("mall/otcOrder/riskSuccess","mall/otcOrder/orderPay",pageParam);
			}else{
				layerUtils.iAlert(error_info);
				layerUtils.iLoading(false);
				return false;
			}
		},{});
	}
	



	//3、销毁
	function destroy()
	{
	

	}

	var riskSuccess =
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = riskSuccess;

	});
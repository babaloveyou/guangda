/**
 * 合同完成签署
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils");
	var _pageId = "#rzxq_contractSuccess ";
    
    /**
     * 初始化
     */
	function init() {

    }
	
	/**
	 * 事件绑定
	 */
	function bindPageEvent() {
		// 返回按钮
		appUtils.bindEvent($(_pageId + ".top_title .icon_back"), function(e){
			pageBack();
		});
		// 返回首页
		appUtils.bindEvent($(_pageId + ".mn_btn .btn"), function(e){
			pageBack();
		});
	}

	function destroy(){
	}
	
	/**
	 * 重写框架里面的pageBack方法
	 */
	function pageBack(){
		appUtils.pageInit("rzxq/contractSuccess","rzxq/contractStatus");
	
	}
	
	var base = {
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy,
		"pageBack": pageBack
	};
	module.exports = base;
});
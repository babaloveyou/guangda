/*
 * 现金宝参与状态设置
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	_pageId = "#xjb_navigation_setState ",
	cyzt = -1;//参与状态   1参与  0退出
	isCanOperation = -1;//是否可操作  0不可操作  1可操作
	/*
	 * 页面初始化
	 */
	function init(){
		//设置页面高度
		$(_pageId + " .main").height($(window).height() - $(_pageId + " .header").height());
		$(_pageId + " .main").css("overflow-y","auto");
		$(_pageId + " .main .definbtn_01").css("background","#1199EE");
		
		cyzt = -1;//参与状态   1参与  0退出
		isCanOperation = -1;//是否可操作  0不可操作  1可操作
		valide();
	}
	
	/*
	 * 绑定页面事件
	 */
	function bindPageEvent(){
		
		//返回
		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(){
//			if(isCanOperation != 1){
//				layerUtils.iMsg(-1,"您还没有参与现金宝");
//				return false;
//			}
			pageBack();
		});
		
		//选择状态
		appUtils.bindEvent($(_pageId+" .col_03"),function(){
			$(_pageId+" .masklayer li").removeClass("check");
			if($(_pageId+" .col_03 span").html() == "参与"){
				$(_pageId+" .masklayer li:first").addClass("check");
			}else{
				$(_pageId+" .masklayer li:last").addClass("check");
			}
			$(_pageId+" .masklayer").show();
		});
		
		//参与或退出
		appUtils.bindEvent($(_pageId+" .masklayer li"),function(){
			$(_pageId+" .masklayer li").removeClass("check");
			$(this).addClass("check");
		});
		
		//修改确定或取消
		appUtils.bindEvent($(_pageId+" .masklayer .selectcity_top a"),function(){
			if($(this).index() == 1){//确定
				$(_pageId+" .col_03 span").html($(_pageId+" .masklayer .selectcity .check a").html());
			}
			$(_pageId+" .masklayer").hide();
		});
		
		
		//确认提交修改
		appUtils.bindEvent($(_pageId+" .definbtn_01"),function(){
			if(cyzt == 1 && $(_pageId+" .col_03 span").html() == "参与"){
				layerUtils.iMsg(-1,"您已经是参与状态");
			}else if(cyzt == 0 && $(_pageId+" .col_03 span").html() == "退出"){
				layerUtils.iMsg(-1,"您已经是退出状态");
			}else if(cyzt == -1){
				layerUtils.iConfirm("初始化状态失败，是否重试？",function(){
					init();
				},null);
			}else{//设置参与状态
				//判断是否在修改时间内
				var today=new Date();
				var h=today.getHours();
				var m=today.getMinutes();
				var s=today.getSeconds();
				var str=h*60*60+m*60+s;
				if(str>=34200 && str<=55800){
					var param = {
							"account":appUtils.getSStorageInfo("fund_account"),
							"market":1,
							"elecstatus":1
					};
					if($(_pageId+" .col_03 span").html() == "参与"){
						param.elecstatus = 1;
						service.setCyzt2(param,function(data){
							if(data.error_no == 0){
								if($(_pageId+" .col_03 span").html() == "参与"){
									cyzt = 1;
									isCanOperation = 1;
								}else{
									cyzt = 0;
									isCanOperation = 0;
								}
								layerUtils.iMsg(0,"现金宝状态设置成功");
							}else{
								layerUtils.iLoading(false);
								var error = data.error_info;
								//后台返回的提示信息不友好
								if(error.indexOf("SQL")> -1){
									error = error.split("SQL")[0];
									error = error.substring(0,error.length-2);
								}
								layerUtils.iAlert(error);
							}
						});
					}else{
						param.elecstatus = 0;
						layerUtils.iConfirm("如果现在退出将不享受本季度现金宝收益，仅为活期存款利率，您是否确认退出？",function(){
							service.setCyzt2(param,function(data){
								if(data.error_no == 0){
									if($(_pageId+" .col_03 span").html() == "参与"){
										cyzt = 1;
										isCanOperation = 1;
									}else{
										cyzt = 0;
										isCanOperation = 0;
									}
									layerUtils.iMsg(0,"现金宝状态设置成功");
								}else{
									layerUtils.iLoading(false);
									var error = data.error_info;
									//后台返回的提示信息不友好
									if(error.indexOf("SQL")> -1){
										error = error.split("SQL")[0];
										error = error.substring(0,error.length-2);
									}
									layerUtils.iAlert(error);
								}
							});
						},null);
					}
				}else{
					layerUtils.iAlert("请在09:30:00与15:30:00之间设置参与状态!");
				}
			}
		});
	}
	
	function valide(){
		var par = {
			"branch_no":appUtils.getSStorageInfo("branch_no"),
			"account":appUtils.getSStorageInfo("fund_account"),
			"market":"1"
		};
		service.queryHtzt(par,function(data){//查询合同状态
			if(data.error_no == 0){
				var result = data.results[0];
				if(result.electronic_contract_status == "1"){//状态为参与，直接进入业务操作
					isCanOperation = 1;
					$(_pageId+" .col_03 span").html("参与");
					cyzt = 1;
				}else{
					isCanOperation = 0;
					$(_pageId+" .col_03 span").html("退出");
					cyzt = 0;
				}
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
	});
		
		// var param = {
			// "fund_account":appUtils.getSStorageInfo("fund_account"),
			// "sign":4
		// };
		// service.isCompleteStep(param,function(data){
			// if(data.error_no == 0){
				// var result = data.results[0];
				// if(result.sfkh == "1"){//已经开户
					// if(result.sfqsdzht == "1"){//合同已签署
						// var par = {
							// "branch_no":appUtils.getSStorageInfo("branch_no"),
							// "account":appUtils.getSStorageInfo("fund_account"),
							// "market":"1"
						// };
						// service.queryHtzt(par,function(data){//查询合同状态
							// if(data.error_no == 0){
								// var result = data.results[0];
								// if(result.electronic_contract_status == "1"){//状态为参与，直接进入业务操作
									// isCanOperation = 1;
									// $(_pageId+" .col_03 span").html("参与");
									// cyzt = 1;
								// }else{
									// isCanOperation = 0;
									// $(_pageId+" .col_03 span").html("退出");
									// cyzt = 0;
								// }
							// }else{
								// layerUtils.iLoading(false);
								// layerUtils.iAlert(data.error_info);
							// }
						// });
					// }else{
						// layerUtils.iMsg(-1,"您还没有签署合同");
					// }
				// }else{
					// layerUtils.iMsg(-1,"您还没有开TA户");
				// }
			// }else{
				// layerUtils.iLoading(false);
				// layerUtils.iAlert(data.error_info);
			// }
		// });
	}
	
	
	/*
	 * 销毁页面
	 */
	function destroy(){
		
	}
	
	function pageBack(){
		appUtils.pageInit("xjb/navigation/setState","xjb/navigation/index",{});
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy,
			"pageBack":pageBack
	};
	//暴露方法
	module.exports = base;
});
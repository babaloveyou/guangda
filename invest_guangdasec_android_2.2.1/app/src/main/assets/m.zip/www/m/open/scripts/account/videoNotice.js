/**
 * 视频见证注意事项
 */
define(function(require, exports, module){ 
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
	      service = require("investService").getInstance(),  //业务层接口，请求数据
		  gconfig = require("gconfig"),
		  layerUtils = require("layerUtils"),
		  global = gconfig.global,
		  needVideo = "",
		  _pageId = "#account_videoNotice";
	var external = require("external");
	/* 私有业务模块的全局变量 end */
	
	function init()
	{
//		window.videoSuccess = videoSuccess;  // 见证成功
//		window.videoFail = videoFail;  // 见证中断
//		window.videoReject = videoReject;  // 见证驳回
//	    window.qqApplay = qqApplay;
	    initPage();  // 初始化页面
		getVedioport();  // 获取营业部视频端口
	}
	
	function bindPageEvent()
	{
		/* 绑定返回 */
		appUtils.bindEvent($(_pageId+" .header .icon_back"),function(){
			pageBack();
		});
		
		/* 重新上传照片 */
		appUtils.bindEvent($(_pageId+" .photo_again"),function(){
			var param = {
				user_id : appUtils.getSStorageInfo("user_id"),
				lastcomplete_step : "0", 
				opacctkind_flag : ""  
			};
			service.queryChangeState(param,function(data){
				var error_no = data.error_no;
				var error_info = data.error_info;
				if(error_no == 0)
				{
					appUtils.setSStorageInfo("idInfo","exist");
					appUtils.pageInit("account/videoNotice","account/uploadPhoto",{});
				}
				else
				{
					layerUtils.iLoading(false);
					layerUtils.iMsg(-1,error_info); 
				}
			});
		});
		
		/* 重新提交资料 */
		appUtils.bindEvent($(_pageId+" .info_again"),function(){
			var Flag = false;
			var currentStep = appUtils.getSStorageInfo("currentStep");
			if(currentStep == "uploadimg" || currentStep == null)
			{
				Flag = true;
			}
			else
			{
				Flag = false;
			}
			var param = {
				user_id : appUtils.getSStorageInfo("user_id"),
				lastcomplete_step : "uploadimg", 
				opacctkind_flag : ""  
			};
			service.queryChangeState(param,function(data){
				var error_no = data.error_no;
				var error_info = data.error_info;
				if(error_no == 0)
				{
					pageBack();
				}
				else
				{
					layerUtils.iLoading(false);
					layerUtils.iMsg(-1,error_info); 
				}
			}, Flag);
		});
		
		/* 申请QQ预约 */
		appUtils.bindEvent($(_pageId+" .c_link"),function(){
			appUtils.pageInit("account/videoNotice","account/orderQq",{});
		});
		
		/* 在线视频视频见证 */
		appUtils.bindEvent($(_pageId+" .ct_btn:eq(0)"),function(){
				var param = {
					"url":global.serverPath+"?",
		            "userId":appUtils.getSStorageInfo("user_id"),
		            "userName":appUtils.getSStorageInfo("custname"),
		            "orgId":appUtils.getSStorageInfo("branchno"),
		            "userType" : "1",
		            "jsessionId":appUtils.getSStorageInfo("jsessionid"),
		            "netWorkStatus":"WIFI",
		            //"clientinfo":appUtils.getSStorageInfo("clientinfo")
		            "funcNo":"60005"
                   // "moduleName":"main"
	            };
				//require("shellPlugin").callShellMethod("videoWitnessPlugin",null,null,param);
				external.callMessage(param);
		});
		
		/* 继续开户 */
		appUtils.bindEvent($(_pageId+" .ct_btn:eq(1)"),function(){
			queryQQOfflineState();  // 查询视频通过状态
		});
	}
	
	function destroy()
	{
		// 页面初始化样式重置
		$(_pageId+" .header h3:eq(0)").show();
		$(_pageId+" .header h3:eq(1)").hide();
		$(_pageId+" .error_notice:eq(0)").hide();
		$(_pageId+" .error_notice:eq(1)").hide();
		$(_pageId+" .camera_notice:eq(0)").show();
		$(_pageId+" .camera_notice:eq(1)").hide();
		$(_pageId+" .photo_again").hide();
		$(_pageId+" .info_again").hide();
		$(_pageId+" .c_link").show();
		$(_pageId+" .fix_bot").show();
		$(_pageId+" .fix_bot .ct_btn:eq(0)").show();
		$(_pageId+" .fix_bot .ct_btn:eq(1)").hide();
		service.destroy();
	}
	
	/* 处理返回按钮 */
	function pageBack()
	{
		var currentStep = appUtils.getSStorageInfo("currentStep");
		// 从短信登陆进入(当前完成步骤为：已提交资料)，处理返回按钮
		if(currentStep == "idconfirm")
		{
			appUtils.setSStorageInfo("currentStep","uploadimg");
			appUtils.setSStorageInfo("personInfo","exist");  // 标记完成资料填写步骤
			appUtils.pageInit("account/videoNotice","account/personInfo",{});
		}
		// 从短信登陆进入，在personInfo提交资料后，处理返回按钮
		else if(appUtils.getSStorageInfo("currentStep") == "uploadimg")
		{
			appUtils.setSStorageInfo("personInfo","exist");  // 标记完成资料填写步骤
			appUtils.pageBack();
		}
		// 正常开户流程处理返回按钮
		else
		{
			appUtils.pageBack();
		}
	}
	
	/* 初始化页面 */
	function initPage()
	{
		needVideo = appUtils.getPageParam("need_video");  
		if(needVideo == 1)
		{
			$(_pageId+" .main .step_box").hide();
			$(_pageId+" .main .error_notice:eq(0)").show();
		}
	}
	
	/* 获取营业部视频端口 */
	function getVedioport()
	{
		//获取营业部视频端口
		/*var param={
			"branchno":appUtils.getSStorageInfo("branchno"),
			"user_id":appUtils.getSStorageInfo("user_id")
		};
		alert(JSON.stringify(param));
		service.queryVideoAddress(param,function(data){
			alert(JSON.stringify(data));
			 if(data.error_no=="0" && data.results.length != 0)
			 {
				appUtils.setSStorageInfo("branch_id",data.results[0].branch_id);
				appUtils.setSStorageInfo("branch_url",data.results[0].url);
				// 如果是从短信验证码页面跳转过来的，从 session 中取 QQ 号并填充
				if(appUtils.getSStorageInfo("_prePageCode") == "account/msgVerify")
				{
					 queryQQOfflineState();  // 查询视频通过状态
				}
			 }
			 else
			 {
				 layerUtils.iMsg(-1,"获取视频服务器IP端口异常");  //提示错误信息
			 }
		 },true,true,handleTimeout);*/
		if(appUtils.getSStorageInfo("_prePageCode") == "account/msgVerify")
		{
			 queryQQOfflineState();  // 查询视频通过状态
		}else{
			layerUtils.iLoading(false);  //关闭等待层
		}
	}
	
	/* 处理请求超时 */
	/*function handleTimeout()
	{
		layerUtils.iConfirm("请求超时，是否重新加载？",function(){
			getVedioport();  // 再次获取视频端口
		});
	}*/
	
	/* 查询离线视频通过状态 */
	function queryQQOfflineState()
	{
		var lookVedioStateParam = {
			"user_id" : appUtils.getSStorageInfo("user_id")
		};
		service.queryQQOfflineState(lookVedioStateParam,function(data){
			console.log("111111111111111111111"+JSON.stringify(data));
			var error_no = data.error_no;
			var error_info = data.error_info;
			if(error_no == 0 && data.results.length != 0)
			{
				// 视频通过状态，0：未见证、2：已预约离线见证未完成见证、1：视频见证完成、3：见证失败
				// 未见证不需要做处理
				var witnessFlag = data.results[0].witness_flag;
				if(witnessFlag == 1)
				{
//					layerUtils.iConfirm("您的视频审核已通过，接下来即将为您安装数字证书...", function(){
//						appUtils.pageInit("account/videoNotice","account/digitalCertificate",{});
//					},function(){return false;});
					
										//判断是否需要证书
					if(appUtils.getSStorageInfo("flag") == "1"){
							
						layerUtils.iConfirm("您的视频审核已通过，接下来即将为您安装数字证书...", function(){
							appUtils.pageInit("account/videoNotice","account/digitalCertificate",{});
						},function(){return false;});
					}else{
						
						appUtils.pageInit("account/videoNotice","account/signProtocol",{});
					}

					
				}
				else if(witnessFlag == 2)
				{
					layerUtils.iAlert("您的预约信息已经提交，我们的客服将尽快联系您！",0);
				}
				else if(witnessFlag == 3)
				{
					$(_pageId+" .c_link").show();
					$(_pageId+" .fix_bot .ct_btn:eq(0)").show();
					$(_pageId+" .fix_bot .ct_btn:eq(1)").hide();
					layerUtils.iAlert("视频见证失败，请重新申请见证！");
				}
				else if(witnessFlag == 4)
				{
					layerUtils.iAlert("资料审核中，工作人员会尽快给您回复，请耐心等候！");
				}
			}
			else
			{
				layerUtils.iAlert(data.error_info);
			}
		});
	}
	
	/* 见证通过 */
	function videoSuccess()
	{
		console.log("111111111111111111111  通过");
		$(_pageId+" .fix_bot .ct_btn:eq(0)").hide();
		$(_pageId+" .fix_bot .ct_btn:eq(1)").show();
		$(_pageId+" .c_link").hide();
		queryQQOfflineState();  // 查询视频通过状态
	}
	
	/* 见证不通过 */
	function videoFail(){}
	
	/* 见证被驳回 */
	function videoReject()
	{
		$(_pageId+" .header h3:eq(0)").hide();
		$(_pageId+" .header h3:eq(1)").show();
		$(_pageId+" .error_notice:eq(0)").hide();
		$(_pageId+" .error_notice:eq(1)").show();
		$(_pageId+" .camera_notice:eq(0)").hide();
		$(_pageId+" .camera_notice:eq(1)").show();
		$(_pageId+" .photo_again").show();
		$(_pageId+" .info_again").show();
		$(_pageId+" .c_link").hide();
		$(_pageId+" .fix_bot").hide();
	}
	
	/* QQ预约 */
	function qqApplay()
	{
		appUtils.pageInit("account/videoNotice","account/orderQq",{});
	}

	//视频见证判断
	function videoFlag(videoFlag) {
		console.log(JSON.stringify(videoFlag));
	
		var videoFlag = videoFlag.videoFlag;
		if (videoFlag == "0") {
			//见证通过
			$(_pageId+" .fix_bot .ct_btn:eq(0)").hide();
			$(_pageId+" .fix_bot .ct_btn:eq(1)").show();
			$(_pageId+" .c_link").hide();
			queryQQOfflineState();  // 查询视频通过状态
		} else if (videoFlag == "1") {
			//见证失败
		} else if (videoFlag == "2") {
			//见证驳回
			$(_pageId+" .header h3:eq(0)").hide();
			$(_pageId+" .header h3:eq(1)").show();
			$(_pageId+" .error_notice:eq(0)").hide();
			$(_pageId+" .error_notice:eq(1)").show();
			$(_pageId+" .camera_notice:eq(0)").hide();
			$(_pageId+" .camera_notice:eq(1)").show();
			$(_pageId+" .photo_again").show();
			$(_pageId+" .info_again").show();
			$(_pageId+" .c_link").hide();
			$(_pageId+" .fix_bot").hide();
		}
	}

	var videoNotice = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"pageBack" : pageBack,
		"destroy" : destroy,
		"videoFlag" : videoFlag
	};
	
	// 暴露对外的接口
	module.exports = videoNotice;
});

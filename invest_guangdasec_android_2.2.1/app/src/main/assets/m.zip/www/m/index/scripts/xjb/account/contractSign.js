/*
 * 签署电子合同
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	_pageId = "#xjb_account_contractSign ";
	var dzht_flag = false;
	var dzqmyds_flag = false;
	var external = require("external");
	/*
	 * 页面初始化
	 */
	function init(){
		//设置页面高度
		$(_pageId + " .main").height($(window).height() - $(_pageId + " .header").height());
		$(_pageId + " .main").css("overflow-y","auto");
		
		//获取username
		var user=appUtils.getSStorageInfo("userinfo");
		var userinfo=JSON.parse(user);
		$(_pageId + " .main .row_01 .em_name").html(userinfo.user_name);
		
		//查询协议属性
		var ProtocolArray = [appUtils.getSStorageInfo("pro_code_qys"),appUtils.getSStorageInfo("pro_code_ht"),appUtils.getSStorageInfo("pro_code_fxjss")]
		for(var i = 0;i<ProtocolArray.length;i++){
			queryProtocolAttr(ProtocolArray[i],i);
		}
		
		fxcp=appUtils.getPageParam("fxcp");
		isTa=appUtils.getPageParam("isTa");
	}
	
	function queryProtocolAttr(protocols,index){
		service.queryProtocolAttr({"pro_code":protocols},function(data){
			if(data.error_no == 0){
				var pro_content = data.results[0].pro_content,
					pro_code = data.results[0].pro_code,
					file_name = data.results[0].file_name;
				$(_pageId+" .ydbobk a").eq(index).html("《"+data.results[0].pro_title+"》").attr("pro_content",pro_content).attr("pro_code",pro_code).attr("file_name",file_name);
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		});
	}
	
	/*
	 * 绑定页面事件	 */
	function bindPageEvent(){
		
		//返回
		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(){
			pageBack();
		});
		
		//跳转
		appUtils.bindEvent($(_pageId+" .ydbobk a"),function(e){
			var param = {
				pro_content:$(this).attr("pro_content"),
				pro_code:$(this).attr("pro_code"),
				file_name:$(this).attr("file_name")
			}
			showDzht(param);
			// if($(this).index() == 0){//跳转电子签名约定书
				// // showDzht(appUtils.getSStorageInfo("pro_code_qys"));
			// }
			// if($(this).index() == 1){//跳转电子合同
				// // showDzht(appUtils.getSStorageInfo("pro_code_ht"));
			// }
			// if($(this).index() == 2){//跳转风险揭示书
				// // showDzht(appUtils.getSStorageInfo("pro_code_fxjss"));
			// }
			e.stopPropagation();
		});
		
		//同意签署
		appUtils.bindEvent($(_pageId + ".readagree p"),function(e){
			$(this).toggleClass("check");
			isCheck();
			e.stopPropagation();
		});
		
		//下一步跳转
		appUtils.bindEvent($(_pageId + ".main .definbtn_02"),function(e){
			if($(this).hasClass("isBlue")){
				//签署合同和电子签名约定书
				signDzxy(); //签名约定书
				setCyzt();  //电子合同
				if(dzqmyds_flag && dzht_flag){
					layerUtils.iAlert("现金宝开户成功",0,function(){
						appUtils.pageInit("xjb/account/contractSign","xjb/navigation/index",{});
					});
				}
			}
			e.stopPropagation();
		});
	}
	
	function isCheck(){
		if($($(_pageId + ".readagree p")[0]).hasClass("check") && $($(_pageId + ".readagree p")[1]).hasClass("check")){
			$(_pageId + " .main .definbtn_02").css("background","#1199EE");
			$(_pageId + " .main .definbtn_02").addClass("isBlue");
		}else{
			$(_pageId + " .main .definbtn_02").css("background","#bebebe");
			$(_pageId + " .main .definbtn_02").removeClass("isBlue");
		}
	}
	
	/**
	 * 展示协议
	 */
	function showDzht(param){
		// service.queryProtocolAttr({"pro_code":protocols},function(data){
			// if(data.error_no == 0){
				// var param = {
					// "pro_content":data.results[0].pro_content,
					// "pro_code":data.results[0].pro_code,
					// "file_name":data.results[0].file_name
				// };
		service.getProtocolContent(param,function(data){
			if(data.error_no == 0){
				var pdfUrl = global.pdfUrl + "/" + data.results[0].pdf_url;
				var results = external.callMessage({"funcNo":"50240","url":pdfUrl});
				console.log(JSON.stringify(results));
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		});
			// }else{
				// layerUtils.iLoading(false);
				// layerUtils.iAlert(data.error_info);
			// }
		// });
   	}
	
	/**
	 * 签署电子协议
	 */
	function signDzxy(){
		//获取手机号
		var mobilePhone = require("external").callMessage({"funcNo":"50043","key":"mobilePhone"}).results[0].value;
		
		var user=appUtils.getSStorageInfo("userinfo");
		var userinfo=JSON.parse(user);
		var s="1002";
		if(userinfo.user_type=="0"){
			s="1001";
		}
		var param = {
			"account":appUtils.getSStorageInfo("fund_account"),
			"ezt_name":userinfo.user_code,
			"ticket":"",
			"risk_uncover":0,
			"com_sign":0,
			"survey_sn":s,
			"entrust_way":"SJWT",
			//20160923送手机号
			"mobile_channel":require("gconfig").platform,
			"mobile":mobilePhone
		};
		service.signDzxy(param,function(data){
			if(data.error_no == 0){
   				dzqmyds_flag = true;
   			}else{
   				layerUtils.iLoading(false);
   				var error = data.error_info;
   				//后台返回的提示信息不友好
   				if(error.indexOf("SQL")> -1){
   					error = error.split("SQL")[0];
   					var len = error.length;
   					error = error.substring(0,len-2);
   				}
   				layerUtils.iAlert(error);
   			}
		},{isAsync:false});
	}
	
   	/**
   	 * 签署电子合同，设置参与状态
   	 */
   	function setCyzt(){
		//获取手机号
		var mobilePhone = require("external").callMessage({"funcNo":"50043","key":"mobilePhone"}).results[0].value;
		
   		var user=appUtils.getSStorageInfo("userinfo");
   		var userinfo=JSON.parse(user);
   		var s="1002";
   		if(userinfo.user_type=="0"){
   			s="1001";
   		}
   		var param = {
   			"account":appUtils.getSStorageInfo("fund_account"),
   			"market":1,
   			"elecstatus":1,
   			"ezt_name":userinfo.user_code,
   			"ticket":"",
   			"risk_uncover":0,
   			"com_sign":0,
   			"survey_sn":s,
   			"entrust_way":"SJWT",
			"mobile_channel":require("gconfig").platform,
			"mobile":mobilePhone
   		};

   		service.setCyzt(param,function(data){
   			if(data.error_no == 0){
   				dzht_flag = true;
   			}else{
   				layerUtils.iLoading(false);
   				var error = data.error_info;
   				//后台返回的提示信息不友好
   				if(error.indexOf("SQL")> -1){
   					error = error.split("SQL")[0];
   					var len = error.length;
   					error = error.substring(0,len-2);
   				}
   				layerUtils.iAlert(error);
   			}
   		},{isAsync:false});
   	}
	
	/*
	 * 销毁页面
	 */
	function destroy(){
		$(_pageId + ".readagree p").removeClass("check");
		$(_pageId + " .main .definbtn_02").css("background","#bebebe");
		$(_pageId + " .main .definbtn_02").removeClass("isBlue");
		dzht_flag = false;
		dzqmyds_flag = false;
	}
	
	function pageBack(){
		appUtils.pageInit("xjb/account/contractSign","xjb/account/index",{"_isTa": fxcp,"_isTa": isTa});
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy,
			"pageBack":pageBack
	};
	//暴露方法
	module.exports = base;
});
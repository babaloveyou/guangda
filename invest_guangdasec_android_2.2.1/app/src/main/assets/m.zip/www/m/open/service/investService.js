/**
 * 手机前端Service层调用接口
 */

define(function(require,exports,module){
    var appUtils = require("appUtils");
    var gconfig = require("gconfig");
    var global = gconfig.global;
    var service = require("service");
    var serviceSingleton = new service.Service();

    /********************************公共代码部分********************************/
    function commonInvoke(paraMap, callback, ctrlParam, reqParamVo){
        reqParamVo.setReqParam(paraMap);
        ctrlParam = ctrlParam?ctrlParam:{};
        reqParamVo.setIsLastReq(ctrlParam.isLastReq);
        reqParamVo.setIsAsync(ctrlParam.isAsync);
        reqParamVo.setIsShowWait(ctrlParam.isShowWait);
        reqParamVo.setTimeOutFunc(ctrlParam.timeOutFunc);
        reqParamVo.setIsShowOverLay(ctrlParam.isShowOverLay);
        reqParamVo.setTipsWords(ctrlParam.tipsWords);
        reqParamVo.setDataType(ctrlParam.dataType);
        reqParamVo.setIsGlobal(ctrlParam.isGlobal);
        reqParamVo.setProtocol(ctrlParam.protocol);
        serviceSingleton.invoke(reqParamVo, callback);
    }

    function destroy(){
        serviceSingleton.destroy();
    }

    var mobileService = {
        //为了避免以前调用getInstance方法报错
        "getInstance": getInstance,
        "destroy": destroy
    };

    function getInstance(){
        return mobileService;
    }

    module.exports = mobileService;

       /**
         * 获取营业部代码(501498)
         * @param op_way
         * @param mobile_no 手机号码
         * @param ip 客户IP地址
         * @param mac 设备mac地址
         * @param callback 回调函数
         * @param isLastReq 是否最后一次请求
         * @param isShowWait 是否显示等待层
         */
        mobileService.getBranchLocation = function(param,callback,ctrlParam)
        {
            var paraMap = {};
            paraMap["funcNo"] = "501498";
            paraMap["branchcode"] = param.branchcode;

            var reqParamVo = new service.ReqParamVo();
            reqParamVo.setUrl(global.serverPath);
            commonInvoke(paraMap, callback, ctrlParam, reqParamVo);

        };

    /********************************应用接口开始********************************/
    /**
     * 短信验证码发送(501520)
     * @param op_way 访问接口来源标识(0：pc,2：pad,3：手机)
     * @param mobile_no 手机号码
     * @param ip 客户IP地址
     * @param mac 设备mac地址
     * @param verify_code 图形验证码
     */
    mobileService.getSmsCode = function(param,callback,ctrlParam){
        var paraMap = {};
        paraMap["funcNo"] = "501520";
        paraMap["op_way"] = param.op_way;
        paraMap["mobile_no"] = param.mobile_no;
        paraMap["ip"] = param.ip;
        paraMap["mac"] = param.mac;
        paraMap["verify_code"] = param.verify_code;

        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     * 登录短信验证码校验(501521)
     * @param mobile_no 手机号码
     * @param mobile_code 手机验证码
     * @param login_flag 登录业务标准 新开户0  转户1  理财户2
     */
    mobileService.checkSmsCode = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501521";
        paraMap["mobile_no"] = param.mobile_no;
        paraMap["mobile_code"] = param.mobile_code;
        paraMap["login_flag"] = param.login_flag;

        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     * 查询营业部数据(501503)
     * @param callback 回调函数
     */

    mobileService.queryBranch = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501503";

        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };


    /**
     * 获取数字证书申请责任书协议信息
     * @param cert_flag 1中登协议，2自建证书协议,默认中登
     * @param callback 回调函数
     */
    mobileService.queryCertAgreement = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501523";
        paraMap["cert_flag"] = param.cert_flag;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     * 获取邮编信息
     * @param addr 地址
     * @param callback 回调函数
     */
    mobileService.queryPostid = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501557";
        paraMap["addr"] = param.addr;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     * 获取数据字典
     * @param enum_type "occupational"为职业,"adapter"为学历,"zqzhlx"为开通证券类型
     * @param callback 回调函数
     */
    mobileService.queryDataDict = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501501";
        paraMap["enum_type"] = param.enum_type;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };


    /**
     * 开户信息资料提交 (501528)
     * @param user_id            客户编号
     * @param infocolect_channel 信息来源渠道( 0：pc，2：pad，3：手机)
     * @param idtype             证件类别(00 身份证)
     * @param idno               身份证号
     * @param custname           客户姓名
     * @param ethnicname         民族
     * @param birthday           生日
     * @param idbegindate        证件开始日期
     * @param idenddate          证件结束日期
     * @param native             证件地址
     * @param policeorg          签发机关
     * @param usersex            性别(0男，1女)
     * @param nationality        国籍(156)
     * @param addr               联系地址
     * @param postid             邮政编码
     * @param edu                学历代码
     * @param profession_code    职业代码
     * @param branchno           营业部代码
     * @param commission        佣金代码
     * @param provinceno         省份
     * @param cityno             城市
     * @param ipaddr             IP地址
     * @param macaddr            mac地址
     * @param recommendno        推荐人号码
     * @param callback           回调函数
     */
    mobileService.submitUserInfo = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501528";
        paraMap["user_id"] = param.user_id;
        paraMap["infocolect_channel"] = param.infocolect_channel;
        paraMap["idtype"] = param.idtype;
        paraMap["idno"] = param.idno;
        paraMap["custname"] = param.custname;
        paraMap["ethnicname"] = param.ethnicname;
        paraMap["birthday"] = param.birthday;
        paraMap["idbegindate"] = param.idbegindate;
        paraMap["idenddate"] = param.idenddate;
        paraMap["native"] = param.native;
        paraMap["policeorg"] = param.policeorg;
        paraMap["usersex"] = param.usersex;
        paraMap["nationality"] = param.nationality;
        paraMap["addr"] = param.addr;
        paraMap["postid"] = param.postid;
        paraMap["edu"] = param.edu;
        paraMap["profession_code"] = param.profession_code;
        paraMap["branchno"] = param.branchno;
        paraMap["commission"] = param.commission;
        paraMap["provinceno"] = param.provinceno;
        paraMap["cityno"] = param.cityno;
        paraMap["ipaddr"] = param.ipaddr;
        paraMap["macaddr"] = param.macaddr;
        paraMap["submitflag"] = param.submitflag;
        paraMap["recommendno"] = param.recommendno;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };


    /**
     * 账户系统存在性查询(501527)
     * @param idtype 证件类型
     * @param idno   身份证号码
     * @param callback 回调函数
     */
    mobileService.queryUserInfoExistSys = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501527";
        paraMap["idtype"] = "00";
        paraMap["idno"] = param.idno;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     *  中登查询股东账号是否存在(501553)
     * @param user_id 用户ID
     * @param callback 回调函数
     */
    mobileService.queryUserInfoExistCompy = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501553";
        paraMap["user_id"] = param.user_id;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     *  转户模拟QQ视频通过同步用户信息专用 (501599)
     * @param user_id 用户ID
     * @param callback 回调函数
     */
    mobileService.syncQQUserInfo = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501599";
        paraMap["user_id"] = param.user_id;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     *  查询离线视频通过状态查询 (501546)
     * @param user_id 用户ID
     * @param callback 回调函数
     */
    mobileService.queryQQOfflineState = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501546";
        paraMap["user_id"] = param.user_id;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     *  流程更改 (501566)
     * @param user_id 用户编号
     * @param uploadimg_flag  1：身份证上次成功
     * @param opacctkind_flag 0：新开，1：转户
     */
    mobileService.queryChangeState = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501566";
        paraMap["user_id"] = param.user_id;
        paraMap["uploadimg_flag"] = param.uploadimg_flag;
        paraMap["opacctkind_flag"] = param.opacctkind_flag;
        paraMap["lastcomplete_step"] = param.lastcomplete_step;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     *  查询用户信息(501567)
     * @param user_id 用户编号
     */
    mobileService.queryUserInfo = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501567";
        paraMap["user_id"] = param.user_id;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     * 获取数字证书申请责任书协议信息 (501523)
     * @param cert_flag 1中登协议，2自建证书协议
     * @param callback 回调函数
     */
    mobileService.queryAgreementTitle = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501523";
        paraMap["cert_flag"] = param.cert_flag;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     * 中登证书获取（501529）
     * @param user_id 客户编号
     * @param pkcs10  证书申请串(由手机壳子生成)
     * @param callback 回调函数
     */
    mobileService.queryCompyCart = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501529";
        paraMap["user_id"] = param.user_id;
        paraMap["pkcs10"] = encodeURIComponent(param.pkcs10);
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };


    /**
     * 自建证书获取，天威（501530）
     * @param user_id 客户编号
     * @param pkcs10  证书申请串(由手机壳子生成)
     * @param callback 回调函数
     */
    mobileService.queryMyselfCart = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501530";
        paraMap["user_id"] = param.user_id;
        paraMap["pkcs10"] = encodeURIComponent(param.pkcs10);
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     *  开户协议列表获取(501531)--证书下载界面
     * @param callback 回调函数
     */
    mobileService.queryOpenAgreement = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501531";
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     * 开立资金账户与客户号(501533)
     * @param user_id 客户编号
     * @param callback 回调函数
     */
    mobileService.queryOpenAccount = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501533";
        paraMap["user_id"] = param.user_id;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     * 开立中登账户(501534)
     * @param user_id 客户编号
     * @param sza_str 深A开通情况
     * @param sha_str 沪A开通情况
     * @param szfnd_str 深基金开通情况
     * @param shfnd_str 沪基金开通情况
     * @param opfnd_str 沪基金开通情况
     * @param callback 回调函数
     */
    mobileService.queryOpenCompyAccount = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501534";
        paraMap["user_id"] = param.user_id;
        paraMap["sza_str"] = param.sza_str;
        paraMap["sha_str"] = param.sha_str;
        paraMap["szfnd_str"] = param.szfnd_str;
        paraMap["shfnd_str"] = param.shfnd_str;
        paraMap["opfnd_str"] = param.opfnd_str;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };


    /**
     * 中登签名批量验签（MD5方式）(501554)
     * @param callback 回调函数
     */
    mobileService.queryOpenCheckSign = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501554";
        paraMap["user_id"] = param.user_id;
        paraMap["jsondata"] = param.jsondata;
        paraMap["ipaddr"] = param.ipaddr;
        paraMap["macaddr"] = param.macaddr;
        paraMap["checksign"] = param.checksign;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     * 天威签名批量验签（MD5方式）(501555)
     * @param callback 回调函数
     */
    mobileService.queryOpenCheckTsign = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501555";
        paraMap["user_id"] = param.user_id;
        paraMap["jsondata"] = param.jsondata;
        paraMap["ipaddr"] = param.ipaddr;
        paraMap["macaddr"] = param.macaddr;
        paraMap["checksign"] = param.checksign;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };


    /**
     * 查询协议内容 (501524)
     * @param protocol_id 协议ID
     * @param callback 回调函数
     */
    mobileService.queryProtocolText = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501524";
        paraMap["protocol_id"] = param.protocol_id;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };


    /**
     * 设置交易密码和资金密码(501535)
     * @param user_id        用户编号
     * @param acct_clientid  账户系统客户号
     * @param password  密码
     * @param pwd_type  密码类型(1:资金密码 2:交易密码)
     * @param is_same  资金密码和交易密码是否一致(1:一致 0：不同)
     * @param callback 回调函数
     */
    mobileService.setAccountPwd = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501535";
        paraMap["user_id"] = param.user_id;
        paraMap["acct_clientid"] = param.acct_clientid;
        paraMap["password"] = param.password;
        paraMap["pwd_type"] = param.pwd_type;
        paraMap["is_same"] = param.is_same;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };


    /**
     * 查询存管银行信息列表(501536)
     * @param user_id     用户编号
     * @param zzbindtype  自助绑定方式(1一步式，2预指定)
     * @param zzispwd     自助一步式绑定是否需要密码(1需要，0不需要)
     * @param callback 回调函数
     */
    mobileService.queryBankList = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501536";
        paraMap["bindtype"] = param.bindtype;
        paraMap["ispwd"] = param.ispwd;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };


    /**
     * 存管银行签约电子协议列表(501537)
     * @param user_id     用户编号
     * @param bankcode    银行代码
     * @param callback    回调函数
     */
    mobileService.queryBankProtocolList = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501537";
        paraMap["bank_code"] = param.bank_code;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };


    /**
     * 存管银行绑定(501538)
     * @param user_id          用户编号
     * @param acct_clientid    账户系统客户号
     * @param acct_fndacct     账户系统资金账号
     * @param bank_code	       银行代码
     * @param bank_account     银行账号
     * @param bank_pwd         银行密码
     * @param op_type          存管绑定方式(自助绑定方式：1一步式，2预指定)
     * @param callback    回调函数
     */
    mobileService.bindBank = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501538";
        paraMap["user_id"] = param.user_id;
        paraMap["acct_clientid"] = param.acct_clientid;
        paraMap["acct_fndacct"] = param.acct_fndacct;
        paraMap["bank_code"] = param.bank_code;
        paraMap["bank_account"] = param.bank_account;
        paraMap["bank_pwd"] = param.bank_pwd;
        paraMap["op_type"] = param.op_type;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };


    /**
     * 驳回后修改资料 (501561)
     * @param userid     用户编号
     * @param fieldname   驳回步骤(zj_pwd资金密码、trade_pwd交易密码、bind_bank三方存管、photo图片、workflowagain重新走流程、opacctkind_flag开户流程业务类型)
     * @param callback    回调函数
     */
    mobileService.rejectStep = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501561";
        paraMap["user_id"] = param.user_id;
        paraMap["fieldname"] = param.fieldname;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };


    /**
     * 查询风险评测题库(501539)
     * @param user_id     用户编号
     * @param callback    回调函数
     */
    mobileService.queryRiskToc = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501539";
        paraMap["user_id"] = param.user_id;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };


    /**
     * 获取视频地址 (501562)
     * @param user_id     用户编号
     * @param callback    回调函数
     */
    mobileService.queryVideoAddress = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501562";
        paraMap["user_id"] = param.user_id;
        paraMap["branchno"] = param.branchno;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };


    /**
     * 提交视频见证预约信息(501545)
     * @param user_id     用户编号
     * @param qq          QQ号码
     * @param deal_date   预约处理日期
     * @param deal_time   预约处理时间
     * @param callback    回调函数
     */
    mobileService.submitQQApplay = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501545";
        paraMap["user_id"] = param.user_id;
        paraMap["qq"] = param.qq;
        paraMap["deal_date"] = param.deal_date;
        paraMap["deal_time"] = param.deal_time;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };


    /**
     * 获取回访问卷(501541)
     * @param user_id     用户编号
     * @param qq          QQ号码
     * @param sub_id
     * @param callback    回调函数
     */
    mobileService.getVisitSub = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501541";
        paraMap["user_id"] = param.user_id;
        paraMap["sub_id"] = param.sub_id;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };


    /**
     * 提交问卷回访答案(501542)
     * @param user_id     用户编号
     * @param sub_id      回访问卷编号
     * @param q_a_args    问卷答题字符串
     * @param callback    回调函数
     */
    mobileService.submitVisitAnswer = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501542";
        paraMap["user_id"] = param.user_id;
        paraMap["sub_id"] = param.sub_id;
        paraMap["q_a_args"] = param.q_a_args;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     * 提交风险评测答案(501540)
     * @param user_id     用户编号
     * @param sub_id      回访问卷编号
     * @param q_a_args    问卷答题字符串
     * @param callback    回调函数
     */
    mobileService.submitTestAnswer = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501540";
        paraMap["user_id"] = param.user_id;
        paraMap["sub_id"] = param.sub_id;
        paraMap["q_a_args"] = param.q_a_args;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };


    /**
     *	查询电子协议列表(501558)
     * @param category_englishname 电子协议英文名
     * @param category_no 类别编号
     * @param econtract_no 协议编号
     * @param callback 回调函数
     */
    mobileService.queryProtocolList = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501558";
        paraMap["category_englishname"] = param.category_englishname;
        paraMap["category_no"] = param.category_no;
        paraMap["econtract_no"] = param.econtract_no;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     *	查询电子协议内容(501559)
     * @param econtract_no 电子协议编号
     * @param econtract_version 电子协议版本
     * @param callback 回调函数
     */
    mobileService.getProtocolInfo = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501559";
        paraMap["econtract_no"] = param.econtract_no;
        paraMap["econtract_version"] = param.econtract_version;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     *	移动客户端版本检测 (501560)
     * @param terminal_type 客户端类型
     * @param callback 回调函数
     */
    mobileService.getVersion = function(param,callback,ctrlParam) {
        var paraMap = {};
     // paraMap["funcNo"] = "501916";
         paraMap["funcNo"] = "501560";
     // paraMap["channel"] = param.channel;
        paraMap["terminal_type"] = param.terminal_type;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     * 获取当前省份、城市（501568）
     * @param ip  ip地址
     * @param callback 回调函数
     */
    mobileService.getProvCity = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501568";
        paraMap["ip"] = param.ip;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     * 身份证信息提交 (501569)
     * @param user_id            客户编号
     * @param infocolect_channel 信息来源渠道( 0：pc，2：pad，3：手机)
     * @param idtype             证件类别(00 身份证)
     * @param idno               身份证号
     * @param custname           客户姓名
     * @param ethnicname         民族
     * @param birthday           生日
     * @param idbegindate        证件开始日期
     * @param idenddate          证件结束日期
     * @param native             证件地址
     * @param policeorg          签发机关
     * @param usersex            性别(0男，1女)
     * @param nationality        国籍(156)
     * @param addr               联系地址
     * @param postid             邮政编码
     * @param edu                学历代码
     * @param profession_code    职业代码
     * @param branchno           营业部代码
     * @param commission        佣金代码
     * @param provinceno         省份
     * @param cityno             城市
     * @param ipaddr             IP地址
     * @param macaddr            mac地址
     * @param callback           回调函数
     */
    mobileService.submitPhoto = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501569";
        paraMap["user_id"] = param.user_id;
        paraMap["infocolect_channel"] = param.infocolect_channel;
        paraMap["idtype"] = param.idtype;
        paraMap["idno"] = param.idno;
        paraMap["custname"] = param.custname;
        paraMap["ethnicname"] = param.ethnicname;
        paraMap["birthday"] = param.birthday;
        paraMap["idbegindate"] = param.idbegindate;
        paraMap["idenddate"] = param.idenddate;
        paraMap["native"] = param.native;
        paraMap["policeorg"] = param.policeorg;
//		paraMap["usersex"] = param.usersex;
        paraMap["nationality"] = param.nationality;
        paraMap["addr"] = param.addr;
        paraMap["postid"] = param.postid;
        paraMap["edu"] = param.edu;
        paraMap["profession_code"] = param.profession_code;
        paraMap["branchno"] = param.branchno;
        paraMap["commission"] = param.commission;
        paraMap["provinceno"] = param.provinceno;
        paraMap["cityno"] = param.cityno;
        paraMap["ipaddr"] = param.ipaddr;
        paraMap["macaddr"] = param.macaddr;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     * 获取rsa加密模块和公钥
     * @param param  参数
     * @param callback 回调函数
     */
    mobileService.getRSAKey = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "1000000";
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    /**
   	 * 获取套餐信息（501933）
   	 * @param callback 回调函数
   	 */
	mobileService.queryPackage = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
		paraMap["funcNo"] = "501933";
	    var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };  
    
     /**
   	 * 提交套餐与客服经理（501932）
   	 * @param callback 回调函数
   	 */
	mobileService.subPackage = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
		paraMap["funcNo"] = "501932";
		paraMap["userid"] = param.userid;
		paraMap["spk_id"] = param.spk_id;
		paraMap["mgr_id"] = param.mgr_id;
		var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };  
    //公安验证
    mobileService.verification = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501550";
        paraMap["user_name"] = param.user_name;
        paraMap["id_no"] = param.id_no;
        paraMap["mobile_no"] = param.mobile_no;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    //修改用户当前视频方式
    mobileService.changeMethod = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501934";
        paraMap["user_id"] = param.user_id;
        paraMap["witness_way"] = param.witness_way;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    //驳回后比对用户信息
    /**custname 客户姓名
     * idno    证件号码
     * native  证件地址
     * policeorg  签发机关
     * idbegindate  证件开始日期
     * idenddate    证件有效截止日期
     */
    mobileService.compareInfo = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501935";
        paraMap["user_id"] = param.user_id;
        paraMap["custname"] = param.custname;
        paraMap["idno"] = param.idno;
        paraMap["native"] = param.native;
        paraMap["policeorg"] = param.policeorg;
        paraMap["idbegindate"] = param.idbegindate;
        paraMap["idenddate"] = param.idenddate;

        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    //单向视频通过操作
    mobileService.singleVideoPass = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501933";
        paraMap["user_id"] = param.user_id;
        paraMap["videoExist"] = param.videoExist;
        paraMap["videoPath"] = param.videoPath;
        paraMap["start_time"] = param.start_time;
        paraMap["video_length"] = param.video_length;
        paraMap["fileType"] = param.fileType;
        paraMap["autentication_type"] = "2";
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };


    /**
     *	获取证书标识 (501504)
     * @param sys_variable_name 入参类型
     * @param callback 回调函数
     */
    mobileService.getisNeedCert = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501504";
        paraMap["sys_variable_name"] = param.sys_variable_name;
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    	   /**
   	 *	查询是否为黑名单(2000001)
   	 * @param sys_variable_name 类型
   	 * @param callback 回调函数
   	 */
	mobileService.isBlacklist = function(param,callback,ctrlParam)
	{
		var paraMap = {};
		paraMap["funcNo"] = "2000001";
		paraMap["idno"] = param.idno;
		paraMap["idtype"] = "00";
		var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	}
    
    /**
     *	获取视频上云标识 (501943)
     * @param sys_variable_name 入参类型
     * @param callback 回调函数
     */
    mobileService.getIsuploadType = function(param,callback,ctrlParam) {
        var paraMap = {};
        paraMap["funcNo"] = "501943";
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };


    /********************************应用接口结束********************************/
});

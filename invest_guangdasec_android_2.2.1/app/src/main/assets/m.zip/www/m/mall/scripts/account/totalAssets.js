/**
 * 总资产
 */
define(function(require, exports, module) 
	{
	var appUtils = require("appUtils");
	var gconfig = require("gconfig");
	var service = require("mobileService");//业务层接口，请求数据
	var global = gconfig.global;
	var layerUtils = require("layerUtils");
	var _pageId ="#account_totalAssets";

	/*初始化*/
	function init()
	{
		queryAsset();
		//E账号登录查询显示
		ifLoginFlag();
	}

	
	function ifLoginFlag(){
		if(gconfig.platform == "0"){
			var fund_list=appUtils.getSStorageInfo("fund_list");
			if(fund_list ==""|| fund_list == null || fund_list==undefined){
				//资金账号登录屏蔽该模块
			//	layerUtils.iAlert("请用E帐号登录！！！");
				$(_pageId+" #otc1").hide();
				$(_pageId+" #otc2").hide();
			}else{
				useableMoney();
				otcProduct();
			}
		} else {
				var fund_list=appUtils.getSStorageInfo("fund_list");
				if(fund_list ==""|| fund_list == null || fund_list==undefined){
					//资金账号登录屏蔽该模块
					$(_pageId+" #otc1").hide();
					$(_pageId+" #otc2").hide();
				}else{
					useableMoney();
					otcProduct();
				}
		}
	}
	
	
	function bindPageEvent() 
	{

		/* 绑定返回事件 */
		appUtils.bindEvent($(_pageId+" .top_title .icon_back"),function()
			{
			appUtils.pageBack();
			});

		/* 绑定LOGO事件 */
		appUtils.bindEvent($(_pageId+" .header .logo"),function(){
			appUtils.pageInit("account/totalAssets","account/mainPage",{});
		});

		/* 绑定返回首页事件 */
		appUtils.bindEvent($(_pageId+" .icon_mall"),function(){
			appUtils.pageInit("account/totalAssets","account/mainPage",{});
		});

		/* 绑定返人民币资金事件 */
		appUtils.bindEvent($(_pageId+" .china"),function()
			{
			// 隐藏美元和港币资金
			$(_pageId+" #AM").hide();
			$(_pageId+" #HK").hide();
			// 显示人民币资金
			$(_pageId+" #CN").show();

			// 设置样式
			$(_pageId+" .tab_box04 ul li").eq(0).addClass("current");
			$(_pageId+" .tab_box04 ul li").eq(1).removeClass("current");
			$(_pageId+" .tab_box04 ul li").eq(2).removeClass("current");
			});

		/* 绑定美元资金事件 */
		appUtils.bindEvent($(_pageId+" .amreica"),function()
			{
			// 隐藏人民币和港币资金
			$(_pageId+" #CN").hide();
			$(_pageId+" #HK").hide();
			// 显示人美元资金
			$(_pageId+" #AM").show();
			// 设置样式
			$(_pageId+" .tab_box04 ul li").eq(0).removeClass("current");
			$(_pageId+" .tab_box04 ul li").eq(1).addClass("current");
			$(_pageId+" .tab_box04 ul li").eq(2).removeClass("current");
			});

		/* 绑定港币资金事件 */
		appUtils.bindEvent($(_pageId+" .hongkong"),function()
			{
			// 隐藏美元和人民币资金
			$(_pageId+" #CN").hide();
			$(_pageId+" #AM").hide();
			// 显示港币资金
			$(_pageId+" #HK").show();
			// 设置样式
			$(_pageId+" .tab_box04 ul li").eq(0).removeClass("current");
			$(_pageId+" .tab_box04 ul li").eq(1).removeClass("current");
			$(_pageId+" .tab_box04 ul li").eq(2).addClass("current");
			});
	}

	function queryAsset(){
		var fund_account=appUtils.getSStorageInfo("fund_account");
		var param={"fund_account" : fund_account};

		/*调用查询资金接口*/
		service.queryAsset(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result = data.results;
			if(error_no == "0" && result.length != 0)
			{
				if(result[0].money_type ==0){
					if(result[0].current_balance){
						var current_balance=parseFloat(result[0].current_balance);
						$(_pageId+" .cmain .fundBalance").html("￥"+current_balance.toFixed(2));
					}
					else{
						$(_pageId+" .cmain .fundBalance").html('暂无');
					}
					if(result[0].useable_money){
						var useable_money=parseFloat(result[0].useable_money);
						$(_pageId+" .cmain .usefulBalance").html("￥"+useable_money.toFixed(2));
					}
					else{
						$(_pageId+" .cmain .usefulBalance").html('暂无');
					}
					if(result[0].fund_money){
						var fund_money=parseFloat(result[0].fund_money);
						$(_pageId+" .cmain .fundMA").html("￥"+fund_money.toFixed(2));
					}
					else{
						$(_pageId+" .cmain .fundMA").html('暂无');
					}
					if(result[0].stock_money){
						var stock_money=parseFloat(result[0].stock_money);
						$(_pageId+" .cmain .stockMA").html("￥"+stock_money.toFixed(2));
					}
					else{
						$(_pageId+" .cmain .stockMA").html('暂无');
					}
					if(result[0].total_money){
						var total_money=parseFloat(result[0].total_money);
						$(_pageId+" .cmain .totalAssets").html("￥"+total_money.toFixed(2));
					}
					else{
						$(_pageId+" .cmain .totalAssets").html('暂无');
					}
//					$(_pageId+" .cmain .fundBalance").html(result[0].current_balance+"￥"?result[0].current_balance:'暂无');
//					$(_pageId+" .cmain .usefulBalance").html(result[0].useable_money?result[0].useable_money:'暂无');
//					$(_pageId+" .cmain .fundMA").html(result[0].fund_money?result[0].fund_money:'暂无');
//					$(_pageId+" .cmain .stockMA").html(result[0].stock_money?result[0].stock_money:'暂无');
//					$(_pageId+" .cmain .totalAssets").html(result[0].total_money?result[0].total_money:'暂无');

				}
				 if(result[1].money_type ==1){
					 if(result[1].current_balance){
							var current_balance=parseFloat(result[1].current_balance);
							$(_pageId+" .cmain .fundBalance1").html("￥"+current_balance.toFixed(2));
						}
						else{
							$(_pageId+" .cmain .fundBalance1").html('暂无');
						}
						if(result[1].useable_money){
							var useable_money=parseFloat(result[1].useable_money);
							$(_pageId+" .cmain .usefulBalance1").html("￥"+useable_money.toFixed(2));
						}
						else{
							$(_pageId+" .cmain .usefulBalance1").html('暂无');
						}
						if(result[1].fund_money){
							var fund_money=parseFloat(result[1].fund_money);
							$(_pageId+" .cmain .fundMA1").html("￥"+fund_money.toFixed(2));
						}
						else{
							$(_pageId+" .cmain .fundMA1").html('暂无');
						}
						if(result[1].stock_money){
							var stock_money=parseFloat(result[1].stock_money);
							$(_pageId+" .cmain .stockMA1").html("￥"+stock_money.toFixed(2));
						}
						else{
							$(_pageId+" .cmain .stockMA1").html('暂无');
						}
						if(result[1].total_money){
							var total_money=parseFloat(result[1].total_money);
							$(_pageId+" .cmain .totalAssets1").html("￥"+total_money.toFixed(2));
						}
						else{
							$(_pageId+" .cmain .totalAssets1").html('暂无');
						}
//					$(_pageId+" .cmain .fundBalance1").html(result[1].current_balance+"￥"?result[1].current_balance:'暂无');
//					$(_pageId+" .cmain .usefulBalance1").html(result[1].useable_money?result[1].useable_money:'暂无');
//					$(_pageId+" .cmain .fundMA1").html(result[1].fund_money?result[1].fund_money:'暂无');
//					$(_pageId+" .cmain .stockMA1").html(result[1].stock_money?result[1].stock_money:'暂无');
//					$(_pageId+" .cmain .totalAssets1").html(result[1].total_money?result[1].total_money:'暂无');

				}
				 if(result[2].money_type ==2){
					 if(result[2].current_balance){
							var current_balance=parseFloat(result[2].current_balance);
							$(_pageId+" .cmain .fundBalance2").html("￥"+current_balance.toFixed(2));
						}
						else{
							$(_pageId+" .cmain .fundBalance2").html('暂无');
						}
						if(result[2].useable_money){
							var useable_money=parseFloat(result[2].useable_money);
							$(_pageId+" .cmain .usefulBalance2").html("￥"+useable_money.toFixed(2));
						}
						else{
							$(_pageId+" .cmain .usefulBalance2").html('暂无');
						}
						if(result[2].fund_money){
							var fund_money=parseFloat(result[2].fund_money);
							$(_pageId+" .cmain .fundMA2").html("￥"+fund_money.toFixed(2));
						}
						else{
							$(_pageId+" .cmain .fundMA2").html('暂无');
						}
						if(result[2].stock_money){
							var stock_money=parseFloat(result[2].stock_money);
							$(_pageId+" .cmain .stockMA2").html("￥"+stock_money.toFixed(2));
						}
						else{
							$(_pageId+" .cmain .stockMA2").html('暂无');
						}
						if(result[2].total_money){
							var total_money=parseFloat(result[2].total_money);
							$(_pageId+" .cmain .totalAssets2").html("￥"+total_money.toFixed(2));
						}
						else{
							$(_pageId+" .cmain .totalAssets2").html('暂无');
						}
//					$(_pageId+" .cmain .fundBalance2").html(result[2].current_balance+"￥"?result[2].current_balance:'暂无');
//					$(_pageId+" .cmain .usefulBalance2").html(result[2].useable_money?result[2].useable_money:'暂无');
//					$(_pageId+" .cmain .fundMA2").html(result[2].fund_money?result[2].fund_money:'暂无');
//					$(_pageId+" .cmain .stockMA2").html(result[2].stock_money?result[2].stock_money:'暂无');
//					$(_pageId+" .cmain .totalAssets2").html(result[2].total_money?result[2].total_money:'暂无');

				}
			}
			else
			{
				layerUtils.iAlert(error_info);
			}
		});
	}

	
	/**
     * 300023：三方存管可用资金查询
     * 
     */
	function useableMoney(){
		var cust_code=appUtils.getSStorageInfo("cust_code");
		var ticket=appUtils.getSStorageInfo("ticket");
//		var mobilePhone = require("external").callMessage({"funcNo":"50043","key":"mobilePhone"}).results[0].value;
		var mobilePhone ="13111111111";
		var param ={
				"cust_code" : cust_code,
				"mobile" : mobilePhone,
				"ticket" : ticket
		};

		/*三方存管可用资金查询*/
		service.useableMoney(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var results = data.results;
			if(error_no == "0"){
				if(results.length != 0){
					var fund_avl = results[0].fund_avl;
					if(fund_avl == ""){
						fund_avl = "0.00";
					}
					$(_pageId+" #useableMoney").html(fund_avl+"元");
				}else{
					$(_pageId+" #useableMoney").html("0.00"+"元");
				}
			}else{
				layerUtils.iAlert(error_info);
			}
		});
	}

	function destroy()
	{
		service.destroy();
	}

	
	/*
	 * 查询OTC持仓
	 */
	function otcProduct(){
		var cust_code=appUtils.getSStorageInfo("cust_code");
		var ticket=appUtils.getSStorageInfo("ticket");
//		var cust_code = result.user_code; //测试
//		var ticket = result.ticket;  //测试
		var param =
		{
			"user_code" : cust_code,
			"page_recnum" :"",
			"page_reccnt" :"8",
			"ticket" :ticket
		};

		/*查询OTC持仓*/
		service.otcProduct(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var results = data.results;
			if(error_no == "0"){
				if(results.length != 0){
					var all_mkt_val = results[0].all_mkt_val;
					if(all_mkt_val == ""){
						all_mkt_val = 0;
					}
//					$(_pageId+" #marketMoney").html(all_mkt_val);
					$(_pageId+" #totalMoney").html(all_mkt_val+"元");
				}else{
//					$(_pageId+" #marketMoney").html("0");
					$(_pageId+" #totalMoney").html("0.00"+"元");
				}
			}else{
				layerUtils.iAlert(error_info);
			}
		});
	}
	
	var TotalAssets = 
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = TotalAssets;

	});
/**
* 风险测评结果
*/
define(function(require,exports,module){
	var appUtils = require("appUtils"),
		global = require("gconfig").global,
		_pageId = "#account_riskAssessmentResult";
	
	function init()
	{
		//设置按钮显示提示文字
		if(appUtils.getSStorageInfo("openChannel") == "change")
		{
			if(appUtils.getSStorageInfo("finance") == "finance")
			{
				$(_pageId+" .fix_bot .ct_btn a").html("下一步");  // 理财户
			}
			else
			{
				$(_pageId+" .fix_bot .ct_btn a").html("下一步");  // 转户
			}
		}
		else
		{
			$(_pageId+" .fix_bot .ct_btn a").html("下一步");  // 新开户
		}
		
		// 只有从 riskAssessment 跳转过来时，才设置页面的填充数据
		if(appUtils.getSStorageInfo("_prePageCode") == "account/riskAssessment")
		{
			var remark  = appUtils.getPageParam("remark");  //风险等级
			var riskdesc = appUtils.getPageParam("riskdesc"); //风险等级描述
			var showStr = riskdesc;
			// 清空原有内容
			$(_pageId+" div[class='test_level']").text("");
			$(_pageId+" div[class='test_level']").append(showStr);
		}
	}
	
	function bindPageEvent()
	{
		// 重新测评绑定事件
		appUtils.bindEvent($(_pageId+" .test_result p:eq(1) a"),function(){
			appUtils.pageInit("account/riskAssessmentResult","account/riskAssessment",{});
		});
		
		/**
		 * 9.1
		 * 风险测评结果页面进入问卷回访页面
		 */
		appUtils.bindEvent($(_pageId+" .ct_btn"),function(){
			if(global.needConfirm)
			{
				appUtils.pageInit("account/riskAssessmentResult","account/openConfirm",{});
			}
			else
			{
				appUtils.pageInit("account/riskAssessmentResult","account/accountResult",{});
			}
		});
	}
	
	function destroy(){}
	
	var riskAssessmentResult = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	
	module.exports = riskAssessmentResult;
});
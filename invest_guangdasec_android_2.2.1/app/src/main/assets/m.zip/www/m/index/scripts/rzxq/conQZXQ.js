/**
 * 权证行权
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils");
	var layerUtils = require("layerUtils");
	var validatorUtil = require("validatorUtil");
	var gconfig = require("gconfig");
	var global = gconfig.global;
	var service = require("serviceImp");  // 业务层接口，请求数据
	var _pageId = "#rzxq_conQZXQ ";
    
    /**
     * 初始化
     */
	function init() {
        queryQZXQList();
		$(_pageId+".data").scrollTop(0);
		$(_pageId+".data").css("overflow-y","auto");
        var height_meau = $(window).height() - $(_pageId+".header").height() - $(_pageId+".top_nav").height() - 10;
		$(_pageId+".data").height(height_meau); //查询目录添加高度
    }
	
	/**
	 * 事件绑定
	 */
	function bindPageEvent() {
		// 返回按钮
		appUtils.bindEvent($(_pageId + ".top_title .icon_back"), function(e){
			pageBack();
		});
		// 菜单栏跳转
		appUtils.bindEvent($(_pageId+'.top_nav:first ul li a'), function(e){
			var pageCode = _pageId.replace("#","").replaceAll("_","/").replace(" ","");
			if($(this).attr("to-page")){
				var topage = $(this).attr("to-page");
				appUtils.pageInit(pageCode,topage,{});	
			}
			e.stopPropagation();
		 });
		// 菜单栏跳转
		appUtils.bindEvent($(_pageId+'.top_nav:first ul li a'), function(e){
			var pageCode = _pageId.replace("#","").replaceAll("_","/").replace(" ","");
			if($(this).attr("to-page")){
				var topage = $(this).attr("to-page");
				appUtils.pageInit(pageCode,topage,{});	
			}
			e.stopPropagation();
		 });
	}
    
	function queryQZXQList(){
		var userInfo =  JSON.parse(appUtils.getSStorageInfo("userinfo"));
		var account = userInfo.client_no;
		var branch_no = userInfo.branch_no;
		var param = {
			"account":account,
			"branch_no":branch_no
		};	
		service.query376(param,function(data){
			if(data.error_no == "0"){  
				var result = data.results;
				if(result && result.length>0){
					var data = "";
                    for(var i=0,len=result.length;i<len;i++){
                    	data += queryHTML(result[i],i+1);
                    }
                	$(_pageId + "#conList").html(data);
                	appUtils.bindEvent($(_pageId+".mn_bond .power"), function(e){
                		var $element = $(this).parent().parent().find("table");
                		var securities_code = $element.find("tr:eq(0) td:eq(0)").text(); // 正股代码
                		var option_code = $element.find("tr:eq(0) td:eq(1)").text(); // 期权代码
                		var exercise_price = $element.find("tr:eq(1) td:eq(1)").text(); // 行权价格
                		var withholding_tax = $element.find("tr:eq(4) td:eq(0)").text(); // 代扣税率
                		var market = $element.find("tr:eq(1) td:eq(0)").text(); // 市场
						var _market='';
						switch(market){
							case '上海A股':_market=1;break;
							case '深圳A股':_market=2;break;
							case '上海B股':_market=3;break;
							case '深圳B股':_market=4;break;
							case '三板A':_market=5;break;
							case '三板B':_market=6;break;
							case '港股':_market=8;break;
						}
                		var infos = {
                			"securities_code":securities_code,
                			"option_code":option_code,
                			"exercise_price":exercise_price,
                			"withholding_tax":withholding_tax,
                			"market":_market
                		};
                		appUtils.pageInit("rzxq/conQZXQ","rzxq/conRZXQEntrust",{"infos":infos});
    				});
				}else{
					$(_pageId + ".no_data").show(); // 没有数据时显示的暂无数据图标
				}
			}else{
				layerUtils.iAlert(data.error_info,-1);
			}
		});
	}
	
	function queryHTML(element,index){
		var eleHTML = "";
		    eleHTML +="<div class=\"mn_bond\">";
		    eleHTML +="<div class=\"top_bond\">";
		    eleHTML +="<a href=\"javascript:void(0)\" class=\"power\">融资行权</a>";
		    eleHTML +="<em>"+index+"</em><h3>"+element.short_name+"</h3>";
			eleHTML +="</div>	";
			eleHTML +="<table>";
	        eleHTML +="<tr>";
		    eleHTML +="<th width=\"20%\">正 股 代 码</th>";
		    eleHTML +="	<td width=\"20%\">"+element.securities_code+"</td>";
		    eleHTML +="	<th width=\"20%\">期 权 代 码</th>";
		    eleHTML +="	<td width=\"20%\">"+element.option_code+"</td>";
		    eleHTML +="</tr>";
		    eleHTML +="<tr>";
		    eleHTML +="	<th>市&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;场</th>";
		    eleHTML +="	<td>"+element.market_code+"</td>";
		    eleHTML +="	<th>行 权 价 格</th>";
		    eleHTML +="	<td>"+element.exercise_price+"</td>";
		    eleHTML +="</tr>";
		    eleHTML +="<tr>";
		    eleHTML +="	<th>行权起始日</th>";
		    eleHTML +="	<td>"+element.exercise_start+"</td>";
		    eleHTML +="	<th>行权结束日</th>";
		    eleHTML +="	<td>"+element.exercise_end+"</td>";
		    eleHTML +="</tr>";
		    eleHTML +="<tr>"; 
		    eleHTML +="	<th>批&nbsp;&nbsp;&nbsp;次&nbsp;&nbsp;&nbsp;号</th>";
		    eleHTML +="	<td>"+element.batch_number+"</td>";
		    eleHTML +="	<th>批 次 状 态</th>";
		    eleHTML +="	<td>"+element.batch_state+"</td>";
		    eleHTML +="</tr>";
		    eleHTML +="<tr>";
		    eleHTML +="	<th>代 扣 税 率</th>";
		    eleHTML +="	<td>"+element.withholding_tax+"</td>";
		    eleHTML +="	<th>已行权数量</th>";      
		    eleHTML +="	<td>"+element.have_exercise_amount+"</td>";
		    eleHTML +="</tr>";
		    eleHTML +="<tr>";
		    eleHTML +="	<th>权 益 数 量</th>";
		    eleHTML +="	<td>"+element.quantity_of_equity+"</td>";
		    eleHTML +="	<th>冻 结 数 量</th>";
		    eleHTML +="	<td>"+element.freezing_quantity+"</td>";
		    eleHTML +="</tr>";
		    eleHTML +="<tr>";
		    eleHTML +="	<th>激励计划号</th>";
		    eleHTML +="	<td>"+element.incentive_plan_no+"</td>";
		    eleHTML +="</tr>";
		    eleHTML +="</table>";
		    eleHTML +="</div>";
		    return eleHTML;
	}
	
	function destroy(){
	}
	
	/**
	 * 重写框架里面的pageBack方法
	 */
	function pageBack(){
		var fromPage = appUtils.getSStorageInfo("fromPage");
		if(fromPage && fromPage=="userCenter"){
			appUtils.clearSStorage("fromPage");
			appUtils.pageInit("rzxq/conQZXQ","account/userCenter");
		}else{
			var param_index = {"funcNo":"50101","moduleName":"main"};
			require("external").callMessage(param_index);
		}
	}
	
	var base = {
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy,
		"pageBack": pageBack
	};
	module.exports = base;
});
/**
 * 创业板转签
 */
define(function(require, exports, module){ 
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
		layerUtils = require("layerUtils"),
		validatorUtil = require("validatorUtil"),
		gconfig = require("gconfig"),
		global = gconfig.global,
		service = require("serviceImp"),  //业务层接口，请求数据
		_pageId = "#account_cybzq ";
	/* 私有业务模块的全局变量 end */
	
	var user_id = "",
		fund_account = "",
		gdzh = null,
		qylb = "",//签约类别
		qyrq = "",//签约日期
		successStep = 0,//能否申请开通
		isClick = 0, //点击确定开通是否满足了条件
		qylbFlag = 1,//1查询到的  2手动输入
		firstymth = null,
		firstzjdm = null,
		instead_stock_code = null,//手工输入的股东账号
		branch_no = "";

	function init(){
		user_id = appUtils.getSStorageInfo("user_id"),
		fund_account = appUtils.getSStorageInfo("fund_account"),
		branch_no = appUtils.getSStorageInfo("branch_no");
		gdzh = null;
		qyrq = "";
		qylb = "";
		firstymth = null;
		firstzjdm = null;
		instead_stock_code = null;
		qylbFlag = 1;//1查询到的  2手动输入
		isClick = 0;
		successStep = 0;
		$(_pageId+" .user_box strong").html(appUtils.getSStorageInfo("fund_account"));
		$(_pageId+" .btn_box a").css("background-color","darkgray");
		$(_pageId+" .delist_info2 a").css("font-size","8px");//兼容部分手机按钮文字显示不全
		is_tradeTime();
	}
	
	function bindPageEvent(){
		/* 返回  */
		appUtils.bindEvent($(_pageId+".icon_back span"),function(e){
			appUtils.pageBack();
		});
		
		//确定
		appUtils.bindEvent($(_pageId + " .btn_box a"),function(){
			if(qylbFlag == 1){
				instead_stock_code = "";
			}
			if(isClick == 0) return;
			if(secondVerify()){//校验紧急联系人
				var par = {
					"zqzh":gdzh,
					"ywlb":"01",
					"qylb":qylb,
					"branch_no":branch_no,
					"qyrq":qyrq
				};
				if(qylbFlag == 1){//如果是选择的老账户  传A
					par.qylb = "A";
					qylb = "A";
				}
				service.sdxglxxwh(par,function(data){
					if(data.error_no == 0){
						//处理成功0000
						var what_customer = "手机客户";
						if(gconfig.platform=="1"){
							what_customer = "android客户";
						}else if(gconfig.platform=="2"){
							what_customer = "ios客户";
						}
						if(data.results[0].jgdm == "0000"){
							//创业板转签
							var param = {
								"fund_account":fund_account,
								"branch_no":branch_no,
								"stock_code":gdzh,
								"zqsbzdjg":1,//转签申报中登结果
								"qylb":qylb,
								"ymth":firstymth,
								"instead_stock_code":instead_stock_code,
								"user_id":appUtils.getSStorageInfo("user_id"),
								"mode_operation":"1",
								"fund_account":appUtils.getSStorageInfo("fund_account"),
								"second_contract_name":$(_pageId+" .secondName input").val(),
								"second_contract_tel":$(_pageId+" .secondMobile input").val(),
								"what_customer":what_customer
							};
							service.operationCyb(param,function(data){
								if(data.error_no == 0){
									layerUtils.iAlert("转签成功");
								}else{
									layerUtils.iLoading(false);
									layerUtils.iAlert(data.error_info);
								}
							});
						}else if(data.results[0].jgdm == "3999"){//重复报送
							layerUtils.iLoading(false);
							layerUtils.iAlert("该证券账号中登查询到的状态为已报送，请联系所在营业部或到现场办理。");
						}else{
							layerUtils.iLoading(false);
							layerUtils.iAlert("申请报送失败");
						}
					}else{
						layerUtils.iLoading(false);
						layerUtils.iAlert(data.error_info);
					}
				},{"isLastReq":false});
			}
		});
		
		//选择框
		appUtils.bindEvent($(_pageId+" .sel_list"),function(){
			$(_pageId+" .sel_list ul").slideToggle();
		});
		
		//学习
		appUtils.bindEvent($(_pageId+" .study a"),function(){
			var param = {
				"funcNo":"60009",
				"url" : "http://www.szse.cn/main/investor/tzsc/cybxt_front/"
			};
			var result = require("external").callMessage(param);
		});
		
		//协议框
		appUtils.bindEvent($(_pageId+" .icon_check"),function(){
			$(this).toggleClass("active");
		});
		
		//账号校验
		appUtils.bindEvent($(_pageId + " .szzh a"),function(){
			var account = $(this).parent().find("input").val();
			if(validatorUtil.isEmpty(account)){
				layerUtils.iMsg(-1,"证券账号不能为空");
				return;
			}else if(account.length != 10){
				layerUtils.iMsg(-1,"证券账号长度不能少于10位");
				return;
			}else if(/^[0-9]*[a-z]*[A-Z]*$/.test(account) == false){
				layerUtils.iMsg(-1,"证券账号格式不正确");
				return;
			}
			//证券账户查询
			service.queryZqzh({"zqzh":account,"branch_no":branch_no,"fund_account":fund_account},function(data){
				if(data.error_no == 0){		
					var sffhtj = data.results[0].sffhtj;
					if(sffhtj == 0){
						layerUtils.iLoading(false);
						layerUtils.iConfirm("该证券账号中登查询到的状态不正常，请联系所在营业部或现场办理",function(){
							$(_pageId+" .input_select").hide();
							$(_pageId+" .cybqyrq a").removeClass("already_pass").html("不通过");
							$(_pageId+" .szzh input").val("");
							$(_pageId+" .szzh").slideDown();
							qylbFlag = 2;
						},function(){
							$(_pageId+" .szzh").hide();
							$(_pageId+" .input_select").slideDown();
							qylbFlag = 1;
						},"手动输入账号","选择其他账号");
						return;
					}
					secondymth= data.results[0].ymth;
					secondzjdm= data.results[0].zjdm;
					var sffhtj = data.results[0].sffhtj;
					//适当性维护
					var param = {
						"zqzh":data.results[0].zqzh,
						"ywlb":"03",
						"branch_no":branch_no
					};
					service.sdxglxxwh(param,function(data){
						if(data.error_no == 0){
							if(sffhtj == "1" && firstymth == secondymth && firstzjdm == secondzjdm){
								instead_stock_code = data.results[0].zqzh;
								qyrq = data.results[0].qyrq;
								qylb = data.results[0].qylb;
								$(_pageId+" .cybqyrq em").html(qyrq);
								//校验交易时间
								service.jysjz({},function(data){
									if(data.error_no == 0){
										if(data.results[0].is_trade_date == "0"){
											layerUtils.iConfirm("该账号签约日期距离现在少于5个交易日",function(){
												$(_pageId+" .input_select").hide();
												$(_pageId+" .cybqyrq a").removeClass("already_pass").html("不通过");
												$(_pageId+" .szzh input").val("");
												$(_pageId+" .szzh").slideDown();
												qylbFlag = 2;
											},function(){
												$(_pageId+" .szzh").hide();
												$(_pageId+" .input_select").slideDown();
												qylbFlag = 1;
											},"手动输入账号","选择其他账号");
										}else{
											successStep+=2;
											isClick = 1;
											changeColor();
											$(_pageId+" .cybqyrq a").addClass("already_pass").html("通过");
											$(_pageId+" .szzh a").addClass("already_pass").html("已校验");
											$(_pageId+" .second").slideDown();
										}
									}else{
										layerUtils.iLoading(false);
										layerUtils.iAlert(data.error_info);
									}
								});
							}else{
								layerUtils.iLoading(false);
								layerUtils.iConfirm("您输入的证券账号不能进行查询匹配，原因可能是身份信息不一致，或证券账户状态不正常，请重新输入证券账户，或到营业部现场办理创业板转签",function(){
									$(_pageId+" .input_select").hide();
									$(_pageId+" .cybqyrq a").removeClass("already_pass").html("不通过");
									$(_pageId+" .szzh input").val("");
									$(_pageId+" .szzh").slideDown();
									qylbFlag = 2;
								},function(){
									$(_pageId+" .szzh").hide();
									$(_pageId+" .input_select").slideDown();
									qylbFlag = 1;
								},"手动输入账号","选择其他账号");
							}
						}else{
							layerUtils.iLoading(false);
							layerUtils.iAlert(data.error_info);
						}
					});
				}else{
					layerUtils.iLoading(false);
					layerUtils.iAlert(data.error_info);
				}
			});
		});
	}
	
	//是否在交易时间内
	function is_tradeTime(){
		service.jysjz({},function(data){
			if(data.error_no == 0){
				if(data.results[0].is_trade=="0"){
					layerUtils.iAlert("不在服务时间内，请于每交易日交易时间办理");
				}else{
					queryGdzh();
				}
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		});
	};
	
	//查询股东账户
	function queryGdzh(){
		service.queryGdzh({"user_id":user_id,"fund_account":fund_account,"branch_no":branch_no},function(data){
			if(data.error_no == 0 && data.results[0].account!=""){//存在股东账户\
				var accounts = data.results[0].account;
				if(typeof(accounts) == "string"){
					accounts = [accounts];
				}
				gdzh = accounts[0];
				$(_pageId+" .zdcqzh em").html(gdzh);
				var html = "";
				for(var i=0;i<accounts.length;i++){
					html += '<li><a href="javascript:void(0)">'+accounts[i]+'</a></li>';
				}
				$(_pageId+" .sel_list ul").html(html);
				$(_pageId+" .sel_list strong").html(gdzh);
				appUtils.bindEvent($(_pageId+" .sel_list ul li"),function(e){
					$(_pageId+" .zdcqzh em").html($(this).text());
					$(_pageId+" .sel_list strong").html($(this).text());
					gdzh = $(this).text();
					successStep = 1;
					queryZdzqzh();
				//	e.stopPropagation();
				});
				successStep++;
				queryZdzqzh();//是否开通创业板
			}else{//没有股东账户
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		},{"isLastReq":false});
	}
	
	//是否开通创业板
	function isKaiTongCYB(){
		var operationCybParam = {
			"user_id":user_id,
			"fund_account":fund_account,
			"branch_no":branch_no,
			"stock_code":gdzh,
			"mode_operation":"3"
		};
		//查询是否开通创业板
		service.operationCyb(operationCybParam,function(data){
			if(data.error_no == 0){
				if(data.results[0].access_type.indexOf("J")>-1){//开通了创业板
					layerUtils.iLoading(false);
					layerUtils.iAlert(gdzh+"股东账号已开通创业板权限");
				}else{//没有开通创业板
					successStep++;
					queryZhState();
				}
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		},{"isLastReq":false});
	}
	
	//查询账户状态   只要能登录就直接给正常
	function queryZhState(){
		queryFxcpState();
	}
	
	//风险测评状态
	function queryFxcpState(){
		service.cyb_queryFxcp({"fund_account":fund_account,"branch_no":branch_no},function(data){
			if(data.error_no == 0){
				if(data.results[0].sffxcp == "1" && !validatorUtil.isEmpty(data.results[0].riskResult)){//已经测评
					successStep++;
					$(_pageId+" .fxcp em").text(data.results[0].riskResult);
					$(_pageId+" .fxcp a").addClass("already_pass").text("通过");
				}else{
					$(_pageId+" .fxcp em").text("未测评或已过期");
					$(_pageId+" .fxcp a").removeClass("already_pass").text("测评");
					appUtils.bindEvent($(_pageId+" .fxcp a"),function(){
						appUtils.pageInit("account/cybzq","account/cybFxcp");
					});
				}
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
			queryQyrq();
		},{"isLastReq":false});
	}
	
	//签约日期
	function queryQyrq(){
		service.sdxglxxwh({"zqzh":gdzh,"ywlb":"03","branch_no":branch_no},function(data){
			if(data.error_no == 0){
			//	data.results[0].status = "0";//test
				if(data.results[0].status == "1"){
					qyrq = data.results[0].qyrq;
					qylb = data.results[0].qylb;
					$(_pageId+" .cybqyrq em").html(qyrq);
					timeVerify();
				}else{
					layerUtils.iLoading(false);
					layerUtils.iConfirm("未查询到签约日期或签约日期不足5个交易日",function(){
					$(_pageId+" .input_select").hide();
						$(_pageId+" .cybqyrq a").removeClass("already_pass").html("不通过");
						$(_pageId+" .szzh").val("");
						$(_pageId+" .szzh").slideDown();
						qylbFlag = 2;
					},function(){
						$(_pageId+" .szzh").hide();
						$(_pageId+" .input_select").slideDown();
						qylbFlag = 1;
					},"手动输入账号","选择其他账号");
				}
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		},{"isLastReq":false});		
	}
	
	//中登证券账户状态查询
	function queryZdzqzh(){
		service.queryZqzh({"zqzh":gdzh,"branch_no":branch_no,"fund_account":fund_account},function(data){
			if(data.error_no == 0){
				firstymth = data.results[0].ymth;
				firstzjdm = data.results[0].zjdm;
				if(data.results[0].sffhtj == "1"){//在中登正常
					successStep++;
					isKaiTongCYB();
				}else{//在中登不正常
					layerUtils.iLoading(false);
					layerUtils.iAlert("该证券账号中登查询到的状态不正常，请联系所在营业部或现场办理");
				}
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		},{"isLastReq":false});
	}
	
	//深圳账号创业板签约日期是否早于当前5个交易日
	function timeVerify(){
		service.jysjz({},function(data){
			if(data.error_no == 0){
				if(data.results[0].is_trade_date == "0"){
					layerUtils.iConfirm("该账号签约日期距离现在少于5个交易日",function(){
					$(_pageId+" .input_select").hide();
						$(_pageId+" .cybqyrq a").removeClass("already_pass").html("不通过");
						$(_pageId+" .szzh input").val("");
						$(_pageId+" .szzh").slideDown();
						qylbFlag = 2;
					},function(){
						$(_pageId+" .szzh").hide();
						$(_pageId+" .input_select").slideDown();
						qylbFlag = 1;
					},"手动输入账号","选择其他账号");
				}else{
					successStep++;
					isClick = 1;
					changeColor();
					$(_pageId+" .cybqyrq a").addClass("already_pass").html("通过");
					$(_pageId+" .second").slideDown();
				}
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		});
	}
	
	function secondVerify(){
		if(successStep < 5){
			layerUtils.iMsg(-1,"您还不满足条件");
			return false;
		}
		var second_contract_name = $(_pageId+" .secondName input").val();
		var second_contract_tel = $(_pageId+" .secondMobile input").val();
		var reg = /^0?1[3|4|5|8][0-9]\d{8}$/;
		if(validatorUtil.isEmpty(second_contract_name)){
			layerUtils.iMsg(-1,"第二联系人姓名不能为空");
			return false;
		}else if(/[^\u4e00-\u9fa5]/.test(second_contract_name)){
			layerUtils.iMsg(-1,"第二联系人姓名只能输入中文");
			return false;
		}else if(second_contract_name.length<2 || second_contract_name.length>10){
			layerUtils.iMsg(-1,"第二联系人姓名在2-10个字之间");
			return false;
		}else if(second_contract_name == appUtils.getSStorageInfo("userinfo").user_name){
			layerUtils.iMsg(-1,"第二联系人姓名不能与自己的姓名相同");
			return false;
		}
		if(validatorUtil.isEmpty(second_contract_tel)){
			layerUtils.iMsg(-1,"第二联系人手机号码不能为空");
			return false;
		}else  if(second_contract_tel.length<11 || !reg.test(second_contract_tel)){
			layerUtils.iMsg(-1,"请输入符合规则的手机号码");
			return false
		}else if(second_contract_tel == appUtils.getSStorageInfo("userinfo").telephone){
			layerUtils.iMsg(-1,"第二联系人手机号码不能与自己的相同");
			return false
		}
		if($(_pageId+" .icon_check").hasClass("active") == false){
			layerUtils.iMsg(-1,"请同意相关协议");
			return false
		}
		return true;
	}
	
	//改变确定按钮的颜色
	function changeColor(){
		if(isClick == 1){
			$(_pageId+" .btn_box a").css("background-color","#1199EE");
		}
	}
	
	function destroy(){
		$(_pageId+" .second").hide();
		$(_pageId+" .input_select").show();
		$(_pageId+" .szzh").hide();
	}
	
	var index = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	module.exports = index;
});
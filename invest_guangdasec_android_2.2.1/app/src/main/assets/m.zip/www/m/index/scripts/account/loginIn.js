/**
 * 光大富尊
 * 外网测试账号40636110 092920
 * 
 * 40633333
111111

40633334
111111
 */
define(function(require, exports, module){ 
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
		layerUtils = require("layerUtils"),
		service = require("serviceImp"), //业务层接口，请求数据
		gconfig = require("gconfig"),
		global = gconfig.global,
		keyPanel = require("keyPanel"),//软键盘
		_pageId = "#account_loginIn ";
	/* 私有业务模块的全局变量 end */
	
	function init(){
	    $(_pageId+"#trade_id").val("");
		$(_pageId+"em").html("交易密码");
		$(_pageId+"#trade_pwd").val("");
		$(_pageId+"#code").val("");

		
		// 获取验证码
		//getCode();
		//getIpMac(); // 获取ip、mac地址
	}
	
	function getIpMac(){
		require("shellPlugin").callShellMethod("getIpMacPLugin",function(data){
			data = data.split("|");
			var mac = data[0];
			var ip = data[1];
			appUtils.setSStorageInfo("ip",ip); // 将 ip 保存到 sessionStorage 里面
			appUtils.setSStorageInfo("mac",mac); // 将 mac 保存到 sessionStorage 里面
		},null);
	}
	
	function bindPageEvent(){
		/*初始化键盘*/
		appUtils.bindEvent($(_pageId+" #password") ,function(e){
			var input_pwd = $(this);
			input_pwd.find("em").html("");  // 清空密码
			input_pwd.attr("data-password","");  // 清空密码值
			$(_pageId+" .input_custom").addClass("active");
			keyPanel.init_keyPanel(function(value){
				var curEchoText = input_pwd.find("em").html();  // 密码回显文本
				var input_pass_curPwd = input_pwd.attr("data-password") || "";  // 密码值
				var valInput=$(_pageId+" #trade_pwd");
				if(value == "del")
				{
					input_pwd.find("em").html(curEchoText.slice(0, -1));
					input_pwd.attr("data-password", input_pass_curPwd.slice(0, -1));
					valInput.val(input_pwd.attr("data-password"));
				}
				else
				{
					if(input_pass_curPwd.length < 6)
					{
						input_pwd.attr("data-password", input_pass_curPwd + value);  // 设置密码值
						input_pwd.find("em").html(curEchoText + "*");
						valInput.val(input_pass_curPwd + value);
					}
					else
					{
						layerUtils.iMsg(-1, "交易密码最多 6位!");
					}
				}
			}, input_pwd);
			e.stopPropagation();	
		});

		//点击页面关闭软键盘
		appUtils.bindEvent($(_pageId),function(){
			keyPanel.closeKeyPanel();
			var mesTrade = $(_pageId+"em").html();
			if(mesTrade ==""){
				$(_pageId+"em").html("交易密码");
			}
			$(_pageId+" .input_custom").removeClass("active");
		});
		
		/* 点击更换验证码  */
		appUtils.bindEvent($(_pageId+".code_pic"),function(e){
			// 获取验证码
			getCode();
		});
		
		/* 点击登陆  */
		appUtils.bindEvent($(_pageId+".loginIn"),function(e){
//			appUtils.pageInit("account/loginIn","account/activateAgre",{});
			if(checkInput()){//判断输入的信息是否合法
				//对登录的信息进行加密
				loginEncrypt();
			}
		});
			
		/* 点击开户  */
		appUtils.bindEvent($(_pageId+" .openIn"),function(e){
			require("external").sendMessage("open", "", 50002, "");
		});
		
		/* 点击同意协议  */
		appUtils.bindEvent($(_pageId+".icon_radio"),function(e){
			$(this).toggleClass("active");
//			if($(this).hasClass("active")){
//				$(_pageId+".ct_btn").addClass("ce_btn").removeClass("ct_btn");
//			}
//			else{
//				$(_pageId+".ce_btn:eq(1)").addClass("ct_btn").removeClass("ce_btn");
//			}
			e.stopPropagation();
		});
		
		/* 点击查看协议  */
		appUtils.bindEvent($(_pageId+".icon_radio a"),function(e){
			appUtils.pageInit("account/loginIn","account/protocol",{});
			e.stopPropagation();
		});
		
		//选择登录方式
		appUtils.bindEvent($(_pageId+" .tab_nav a"),function(){
			var $a = $(this);
			var aId = $a.attr("id"),
			aClass = $a.attr("class");
			if(aClass){
				return false;
			}else{
				getCode();
				$a.addClass("active").siblings().removeClass("active");
				if(aId === "a_first"){
					$(_pageId+" .notice2").hide();
					$(_pageId+" #account").html("资金账号：");
					$(_pageId+" #passspan").html("交易密码：");
					$(_pageId+" #trade_id").attr("placeholder","资金账号");
					$(_pageId+" #password>em").html("交易密码");
					$(_pageId+"#trade_pwd").val("");
					$(_pageId+"#trade_id").val("");
					$(_pageId+" #trade_id").val("40612551"); //40636111 40612549
					$(_pageId+" #trade_pwd").val("111111");
				}else{
					$(_pageId+" .notice2").show();
					$(_pageId+" #account").html("E账通账号：");
					$(_pageId+" #passspan").html("E账通密码：");
					$(_pageId+" #trade_id").attr("placeholder","E账通账号");
					$(_pageId+" #password>em").html("E账通密码");
					$(_pageId+"#trade_pwd").val("");
					$(_pageId+"#trade_id").val("");
					$(_pageId+" #trade_id").val("880001432399");  //zhoushuren  880003128746   880000378535
					$(_pageId+" #trade_pwd").val("600446");
				}
			}
		});
	}
	
	function destroy(){}
	
	/*
	 * 对登录的信息 加密
	 */
	function loginEncrypt(){
		service.getRSAKey({},function(data){
			var fund_account = $.trim($(_pageId+" #trade_id").val());
			var fund_pwd = $.trim($(_pageId+" #trade_pwd").val());
			var code = $.trim($(_pageId+" .code").val());
			if(data.error_no === "0"){
				var results = data.results[0];
				var modulus = results.modulus;
				var publicExponent = results.publicExponent;
				var endecryptUtils = require("endecryptUtils");
				var trade_pwd = endecryptUtils.rsaEncrypt(modulus,publicExponent,fund_pwd);
				//判断登录的方式
				var aClass =  $(_pageId+" #a_first").attr("class");
				if(aClass){
					//资金账号登录
					userLogin(fund_account,trade_pwd,code);
				}else{
					//E账通账号登录
					E_userLogin(fund_account,trade_pwd,code);
				}
			}
		},false);
	}
	
	/*
	 * 资金账号登录
	 */
	function userLogin(fund_account,trade_pwd,code){
		var mac = appUtils.getSStorageInfo("mac");
		var param  = {
				"fund_account": fund_account,
				"trade_pwd": trade_pwd,
				"vf_code": code,
				"mac" : mac
		};
		service._fundLogin(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result = data.results;//验证码输入错误
			if(error_info=='验证码输入错误')
			{	 
				$(_pageId+" #code").val("");       // 清除验证码
				layerUtils.iMsg(0,"验证码输入错误");
				getCode();
				return false;
			}
			if(error_info!='调用成功')
			{	 
				$(_pageId+" #password em").html("");  // 清除密码
				$(_pageId+" #trade_pwd").val('');  //清除密码
				$(_pageId+" #code").val("");       // 清除验证码
				getCode();
			}
			if(error_no == "0" && result.length != 0){
				var xdt_token = result[0].xdt_token; // 小贷token值
				var mall_token = result[0].mall_token; // 商城token值
				var ggt_token = result[0].hgt_token; // 港股通token值
				var xd_str = {key:"APP_XD",value:xdt_token};
				var mall_str = {key:"APP_SC",value:mall_token};
				var ggt_str = {key:"APP_GGT",value:ggt_token};
				var login_str = {key:"login_state",value:"1"};
//				require("external").callFunction("55400",JSON.stringify(xd_str));
//				require("external").callFunction("55400",JSON.stringify(mall_str));
//				require("external").callFunction("55400",JSON.stringify(ggt_str));
//				require("external").callFunction("55400",JSON.stringify(login_str));
				//港股通标识,值为true则登陆后直接跳到港股通模块,否则跳转到富尊个人中心
//				var ggt_flag = require("external").callFunction("55401",JSON.stringify({key:"ggt_flag"}));
				/*把用户编号存到session*/
				if(result[0].user_id)
				{
					appUtils.setSStorageInfo("user_id",result[0].user_id);
				}
				/*把资金账号存到session*/
				if(result[0].fund_account)
				{
					appUtils.setSStorageInfo("fund_account",result[0].fund_account);
				}
				/*把客户号存到session*/
				if(result[0].client_no)
				{
					appUtils.setSStorageInfo("client_no",result[0].client_no);
				}
				/*把营业部存到session*/
				if(result[0].branch_no)
				{
					appUtils.setSStorageInfo("branch_no",result[0].branch_no);
				}
				/*把jsessionid存到session*/
				if(result[0].jsessionid)
				{
					appUtils.setSStorageInfo("jsessionid",result[0].jsessionid);
				}
				
				//保存用户信息到session
				appUtils.setSStorageInfo("userinfo",JSON.stringify(result[0]));
				
				
				appUtils.setSStorageInfo("_isLoginIn","true");
				appUtils.pageInit("account/loginIn","account/userCenter",{});
//				if(ggt_flag == "1"){
//					if(gconfig.platform == "1")
//					{
//						var param = {"url":"file:///android_asset/www/plat/ggt/index.html?key="+Math.random()+"#!/business/index.html"};
//						require("external").sendMessage("ggt", "", 50002, JSON.stringify(param));
//					}
//					else
//					{
//						var param = {"dir":"www/plat/ggt","index":"index","code":"business/index.html"};
//						require("external").sendMessage("ggt", "", 50002, param);
//					}
//				}
//				else if(appUtils.getSStorageInfo("_loginInPageCode")){
//					appUtils.pageInit("account/loginIn", appUtils.getSStorageInfo("_loginInPageCode"), JSON.parse(appUtils.getSStorageInfo("_loginInPageParam")));
//					appUtils.clearSStorage("_loginInPageCode");
//					appUtils.clearSStorage("_loginInPageParam");
//				}
//				else
//				{
//					appUtils.pageInit("account/loginIn","account/userCenter",{});
//				}
			}
			else
			{
				$(_pageId+"em").html("交易密码");
				$(_pageId+"#trade_pwd").val("");
				layerUtils.iAlert(error_info);
				return false;
			}
		});
	}
	
	/*
	 * E账通登录
	 */
	function E_userLogin(fund_account,trade_pwd,code){
		var mac = appUtils.getSStorageInfo("mac");
		var ip = appUtils.getSStorageInfo("ip");
		var user_id_type = /^[8]{2}\d{10}$/.test(fund_account)?"E":"N";
		var param = {
				"user_id": fund_account,
				"trade_pwd": trade_pwd,
				"ip": ip,
				"mac": mac,
				"vf_code": code,
				"user_id_type": user_id_type
		};
		service.E_fundLogin(param,function(data){
			var error_info = data.error_info;
			var error_no = data.error_no;
			if(error_info=='验证码输入错误')
			{	 
				$(_pageId+" #code").val("");       // 清除验证码
				layerUtils.iMsg(0,"验证码输入错误");
				getCode();
				return false;
			}
			if(error_info!='调用成功')
			{	 
				$(_pageId+" #password em").html("");  // 清除密码
				$(_pageId+" #trade_pwd").val('');  //清除密码
				$(_pageId+" #code").val("");       // 清除验证码
				getCode();
			}
			if(error_no == "0"){
				var result = data.results[0];
				if(result.length != 0){
					appUtils.setSStorageInfo("userinfo",JSON.stringify(result));
//					/*把jsessionid存到session*/
//					if(result[0].jsessionid){
//						appUtils.setSStorageInfo("jsessionid",result[0].jsessionid);
//					}
					appUtils.pageInit("account/loginIn","account/userCenter",{});
				}
			}else{
				$(_pageId+"em").html("E账通密码");
				$(_pageId+"#trade_pwd").val("");
				layerUtils.iAlert(error_info);
			}
		});
	}
	
	//验证输入的登录信息是否合法
	function checkInput(){
		var check = false;
		var fund_account = $.trim($(_pageId+" #trade_id").val());
		var fund_pwd = $.trim($(_pageId+" #trade_pwd").val());
		var code = $.trim($(_pageId+" .code").val()); 
//		var select_flag = $(_pageId+".icon_radio").hasClass("active");
//		if(!select_flag)
//		{
//			layerUtils.iMsg(-1,"请先同意服务协议");
//			return false;
//		}
		if(fund_account == ""|| trade_pwd == ""){
			layerUtils.iMsg(-1,"账号不能为空");
			check = false;
		}else if(fund_pwd == "" || fund_pwd == null){
			layerUtils.iMsg(-1,"密码不能为空");
			check = false;
		}else if(code == ""){
			layerUtils.iMsg(-1,"验证码不能为空");
			check = false;
		}else{
			check = true;
		}
		return check;
	}
	
	/*获取验证码/重新获取验证码*/
	function getCode(){	 
		$(_pageId+" .code").val("");
		var url=global.imgUrl +"?key="+new Date().format("yyyy-MM-dd hh:mm:ss");
		$(_pageId+' .code_pic').attr('src',url);//验证码错误，刷新获得验证码
	}
	
	var index = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	module.exports = index;
});

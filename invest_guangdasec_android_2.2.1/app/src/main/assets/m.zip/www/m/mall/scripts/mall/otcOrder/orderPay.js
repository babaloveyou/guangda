/**
 * otc--订单支付
 */

define(function(require, exports, module) {
	var service = require("mobileService");// 业务层接口，请求数据
	var appUtils = require('appUtils'), putils = require("putils"), layerUtils = require("layerUtils"), constants = require("constants");// 常量类
	gconfig = require("gconfig"), global = gconfig.global;
	var keyPanel = require("keyPanel"); // 软键盘
	var _pageId = "#mall_otcOrder_orderPay ";
	var timeNum = 0;
	var tot_price = 0;
	var inst_sname = "";

	// 1、初始化
	function init() {
		// 查询订单
		getOTCOrder();
		var product_id = appUtils.getPageParam().product_id;// 产品编号
		// var inst_sname=appUtils.getPageParam("inst_sname");//产品名称
		// var fund_account = appUtils.getSStorageInfo("fund_account");
		var cuacct_code = appUtils.getPageParam("cuacct_code");
		$(_pageId + " #fund_account").html(cuacct_code);

		// 防止直接到该页面
		if (product_id == null) {
			layerUtils.iMsg(1, "数据加载错误！");
			appUtils.pageInit("mall/otcOrder/orderPay", "account/mainPage", {});
			return false;
		}

	}
	// 初始化进来查询订单
	function getOTCOrder() {
		var order_id = appUtils.getPageParam().order_id;// 订单编号
		var ticket = appUtils.getSStorageInfo("ticket");
		var param = {
			"user_id" : appUtils.getSStorageInfo("user_id"),
			"order_id" : order_id,
			"ticket" : ticket
		};
		service.getOTCOrder(param, function(data) {
			if (data.error_no != "0") {
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}

			var product_id = appUtils.getPageParam().product_id;// 产品编号
			// var inst_sname=appUtils.getPageParam().inst_sname;//产品名称
			var perData = data.results;
			inst_sname = perData[0].inst_sname;

			if (inst_sname.length > 12) {
				$(_pageId + " #product_name").css("font-size", "13px");
			}
			$(_pageId + " #product_name").html(
					inst_sname.substring(0, 12) + "...");

			$(_pageId + " #product_name").hover(
					function() {
						$(_pageId + " #product_name").html(inst_sname);
					},
					function() {
						$(_pageId + " #product_name").html(
								inst_sname.substring(0, 12) + "...");
					});

			/*
			 * //判断是否是新订单(订单已确认)
			 * if(data.results[0].order_state!=constants.order_state.NEW) {
			 * layerUtils.iMsg(0,"订单已确认，请在我的订单中查看该订单",1);
			 * layerUtils.iLayerClose(); layerUtils.iTipsClose();
			 * appUtils.pageInit("mall/otcOrder/orderPay","account/myOrder",{}); }
			 */
			var trd_amt = data.results[0].trd_amt;
			if (trd_amt) {
				$(_pageId + " #trd_amt").html("￥" + trd_amt);// 购买金额
				$(_pageId + " .pay_money").html("￥" + trd_amt);// 支付金额
			}
			// OTC支付账户信息查询
			// otcAccoInfo();
			var cuacct_code = appUtils.getPageParam("cuacct_code");
			queryAsset(cuacct_code);// 资产查询
		});
	}

	// 订单支付
	function orderPayment() {
		// 加密
		service.getRSAKey({}, function(data) {
			if (data.error_no == "0") {
				var modulus = data.results[0].modulus;
				var publicExponent = data.results[0].publicExponent;
				var endecryptUtils = require("endecryptUtils");
				var trade_pwd = endecryptUtils.rsaEncrypt(modulus,
						publicExponent, $.trim($(_pageId + "  #trade_pwd")
								.val()));
			}
			var mobilePhone = require("external").callMessage({
				"funcNo" : "50043",
				"key" : "mobilePhone"
			}).results[0].value;
			var param = {
				"fund_account" : $(_pageId + " #fund_account").html(),
				"ticket" : appUtils.getSStorageInfo("ticket"),
				"order_channel" : "7",
				"order_id" : appUtils.getPageParam().order_id,// 订单编号,
				"mobile" : mobilePhone,
				"trade_pwd" : trade_pwd
			};
			service.otcOrderPayment(param, function(data) {
				if (data.error_no != "0") {
					$(_pageId + " #password em").html("");// 清空输入的值
					$(_pageId + " #trade_pwd").val("");// 清空表单的值
					$(_pageId + " #password").find("em").html("请输交易密码"); // 清空密码
					$(_pageId + " .input_custom_new").addClass(" active");
					$(" #qrzf").css("background", "#1199EE");
					// $(_pageId+" #qrzf").removeAttr("style");
					$(_pageId + " #qrzf").text("确定支付");
					layerUtils.iMsg(-1, data.error_info, "3");
					layerUtils.iLoading(false);
					return false;
				} else {
					setTimeout(function() {
						otcOrderInfo();
					}, 5000);
				}

			}, {
				"isLastReq" : false
			});

		}, {
			"isLastReq" : false
		});

	}

	// 获取订单信息，轮循
	function otcOrderInfo() {
		var param = {
			"order_id" : appUtils.getPageParam().order_id,// 订单编号,
			"ticket" : appUtils.getSStorageInfo("ticket")
		};
		service
				.getOTCOrder(
						param,
						function(data) {
							timeNum++;
							if (data.error_no != "0") {
								layerUtils.iAlert(data.error_info);
								layerUtils.iLoading(false);
								return false;
							} else {
								var results = data.results;
								var order_state = results[0].order_state;
								var trd_amt = results[0].trd_amt;
								var inst_sname = results[0].inst_sname;
								var order_id = results[0].order_id;
								var entrust_state = results[0].entrust_state;
								if (order_state
										&& order_state != constants.order_state.SUBMIT) {
									var param = {
										"order_id" : order_id,
										"trd_amt" : parseFloat(trd_amt),
										"order_state" : order_state,
										"entrust_state" : entrust_state,
										"inst_sname" : inst_sname

									};
									layerUtils.iLoading(false);
									appUtils.pageInit("mall/otcOrder/orderPay",
											"mall/otcOrder/payment", param);
								} else {
									if (timeNum < 3) {
										setTimeout(function() {
											otcOrderInfo();
										}, 5000);
									} else {
										var results = data.results;
										var order_state = results[0].order_state;
										var trd_amt = results[0].trd_amt;
										var entrust_state = results[0].entrust_state;
										var inst_sname = results[0].inst_sname;
										var order_id = results[0].order_id;
										var param = {
											"order_id" : order_id,
											"trd_amt" : parseFloat(trd_amt),
											"entrust_state" : entrust_state,
											"order_state" : order_state,
											"inst_sname" : inst_sname

										};
										layerUtils.iLoading(false);
										appUtils.pageInit(
												"mall/otcOrder/orderPay",
												"mall/otcOrder/payment", param);
									}
								}
							}
						}, {
							"isLastReq" : false
						});
	}

	function otcAccoInfo() {
		var cust_code = appUtils.getSStorageInfo("cust_code");
		// var fund_account=appUtils.getSStorageInfo("fund_account");
		var fund_list = appUtils.getSStorageInfo("fund_list");
		var ticket = appUtils.getSStorageInfo("ticket");
		var param = {
			"cust_code" : cust_code,
			"cuacct_code" : fund_list,
			"ticket" : ticket
		};

		/* 查询是否有支付账户 */
		service.otcAccoInfo(param, function(data) {
			var error_no = data.error_no;
			var error_info = data.error_info;
			var results = data.results;
			if (error_no == "0" && results.length != 0) {
				var otcflag = results[0].otcflag;
				if (otcflag == "1") {
					var cuacct_code = results[0].cuacct_code;
					$(_pageId + " #fund_account").html(cuacct_code);
					queryAsset(cuacct_code);// 资产查询
				}
			} else {
				layerUtils.iAlert(error_info);
				layerUtils.iLoading(false);
				return false;
			}
		});
	}

	// 总资产
	function queryAsset(cuacct_code) {
		var param = {
			"fund_account" : cuacct_code
		};

		/* 调用查询资金接口 */
		service.queryAsset(param, function(data) {
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result = data.results;
			var pageInParam = appUtils.getPageParam();
			var total_money = result[0].useable_money;// 保存总资产
			var order_id = pageInParam.order_id;
			var trd_amt = appUtils.getPageParam().trd_amt;// 购买金额
			if (error_no != "0") {
				layerUtils.iAlert(error_info);
				layerUtils.iLoading(false);
				return false;
			}
			// 页面展示
			$(_pageId + " #restMoney").html(
					"￥" + parseFloat(total_money).toFixed(2)); // 总资产
			if (parseFloat($.trim(trd_amt)) > parseFloat($.trim(total_money))) {
				$(_pageId + " #che").show(); // 将div显示
				var product_id = appUtils.getPageParam().product_id;// 产品编号
				var param = {
					"order_id" : order_id,
					"product_id" : product_id
				};
				layerUtils.iConfirm("资金不足，是否进行转账？", function() {
					appUtils.pageInit("mall/otcOrder/orderPay",
							"account/bankTransfer", param);
					return false;
				}, function() {
					$(" #qrzf").css("background", "#CDCDCD");
					$(" #qrzf").removeAttr("href");
				});
			}

		});
	}

	// 2、事件绑定
	function bindPageEvent() {
		/* 初始化键盘 */
		appUtils.bindEvent($(_pageId + " #password"), function(e) {
			var input_pwd = $(this);
			input_pwd.find("em").html(""); // 清空密码
			input_pwd.attr("data-password", ""); // 清空密码值
			$(_pageId + " .input_custom_new").addClass("active");
			keyPanel.init_keyPanel(function(value) {
				var curEchoText = input_pwd.find("em").html(); // 密码回显文本
				var input_pass_curPwd = input_pwd.attr("data-password") || ""; // 密码值
				var valInput = $(_pageId + " #trade_pwd");
				if (value == "del") {
					input_pwd.find("em").html(curEchoText.slice(0, -1));
					input_pwd.attr("data-password", input_pass_curPwd.slice(0,
							-1));
					valInput.val(input_pwd.attr("data-password"));
				} else {
					if (input_pass_curPwd.length < 6) {
						input_pwd.attr("data-password", input_pass_curPwd
								+ value); // 设置密码值
						input_pwd.find("em").html(curEchoText + "*");
						valInput.val(input_pass_curPwd + value);
					} else {
						layerUtils.iMsg(-1, "交易密码最多 6位!");
					}
				}
			}, input_pwd);
			e.stopPropagation();
		});

		// 点击页面关闭软键盘
		appUtils.bindEvent($(_pageId), function() {
			keyPanel.closeKeyPanel();
		});

		// 提交订单
		appUtils.bindEvent($(_pageId + " #qrzf"), function() {
			$(_pageId + " .input_custom_new").removeClass(" active");
			var fund_money = $(_pageId + " .pay_money").html();
			if (fund_money == "" || fund_money == null || fund_money <= "0") {
				return false;
			}

			if (!$(this).attr("href")) {
				return false;
			}
			// 输入校验
			var check_isNull = $.trim($(_pageId + " #trade_pwd").val());
			if (check_isNull == null || check_isNull == "") {
				layerUtils.iMsg(0, "密码不能为空");
				return false;
			}

			$(this).css("background", "#CDCDCD");
			$(_pageId + " #qrzf").text("支付中···");
			// $(this).removeAttr("href");
			// 订单支付
			orderPayment();
		});

		// 绑定返回事件
		appUtils.bindEvent($(_pageId + " .icon_back"), function() {
			appUtils.pageBack();
		});
	}

	// 3、销毁
	function destroy() {
		$(_pageId + " .input_custom_new").addClass("active");
		appUtils.pageResetValue("mall_finanOrder_orderPay");
		$(_pageId + " #password em").html("");// 清空输入的值
		$(_pageId + " #qrzf").removeAttr("style");
		$(_pageId + " #qrzf").text("确定支付");
		keyPanel.closeKeyPanel();
		$(_pageId + " .input_custom").removeClass(" active");
		$(_pageId + " #trade_pwd").val("");
		$(_pageId + " #qrzf").attr("href", "javascript:;");

	}

	var orderPay = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};

	module.exports = orderPay;

});
/**
 * 选择营业部
 */
define(function(require, exports, module){ 
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
		  service = require("investService").getInstance(),  //业务层接口，请求数据
	       global = require("gconfig").global,
	       layerUtils = require("layerUtils"),
	       shellPlugin = require("shellPlugin"),
	       platform = require("gconfig").platform,
	       validatorUtil = require("validatorUtil"),
	       provinceList = "",  //省份
		   cityList = "",  //城市
		   branchList = "",  //营业部
		   commissionList = "",  //佣金套餐
		   localPro = "",  // 本地省份
		   localCity = "",  // 本地城市
		   localBranch = "",  // 本地营业部
		   branchParam={"branchno" : "", "commission" : ""},  //营业部编号
		   hasbranch = true,  // 判断定位的城市是否拥有营业部
		   _pageId = "#account_selDepartment";
	var external = require("external");
	var protocol = null;	//用于保存协议
	var channelInfo = global.channelInfo;
	
	var arrayData = null;
	//光大银行
	var arrayGDYH = ["GDYBNN0218","GDYBLZ0516","GDYBGL0235","GDYBQZ0436","GDYBXM0439","GDYBZS0253",
	                 "GDYBZS0212","GDYBQY0209","GDYBZQ0255","GDYBLH0223","GDYBGZ0232","GDYBFS0206","GDYBFS0222",
	                 "GDYBMM0252","GDYBSD0210","GDYBFS0531","GDYBHZ0207","GDYBHY0251","GDYBHZ0525","GDYBHZ0530",
	                 "GDYBJM0208","GDYBJM0526","GDYBJM0239","GDYBZJ0211","GDYBZH0288","GDYBST0229","GDYBMZ0256",
	                 "GDYBCS0534","GDYBYZ0467","GDYBHZ0124","GDYBJH0125","GDYBSX0109","GDYBWZ0461","GDYBNJ0107",
	                 "GDYBSQ0462","GDYBNJ0126","GDYBSZ0127","GDYBKS0472","GDYBHM0433","GDYBNT0473","GDYBCZ0456",
	                 "GDYBYZ0457","GDYBHA0459","GDYBYC0460","GDYBHF0458","GDYBWX0466","GDYBJY0463","GDYBYX0465",
	                 "GDYBWH0203","GDYBZX0237","GDZQYB0208","GDYBSY0236","GDYBZZ0129","GDYBHB0305","GDYBDQ0308",
	                 "GDYBQH0307","GDYBHH0306","GDYBCC0304","GDYBSY0311","GDYBFS0318","GDYBDD0321","GDYBDL0147",
	                 "GDYBNM0325","GDYBJN0312","GDYBZB0320","GDYBYT0315","GDYBQD0128","GDYBZY0216","GDYBGY0523",
	                 "GDYBKM0405","GDYBKM0522","GDYBCD0403","GDYBDY0515","GDYBNJ0529","GDYBNJ0404"];
	//建设银行
	var arrayJSYH = [];
	//农业银行
	var arrayNYYH = [];
	//中国银行
	var arrayZGYH = [];
	//工商银行
	var arrayGSYH = [];
	//交通银行
	var arrayJTYH = [];
	/* 私有业务模块的全局变量 end */
	
	function init()
	{
		queryDataSourceByChannel(channelInfo);
		if(channelInfo == 3){
			
			$(_pageId + " .user_form").show();
		}
		
		initPage();  // 初始化页面
	}
	
	function bindPageEvent()
	{
		/* 绑定返回 */
		appUtils.bindEvent($(_pageId+" .header .icon_back"),function(){
			appUtils.pageBack();
		});
		
		/* 绑定退出按钮*/
//		appUtils.bindEvent($(_pageId+" .header .icon_close"),function(){
//			require("utils").layerTwoButton("退出系统？","确认","取消",function(){
//				require("shellPlugin").callShellMethod("closeAppPlugin",null,null);  // 退出程序
//			},
//			function(){return false;});
//		});
		
		/* 点击页面其他元素隐藏下拉列表 */
		appUtils.bindEvent($(_pageId),function(e){
			$(_pageId+" .sel_list").slideUp("fast");	// 隐藏下拉列表
			e.stopPropagation();	// 阻止冒泡
		});
		
		
		/* 绑定套餐 */
		appUtils.bindEvent($(_pageId+" .input_form .pac"),function(e){
			$(_pageId+" .city").hide();  //隐藏城市列表
			$(_pageId+" .province").hide();  //隐藏省份列表
			$(_pageId+" .branch").hide();  //隐藏营业部列表
			$(_pageId+" .commission").hide();  //隐藏佣金列表
			$(_pageId+" .province ul li").removeClass("active");
			$(_pageId+" .packages").slideToggle("fast");	 // 显示选择省份的下拉列表
			e.stopPropagation();	// 阻止冒泡
		});
		
		/*客户经理输入框失去焦点时*/
		appUtils.bindEvent($(_pageId+" .name"),function(e){
			
			if($(this).val().trim().length > 0){
				
				if($(_pageId + " .protocolshow").css("display") == "none"){
					//查询协议
					queryProtocolList();
				}
			}else{
				
				$(_pageId + " .protocolshow").hide();
			}
		},"input");

		
		
		
		/* 绑定选择省份 */
		appUtils.bindEvent($(_pageId+" .mobile_form .sel_province"),function(e){
			
			//工行版本默认选择上海市,不可切换
			if(global.channelInfo == "6"){
				return false;
			}
			
			$(_pageId+" .city").hide();  //隐藏城市列表
			$(_pageId+" .branch").hide();  //隐藏营业部列表
			$(_pageId+" .commission").hide();  //隐藏佣金列表
			
				$(_pageId+" .packages").hide();  //隐藏套餐列表

			$(_pageId+" .province ul li").removeClass("active");
			$(_pageId+" .province").slideToggle("fast");	 // 显示选择省份的下拉列表
			e.stopPropagation();	// 阻止冒泡
		});
		
		/* 绑定选择城市 */
		appUtils.bindEvent($(_pageId+" .mobile_form .sel_city"),function(e){
			
			//工行版本默认选择上海市,不可切换
			if(global.channelInfo == "6"){
				return false;
			}
			
			$(_pageId+" .province").hide();  //隐藏省份列表
			$(_pageId+" .branch").hide();  //隐藏营业部列表
			$(_pageId+" .commission").hide();  //隐藏佣金列表
			
				$(_pageId+" .packages").hide();  //隐藏套餐列表
			
			$(_pageId+" .city ul li").removeClass("active");
			$(_pageId+" .city").slideToggle("fast");	// 显示选择城市的下拉列表
			e.stopPropagation();	// 阻止冒泡
		});
		
		/* 绑定选择营业部 */
		appUtils.bindEvent($(_pageId+" .mobile_form .sel_branch"),function(e){
			$(_pageId+" .province").hide();  //隐藏省份列表
			$(_pageId+" .city").hide();  //隐藏城市列表
			
				$(_pageId+" .packages").hide();  //隐藏套餐列表	
			
			$(_pageId+" .commission").hide();  //隐藏佣金列表
			$(_pageId+" .branch ul li").removeClass("active");
			$(_pageId+" .branch").slideToggle("fast");	// 显示选择营业厅的下拉列表
			e.stopPropagation();	// 阻止冒泡
		});
		
		/* 绑定选择佣金套餐 */
		appUtils.bindEvent($(_pageId+" .mobile_form .sel_commission"),function(e){
			$(_pageId+" .province").hide();  //隐藏省份列表
			$(_pageId+" .city").hide();  //隐藏城市列表
			
				$(_pageId+" .packages").hide();  //隐藏套餐列表
			
			$(_pageId+" .branch").hide();  //隐藏营业部列表
			$(_pageId+" .commission ul li").removeClass("active");
			$(_pageId+" .commission").slideToggle("fast");	// 显示选择营业厅的下拉列表
			e.stopPropagation();	// 阻止冒泡
		});
		
		/* 绑定下一步 */
		appUtils.bindEvent($(_pageId+" .fix_bot .ct_btn"),function(){
			var province_name =$(_pageId+" .mobile_form .sel_province").text();
			var city_name =$(_pageId+" .mobile_form .sel_city").text();
			var branch_name = $(_pageId+" .mobile_form .sel_branch").text();
			appUtils.setSStorageInfo("branchno",branchParam.branchno);  // 营业部id保存在session
			appUtils.setSStorageInfo("commission",branchParam.commission);  // 佣金保存在session
			if(province_name == "请选择省份")
			{
				layerUtils.iMsg(-1,"请先选择开户省份部");
				return false;
			}
			if(city_name == "请选择城市")
			{
				layerUtils.iMsg(-1,"请先选择开户城市");
				return false;
			}
			if(branch_name == "请选择营业部")
			{
				layerUtils.iMsg(-1,"请选择开户营业部");
				return false;
			}
			if(channelInfo == 3){
				var name = $(_pageId + " .name").val().trim();
				
				if(name.length > 0 && !validatorUtil.isCnAndEnNumeric(name)){
					
					layerUtils.iMsg(-1,"请输入正确的客服经理姓名");
					return;
				}
							
				if($(_pageId + " .protocolshow").css("display") == "block" && $(_pageId + " #check").attr("checked") !="checked"){
					
					layerUtils.iMsg(-1,"请阅读并同意以上协议");
					return false;
				}
			
				if($(_pageId + " #package").css("display") == "block" && 
						$(_pageId + " .pac").attr("spk_id") == undefined){
					
					layerUtils.iMsg(-1,"请选择服务套餐");
					return false;
				}
				//有协议就签署，没协议就提交套餐
				if($(_pageId + " .protocolshow").css("display") == "block"){
					
					queryOpenCheckSign();
				}else{
					//标准版才提交
					subPackage();
				}
			}else{
				appUtils.pageInit("account/selDepartment","account/uploadPhoto",branchParam);
			}

		});
	}
	
	/*通过渠道查询数据源*/
	function queryDataSourceByChannel(channel){
//		1-建设银行 ; 2-农业银行 ; 3-标准版 ; 4 - 中国银行  ; 
//		6-工商银行 ; 7-表示雪球 ; 9-光大银行  ; a-交通银行
		switch (channel) {
			case "1":
				arrayData = arrayJSYH;
				break;
			case "2":
				arrayData = arrayNYYH;
				break;
			case "4":
				arrayData = arrayZGYH;
				break;
			case "6":
				arrayData = arrayGSYH;
				break;
			case "9":
				arrayData = arrayGDYH;
				break;
			case "a":
				arrayData = arrayJTYH;
				break;
			default:
				break;
		}
	}
	
	
	/*中登验签*/
	function queryOpenCheckSign(){
		
		// 进行协议签署
		var protocolArray = new Array(),  // 协议数组
			userid = appUtils.getSStorageInfo("user_id"),
			ipaddr  = appUtils.getSStorageInfo("ip"),
			macaddr = appUtils.getSStorageInfo("mac"),
			protocolid = protocol.econtract_no,
			summary = protocol.econtract_md5,  // 协议内容MD5,签名摘要信息
			protocolParam = {
				"protocol_id":protocolid,
				"protocol_content":summary,
				"userId":userid,
				"type": "zd"
			};
		layerUtils.iLoading(true);  // 开启等待层......
		protocolArray.push(protocolParam);   // 添加值到数组中
			// 签署协议
			var signProtocolParam = {
				"user_id" : userid,
				"jsondata" : JSON.stringify(protocolArray),
				"ipaddr" : ipaddr,
				"checksign" : 0,
				"macaddr" : macaddr
			};
			
			// 新开中登验签
			service.queryOpenCheckSign(signProtocolParam,subPackage,false);
	}

	
	/*提交套餐*/
	function subPackage(){
		
		//屏蔽套餐
				/*if(appUtils.getSStorageInfo("openChannel") == "new")
				{
					appUtils.pageInit("account/selDepartment","account/uploadPhoto",branchParam);
					appUtils.clearSStorage("idInfo");  // 清除完成身份证上传步骤标记
				}
				else
				{
					appUtils.pageInit("account/selDepartment","account/uploadPhoto",branchParam);
				}
				return false;*/
		
		var param = {
				"userid" : appUtils.getSStorageInfo("user_id"),
				"mgr_id" : $(_pageId + " .name").val(),
				"spk_id" : $(_pageId + " .pac").attr("spk_id")
		};
		service.subPackage(param,function(data){
			
			var error_no = data.error_no,
				error_info = data.error_info,
				result = data.results;
			if(error_no == 0){
				
				//判断新开户还是转户
				if(appUtils.getSStorageInfo("openChannel") == "new")
				{
					appUtils.pageInit("account/selDepartment","account/uploadPhoto",branchParam);
					appUtils.clearSStorage("idInfo");  // 清除完成身份证上传步骤标记
				}
				else
				{
//					appUtils.pageInit("account/selDepartment","account/uploadPhotoChange",branchParam);
					appUtils.pageInit("account/selDepartment","account/uploadPhoto",branchParam);
				}
			}else{
				
				layerUtils.iMsg(-1,error_info);
				layerUtils.iLoading(false);  
			}
		});
	}

	
	function destroy()
	{
		service.destroy();
	}
	
	
	//查询协议
	function queryProtocolList(){
		
		service.queryProtocolList({"category_englishname":"yxryprotcl"},function(data){
			
			var error_no = data.error_no,
	          error_info = data.error_info;
			
			if(error_no == 0 && data.results.length > 0)
			{
				protocol = data.results[0];
				$(_pageId + " .protocolshow span").html("<span><input type=\"checkbox\" id=\"check\"/> 我已阅读并同意</span><a href=\"javascript:void(0)\" id=\"protocol00\" style=\"color:#00ACED\">《"+data.results[0].econtract_name+"》</a>");
			
				// 预绑定查看协议的事件
				appUtils.preBindEvent($(_pageId)," #protocol00",function(e){
					e.stopPropagation();  // 阻止冒泡
					appUtils.pageInit("account/selDepartment","account/showDigitalProtocol",{"protocolId" : data.results[0].econtract_no,"name":$(_pageId + " .name").val()});
				});
				$(_pageId + " .protocolshow").show();
			}else{
				layerUtils.iAlert(error_info);
				layerUtils.iLoading(false);
			}
		});
	}

	/*
	 * 查询套餐信息
	 * 501933
	 */
	function queryPackage(){
		
		service.queryPackage({},function(data){
			
			var error_no = data.error_no,
				error_info = data.error_info,
				results = data.results;
			
			if(error_no == 0 ){
				
				//有配置套餐信息时
				if(results.length > 0){
					var items = "";
					for(var i = 0; i < results.length; i++){
						
						var spk_id = results[i].spk_id,
							spk_name = results[i].spk_name,
							spk_content =results[i].spk_content,
							spk_commissionratio = results[i].spk_commissionratio;
						
						items += "<li spk_id='"+spk_id+"' spk_content='"+spk_content+"'><span>"+spk_name+"</span></li>";
					}
					
					$(_pageId + " .packages ul").html(items);
					$(_pageId + " #package").show();
					//绑定事件
					appUtils.bindEvent($(_pageId+" .packages ul li"),function(e){
						
						$(_pageId + " .pac").text($(this).text());
						$(_pageId + " .pac").attr("spk_id",$(this).attr("spk_id"));
						$(_pageId + " #pacContent").text("套餐类容："+$(this).attr("spk_content"));
						$(_pageId+" .packages").slideUp("fast");	//隐藏下拉框
						
						e.stopPropagation();	// 阻止冒泡
					});
					//默认选中第一个套餐
					setTimeout(function(){
						$(_pageId+" .packages ul li:eq(0)").click( function (e) {}).trigger("click");
					},"200");
					
				}else{
					//未配置套餐信息
					$(_pageId + " #package").hide();
				}
			}else{
				
				layerUtils.iMsg(-1,error_info);
				layerUtils.iLoading(false);  
			};
		});
		
	}

	
	/* 初始化页面 */
	function initPage()
	{
		cleanPageElement(); // 清理页面元素值
		var Commission = appUtils.getSStorageInfo("commission");  // 用户已选佣金id
		var Commission_name = appUtils.getSStorageInfo("commissionname");  // 用户已选佣金值
		var Branch_no = appUtils.getSStorageInfo("branchno"); // 用户已选营业部id
		var Branch_name = appUtils.getSStorageInfo("branchname");  // 用户已选营业部名称
		var Province_name = appUtils.getSStorageInfo("provincename");  // 用户已选省份
		var City_name = appUtils.getSStorageInfo("cityname");  // 用户已选城市
		//  用户如果已选择了营业部，就不需要定位
		if(Province_name && City_name && Branch_name)
		{
			hasbranch = true;
			localPro = Province_name;
			localCity = City_name;
			localBranch = Branch_name;
			branchParam.branchno = Branch_no;
			$(_pageId+" .sel_province").html(Province_name);
			$(_pageId+" .sel_city").html(City_name);
			$(_pageId+" .sel_branch").html(Branch_name);
			if(Commission)
			{
				branchParam.commission = Commission;
				$(_pageId+" .sel_commission").html(Commission_name);
			}
			getBranch();  // 获取营业部List
		}
		else
		{
			//工行版本默认选择上海市
			if(global.channelInfo == "6" || global.channelInfo == "1" || global.channelInfo == "4"
			|| global.channelInfo == "2" || global.channelInfo == "a"){
				
				localPro = "上海市";		
				localCity = "上海市";		
				$(_pageId+" .sel_province").text(localPro);	  
				$(_pageId+" .sel_city").text(localCity);	  
				getBranch();  // 获取营业部List
			}else{
				getPosition();  // 进行地理定位
			}
		}
	}
	
	/* 定位本地地址 */
	function getPosition()
	{
		var positionSign = "";
		layerUtils.iAlert("正在定位中，请稍后....", -1, function(){
			layerUtils.iLayerClose();
			positionSign = "1";
			if(positionSign == "1"){
				getBranch();  // 获取营业部List
			}
//			getBranch();  // 获取营业部List
//			//cleanPageElement(); // 清理页面元素值
		},"取消");
		var param = {
			"funcNo":"50023"
		};
		var result = external.callMessage(param);
		
		if(result.error_no == "0") {
			ip = result.results[0].ip;
			//获取定位省份和城市
			service.getProvCity({"ip":ip}, function(data){
				layerUtils.iLayerClose();  // 关闭定位提示
				if(positionSign == ""){
					positionSign = "2";
				}
				if(positionSign == "2"){
					if(data.error_no == 0 && data.results.length !=0 )
					{
						hasbranch = false;
						localPro = data.results[0].province;
						localCity = data.results[0].city;
						$(_pageId+" .sel_province").text(localPro);
						$(_pageId+" .sel_city").text(localCity);
					}
					else
					{
						hasbranch = true;
						layerUtils.iMsg(-1,"定位附近营业部失败，请您手动选择", 2);
					}
					getBranch();  // 获取营业部List
				}
			},false,false);
		}
	}
	
	/* 获取营业部List */
	function getBranch()
	{
		service.queryBranch({},function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			if(error_no=="0" && data.dsName)
			{
				provinceList = data.provinceList; //省份集合
			    cityList = data.cityList;	//城市集合
			    branchList = data.branchList;	//营业部集合
			    var n_branchList = new Array();	//创建一个新的省份数组
			    var n_cityList = new Array();
			    var n_provinceList = new Array();
			   if(arrayData != null && arrayData != undefined && arrayData!=""){
				   
				    //循环匹配营业部
				    for(var i = 0; i < branchList.length; i++){
				    	
				    	for(var j = 0; j < arrayData.length; j++){
				    		
				    		if(branchList[i].branchcode == arrayData[j]){
				    			n_branchList.push(branchList[i]);
				    			break;
				    		}
				    	}
				    }
				    //重新给营业部赋值
				    branchList = n_branchList;
				    console.log(JSON.stringify(branchList));
				    
				    //循环匹配城市
				    for(var i = 0; i < cityList.length; i++){
				    	
				    	for(var j = 0; j < branchList.length; j++){
				    		
				    		if(cityList[i].cityno == branchList[j].cityno){
				    			n_cityList.push(cityList[i]);
				    			break;
				    		}
				    	}
				    }
				    cityList = n_cityList;
				    console.log("=============");
				    console.log(JSON.stringify(cityList));
				    
				    //循环匹配省
				    for(var i = 0; i < provinceList.length; i++){
				    	
				    	for(var j = 0; j < cityList.length; j++){
				    		
				    		if(provinceList[i].provinceno == cityList[j].provincenno){
				    			n_provinceList.push(provinceList[i]);
				    			break;
				    		}
				    	}
				    }
				    provinceList = n_provinceList;
				    console.log("=============");
				    console.log(JSON.stringify(provinceList));
			   }
//			    return;

			    commissionList = data.commissionList;	//佣金集合
				var plen = provinceList.length,
				      clen = cityList.length,
				      blen = branchList.length,
					  colen = commissionList.length;
				var pro_str = "", provinceno = "", provincename = "";
				// 遍历省份集合
				for(var i=0; i<plen; i++)
				{
					provinceno = provinceList[i].provinceno; // 省份id
					provincename = provinceList[i].provincename;  // 省份名称
					pro_str += "<li pid='"+provinceno+"'><span>"+provincename+"</span></li>";
					if(localPro != "")  // 若定位省份存在，进行填充
					{
						// 填充定位省份下的所有城市
						if(provincename == localPro)
						{
							var city_str = "", pid = "", cityno = "", cityname = "";
							for(var j=0; j<clen; j++)
							{
								pid = cityList[j].provincenno;
							    cityno = cityList[j].cityno;
							    cityname = cityList[j].cityname;
								if(pid == provinceno) 
								{
									city_str += "<li cid='"+cityno+"'><span>"+cityname+"</span></li>";
								}
							}
							$(_pageId+" .city ul").html(city_str);  // 填充城市下拉框
							bindCity();  //点击城市
						}
					}
				}
				$(_pageId+" .province ul").html(pro_str);  // 填充省份下拉框
				bindProvince();  //点击省份
				
				// 存在localCity则遍历所有城市集合
				if(localCity != "")
				{
					for(var i=0; i<clen; i++)
					{
						var cityno = cityList[i].cityno; // 城市id
						var cityname = cityList[i].cityname;  // 城市名称
						// 填充定位城市下的所有营业部名称
						if(cityname == localCity)
						{
							hasbranch = true;  // 定位的城市拥有营业部
							var branch_str = "", cno = "", branchcode = "", branchname = "";
							for(var j=0; j<blen; j++)
							{
								cno = branchList[j].cityno;
						        branchcode = branchList[j].branchcode,
						        branchname = branchList[j].branchname;
									
									branch_str+= "<li bid='"+branchcode+"'><span>"+branchname+"</span></li>";
								}
							}
							$(_pageId+" .branch ul").html(branch_str);  // 填充对应城市的营业部
							bindBranch();  //点击营业部
						}
					}
					if(!hasbranch)  // 定位的城市没有相关营业部
					{
						layerUtils.iMsg(-1,"您当前所处城市无相关营业部，请手动选择", 4);
					}
				}
				
				// 存在localBranch则遍历所有营业部集合
			if(localBranch != "")
			{
					for(var i=0; i<blen; i++)
					{
						var branchcode = branchList[i].branchcode;
						var branchname = branchList[i].branchname;
						
						// 填充该营业部下的所有佣金套餐
						if(branchname == localBranch)
						{
							var commission_str = "", bno = "", commission = "", sortno = "";
							for(var j=0; j<colen; j++)
							{
								
								bno = commissionList[j].branchcode;
						        sortno = commissionList[j].sortno,
						        commission = commissionList[j].commission;
								if(bno == branchcode)  
								{
									commission_str+= "<li yid='"+sortno+"'><span>"+commission+"</span></li>";
								}
							}
							$(_pageId+" .commission ul").html(commission_str);  // 填充对应城市的营业部
							bindCommission();  //点击营业部
						}
					}
			}
			else
			{
				layerUtils.iMsg(-1,"定位营业部失败,请手动选择");  //提示错误信息
			}
			
			//屏蔽套餐
		//	queryPackage();  //查询套餐

		},true,true,handleTimeout);
	}
	
	/* 处理请求超时 */
	function handleTimeout()
	{
		layerUtils.iConfirm("请求超时，是否重新加载？",function(){
			getBranch();  // 再次获取营业部
		});
	}
	
	/* 选中省份事件处理 */
	function bindProvince()
	{
		appUtils.bindEvent($(_pageId+" .province ul li"),function(e){
			var pid = $(this).attr("pid");
			$(this).addClass("active").siblings().removeClass("active");
			var provincename = $(this).text();  //当前选中省份的值
			var sel_pname = $(_pageId+" .sel_province").text();  //上一次选中省份的值
			$(_pageId+" .sel_province").text(provincename);	  //将选中值赋给选择框
			appUtils.setSStorageInfo("provincename",provincename);
			$(_pageId+" .province").slideUp("fast");	//隐藏下拉框
			 //再次点击相同省份,下级菜单不改变，否则重置
			if(provincename != sel_pname)   
			{
				$(_pageId+" .sel_city").text("请选择城市");
				$(_pageId+" .sel_branch").text("请选择营业部");
				$(_pageId+" .sel_commission").text("请选择佣金套餐");
				$(_pageId+" .branch ul").html("");
				$(_pageId+" .commission ul").html("");
			}
			var provincenno = "";  //省份ID
			var city_str = "";
			//选中省份立即填充相应城市
			for(var i=0; i<cityList.length; i++)
			{
				provincenno = cityList[i].provincenno;
				cityno = cityList[i].cityno;
				cityname = cityList[i].cityname;
				if(pid == provincenno)  //填充当前省份下的城市列表
				{
					city_str+= "<li cid='"+cityno+"'><span>"+cityname+"</span></li>";
				}
			}
			$(_pageId+" .city ul").html(city_str);  //填充城市下拉框
			e.stopPropagation();	// 阻止冒泡
			bindCity();  //点击城市
		});
	}
	
	/* 选中城市事件绑定 */
	function bindCity()
	{
		appUtils.bindEvent($(_pageId+" .city ul li"),function(e){
			var cid = $(this).attr("cid");
			$(this).addClass("active").siblings().removeClass("active");
			var cityname = $(this).text();  //当前选择城市的值
			var sel_cname = $(_pageId+" .sel_city").text();  //上次选择城市的值
			$(_pageId+" .sel_city").text(cityname);	  //选中值赋给选择框
			appUtils.setSStorageInfo("cityname",cityname);
			$(_pageId+" .city").slideUp("fast");	//隐藏下拉框
			//再次点击相同城市,下级菜单不改变，否则重置
			if(sel_cname != cityname)	 
			{
				$(_pageId+" .sel_branch").text("请选择营业部");
				$(_pageId+" .sel_commission").text("请选择佣金套餐");
				$(_pageId+" .commission ul").html("");
			}
			//选中城市立即填充相应营业部
			var cityno = "";  //城市ID
			var branch_str = "";
			for(var i=0; i<branchList.length; i++)
			{
				cityno = branchList[i].cityno;
				branchcode = branchList[i].branchcode;
				branchname = branchList[i].branchname;
				if(cid == cityno)  //填充当前城市下的营业部列表
				{
					branch_str+= "<li bid='"+branchcode+"'><span>"+branchname+"</span></li>";
				}
			}
			$(_pageId+" .branch ul").html(branch_str);  //填充营业部下拉框
			e.stopPropagation();	// 阻止冒泡
			bindBranch();  //点击营业部
		});
	}
	
	/* 选中营业部事件绑定*/
	function bindBranch()
	{
		appUtils.bindEvent($(_pageId+" .branch ul li"),function(e){
			var bid = $(this).attr("bid");
			$(this).addClass("active").siblings().removeClass("active");
			branchParam.branchno = bid;
			var branchname = $(this).text();  //当前选中营业部的值
			var sel_bname = $(_pageId+" .sel_branch").text();  //上一次选中营业部的值
			$(_pageId+" .sel_branch").attr("branchcode",bid);	
			$(_pageId+" .sel_branch").text(branchname);	  //选中值赋给选择框
			appUtils.setSStorageInfo("branchname",branchname);
			$(_pageId+" .branch").slideUp("fast");	//隐藏下拉框
			//再次点击相同城市,下级菜单不改变，否则重置
			if(sel_bname != branchname)	 
			{
				$(_pageId+" .sel_commission").text("请选择佣金套餐");
			}
			// 选中营业部立即填充对应的佣金套餐 
			var branchcode = "";  //营业部ID
			var commission_str = "";
			for(var i=0; i<commissionList.length; i++)
			{
				branchcode =commissionList[i].branchcode;
				commission =commissionList[i].commission;
				sortno =commissionList[i].sortno;
				if(bid == branchcode)
				{
					commission_str+= "<li yid='"+sortno+"'><span>"+commission+"</span></li>";
				}
			}
			$(_pageId+" .commission ul").html(commission_str);  //填充佣金套餐下拉框
			e.stopPropagation();	// 阻止冒泡
			bindCommission();  //点击佣金套餐
		});	
	}
	
	/* 选中佣金事件绑定*/
	function bindCommission()
	{
		appUtils.bindEvent($(_pageId+" .commission ul li"),function(e){
			var yid = $(this).attr("yid");
			$(this).addClass("active").siblings().removeClass("active");
			branchParam.commission = yid;
			var commissionname = $(this).text();  //当前选中的佣金值
			$(_pageId+" .sel_commission").attr("commissionname",yid);	 
			$(_pageId+" .sel_commission").text(commissionname);	  //选中值赋给选择框
			appUtils.setSStorageInfo("commissionname",commissionname);
			$(_pageId+" .commission").slideUp("fast");	//隐藏下拉框
			e.stopPropagation();	// 阻止冒泡
		});	
	}
	
	/* 清理界面元素 */
	function cleanPageElement()
	{
		hasbranch = false;
		$(_pageId+" .header .icon_back").hide(); //隐藏返回按钮
		$(_pageId+" .sel_province").text("请选择省份");
		$(_pageId+" .sel_city").text("请选择城市");
		$(_pageId+" .sel_branch").text("请选择营业部");
		$(_pageId+" .sel_commssion").text("请选择佣金套餐");
	}
	var selDepartment = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	
	// 暴露对外的接口
	module.exports = selDepartment;
});

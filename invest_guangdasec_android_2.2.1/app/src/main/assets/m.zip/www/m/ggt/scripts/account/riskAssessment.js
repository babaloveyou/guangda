/**
* 风险测评
*/
define(function(require, exports, module){
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
		  service = require("investService").getInstance(),  //业务层接口，请求数据
		  global = require("gconfig").global,
		  layerUtils = require("layerUtils"),
		  util=require("utils"),
		  arrs=[],
		  _pageId = "#account_riskAssessment";
	/* 私有业务模块的全局变量 end */
	
	function init()
	{
		
		getRiskAssessQuestions();  // 获取问卷答题
		util.setContentHeight(_pageId +" .main",_pageId+" .header");
	}
	
	function bindPageEvent()
	{
		/* 提交答题  */
		appUtils.preBindEvent($(document),_pageId+" .ce_btn",function(){
			postRiskAssessmentData();  // 提交答题
		});
		
		/* 绑定返回事件 */
		appUtils.bindEvent($(_pageId+" .header .icon_back"),function(){
			appUtils.pageBack();
		});
	}
	
	function destroy()
	{
		arrs=[];
		$(_pageId).remove();
		service.destroy();
	}
	
	/* 获取风险测评题库 */
	function getRiskAssessQuestions()
	{
		// 查询风险评测
		var survey_type = "1",
			queryTestParam = {"survey_type":survey_type};
		service.queryRiskToc(queryTestParam,function(data){
			var errorNo = data.error_no,
				errorInfo = data.error_info;
			if(errorNo=="0" && data.dsName)   //调用成功
			{
				$(data.questionList).each(function(i,ele){
					//遍列题目名称
					var id=ele.question_id,
						ibind,
						obj={};
					obj["qId"]=id;
					arrs.push(obj); //题目id数组
					if(i==0){
						ibind=id;
					}
					var name=ele.question_name;
					var type=ele.type;
					var htmltext="<dl><dt>"+(i+1)+"、"+name+"</dt><dd>";
					//遍列答案
					if(type=="0"){
						$(data.answerList).each(function(idx,e){
							if(e.question_id==id){
								htmltext+="<p><a href='javascript:void(0);' name='"+id+"' id='"+(i+1)+"' value='"+e.answer_id+"' type='0'>"+e.answer_name+"</a></p>";
							}
						});
					}else{
						$(data.answerList).each(function(idx,e){
							if(e.question_id==id){
								htmltext+="<p><a href='javascript:void(0);' name='"+id+"' id='"+(i+1)+"' value='"+e.answer_id+"' type='1'>"+e.answer_name+"</a></p>";
							}
						});
					}
					
					htmltext+="</dd></dl>";
					$(_pageId+" .test_list").append(htmltext);
				});
				
				// 为选择按钮添加事件
				appUtils.bindEvent($(_pageId+" .test_list a"),function(){
					var quetype = $(this).attr("type");	 // 问题类型0：单选，1：多选
					var queid   = $(this).attr("id");
					if(quetype == 1)
					{
						$(this).toggleClass("active");
					}
					else
					{
						if($(this).hasClass("active"))
						{
							$(this).parent().parent().parent().find("dt").css("color","red");  // 未选择答案，则将该题标记为红色
							$(this).removeClass("active");
						}
						else
						{
							$(_pageId+" .test_list #"+queid).removeClass("active");
							$(this).parent().parent().parent().find("dt").css("color","#666666");	// 题目红色标记恢复黑色
							$(this).addClass("active");
						}
					}
				});
			}
			else{
				layerUtils.iAlert(errorInfo,-1);
			}
		},{"isLastReq":true,"isShowWait":true,"timeOutFunc":handleTimeout});
	}
	
	/* 处理请求超时 */
	function handleTimeout()
	{
		layerUtils.iConfirm("请求超时，是否重新加载？",function(){
			getRiskAssessQuestions();  // 再次风险测评题目
		});
	}
	
	/**
	 * 港股通模拟登陆成功后保存数据（session）
	 * */
	function saveData(result)
	{
		// 黑名单标志
		appUtils.setSStorageInfo("in_blacklist",result.in_blacklist);
		//沪A账户是否指定交易
		appUtils.setSStorageInfo("is_regTrade",result.is_regTrade);
		//是否需要跑批
		appUtils.setSStorageInfo("is_autoTask",result.is_autoTask);
		//开通港股通备注
		appUtils.setSStorageInfo("ggtopen_remark",result.ggtopen_remark);
		//当前步骤
		appUtils.setSStorageInfo("current_step",result.current_step);
		//证件类型
		appUtils.setSStorageInfo("idtype",result.idtype);
		//证件有效截止日期
		appUtils.setSStorageInfo("idenddate",result.idenddate);
		//证件有效开始日期
		appUtils.setSStorageInfo("idbegindate",result.idbegindate);
		//沪A账号是否加挂
		appUtils.setSStorageInfo("isadd",result.isadd);
		//港股通开立标志
		appUtils.setSStorageInfo("ggtopen_flag",result.ggtopen_flag);
		//风险测评分数
		appUtils.setSStorageInfo("survey_score",result.survey_score);
		//风险测评是否有效
		appUtils.setSStorageInfo("risk_survey_valid",result.risk_survey_valid);
		//风险测评等级
		appUtils.setSStorageInfo("rating_lvl",result.rating_lvl);
		//知识测评分数
		appUtils.setSStorageInfo("knowledge_score",result.knowledge_score);
		//营业部编号
		appUtils.setSStorageInfo("branchno",result.branchno);
		//用户编号
		appUtils.setSStorageInfo("user_id",result.user_id);
		//风险测评等级名称
		appUtils.setSStorageInfo("rating_lvl_name",result.rating_lvl_name);
		//客户姓名
		appUtils.setSStorageInfo("custname",result.custname);
		//沪A账号
		appUtils.setSStorageInfo("shaaccount",result.shaaccount);
		//证券账户资产总值
		appUtils.setSStorageInfo("marketvalue",result.marketvalue);
		//电话号码
		appUtils.setSStorageInfo("mobileno",result.mobileno);
		//客户类型
		appUtils.setSStorageInfo("cust_type",result.cust_type);
		//信用证券账户总资产
		appUtils.setSStorageInfo("net_asset",result.net_asset);
		//联系地址
		appUtils.setSStorageInfo("address",result.address);
		//身份证是否在有效期内
		appUtils.setSStorageInfo("idenddate_valid",result.idenddate_valid);
		//身份证号
		appUtils.setSStorageInfo("idno",result.idno);
	}

	/* 提交风险评测答案 */
	function postRiskAssessmentData()
	{
		var len=$(_pageId+" .test_list dl").length;
		var str="";   //题目，答案拼接的字符串
		var strs="";
		$(arrs).each(function(i,e){
			var val="";
			var types=$(_pageId+ " a[name='"+e.qId+"']").attr("type");
			if(types=="1"){
				$(_pageId+ " a[name='"+e.qId+"']").each(function(){
	                if($(this).hasClass("active")){
	                    val += $(this).attr("value")+"-";
	                }
	            });
	            if(val.indexOf("-")!=-1){
	            	val=val.substr(0,val.length-1);
	            }
			}else{
				val=$(_pageId+" .test_list a[name='"+e.qId+"'].active").attr("value");
			}
			if(val==undefined||val==""){
				strs+=$(_pageId+" a[name='"+e.qId+"']").attr("id")+"、";
			}else{
				str+=e.qId+"|"+val+"||,";
			}
		});
		str=str.substr(0,str.length-1);
		var strss=str.split(",");
		if(strss.length!=len){
			strs=strs.substr(0,strs.length-1);
			layerUtils.iMsg(-1,"第"+strs+"题没有选择，请检查后重新确认！");
		}else{
			var submitTestParam={
				"user_id":appUtils.getSStorageInfo("user_id"),
				"survey_type":"1",
				"answer_str":str
			};
			//提交风险评测答案
			service.submitTestAnswer(submitTestParam,function(data){
				var errorNo = data.error_no;
				var errorInfo = data.error_info;
				if(errorNo==0 && data.results.length != 0)	//调用成功,跳转到风险测评页面
				{
					var remark = data.results[0].total_score,   //风险等级评分
						riskdesc = data.results[0].define,  //风险评测文字等级
						define_value = data.results[0].define_value;  //风险评测字母等级
					var checkLoginPath = global.checkLoginPath;
					// 检测是否登录，保存返回值
					appUtils.invokeServer(checkLoginPath,{}, function(data){
						var result = data.data;
						if(result != undefined){
							saveData(result);  // 将数据保存到 session 中
							appUtils.pageInit("account/riskAssessment","account/riskInfo",{"remark":remark,"riskdesc":riskdesc,"define_value":define_value});
						}
						else{
							layerUtils.iMsg(-1,data.err_info);
							layerUtils.iLoading(false);
						}
					});
				}
				else
				{
					layerUtils.iAlert(errorInfo,-1);
				}
			},{"isLastReq":false});
		}
	}
	
	var riskAssessment = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	
	module.exports = riskAssessment;
});
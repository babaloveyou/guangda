﻿/**
 * 手机前端service层调用接口
 **/
define(function(require,exports,module){
	var appUtils = require("appUtils");
	var gconfig = require("gconfig");
	var global = gconfig.global;
	var service = require("service");
	var serviceSingleton = new service.Service();
	
	/********************************公共代码部分********************************/
    function commonInvoke(paraMap, callback, ctrlParam, reqParamVo){
		reqParamVo.setReqParam(paraMap);
		ctrlParam = ctrlParam?ctrlParam:{};
		reqParamVo.setIsLastReq(ctrlParam.isLastReq);
		reqParamVo.setIsAsync(ctrlParam.isAsync);
		reqParamVo.setIsShowWait(ctrlParam.isShowWait);
		reqParamVo.setTimeOutFunc(ctrlParam.timeOutFunc);
		reqParamVo.setIsShowOverLay(ctrlParam.isShowOverLay);
		reqParamVo.setTipsWords(ctrlParam.tipsWords);
		reqParamVo.setDataType(ctrlParam.dataType);
		reqParamVo.setIsGlobal(ctrlParam.isGlobal);
		reqParamVo.setProtocol(ctrlParam.protocol);
		serviceSingleton.invoke(reqParamVo, callback);
	}
	function destroy(){
		serviceSingleton.destroy();
	}
	var mobileService = {
		"getInstance": getInstance, //为了避免以前调用getInstance方法报错
		"destroy": destroy
	};
	function getInstance(){
		return mobileService;
	}
	module.exports = mobileService;
	
	/********************************应用接口开始********************************/
	/**
	 * 接口方法模板
	 * @param param json格式入参
	 * @param callback 回调处理
	 * @param ctrlParam json格式控制参数，包括protocol、isLastReq、isAsync、isShowWait、
	 * 	isShowOverLay、tipsWords、timeOutFunc、dataType、isGlobal
	 */
	mobileService.submitPhoto = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
		paraMap["funcNo"] = "501503";
		paraMap["user_id"] = param.user_id;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    }
	
	/**
	 *  获取用户手机号码 
	 */
	function getPhone(){
		var phone = "";
		if(global.phone){
			phone = global.phone;
		}
		else{
			// 获取壳子里的手机号
//			var key = {key : "phone"};
//			phone = require("external").callFunction("55601",JSON.stringify(key)); 
//			global.phone = phone;
		}
		return phone;
	}
	
	/**
	 * 添加 op_station 到接口请求参数中
	 * @param param 参数对象
	 * 渠道定义为（0：PC，1：android，2：ios，3：pad，4：其他）
		op_station的值格式为如下：通道编号|IP地址|MAC地址|硬盘序列号|CPU序列号|手机号码|硬件特征码|来源|其他
		来源的定义为（0：腾讯，1：新浪，2：百度）
	 */
	function addOpStation(param)
	{
		var channelNo = " "; // 通道编号
		var ipAddr = " "; // ip 
		var macAddr = " "; // mac
		var hardId = " "; // 硬盘序列号（硬件id）
		var cpuId = " "; // cpu 序列号
		var mobileNo = " "; // 手机号
		var hardIdentifier = " "; // 硬件特征码
		var source = " "; // 来源
		var other = " "; // 其他
		if(iBrowser.android)
		{
			channelNo = "1";
		}
		else if(iBrowser.iPad || iBrowser.iPhone || iBrowser.ios)
		{
			channelNo = "2";
		}
		if(global.hardId)
		{
			hardId = global.hardId;
		}
		var local_phone = appUtils.getLStorageInfo("MobileNum"); // local 中的电话
		if(local_phone)
		{
			mobileNo = local_phone;
		}
		if(param.phone)
		{
			mobileNo = param.phone;
		}
		var aOpStation = [];
		aOpStation.push(channelNo);
		aOpStation.push("|");
		aOpStation.push(ipAddr);
		aOpStation.push("|");
		aOpStation.push(macAddr);
		aOpStation.push("|");
		aOpStation.push(hardId);
		aOpStation.push("|");
		aOpStation.push(cpuId);
		aOpStation.push("|");
		aOpStation.push(mobileNo);
		aOpStation.push("|");
		aOpStation.push(hardIdentifier);
		aOpStation.push("|");
		aOpStation.push(source);
		aOpStation.push("|");
		aOpStation.push(other);
		param.op_station = aOpStation.join(""); // 通道编号|IP地址|MAC地址|硬盘序列号|CPU序列号|手机号码|硬件特征码|来源|其他
	}
	
	/**
	 * @Title 加密(1000000)
	 */
	mobileService.getRSAKey = function (param,callback,ctrlParam)
	{
		var paraMap = {};
		paraMap["funcNo"] = "1000000";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	}
	
	/**
	 * 资金账号用户登入(1001103)
	 * @param fund_account 资金账号
	 * @param trade_pwd 交易密码
	 * @param callback 回调函数
	 * @param isLastReq 是否最后一次请求
	 * @param isShowWait 是否显示等待层
	 */
	mobileService.fundLogin = function(param,callback,ctrlParam)
	{
		var paraMap = {};
		paraMap["funcNo"] = "1001103";
		paraMap["fund_account"] = param.fund_account;
		paraMap["trade_pwd"] = param.trade_pwd;
		paraMap["ticket"] = param.vf_code;
		paraMap["mac"] = param.mac;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	};
	
	/*
	 * 风险测评
	 */
	mobileService.queryRiskToc = function(param,callback,ctrlParam)
	{
		var paraMap = {};
		paraMap["funcNo"] = "1005002";
		paraMap["fund_account"] = param.fund_account;
		paraMap["branch_no"] = param.branch_no;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	};
	
	/*
	 * 客户信息查询1005001
	 */
	mobileService.queryAccountInfo = function(param,callback,ctrlParam)
	{
		var paraMap = {};
		paraMap["funcNo"] = "1005001";
		paraMap["fund_account"] = param.fund_account;
		paraMap["branch_no"] = param.branch_no;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	};
	
	/*
	 * 股东信息查询1005004
	 */
	mobileService.queryStockAcccount = function(param,callback,ctrlParam)
	{
		var paraMap = {};
		paraMap["funcNo"] = "1005004";
		paraMap["fund_account"] = param.fund_account;
		paraMap["branch_no"] = param.branch_no;
		paraMap["user_id"] = param.user_id;
		paraMap["market"] = param.market;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	};
	
	/*
	 *查询首次交易日期 
	 */
	mobileService.queryFirstTime = function(param,callback,ctrlParam)
	{
		var paraMap = {};
		paraMap["funcNo"] = "1005010";
		paraMap["stock_type"] = param.stock_type;
		paraMap["stock_code"] = param.stock_code;
		paraMap["user_id"] = param.user_id;
		paraMap["type"] = param.type;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	};
	
	/*
	 * 查询协议名称1005005
	 */
	mobileService.queryXyname = function(param,callback,ctrlParam)
	{
		var paraMap = {};
		paraMap["funcNo"] = "1005005";
		paraMap["category_englishname"] = param.category_englishname;
		paraMap["category_no"] = param.category_no;
		paraMap["econtract_no"] = param.econtract_no;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	};
	
	/*
	 * 查询协议内容
	 */
	mobileService.queryXyInfo = function(param,callback,ctrlParam)
	{
		var paraMap = {};
		paraMap["funcNo"] = "1005006";
		paraMap["econtract_version"] = param.econtract_version;
		paraMap["econtract_no"] = param.econtract_no;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	};
	
	/*
	 * 电子协议签署
	 */
	mobileService.signCheck = function(param,callback,ctrlParam)
	{
		var paraMap = {};
		paraMap["funcNo"] = "1005007";
		paraMap["user_id"] = param.user_id;
		paraMap["jsondata"] = param.jsondata;
		paraMap["checksign"] = param.checksign;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	};
	
	mobileService.queryxyMoney = function(param,callback,ctrlParam)
	{
		var paraMap = {};
		paraMap["funcNo"] = "1005011";
		paraMap["account"] = param.account;
		paraMap["user_id"] = param.user_id;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	};
	
	/*
	 * 客户退市整理签约/查询 
	 */
	mobileService.querySignInfo = function(param,callback,ctrlParam)
	{
		var paraMap = {};
		paraMap["funcNo"] = "1005009";
		paraMap["fund_account"] = param.fund_account;
		paraMap["branch_no"] = param.branch_no;
		paraMap["user_id"] = param.user_id;
		paraMap["market_code"] = param.market_code;
		paraMap["stock_code"] = param.stock_code;
		paraMap["access_type"] = param.access_type;
		paraMap["mode_operation"] = param.mode_operation;
		paraMap["market_codes"] = param.market_codes;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	};
	
	/**
	 * 查询用户信息(1000203)
	 * @param user_id 用户编号
	 * @param account_name 账户名
	 * @param callback 回调函数
	 * @param isLastReq 是否最后一次请求
	 * @param isShowWait 是否显示等待层
	 */
	mobileService.queryUserInfo = function(param,callback,ctrlParam)
	{
		var paraMap = {};
		paraMap["funcNo"] = "1000203";
		paraMap["user_id"] = param.user_id;
		paraMap["account_name"] = param.account_name;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	};
	
	/**
	 * 查询资金(1001113)
	 * @param fund_account   资金账号
	 * @param callback 回调函数
	 * @param isLastReq 是否最后一次请求
	 * @param isShowWait 是否显示等待层
	 */
	mobileService.queryAsset = function(param,callback,ctrlParam)
	{
		var paraMap = {};
		paraMap["funcNo"] = "1001113";
		paraMap["fund_account"] = param.fund_account;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	};
	
	/**
     * 查询合约信息
     * @param sub_id   题号
     */
	mobileService.queryLoanInfo = function(param,callback,ctrlParam)
    {
    	var paraMap = {};
    	paraMap["funcNo"] = "610018";
		paraMap["page"] = param.page;
		paraMap["fund_account"] = param.fund_account;
		paraMap["size"] = param.size;
		paraMap["order_no"] = param.orderNo;
		paraMap["order_status"] = "1,2,3,5,6,8,9,11,12,13,14,15";
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
  	 * 持仓查询 301503
	 * @param {Object} entrust_way              委托方式
  	 * @param {Object} branch_no                分支机构
  	 * @param {Object} fund_account             资金账号
  	 * @param {Object} cust_code                客户编号
  	 * @param {Object} sessionid                会话号
   	 * @param {Object} stock_account            证券账号
   	 * @param {Object} stock_code               股票号码
  	 * @param {Object} exchange_type            交易类别
  	 * @param {Object} callback	回调方法
  	 */	
    mobileService.queryStockData = function(param,callback,ctrlParam) 
    {
		var paraMap = {};
		paraMap["funcNo"] = "301503";
		paraMap["entrust_way"] = "SJWT";
		paraMap["branch_no"] =  param.branch_no;
		paraMap["fund_account"] = param.fund_account;
		paraMap["cust_code"] =  param.cust_code;
		paraMap["sessionid"] =  param.sessionid;
		paraMap["stock_account"] = param.stock_account;
		paraMap["stock_code"] =  param.stock_code;
		paraMap["exchange_type"] = param.exchange_type;
		paraMap["phone"] = getPhone();
		addOpStation(paraMap); // 添加 op_station 到接口请求参数中
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
	
    /**
  	 * 当日成交查询 301509
	 * @param {Object} entrust_way              委托方式
  	 * @param {Object} branch_no                分支机构
  	 * @param {Object} fund_account             资金账号
  	 * @param {Object} cust_code                客户编号
  	 * @param {Object} sessionid                会话号
  	 * @param {Object} callback	回调方法
  	 */
    mobileService.queryTodayTrade = function(param,callback,ctrlParam)
  	{
  		var paraMap = {};
  	    paraMap["funcNo"] = "301509";
  	    paraMap["entrust_way"] = "SJWT";
	    paraMap["branch_no"] =  param.branch_no;
	    paraMap["fund_account"] = param.fund_account;
	    paraMap["cust_code"] =  param.cust_code;
	    paraMap["sessionid"] =  param.sessionid;
	    paraMap["entrust_bs"] = param.entrust_bs;
	    paraMap["phone"] = getPhone();
	    addOpStation(paraMap); // 添加 op_station 到接口请求参数中
	    var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
  	};
  	
  	/**
  	 * 当日委托查询301508
	 * @param {Object} entrust_way              委托方式
  	 * @param {Object} branch_no                分支机构
  	 * @param {Object} fund_account             资金账号
  	 * @param {Object} cust_code                客户编号
  	 * @param {Object} sessionid                会话号
  	 */
  	mobileService.queryTodayTrust = function(param,callback,ctrlParam)
  	{
  		var paraMap = {};
  	    paraMap["funcNo"] = "301508";
  	    paraMap["entrust_way"] = "SJWT";
	    paraMap["branch_no"] =  param.branch_no;
	    paraMap["fund_account"] = param.fund_account;
	    paraMap["cust_code"] =  param.cust_code;
	    paraMap["sessionid"] =  param.sessionid;
	    paraMap["entrust_bs"] = param.entrust_bs;
	    paraMap["phone"] = getPhone();
	    addOpStation(paraMap); // 添加 op_station 到接口请求参数中
	    var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
  	};
    
  	/**
  	 * 当日资金变动(1001110)
  	 * @param {Object} entrust_way              委托方式
  	 * @param {Object} branch_no                分支机构
  	 * @param {Object} fund_account             资金账号
  	 * @param {Object} cust_code                客户编号
  	 * @param {Object} sessionid                会话号
  	 */
  	mobileService.queryTodayFund = function(param,callback,ctrlParam)
  	{
  		var paraMap = {};
  		paraMap["funcNo"] = "1001110";
  		paraMap["entrust_way"] = "SJWT";
  		paraMap["branch_no"] =  param.branch_no;
  		paraMap["fund_account"] = param.fund_account;
  		paraMap["cust_code"] =  param.cust_code;
  		paraMap["sessionid"] =  param.sessionid;
  		paraMap["entrust_bs"] = param.entrust_bs;
  		paraMap["phone"] = getPhone();
  		addOpStation(paraMap); // 添加 op_station 到接口请求参数中
  		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
  	};
  	
  	/**
	 * 短信验证码发送(501600)
	 * @param op_way 访问接口来源标识(0：pc,2：pad,3：手机)
	 * @param mobile_no 手机号码
	 * @param ip 客户IP地址
	 * @param mac 设备mac地址
	 * @param callback 回调函数
	 * @param isLastReq 是否最后一次请求
	 * @param isShowWait 是否显示等待层
	 */
	mobileService.getSmsCode = function(param,callback,ctrlParam)
    {
 	    var paraMap = {};
		paraMap["funcNo"] = "501600";
		paraMap["op_way"] = param.op_way;
		paraMap["verify_code"] = param.verify_code;
		paraMap["mobile_no"] = param.mobile_no;
		paraMap["ip"] = param.ip;
		paraMap["mac"] = param.mac;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath_open);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
 	 * 登录短信验证码校验(501521)
 	 * @param mobile_no 手机号码
 	 * @param mobile_code 手机验证码
 	 * @param login_flag 登录业务标准
 	 * @param callback 回调函数
 	 */
	mobileService.checkSmsCode = function(param,callback,ctrlParam)
      {
  	    var paraMap = {};
 		paraMap["funcNo"] = "501521";
 		paraMap["mobile_no"] = param.mobile_no;
 		paraMap["mobile_code"] = param.mobile_code;
 		paraMap["login_flag"] = param.login_flag;
 		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath_open);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };     
      
      /**
       * 手机绑定(901930)
       * @param phone 手机号码
       * @param hardsn 硬件信息
       * @param callback 回调函数
       */
      mobileService.bindMobile = function(param,callback,ctrlParam)
      {
		  var paraMap = {};
		  paraMap["funcNo"] = "901930";
		  paraMap["phone"] = param.phone;
		  paraMap["hardsn"] = param.hardsn;
		  paraMap["entrust_way"] = "SJWT";
		  var reqParamVo = new service.ReqParamVo();
		  reqParamVo.setUrl(global.serverPath_mall);
		  commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };     
      
     /**
	  * 富尊退出登入 (1000001)
	 */
      mobileService.fzExist = function (param,callback,ctrlParam)
      {
		var paraMap = {};
		paraMap["funcNo"] = "1000001";
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
	
     /**
	  * 商城退出登入 (1000001)
	 */
      mobileService.loginOut = function (param,callback,ctrlParam)
      {
		var paraMap = {};
		paraMap["funcNo"] = "1000001";
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath_mall);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
	
      /**
        *小贷退出（600005）
      */
      mobileService.exitNotifyServer = function(param,callback,ctrlParam)
      {
		var paraMap = {};
		paraMap["funcNo"]   = "600005";
		paraMap["exitFlag"] = "exit";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath_xdt);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
        
      /**
        *查询是否开通港股通
       */
      mobileService.queryGgt = function(param,callback,ctrlParam)
      {
		var paraMap = {};
		paraMap["funcNo"] = "1004226";
		paraMap["fund_account"] = param.fund_account;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath_ggt);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      /**
       * 资金账号登录(100006)
       * @param fund_account 资金账号
       * @param trade_pwd 交易密码
       * @param callback 回调函数
       * @param isLastReq 是否最后一次请求
       * @param isShowWait 是否显示等待层
       * */
      mobileService._fundLogin = function(param,callback,ctrlParam)
      {
		var paraMap = {};
		paraMap["funcNo"] = "100006";
		paraMap["fund_account"] = param.fund_account;
		paraMap["trade_pwd"] = param.trade_pwd;
		paraMap["ip"] = param.ip;
		paraMap["mac"] = param.mac;
		paraMap["ticket"] = param.vf_code;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      /**
		* E账号登录(100007)
		* @param user_id E账号
		* @param trade_pwd 交易密码
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		* */
      mobileService.E_fundLogin = function(param,callback,ctrlParam)
      {
		var paraMap = {};
		paraMap["funcNo"] = "100007";
		paraMap["user_id"] = param.user_id;
		paraMap["trade_pwd"] = param.trade_pwd;
		paraMap["ip"] = param.ip;
		paraMap["mac"] = param.mac;
		paraMap["user_id_type"] = param.user_id_type;
		paraMap["ticket"] = param.vf_code;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      /**
		* 查询融资融券资金信息(100015)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.queryMarginInfo = function(param,callback,ctrlParam)
      {
		var paraMap = {};
		paraMap["funcNo"] = "100015";
		paraMap["branchno"] = param.branchno;
		paraMap["currency"] = param.currency;
		paraMap["account"] = param.account;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      /**
		* 激活登录名和密码（昵称）(100005)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.activateE_Account = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
  		paraMap["funcNo"] = "100005";
  		paraMap["cust_code"] = param.cust_code;
  		paraMap["cust_pwd"] = param.cust_pwd;
  		paraMap["cust_dname"] = param.cust_dname;
  		paraMap["account"] = param.account;
  		paraMap["protocol_code"] = param.protocol_code;
  		paraMap["phone"] = getPhone();
  		paraMap["entrust_way"] = "SJWT";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      /**
		* 修改客户昵称(100001)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.updateLoginName = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
	    paraMap["funcNo"] = "100001";
		paraMap["cust_code"] = param.cust_code;
		paraMap["cust_dname"] = param.cust_dname;
		paraMap["ticket"] = param.ticket;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      /**
		* 资金账号查询客户信息（有返回）和风险测评（融资融券暂无）信息(100014)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.getUserinfoByFund = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
	    paraMap["funcNo"] = "100014";
		paraMap["branchno"] = param.branchno;
		paraMap["account"] = param.account;
		paraMap["messageType"] = param.messageType;
		paraMap["ip"] = param.ip;
		paraMap["mac"] = param.mac;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      /**
		* 持仓（融资融券专用）(100022)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.getMarginOp = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
	    paraMap["funcNo"] = "100022";
		paraMap["branchno"] = param.branchno;
		paraMap["account"] = param.account;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      /**
		* 股票当日委托查询、股票历史委托查询、查询当日可撤委托(100021)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.getMarginEntrust = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
	    paraMap["funcNo"] = "100021";
		paraMap["branchno"] = param.branchno;
		paraMap["account"] = param.account;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      /**
		* 查询资金流水（包含银证转账历史流水查询）(融资融券专用)(100023)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.getMarginMoneyInfo = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
	    paraMap["funcNo"] = "100023";
		paraMap["branchno"] = param.branchno;
		paraMap["account"] = param.account;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      
        /***************************现金宝接口**************************************/
      /**
		* 查询电子协议内容(现金宝)(1005006)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
//      mobileService.queryProtocol = function(param,callback,ctrlParam)
//      {
//	    var paraMap = {};
//	    paraMap["funcNo"] = "1005006";
//		paraMap["econtract_no"] = param.econtract_no;
//		paraMap["econtract_version"] = param.econtract_version;
//		var reqParamVo = new service.ReqParamVo();
//		reqParamVo.setUrl(global.serverPath);
//		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
//    };
      
      /**
		* 基金账户开户(现金宝)(20020100)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.openTAAccount = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
	    paraMap["funcNo"] = "20020100";
		paraMap["branch_no"] = param.branch_no;
		paraMap["account"] = param.account;
		paraMap["ezt_name"] = param.ezt_name;
		paraMap["ticket"] = param.ticket;
		paraMap["survey_sn"] = param.survey_sn;
		
		//20160920送手机号
		paraMap["entrust_way"] = param.entrust_way;
		paraMap["mobile_channel"] = param.mobile_channel;//安卓1，ios:2
		paraMap["mobile"] = param.mobile;  //手机号
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      /**
		* 签署电子协议(现金宝)(20020090)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.signDzxy = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
	    paraMap["funcNo"] = "20020090";
		paraMap["account"] = param.account;
		paraMap["ezt_name"] = param.ezt_name;
		paraMap["ticket"] = param.ticket;
		paraMap["risk_uncover"] = param.risk_uncover;
		paraMap["com_sign"] = param.com_sign;
		paraMap["survey_sn"] = param.survey_sn;
		paraMap["entrust_way"] = param.entrust_way;
		//20160923送手机号
		paraMap["mobile_channel"] = param.mobile_channel;//安卓1，ios:2
		paraMap["mobile"] = param.mobile;  //手机号
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      /**
		* 设置参与状态(现金宝)(2002025)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.setCyzt = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
	    paraMap["funcNo"] = "2002025";
		paraMap["account"] = param.account;
		paraMap["is_set_money"] = "1";
		paraMap["market"] = param.market;
		paraMap["elecstatus"] = param.elecstatus;
		paraMap["ezt_name"] = param.ezt_name;
		paraMap["ticket"] = param.ticket;
		paraMap["risk_uncover"] = param.risk_uncover;
		paraMap["com_sign"] = param.com_sign;
		paraMap["survey_sn"] = param.survey_sn;
		paraMap["entrust_way"] = param.entrust_way;
		//20160920送手机号
		paraMap["mobile_channel"] = param.mobile_channel;//安卓1，ios:2
		paraMap["mobile"] = param.mobile;  //手机号
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      /**
		* 现金宝参与状态设置(2002005)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.setCyzt2 = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
	    paraMap["funcNo"] = "20020050";
		paraMap["account"] = param.account;
		paraMap["is_set_money"] = "1";
		paraMap["market"] = param.market;
		paraMap["elecstatus"] = param.elecstatus;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      /**
		* 是否完成步骤(现金宝)(20020120)
		* @param fund_account 资金账户
		* @param sign 查询标识（1,2,3,4分别代表查询是否开户，是否签署电子约定书，是否进行风险测评，是否签署电子合同 ）
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.isCompleteStep = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
	    paraMap["funcNo"] = "20020120";
		paraMap["account"] = param.fund_account;
		paraMap["sign"] = param.sign;
		paraMap["ezt_name"] = param.ezt_name;
		paraMap["ticket"] = param.ticket;
		paraMap["survey_sn"] = param.survey_sn;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      /**
		* 查询电子协议状态(现金宝)(20020080)
		* @param fund_account 资金账户
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.queryDzxyState = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
	    paraMap["funcNo"] = "20020080";
		paraMap["account"] = param.account;
		paraMap["eztName"] = param.eztName;
		paraMap["ticket"] = param.ticket;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      /**
		* 风险评测题目查询(现金宝)(1000303)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.queryFxpctm = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000303";
		paraMap["risk_type_id"] = param.risk_type_id;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
       /**
		* 风险评测数据提交(现金宝)(1000304)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.submitFxcp = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000304";
	    paraMap["user_id"] = param.user_id;
	    paraMap["content"] = param.content;
		paraMap["risk_type_id"] = param.risk_type_id;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      /**
		* 现金宝风险评测(现金宝)(20020130)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.xjb_fxcp = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
	    paraMap["funcNo"] = "20020130";
	    paraMap["branch_no"] = param.branch_no;
	    paraMap["account"] = param.account;
		paraMap["evaluating_score"] = param.evaluating_score;
		paraMap["evaluating_result_grade"] = param.evaluating_result_grade;
		paraMap["ezt_name"] = param.ezt_name;
		paraMap["ticket"] = param.ticket;
		paraMap["survey_sn"] = param.survey_sn;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      /**
		* 合同签署状态查询(现金宝)(2002026)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.queryHtzt = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
	    paraMap["funcNo"] = "2002026";
		paraMap["account"] = param.account;
		paraMap["market"] = param.market;
		paraMap["branch_no"] = param.branch_no;
		paraMap["eztName"] = param.eztName;
		paraMap["ticket"] = param.ticket;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      /**
		* 现金理财预约可取金额查询(现金宝)(2002004)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.queryYykqje = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
	    paraMap["funcNo"] = "2002004";
		paraMap["account"] = param.account;
		paraMap["market"] = param.market;
		paraMap["branch_no"] = param.branch_no;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      /**
		* 现金理财最大预约可取金额查询(现金宝)(1001113)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.queryMaxYykqje = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
	    paraMap["funcNo"] = "1001113";
		paraMap["fund_account"] = param.fund_account;
		paraMap["market"] = param.market;
		paraMap["branch_no"] = param.branch_no;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      /**
		* 现金理财预约可取金额设置(现金宝)(2002003)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.setYykqje = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
	    paraMap["funcNo"] = "2002003";
		paraMap["account"] = param.fund_account;
		paraMap["money"] = param.money;
		paraMap["branch_no"] = param.branch_no;
		paraMap["market"] = param.market;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
	  
	 /**适当性
  	 * 功能：适当性现金理财预约可取金额设置,为不影响app上现金宝,重写功能号
  	 * 参数: callBackFunc:回调函数
  	 * 修改:2015年12月24日15:42:53对功能号2002003,2002005,2002007,2002008,2002009,2002010,2002012,2002013,2002020都增加cust_code和ticket
  	 * 新增2002025,2002026两个功能号,满足适当性的需求
	 *20160920添加
  	 */
      mobileService.xjb_SetYyMoney_apro= function(param,callback,ctrlParam)
  	{
  		var paraMap = {};
  		paraMap["funcNo"] = "20020030";
  		paraMap["ezt_name"] = param.cust_code;
  		paraMap["ticket"] = param.ticket;
  		paraMap["survey_sn"] = param.survey_sn;
  		paraMap["account"] = param.fund_account;
  		paraMap["money"] = param.money;
  		paraMap["branch_no"] = param.branch_no;
  		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
  	};
	  
      
      /**
		* 现金理财预留可取金额查询(现金宝)(2002001)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.queryYlkqje = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
	    paraMap["funcNo"] = "2002001";
		paraMap["account"] = param.fund_account;
		paraMap["market"] = param.market;
		paraMap["branch_no"] = param.branch_no;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      /**
		* 现金理财预留可取金额设置(现金宝)(2002002)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.setYlkqje = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
	    paraMap["funcNo"] = "2002002";
		paraMap["account"] = param.account;
		paraMap["money"] = param.money;
		paraMap["branch_no"] = param.branch_no;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      /**
		* 份额查询(现金宝)(2002000)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.queryFe = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
	    paraMap["funcNo"] = "2002000";
		paraMap["account"] = param.fund_account;
	//	paraMap["account_type"] = param.account_type;
		paraMap["branch_no"] = param.branch_no;
	//	paraMap["fundcode"] = param.fund_code;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      /**
		* 记录现金宝信息(现金宝)(2002014)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.recordInfo = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
	    paraMap["funcNo"] = "2002014";
		paraMap["account"] = param.fund_account;
		paraMap["branch_no"] = param.branch_no;
		paraMap["entrust_way"] = param.entrust_way;
		paraMap["mac"] = param.mac;
		paraMap["ip"] = param.ip;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      /**
		* 创新业务类型是否存在(现金宝T+0)(2002015)
	 	 branch_no			varchar(4)	Y	营业部编号
		account_type		varchar(4)	Y	账户类型
		entrust_way			varchar(4)	Y	委托方式
		account				varchar(4)	Y	客户号
		new_business_type   varchar(4)	N	创新业务类型
		money_code          varchar(4)	N	市场代码
		zqzh_account        varchar(4)	N	证券账户
	**/
    mobileService.innovateBusinessIsExist = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "2002015";
		paraMap["branch_no"] = param.branch_no;
		paraMap["account_type"] = param.account_type;
		paraMap["account"] = param.account;
		paraMap["entrust_way"] = param.entrust_way;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
		* 最大快速取现资金(现金宝T+0)(2002016)
	 	 pro_code        varchar(4)	Y	现金理财产品代码
		account_type		varchar(4)	Y	账户类型
		 branch_no			varchar(4)	Y	营业部编号
		entrust_way			varchar(4)	Y	委托方式
		account				varchar(4)	Y	客户号
	**/
    mobileService.queryMaxCash = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "2002016";
		paraMap["pro_code"] = param.pro_code;
		paraMap["branch_no"] = param.branch_no;
		paraMap["account_type"] = param.account_type;
		paraMap["account"] = param.account;
		paraMap["entrust_way"] = param.entrust_way;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
		* T+0快速取现权限开通(现金宝T+0)(2002017)
		account_type		varchar(4)	Y	账户类型
		 branch_no			varchar(4)	Y	营业部编号
		entrust_way			varchar(4)	Y	委托方式
		account				varchar(4)	Y	客户号
		is_open				varchar(4)	Y	1开通
	**/
    mobileService.openPower = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "2002017";
		paraMap["branch_no"] = param.branch_no;
		paraMap["account_type"] = param.account_type;
		paraMap["account"] = param.account;
		paraMap["entrust_way"] = param.entrust_way;
		paraMap["is_open"] = param.is_open;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
		* 取现到证券账户(现金宝T+0)(2002018)
		account_type		varchar(4)	Y	账户类型
		 branch_no			varchar(4)	Y	营业部编号
		entrust_way			varchar(4)	Y	委托方式
		account				varchar(4)	Y	客户号
		cash_amount				varchar(4)	Y	取现金额
	**/
    mobileService.getCash = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "2002018";
		paraMap["branch_no"] = param.branch_no;
		paraMap["account_type"] = param.account_type;
		paraMap["account"] = param.account;
		paraMap["entrust_way"] = param.entrust_way;
		paraMap["cash_amount"] = param.cash_amount;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
		* 根据电子协议名称查询电子协议内容(现金宝T+0)(2002019)
		account_type		varchar(4)	Y	账户类型
		 branch_no			varchar(4)	Y	营业部编号
		entrust_way			varchar(4)	Y	委托方式
		account				varchar(4)	Y	客户号
		econtract_name		varchar(4)	Y	
	**/
    mobileService.queryProtocolContentByName = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "2002019";
		paraMap["branch_no"] = param.branch_no;
		paraMap["account_type"] = param.account_type;
		paraMap["account"] = param.account;
		paraMap["entrust_way"] = param.entrust_way;
		paraMap["econtract_name"] = param.econtract_name;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
		* 根据电子协议名称查询电子协议内容(现金宝T+0)(20020200)
		account_type		varchar(4)	Y	账户类型
		 branch_no			varchar(4)	Y	营业部编号
		entrust_way			varchar(4)	Y	委托方式
		account				varchar(4)	Y	客户号
		econtract_name		varchar(4)	Y	
	**/
    mobileService.signFastCashProtocol = function(param,callback,ctrlParam)
    {	
    	//20160825更改
	    var paraMap = {};
	    paraMap["funcNo"] = "20020200";
		paraMap["branch_no"] = param.branch_no;
		paraMap["account_type"] = param.account_type;
		paraMap["account"] = param.account;
		paraMap["entrust_way"] = param.entrust_way;
		//20160923送手机号
		paraMap["mobile_channel"] = param.mobile_channel;//安卓1，ios:2
		paraMap["mobile"] = param.mobile;  //手机号
		
    	paraMap["eztName"] = param.ezt_name;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
		*  根据资金账号查询银行卡信息 查询三方是否支持快速取现(现金宝T+0)(2002022)
	 	 pro_code        varchar(4)	Y	现金理财产品代码
		account_type		varchar(4)	Y	账户类型
		 branch_no			varchar(4)	Y	营业部编号
		entrust_way			varchar(4)	Y	委托方式
		account				varchar(4)	Y	客户号
	**/
    mobileService.getCardInfo = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "2002022";
		paraMap["branch_no"] = param.branch_no;
		paraMap["account_type"] = param.account_type;
		paraMap["fund_account"] = param.fund_account;
		paraMap["entrust_way"] = param.entrust_way;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
     /**
		*  银证转账(现金宝T+0)(1001107)
	 	 pro_code        varchar(4)	Y	现金理财产品代码
		fund_amount		varchar(4)	Y	转账金额
		fund_pwd		varchar(4)	Y	资金密码
		 branch_no			varchar(4)	Y	营业部编号
		entrust_way			varchar(4)	Y	委托方式
		trans_type				varchar(4)	Y
	**/
    mobileService.saveCash = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1001107";
		paraMap["fund_account"] = param.fund_account;
		paraMap["fund_amount"] = param.fund_amount;
		paraMap["bank_no"] = param.bank_no;
		paraMap["bank_card_no"] = param.bank_card_no;
		paraMap["trans_type"] = param.trans_type;
		paraMap["entrust_way"] = param.entrust_way;
		paraMap["fund_pwd"] = param.fund_pwd;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
      
       /**
		*根据资金账号查询融资融券账号(1005019)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.queryRzrqAccount = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
	    paraMap["funcNo"] = "1005019";
		paraMap["fund_account"] = param.fund_account;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
      /**
		*融资融券浮动授信申请或取消(1005012)
		* @param callback 回调函数
		* @param isLastReq 是否最后一次请求
		* @param isShowWait 是否显示等待层
		**/
      mobileService.ktOrQxFdsx = function(param,callback,ctrlParam)
      {
	    var paraMap = {};
	    paraMap["funcNo"] = "1005012";
		paraMap["scust_no"] = param.fund_account;
		paraMap["scust_auth"] = param.scust_auth;
		paraMap["econtract_name"] = param.econtract_name;
		paraMap["branch_no"] = param.branch_no;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
    
    /********************************应用接口结束********************************/
    
 /********************************20150731应用接口开始********************************/
      /**
       * 200004：OTC支付账户信息查询  
       * 20150730新增
       * 
       */
      mobileService.otcAccoInfo = function(param,callback,ctrlParam)
      {
  	    var paraMap = {};
  	    paraMap["funcNo"]="200004";
      	paraMap["cust_code"]=param.cust_code;
      	paraMap["cuacct_code"]=param.cuacct_code;
      	paraMap["ticket"]=param.ticket;
  		
  		var reqParamVo = new service.ReqParamVo();
  		reqParamVo.setUrl(global.serverPath);
  		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
      };
      
    /**
     * 2000005：OTC推荐产品查询
     * 
     */
    mobileService.getOTCProduct = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="2000005";
    	  paraMap["rec_type"]=param.rec_type;
    	  paraMap["rownum"]=param.rownum;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 200018：客户电子协议签署查询
     * 
     */
    mobileService.queryOTCAgreement = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="200018";
    	  paraMap["cust_code"]=param.cust_code;
    	  paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 200015：otc风险测评提交
     * 
     */
    mobileService.submitOTCAnswer = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="200015";
    	paraMap["cust_code"]=param.cust_code;
    	paraMap["content"]=param.content;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 200016：客户电子协议签署
     * 
     */
    mobileService.signOTCAgreement = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="200016";
    	  paraMap["cust_code"]=param.cust_code;
    	  paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 200017：风险测评结果
     * 
     */
    mobileService.otcRiskResult = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="200017";
    	  paraMap["cust_code"]=param.cust_code;
    	  paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 200005：OTC支付账户开户
     * 
     */
    mobileService.otcOpenAcco = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="200005";
    	paraMap["cust_code"]=param.cust_code;
    	paraMap["int_org"]=param.int_org;
    	paraMap["cuacct_code"]=param.cuacct_code;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    
    /**
	 * 获取用户风险评测试题(1000303)
	 * @Author:黎志勇
	 * @param risk_type_id 试题类号
	 * @param callback 回调函数
	 */
    mobileService.queryEval = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000303";
	    paraMap["risk_type_id"] = param.risk_type_id;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * 提交风险测评(1000304)
	 * @Author:黎志勇
	 * @param user_id 用户编号
	 * @param risk_type_id 试题类号
	 * @param content 提交数据
	 * @param callback 回调函数
	 */
    mobileService.submitTestAnswer = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000304";
		paraMap["user_id"] = param.user_id;
		paraMap["risk_type_id"] = param.risk_type_id;
		paraMap["content"] = param.content;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 300031：产品份额汇总查询(我的产品)
     * 
     */
    mobileService.otcProduct = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="300031";
    	paraMap["user_code"]=param.user_code;
    	paraMap["page_recnum"]=param.page_recnum;
    	paraMap["page_reccnt"]=param.page_reccnt;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 300033：otc赎回
     * 
     */
    mobileService.otcRedemption = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="300033";
    	paraMap["cust_code"]=param.cust_code;
    	paraMap["cuacct_code"]=param.cuacct_code;
    	paraMap["ta_code"]=param.ta_code;
    	paraMap["ta_acct"]=param.ta_acct;
    	paraMap["trans_acct"]=param.trans_acct;
    	paraMap["iss_code"]=param.iss_code;
    	paraMap["inst_code"]=param.inst_code;
    	paraMap["trd_qty"]=param.trd_qty;
    	paraMap["inst_id"]=param.inst_id;
    	paraMap["trade_pwd"]=param.trade_pwd;
    	paraMap["mobile"]=param.mobile;
    	paraMap["mobile_num"]=param.mobile_num;
    	paraMap["entrust_way"]="SJWT";
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 300008：产品分红业务设置
     * 
     */
    mobileService.otcFH = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="300008";
    	paraMap["cust_code"]=param.cust_code;
    	paraMap["cuacct_code"]=param.cuacct_code;
    	paraMap["ta_code"]=param.ta_code;
    	paraMap["ta_acct"]=param.ta_acct;
    	paraMap["trans_acct"]=param.trans_acct;
    	paraMap["inst_code"]=param.inst_code;
    	paraMap["inst_id"]=param.inst_id;
    	paraMap["div_method"]=param.div_method;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 300032：我的订单查询
     * 
     */
    mobileService.otcOrderInfo = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="300032";
    	paraMap["user_code"]=param.user_code;
    	/*paraMap["order_id"]=param.order_id;*/
    	paraMap["page"]=param.page;
    	paraMap["numPerPage"]=param.numPerPage;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 300027：OTC订单查询
     * 
     */
    mobileService.getOTCOrder = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="300027";
    	paraMap["order_id"]=param.order_id;
    	paraMap["ticket"]=param.ticket;
    	/*paraMap["user_id"]=param.user_id;*/
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    
    
    /*************************创业板转签****************************************/
    /**
     * 1005013：风险测评
     */
  	mobileService.cyb_fxcp = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="1005013";
    	paraMap["branch_no"] = param.branch_no;
	    paraMap["fund_account"] = param.fund_account;
		paraMap["evaluating_score"] = param.evaluating_score;
		paraMap["evaluating_result_grade"] = param.evaluating_result_grade;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    /**
     * 1005014：风险测评查询
     */
  	mobileService.cyb_queryFxcp = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="1005014";
    	paraMap["fund_account"]=param.fund_account;
    	paraMap["branch_no"]=param.branch_no;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
     /**
     * 1005015：创业板转签查询账户股东户
     */
  	mobileService.queryGdzh = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="1005015";
    	paraMap["user_id"]=param.user_id;
    	paraMap["fund_account"]=param.fund_account;
    	paraMap["branch_no"]=param.branch_no;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
     /**
     * 1005016：适当性管理信息维护
     */
  	mobileService.sdxglxxwh = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="1005016";
    	paraMap["ywlb"]=param.ywlb;
    	paraMap["zqzh"]=param.zqzh;
    	paraMap["qylb"]=param.qylb;
    	paraMap["qyrq"]=param.qyrq;
    	paraMap["branch_no"]=param.branch_no;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
     /**
     * 1005017：创业板转签签约
     * mode_operation 权限代码 1签约  3查询
     */
  mobileService.operationCyb = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="1005017";
    	paraMap["user_id"]=param.user_id;
    	paraMap["fund_account"]=param.fund_account;
    	paraMap["branch_no"]=param.branch_no;
    	paraMap["zqsbzdjg"]=param.zqsbzdjg;
    	paraMap["qylb"]=param.qylb;
    	paraMap["ymth"]=param.ymth;
    	paraMap["mode_operation"]=param.mode_operation;
    	paraMap["second_contract_name"]=param.second_contract_name;
    	paraMap["second_contract_tel"]=param.second_contract_tel;
    	paraMap["stock_code"]=param.stock_code;
    	paraMap["instead_stock_code"]=param.instead_stock_code;
    	paraMap["zqsbzdjg"]=param.zqsbzdjg;
    	paraMap["market_code"]=param.market_code;
    	paraMap["what_customer"]=param.what_customer;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 1005020：交易时间校准接口
     */
  	mobileService.jysjz = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="1005020";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
     /**
     * 1005021：中登证券账户查询
     */
  	mobileService.queryZqzh = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="1005021";
	    paraMap["zqzh"]=param.zqzh;
    	paraMap["account"]=param.fund_account;
    	paraMap["branch_no"] = param.branch_no;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
     /**
     * 1005022：客户资料业务
     */
  	mobileService.khzlyw = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="1005022";
    	paraMap["user_id"]=param.user_id;
    	paraMap["fund_account"]=param.fund_account;
    	paraMap["branch_no"]=param.branch_no;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 非金融产品交易时间校准 (1000301)
	 * @param :data 时间
	 */
    mobileService.dealTimeSyn = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000301";
		paraMap["data"] = param.data;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    /********************************20151124 融资行权接口********************************/
    /**
	 * 股权激励行权员工信息查询-3.17
	 */
	mobileService.queryEmpInfo = function(param,callback,ctrlParam){
	    var paraMap = {};
		paraMap['funcNo']="1006021";
    	paraMap["account"]=param.account;
    	paraMap["branch_no"]=param.branch_no;
    	paraMap["LCCode"]=param.LCCode;
    	paraMap["mac"]="74-29-143-42";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
		
	}
	/**
	 * 查询我的借款
	 * Loan 释意: 借款
	 */
	mobileService.queryMyLoan = function(param,callback,ctrlParam){
	    var paraMap = {};
		paraMap['funcNo']="610018";
		//paraMap["page"] = page;
		//paraMap["size"] = size;
		paraMap["order_status"] = "1,2,3,5,6,8,9,11,12,13,14,15";//我的借款
		//paraMap["op_source"] = $.gconfig.global.op_source;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
		
	}
	/**
	 *  融资行权股票质押合约查询-630
	 *  zygt
        bussness_type
		islogin
		account
		account_type
		entrust_way
		branch_no
	 */
	mobileService.query630 = function(param,callback,ctrlParam){
	    var paraMap = {};
		paraMap['funcNo']="1006020";
		paraMap['branch_no']=param.branch_no;
		paraMap['account']=param.account;
		paraMap['entrust_way']="WSWT";
		paraMap['account_type']="0";
		paraMap['bussness_type']="1";
		paraMap['islogin']="0";
		paraMap['zygt']="1";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
		
	}
	/**
	 * 查询征信因子
	 *  sbranch_code0	varchar(4)	Y	营业部代码
	 *	mac				varchar(4)	Y	网卡地址
	 *	sbank_code2		varchar(4)	Y	委托方式
	 */
	mobileService.questions = function(param,callback,ctrlParam){
		var paraMap={};
		paraMap['funcNo']="1006001";
		paraMap['sbranch_code0']=param.branch_no;
		paraMap['sbank_code2']=param.bank_code;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
		
	}
	/**
	 * 查询征信因子录入
	 * sbranch_code0    营业部代码
	 * mac				网卡地址
	 * scust_no			客户账户
	 * sbank_code2		委托方式
	 * sstock_code		评级因子类别
	 * sstock_code2		因子选项代码
	 * vsvarstr1		客户实际信息
	 */
	mobileService.answers = function(param,callback,ctrlParam){
		var paraMap={};
		paraMap['funcNo']="1006002";
		paraMap['sbranch_code0']=param.branch_no;
		paraMap['sbank_code2']=param.bank_code;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
		
	}
	/**
	 * 行权质押合同签署
	 *  sbranch_code0	varchar(4)	Y	营业部代码
		mac				varchar(4)	Y	网卡地址
		scust_no		varchar(4)	Y	客户账户
		sbank_code2		varchar(4)	Y	委托方式
	 */
	mobileService.xqzySignAgree = function(param,callback,ctrlParam){
	    var paraMap = {};
		paraMap['funcNo']="1006003";
		paraMap['sbank_code2']='WSWT';
		paraMap['sbranch_code0'] = param.sbranch_code0;
		paraMap['mac'] = param.mac;
		paraMap['scust_no'] = param.scust_no;
		paraMap['sdate0'] = param.sdate0;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
		
	}
	/**
	 * 行权质押合同查询
	 *  sbranch_code0	varchar(4)	Y	营业部代码
		mac				varchar(4)	Y	网卡地址
		scust_no		varchar(4)	Y	客户账户
		sbank_code2		varchar(4)	Y	委托方式
		sstatus2		varchar(4)	Y	合同类型
	 */
	mobileService.queryXQZYHT = function(param,callback,ctrlParam){
		var paraMap={};
		paraMap['funcNo']="1006004";
		paraMap['sbranch_code0']=param.branch_no;
		paraMap['scust_no']=param.account;
		paraMap['mac']=param.mac;
		paraMap['sbank_code2']='WSWT';
		paraMap['sstatus2']='3';
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
		
	}
	/**
	 * 股权融资合同签署申请
	 *  sbranch_code0	varchar(4)	Y	营业部代码
		sstock_code2	varchar(4)	Y	上市公司编号
		scust_no		varchar(4)	Y	客户账户
		sdate0			varchar(4)	Y	客户协议签署日期
		scust_auth		varchar(4)	Y	股票质押合同编号
		sbank_code2		varchar(4)	Y	委托方式
	 */
	mobileService.gqrzSignAgree = function(param,callback,ctrlParam){
	    var paraMap = {};
		paraMap['funcNo']="1006005";
		paraMap['sbank_code2']="WSWT";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
		
	}
	/**
	 * 股权融资资格查询
	 *  sbranch_code0	varchar(4)	Y	营业部代码
		semp			varchar(4)	Y	职工代码
		sbank_code2		varchar(4)	Y	委托方式
		scust_no		varchar(4)	Y	客户账户
	 */
	mobileService.query3_23 = function(param,callback,ctrlParam){
	    var paraMap = {};
		paraMap['funcNo']="1006006";
		paraMap['account_type']="0";
		paraMap['entrust_way']="WSWT";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
		
	}
	/**
	 * 股权激励计划明细查询(客户所有可行权权证查询)376
	 *  branch_no       	varchar(4)	Y	营业部编号
	 *  account_type    	varchar(4)	Y	账户类型
	 *	account         	varchar(4)	Y	客户号
	 *  listed_company_no	varchar(4)	Y	上市公司编号(未签合同时让用户输入)
	 *	entrust_way     	varchar(4)	Y	委托方式
	 */
	mobileService.query376 = function(param,callback,ctrlParam){
	    var paraMap = {};
		paraMap['funcNo']="1006007";
		paraMap['branch_no']=param.branch_no;
		paraMap['account']=param.account;
		paraMap['listed_company_no']=param.listed_company_no;
		paraMap['account_type']="0";
		paraMap['entrust_way']="WSWT";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
		
	}
	/**
	 * 查询用户资金信息
	 * 	branch_no    	varchar(4)	Y	营业部编号
		account_type 	varchar(4)	Y	账户类型
		account      	varchar(4)	Y	客户号
		entrust_way  	varchar(4)	Y	委托方式
	 */
	mobileService.queryUserInfo = function(param,callback,ctrlParam){
	    var paraMap = {};
		paraMap['funcNo']="1006008";
		paraMap['branch_no']=param.branch_no;
		paraMap['account']=param.account;
		paraMap['entrust_way']="WSWT";
		paraMap['account_type']="0";
		paraMap['currency']="1";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		reqParamVo.setIsAsync(false);//同步查询(重要)
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
		
	}
	/**
	 * 股权融资资格查询-690
	 *  branch_no   	varchar(4)	Y	营业部编号
	 *	account_type	varchar(4)	Y	账户类型
	 *	account     	varchar(4)	Y	客户号
	 *	entrust_way 	varchar(4)	Y	委托方式  
	 */
	mobileService.query690 = function(param,callback,ctrlParam){
	    var paraMap = {};
		paraMap['funcNo']="1006009";
		paraMap['branch_no']=param.branch_no;
		paraMap['account']=param.account;
		paraMap['account_type']="0";
		paraMap['entrust_way']="WSWT";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
		
	}
	
	
	/**
	 * 融资行权-691
	 *  branch_no          	varchar(4)	Y	营业部编号
		account_type       	varchar(4)	Y	账户类型
		account            	varchar(4)	Y	客户号
		entrust_way        	varchar(4)	Y	委托方式
		market             	varchar(4)	Y	市场代码
		business_class     	varchar(4)	Y	业务类别
		option_code        	varchar(4)	Y	期权代码
		positive_unit_code 	varchar(4)	Y	正股代码
		exercise_amount    	varchar(4)	Y	行权数量
		financing_amount   	varchar(4)	Y	融资金额
		contract_number		varchar(4)  Y	合同编号
	 */
	mobileService.rzxq691 = function(param,callback,ctrlParam){
	    var paraMap = {};
		paraMap['funcNo']="1006010";
		paraMap['account_type']="0";
		paraMap['entrust_way']="WSWT";
		paraMap['branch_no']= param.branch_no;
		paraMap['account']=param.account;
		paraMap['market']=param.market;
		paraMap['business_class']=param.business_class;
		paraMap['option_code']=param.option_code ;
		paraMap['positive_unit_code']=param.positive_unit_code ;
		paraMap['exercise_amount']=param.exercise_amount   ;
		paraMap['financing_amount']=param.financing_amount;
		paraMap['contract_number']=param.contract_number;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
		
	}
	/**
	 * 融资行权撤单-692
	 *  branch_no              	varchar(4)	Y	营业部编号
		account_type           	varchar(4)	Y	账户类型
		account                	varchar(4)	Y	客户号
		entrust_way            	varchar(4)	Y	委托方式 
		market                 	varchar(4)	Y	市场代码
		financing_agreement_no 	varchar(4)	Y	融资协议编号
	 */
	mobileService.rzcd692 = function(param,callback,ctrlParam){
	    var paraMap = {};
		paraMap['funcNo']="1006011";
		paraMap['account_type']="0";
		paraMap['entrust_way']="WSWT";
		paraMap['branch_no']= param.branch_no;
		paraMap['account']=param.account;
		paraMap['market']=param.market;
		paraMap['financing_agreement_no']=param.financing_agreement_no;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
		
	}
	/**
	 * 行权融资协议查询-693
	 *  branch_no              	varchar(4)	Y	营业部编号
		account_type           	varchar(4)	Y	账户类型
		account                	varchar(4)	Y	客户号
		entrust_way            	varchar(4)	Y	委托方式        
	 */
	mobileService.query693 = function(param,callback,ctrlParam){
		var paraMap = {};
		paraMap['funcNo']="1006012";
		paraMap['branch_no']=param.branch_no;
		paraMap['account']=param.account;
		paraMap['account_type']="0";
		paraMap['entrust_way']="WSWT";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
		
	}
	
	/**
	 * 行权融资直接还款-694
	 *  branch_no             	varchar(4)	Y	营业部编号
		account_type          	varchar(4)	Y	账户类型
		account               	varchar(4)	Y	客户号
		entrust_way           	varchar(4)	Y	委托方式      
		financing_agreement_no	varchar(4)	Y	融资协议编号
		return_amount         	varchar(4)	Y	归还金额
	 */
	mobileService.rzhk694 = function(param,callback,ctrlParam){
	    var paraMap = {};
		paraMap['funcNo']="1006013";
		paraMap['branch_no']=param.branch_no;
		paraMap['account']=param.account;
		paraMap['financing_agreement_no']=param.financing_agreement_no;
		paraMap['return_amount']=param.return_amount;
		paraMap['account_type']="0";
		paraMap['entrust_way']="WSWT";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
		
	}
	/**
	 * 股票质押合约直接还款-695
	 *  branch_no        	varchar(4)	Y	营业部编号
		account_type     	varchar(4)	Y	账户类型
		account          	varchar(4)	Y	客户号
		entrust_way      	varchar(4)	Y	委托方式        
		trading_agreement	varchar(4)	Y	交易协议书编号
		return_amount    	varchar(4)	Y	归还金额
	 */
	mobileService.gpzyhk695 = function(param,callback,ctrlParam){
	    var paraMap = {};
		paraMap['funcNo']="1006014";
		paraMap['account_type']="0";
		paraMap['entrust_way']="WSWT";
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
		
	}
	/**
	 * 交易密码校验
	 *  branch_no        	varchar(4)	Y	营业部编号
		account_type     	varchar(4)	Y	账户类型
		account          	varchar(4)	Y	客户号
		entrust_way      	varchar(4)	Y	委托方式        
		trade_pwd			varchar(4)	Y	交易密码
	 */
	mobileService.safeCheck = function(param,callback,ctrlParam){
	    var paraMap = {};
		paraMap['funcNo']="1006015";
		paraMap['account_type']="0";
		paraMap['entrust_way']="WSWT";
		paraMap['branch_no']=param.branch_no;
		paraMap['account']=param.account;
		paraMap['trade_pwd']=param.trade_pwd;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
		
	}
	/**
	 * 新增处置卖券委托-697
	 * branch_no
	 * gdzh
	 * entrust_way
	 * business_type  //买卖类型
	 * wt_mount       //委托数量
	 * wt_price
	 * client_wt_flag // 客户委托确认标志 0-未确认 1-已确认
	 * zq_code        //证券代码
	 * market_code
	 */
	mobileService.mqhk_wt = function(param,callback,ctrlParam){
	    var paraMap = {};
		paraMap['funcNo']="1006016";
		paraMap['entrust_way']="WSWT";
		paraMap['client_wt_flag']="1";
		paraMap['business_type']='2';
		paraMap['branch_no']=param.branch_no;
		paraMap['account']=param.account;
		paraMap['wt_mount']=param.wt_mount;
		paraMap['wt_price']=param.wt_price;
		paraMap['zq_code']=param.zq_code;
		paraMap['market_code']=param.market_code;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
		
	}
	/**
	 * 新增处置卖券撤单-698
	 * branch_no
	 * account
	 * entrust_way
	 * contract_no  //合同号
	 * market_code
	 */
	mobileService.mqhk_cd = function(param,callback,ctrlParam){
	    var paraMap = {};
		paraMap['funcNo']="1006017";
		paraMap['entrust_way']="WSWT";
		paraMap['branch_no']=param.branch_no;
		paraMap['account']=param.account;
		paraMap['contract_no']=param.contract_no;
		paraMap['market_code']=param.market_code;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
		
	}
	/**
	 * 新增处置可卖证券查询-696
	 * branch_no
       account
	   entrust_way
	   operating // 操作功能 1明细、2汇总
       market_code
	 */
	mobileService.query696 = function(param,callback,ctrlParam){
	    var paraMap = {};
		paraMap['funcNo']="1006018";
		paraMap['operating']="1";
		paraMap['entrust_way']="WSWT";
		paraMap['account_type']="0";
		paraMap['ip']=param.ip;
		paraMap['branch_no']=param.branch_no;
		paraMap['account']=param.account;
		paraMap['market_code']=param.market_code;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
		
	}
	/**
	 * 新增处置卖券委托查询-699
	 * branch_no
       account
	   entrust_way
	   order_by_type //排序方式 0-市场代码、1-委托时间、2-委托时间倒序
       market_code
	 */
	mobileService.query699 = function(param,callback,ctrlParam){
	    var paraMap = {};
		paraMap['funcNo']="1006019";
		paraMap['order_by_type']="1";
		paraMap['entrust_way']="WSWT";
		paraMap['branch_no']=param.branch_no;
		paraMap['account']=param.account;
		paraMap['market_code']=param.market_code;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
		
	}
	/**
	 * 功能:获取指定证券代码的标准行情(1000003)
	 * 入参: callBackFunc: 回调函数
	 *       exchange_type：交易市场类别(Y)
	 *       stock_code：证券代码(Y)
	 */
	mobileService.queryStandardMarket = function(param,callback,ctrlParam){
	    var paraMap = {};
		paraMap["funcNo"] = "1000003";
		paraMap['stockcode']=param.stockcode;
		paraMap['market']=param.market;
		paraMap['count']=param.count;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
		
	};
	/**
	 * 功能:股票查询(1000004)
	 * 入参: callBackFunc: 回调函数
	 *       type：交易市场类别(Y)
	 * 		count：返回数目（N）
	 *		 p：证券代码(Y)
	 */			
	mobileService.queryStockInterceptor = function(param,callback,ctrlParam){
	    var paraMap = {};
		paraMap["funcNo"] = "1000004";
		paraMap["q"] = param.q;
		paraMap["type"] = param.type;
		paraMap["count"] = param.count;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
		
	};
    
    /********************************20150731应用接口结束********************************/
    
    /********************************20151126应用适当性接口开始********************************/
    /**
     * 500001：试题题库查询
     *  @param survey_sn 登记机构（默认1001）
     *  @param number 分页起始记录号
     *  @param survey_col 分页起始记录号
     */
    mobileService.queryTestQuestion = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="500001";
	    paraMap["cust_code"]=param.cust_code;
	    paraMap["survey_sn"]=param.survey_sn;
    	paraMap["ticket"]=param.ticket;
    	paraMap["number"]=param.number;
    	paraMap["survey_col"]=param.survey_col;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 500002：客户问卷作答录入
     * @param cust_code 客户代码
	 * @param survey_sn 调查表编码
	 * @param cust_status	客户状态
	 * @param	 content  作答明细 
	 *	@param survey_col 题目编码
	 *	@param survey_cells 答案编号
	 *	@param ticket 票据
	 *	@param cust_type 0：个人 ； 1：机构
     */
    mobileService.submitQuestionAnswer = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="500002";
	    paraMap["cust_code"]=param.cust_code;
    	paraMap["content"]=param.content;
	    paraMap["survey_sn"]=param.survey_sn;
    	paraMap["ticket"]=param.ticket;
    	paraMap["cust_status"]=param.cust_status;
    	paraMap["survey_col"]=param.survey_col;
    	paraMap["survey_cells"]=param.survey_cells;
    	paraMap["cust_type"]=param.cust_type;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 500003：客户风险测评结果查询
     * 
     */
    mobileService.newRiskResult = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="500003";
	    paraMap["cust_code"]=param.cust_code;
	    paraMap["survey_sn"]=param.survey_sn;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 500004：客户已经签署的协议查询
     * @param pro_type 0:业务开通协议书,1:理财协议,2:电子约定书,3:电子合同,4:风险揭示书；5：柜台市场客户协议；6：委托方式协议书,7:资讯免责说明书；8：权限开通协议书
     * @param pro_code 协议编号
     */
    mobileService.querySingedAgreement = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="500004";
	    paraMap["cust_code"]=param.cust_code;
	    paraMap["pro_type"]=param.pro_type;
	    paraMap["pro_code"]=param.pro_code;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 500100：协议签署
     * @param query_type 签署类型  otclc  -otc理财  otckh  -otc开户
     * @param pro_code 协议编号
     * @param risk_uncover 风险是否揭示  0否，1是
     * @param com_sign 强制签署   是否强制签署 0：非强制签署 1：强制签署
     * @param com_sign 签署类型   0：文本；1：电子
     */
    mobileService.signNewAgreement = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="500100";
	    paraMap["cust_code"]=param.cust_code;
	    paraMap["query_type"]=param.query_type;
	    paraMap["product_id"]=param.product_id;
    	paraMap["ticket"]=param.ticket;
    	paraMap["risk_uncover"]=param.risk_uncover;
    	paraMap["com_sign"]=param.com_sign;
    	paraMap["sign_mode"]=param.sign_mode;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    /********************************20151126应用适当性接口结束********************************/
    /********************************20160121应用接口开始********************************/
    /**
     * 300023：三方存管可用资金查询
     * 
     */
    mobileService.useableMoney = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="300023";
	    paraMap["cust_code"]=param.cust_code;
    	paraMap["order_channel"]="7";
    	paraMap["mobile"]=param.mobile;
    	paraMap["mobile_num"]=param.mobile_num;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    /********************************20160121应用接口结束********************************/
   /********************************20160511应用接口开始********************************/
    /**
     * 2002027：获取现金宝所有协议id
     * 
     */
    mobileService.getAllProtocolId = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="2002027";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    /**
	 * 500008：获取现金宝协议属性
	 *
	 */
	mobileService.queryProtocolAttr = function(param,callback,ctrlParam)
	{
		var paraMap = {};
		paraMap["funcNo"]="500008";
		paraMap["pro_code"] = param.pro_code;

		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	};
	/**
	 * 500009：获取现金宝所有协议id
	 *
	 */
	mobileService.getProtocolContent = function(param,callback,ctrlParam)
	{
		var paraMap = {};
		paraMap["funcNo"]="500009";
		paraMap["pro_content"]=param.pro_content;
		paraMap["pro_code"]=param.pro_code;
		paraMap["file_name"]=param.file_name;

		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	};

	/**
	 * 功能：基金帐号查询 (是否开通ta账户)
	 * 参数: callBackFunc:回调函数
	 */
	mobileService.taIsOpen = function(param,callback,ctrlParam){
		var paraMap = {};
		paraMap["funcNo"] = "2002006";
		paraMap["account"] = param.fund_account;

		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	};
    /********************************20160511应用接口结束********************************/
});
/**
 * 交易主界面
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils"),
		layerUtils = require("layerUtils"),
		gconfig = require("gconfig"),
		global = gconfig.global,
		service_common = require("service_common"),
		validata = require("validatorUtil"),
		external = require("external"),
		common = require("common"),
    	_pageId = "#account_activePhone ",
    	startCountDown = null; // 验证码
	var canvasActive = require("canvasActive");
    
    /**
     * 初始化
     */
	function init(){
		//只要走到此JS，代表本地是没有手机号码的（就一定要经过激活）
		common.systemKeybord(); // 解禁系统键盘
		$(_pageId).css("overflow-x","hidden");
		
		if(gconfig.platform != "0"){
			$(_pageId + "#canvasMain").hide();
		}
		
		if(window.navigator.userAgent.indexOf("iPhone") > -1 || window.navigator.userAgent.indexOf("iPad") > -1){
			var mb = myBrowser();
			if (mb != "Safari" && gconfig.platform != "2") {
				layerUtils.iAlert("当前浏览器为第三方浏览器,为保证正常功能,请使用Safari浏览器!");
			}
		}
		if(window.navigator.userAgent.indexOf("Android") > -1){
			if(navigator.userAgent.indexOf("browser") > -1 || navigator.userAgent.indexOf("Browser") > -1 || navigator.userAgent.indexOf("qq") > 1 || navigator.userAgent.indexOf("QQ") > 1 && gconfig.platform != "1" && common.isWeiXin()){
				layerUtils.iAlert("当前浏览器为第三方浏览器,为保证正常功能,请使用手机系统浏览器!");
			}
		}
		
		$(_pageId + " #phoneNum").val(appUtils.getLStorageInfo("acitve_phone")?appUtils.getLStorageInfo("acitve_phone").substring(0,appUtils.getLStorageInfo("acitve_phone").length -2):"");
		
		var cHeight = $(_pageId+"#canvasMain").height();
		var cWidth = $(_pageId+"#canvasMain").width();
		$(_pageId+"#activeCanvas").css({"height":cHeight,"width":cWidth});
		var opts = {
				"fcolor1":"red",
				"fcolor2":"#ccc",
				"fcolor3":"#ccc",
				"lcolor1":"red",
				"lcolor2":"#ccc",
				"acolor1":"red",
				"acolor2":"white",
				"acolor3":"white",
				"abcolor1":"#ccc",
				"abcolor2":"#ccc",
				"abcolor3":"#ccc"
		};
		canvasActive.init(opts);
    }
	
	/**
	 * 事件绑定
	 */
	function bindPageEvent(){
		//返回按钮
		appUtils.bindEvent($(_pageId+".top_title .icon_back"), function(e){
			e.stopPropagation();
		});
		
		//点击发送验证码
		appUtils.bindEvent($(_pageId+" #sendMsg"), function(e){
			var phoneNum = $.trim($(_pageId + " #phoneNum").val());
			if(!validata.isMobile(phoneNum)){
				layerUtils.iMsg(-1,"请输入正确的手机号码");
				return false;
			}
			//发送验证码
			sendmsg(phoneNum);
			$(_pageId + " #phoneMsg").focus();
			e.stopPropagation();
		});
		
		//点击下一步
		appUtils.bindEvent($(_pageId+" #next"), function(e){
			if(verifyNext()){
				checkPhoneMsg(); // 校验验证码
			}
			e.stopPropagation();
		});
	}
	
	/**
	 * 校验验证码
	 */
	function checkPhoneMsg(){
		var phoneNum = $.trim($(_pageId + " #phoneNum").val());
		var phoneMsgNum = $(_pageId + " #phoneMsg").val();
		var login_flag = "0";
		var param = {
			"phone": phoneNum,
			"vcode": phoneMsgNum,
			"login_flag":login_flag
		};
		var callback = function(data){
			if (data){
				if (data.error_no == 0){
					acitvePhone();//激活手机
				}else{
					layerUtils.iAlert(data.error_info);
				}
			}
		};
		service_common.checkSmsCode(param, callback, true, true);
	}
	
    /**
     * 发送验证码
     */
    function sendmsg(phoneNum){
    	var param = {
			"phone" : phoneNum
		};
		//请求获取验证码接口
		service_common.getSmsCode(param,function(data){
			if(data.error_no == "0"){  
				if(data.results){
					if(data.results[0]){
						var vCode = data.results[0].vcode;
						if(vCode){
							$(_pageId + "#phoneMsg").val(vCode);
						}
					}
					// 计时器
					var sumTime = 60;
					//处理获取验证码时发生的动作
					var handleCount = function(){
						// 获取验证码之后按钮隐藏
						$(_pageId+" #sendMsg").hide();
						// 显示倒计时
						$(_pageId+" #time").show();
						$(_pageId+" #time").text(sumTime--+"秒后重发");
						if(sumTime <= 0){
							clearInterval(startCountDown);
							// 显示按钮
							$(_pageId+" #sendMsg").show();
							// 隐藏倒计时
							$(_pageId+" #time").hide();
							$(_pageId+" #time").text(60);
							//关闭定时器
						}
					};
					handleCount();
					//每秒刷新下发送验证码框的数字
					startCountDown = window.setInterval(function(){
						handleCount();
					}, 1000);
				}
			}else{
				layerUtils.iAlert(data.error_info,-1);
			}
		});
    }
    
    /**
     * 激活客户的手机，并跳转页面
     */
    function acitvePhone(){
    	var phoneNum = $.trim($(_pageId + " #phoneNum").val());
    	if(gconfig.platform != "0"){
    		var hardsn = external.callMessage({"funcNo": "50022"}).results[0].deviceToken;
    		var param = {
    			"phone" : phoneNum + "FZ",
    			"hardsn": hardsn
    		};
    		service_common.binDingCustomerPhone(param,function(data){
    			if(data.error_no == "0"){
    				global.trade_flag = phoneNum+"FZ"; //手机号码
    				appUtils.setLStorageInfo("acitve_phone", phoneNum + "FZ");
    			    appUtils.setLStorageInfo("hardsn", hardsn);
    			    appUtils.pageInit("account/activePhone","account/index",{});
    			}else{
    				layerUtils.iMsg(data.error_info);
    			}
    		});
    	}else{
    		appUtils.setLStorageInfo("acitve_phone", phoneNum + "FZ");
    		appUtils.pageInit("account/activePhone","account/activeBind",{});
    	}
		
//    	var token = "";
//		//获取token
//    	if(gconfig.platform != "0"){
//			token = external.callMessage({"funcNo": "50022"}).results[0].deviceToken;
//		}else{
//			token = "aabbccddeeffgg";
//		}
//		var phoneNum = $(_pageId + " #phoneNum").val();
//		//手机绑定,入参为手机号和从原生获得的手机ID
//		var binDindParam = {
//				"phone":phoneNum,
//				"hardsn":token
//		};
//		service_common.binDingCustomerPhone(binDindParam,function(data){
//			if(data.error_no != 0){
//				//因为isLastReq为true ,所以不需要手动将isShowWait隐藏
//				layerUtils.iAlert(data.error_info);
//				return false;
//			}else{
//				//获取activePhone
//				if(gconfig.platform != "0"){
//					external.callMessage({"funcNo":"50042","key":"activePhone","value":phoneNum});
//				}else{
//					appUtils.setLStorageInfo("activePhone",phoneNum);
//				}
//				global.trade_flag = phoneNum+""; //手机号码
//				appUtils.pageInit("account/activePhone","account/index",{});
//			}
//    	});
	}
	/**
	 * 销毁
	 */
	function destroy(){
		$(_pageId + " #phoneNum").val("");
		$(_pageId + " #phoneMsg").val("请输入手机验证码");	
	}
	
	/**
	 * 校验下一步
	 */
	function verifyNext(){
		var result = true;
		var phoneNum = $.trim($(_pageId + " #phoneNum").val());
		var phoneMsgNum = $(_pageId + " #phoneMsg").val();
		if(phoneMsgNum == "88888888" && phoneNum == "88888888"){
			appUtils.setLStorageInfo("acitve_phone",phoneNum + "FZ");
			appUtils.setLStorageInfo("hardsn","hardsnTest");
			if(gconfig.platform != "0"){
				appUtils.pageInit("account/activePhone","account/index",{});
			}else{
				if(appUtils.getLStorageInfo("hardsn") == "hardsnTest"){
					appUtils.pageInit("account/activePhone","account/index",{});
				}else{
					appUtils.pageInit("account/activePhone","account/activeBind",{"phone":phoneNum,"isFromWeiXin":common.isWeiXin()});
				}
			}
			result = false;
		}
		else if(!validata.isMobile(phoneNum)){
			layerUtils.iMsg(-1, "请输入正确的手机号码");
			result = false;
		}
		else if(phoneMsgNum == ""){
			layerUtils.iMsg(-1, "验证码不能为空");
			result = false;
		}
		return result;
	}
	
	
	/**
	 * 获取随机数
	 */
	function getRndNum(n){
		  var rnd="";
		  for(var i=0;i<n;i++)
		     rnd+=Math.floor(Math.random()*10);
		  return rnd;
	}
	
	
	function myBrowser(){
	    var userAgent = navigator.userAgent; //取得浏览器的userAgent字符串
	    var isOpera = userAgent.indexOf("Opera") > -1;
	    if (isOpera) {
	        return "Opera"
	    }; //判断是否Opera浏览器
	    if (userAgent.indexOf("Firefox") > -1) {
	        return "FF";
	    } //判断是否Firefox浏览器
	    if (userAgent.indexOf("Chrome") > -1){
			return "Chrome";
		}
	    if (userAgent.indexOf("Safari") > -1) {
	        return "Safari";
	    } //判断是否Safari浏览器
	    if (userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1 && !isOpera) {
	        return "IE";
	    }; //判断是否IE浏览器
	}
	
	
	var base = {
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};
	module.exports = base;
});
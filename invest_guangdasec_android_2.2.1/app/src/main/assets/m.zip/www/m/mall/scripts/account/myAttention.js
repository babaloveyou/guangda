/**
 * 我的关注查询
 */
define( function(require, exports, module) {
	var appUtils = require("appUtils");
	var gconfig = require("gconfig");
	var service = require("mobileService"); //业务层接口，请求数据
	var global = gconfig.global;
	var layerUtils = require("layerUtils");
	var _pageId="#account_myAttention ";
	var idx=null;
	var product_type=1;
	VIscroll = require("vIscroll");
	var customVIscroll = {"scroll":null, "_init":false}; // 上下滑动
	var pagingObjArr = [{"total_pages":0,"curr_page":0}]; //消息分页对象数组，这个页面只有一个分页，简单分页

	/*初始化*/
	function init()
	{
		clearPageEvent();
		$(_pageId+" .product_cont_list").empty();
		product_type= $(_pageId+" .tab_box04 li:eq(0)").val();
		$(_pageId+" .tab_box04 ul li:eq(1)").removeClass(" current");
		$(_pageId+" .tab_box04 ul li:eq(2)").removeClass(" current");
		$(_pageId+" .tab_box04 ul li:eq(3)").removeClass(" current");
		$(_pageId+" .tab_box04 ul li:eq(0)").addClass(" current");
		queryMyAttention();
	}

	function bindPageEvent() 
	{
		/* 绑定返回事件 */
		appUtils.bindEvent($(_pageId+" .new_nav .icon_back"),function(){
			appUtils.pageBack();
		});

		/* 绑定返回首页事件 */
		appUtils.bindEvent($(_pageId+" .header .logo"),function(){
			appUtils.pageInit("account/myAttention","account/mainPage",{});
		});

		/* 点击返回首页 */
		appUtils.bindEvent($(_pageId+" .icon_mall"),function(){
			appUtils.pageInit("account/myAttention","account/mainPage",{});
		});
		// 点击理财
		appUtils.bindEvent($(_pageId+" #lc"),function(){ 
			product_type= $(_pageId+" .tab_box04 li:eq(0)").val();
			$(_pageId+" .tab_box04 ul li:eq(1)").removeClass(" current");
			$(_pageId+" .tab_box04 ul li:eq(2)").removeClass(" current");
			$(_pageId+" .tab_box04 ul li:eq(3)").removeClass(" current");
			$(_pageId+" .tab_box04 ul li:eq(0)").addClass(" current");
			queryMyAttention();
		});

		// 点击基金 
		appUtils.bindEvent($(_pageId+"   #jj"),function(){
			product_type= $(_pageId+" .tab_box04 li:eq(1)").val();
			$(_pageId+" .tab_box04 ul li:eq(0)").removeClass(" current");
			$(_pageId+" .tab_box04 ul li:eq(2)").removeClass(" current");
			$(_pageId+" .tab_box04 ul li:eq(3)").removeClass(" current");
			$(_pageId+" .tab_box04 ul li:eq(1)").addClass(" current");
			queryMyAttention();
		}); 

		// 点击资讯 
		appUtils.bindEvent($(_pageId+"   #zx"),function(){
			product_type= $(_pageId+" .tab_box04 li:eq(2)").val();
			$(_pageId+" .tab_box04 ul li:eq(0)").removeClass(" current");
			$(_pageId+" .tab_box04 ul li:eq(1)").removeClass(" current");
			$(_pageId+" .tab_box04 ul li:eq(3)").removeClass(" current");
			$(_pageId+" .tab_box04 ul li:eq(2)").addClass(" current");
			queryMyAttention();
		}); 

		// 点击服务
		appUtils.bindEvent($(_pageId+"   #fw"),function(){
			product_type= $(_pageId+" .tab_box04 li:eq(3)").val();
			$(_pageId+" .tab_box04 ul li:eq(0)").removeClass(" current");
			$(_pageId+" .tab_box04 ul li:eq(2)").removeClass(" current");
			$(_pageId+" .tab_box04 ul li:eq(1)").removeClass(" current");
			$(_pageId+" .tab_box04 ul li:eq(3)").addClass(" current");
			queryMyAttention();
		}); 


		/*点击 跳到到顶部*/
		appUtils.bindEvent($(_pageId+"  .back_btn"),function()
			{
			$('body,html').animate({
				scrollTop:0
			},
			1000);
			return false;
			});

		//上一页、下一页
		appUtils.bindEvent($(_pageId+" span[name='aPrePage']"),function()
			{  
			if(pagingObjArr[0].curr_page==1){
				handlePreNextPage(-1);
			}
			else{
				handlePreNextPage(-1);
			}
			});
		appUtils.bindEvent($(_pageId+" span[name='aNextPage']"),function()
			{
			if(pagingObjArr[0].total_pages==pagingObjArr[0].curr_page){
				handlePreNextPage(1);
			}
			else{
				handlePreNextPage(1);
			}
			});

	}
	/* 取消关注 */
	function cancelAttention(product_id, index,curr_page){

		var user_id =appUtils.getSStorageInfo("user_id");
		var param =
		{
			"user_id" :user_id,
			"product_id" :product_id,
		};
		service.cancerAttention(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;

			if(error_no =="0")
			{
				$(_pageId+" .product_cont_list li[data-idx="+index+"]").remove();
				var user_id =appUtils.getSStorageInfo("user_id");
				var productType =product_type;
				var param =
				{
					"user_id" :user_id,
					"product_sub_type" :productType,
					"page" :curr_page,
					"numPerPage" :"4",
				};

				service.queryMyAttention(param,function(data){
					var error_no = data.error_no;
					var error_info = data.error_info;
					var result=data.results[0].data;
					if(error_no =="0" && productType=="1")
					{
						if(result.length=="0"){
							layerUtils.iMsg(-1,"您还没有关注的产品!");
							$(_pageId+" .product_bd_title").html('理财产品总数 : 0');
							$(_pageId+" .product_cont_list").empty();
						}
						else{
							for(var i=0; i<result[i].length;i++){
								/*把账户名存到session*/
								if(result[i].product_id)
								{
									appUtils.setSStorageInfo("product_id"+[i],result[i].product_id);
								}
							}
							attentionItems(data);
						}
					}
					else if(error_no =="0" && productType=="0")
					{
						if(result.length=="0"){
							layerUtils.iMsg(-1,"您还没有关注的产品!");
							$(_pageId+" .product_bd_title").html('基金产品总数 : 0');
							$(_pageId+" .product_cont_list").empty();
						}
						else{
							for(var i=0; i<result[i].length;i++){
								/*把账户名存到session*/
								if(result[i].product_id)
								{
									appUtils.setSStorageInfo("product_id"+[i],result[i].product_id);
								}
							}
							attentionItems1(data);
						}
					}
					else if(error_no =="0" && productType=="2")
					{

						if(result.length=="0"){
							layerUtils.iMsg(-1,"您还没有关注的产品!");
							$(_pageId+" .product_bd_title").html('服务产品总数 : 0');
							$(_pageId+" .product_cont_list").empty();
						}
						else{
							for(var i=0; i<result[i].length;i++){
								/*把账户名存到session*/
								if(result[i].product_id)
								{
									appUtils.setSStorageInfo("product_id"+[i],result[i].product_id);
								}
							}
							attentionItems2(data);
						}
					}
					else if(error_no =="0" && productType=="3")
					{

						if(result.length=="0"){
							layerUtils.iMsg(-1,"您还没有关注的产品!");
							$(_pageId+" .product_bd_title").html('资讯产品总数 : 0');
							$(_pageId+" .product_cont_list").empty();
						}
						else{
							for(var i=0; i<result[i].length;i++){
								/*把账户名存到session*/
								if(result[i].product_id)
								{
									appUtils.setSStorageInfo("product_id"+[i],result[i].product_id);
								}
							}
							attentionItems3(data);
						}
					}else{
						layerUtils.iMsg(-1,error_info);
					}

				});

			}else{
				layerUtils.iMsg(-1,error_info);
			}

		});

	}

	/*获取关注产品 */
	function queryMyAttention(){
		var user_id =appUtils.getSStorageInfo("user_id");
		var productType =product_type;
		var param =
		{
			"user_id" :user_id,
			"product_sub_type" :productType,
			"page" :"",
			"numPerPage" :"4",
		};

		service.queryMyAttention(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result=data.results[0].data;
			if(error_no =="0" && productType=="1")
			{
				if(result.length=="0"){
					layerUtils.iMsg(-1,"您还没有关注的产品!");
					$(_pageId+" .product_bd_title").html('理财产品总数 : 0');
					$(_pageId+" .product_cont_list").empty();
					var total_pages = data.results[0].totalPages;
					var curr_page = data.results[0].currentPage;
					var total_rows = data.results[0].totalRows;
					total_pages = total_pages ? total_pages:0;
					curr_page = curr_page ? curr_page:0;
					total_rows=total_rows?total_rows:0;
					pagingObjArr[0].total_pages=total_pages;
					$(_pageId+" em[name='totalPage']").html(total_pages);
					pagingObjArr[0].curr_page=curr_page;
					$(_pageId+" em[name='curPage']").html(curr_page);
					//显示多少条数据
					$(_pageId+" em[name='total_rows']").html(total_rows);
					$(_pageId + "  span[name='aNextPage']").removeClass("blue");
				}
				else{
					for(var i=0; i<result[i].length;i++){
						/*把账户名存到session*/
						if(result[i].product_id)
						{
							appUtils.setSStorageInfo("product_id"+[i],result[i].product_id);
						}
					}
					attentionItems(data);
				}
			}
			else if(error_no =="0" && productType=="0")
			{

				if(result.length=="0"){
					layerUtils.iMsg(-1,"您还没有关注的产品!");
					$(_pageId+" .product_bd_title").html('基金产品总数 : 0');
					$(_pageId+" .product_cont_list").empty();
					var total_pages = data.results[0].totalPages;
					var curr_page = data.results[0].currentPage;
					var total_rows = data.results[0].totalRows;
					total_pages = total_pages ? total_pages:0;
					curr_page = curr_page ? curr_page:0;
					total_rows=total_rows?total_rows:0;
					pagingObjArr[0].total_pages=total_pages;
					$(_pageId+" em[name='totalPage']").html(total_pages);
					pagingObjArr[0].curr_page=curr_page;
					$(_pageId+" em[name='curPage']").html(curr_page);
					//显示多少条数据
					$(_pageId+" em[name='total_rows']").html(total_rows);
					$(_pageId + "  span[name='aNextPage']").removeClass("blue");
				}
				else{
					for(var i=0; i<result[i].length;i++){
						/*把账户名存到session*/
						if(result[i].product_id)
						{
							appUtils.setSStorageInfo("product_id"+[i],result[i].product_id);
						}
					}
					attentionItems1(data);
				}
			}else if(error_no =="0" && productType=="2")
			{

				if(result.length=="0"){
					layerUtils.iMsg(-1,"您还没有关注的产品!");
					$(_pageId+" .product_bd_title").html('服务产品总数 : 0');
					$(_pageId+" .product_cont_list").empty();
					var total_pages = data.results[0].totalPages;
					var curr_page = data.results[0].currentPage;
					var total_rows = data.results[0].totalRows;
					total_pages = total_pages ? total_pages:0;
					curr_page = curr_page ? curr_page:0;
					total_rows=total_rows?total_rows:0;
					pagingObjArr[0].total_pages=total_pages;
					$(_pageId+" em[name='totalPage']").html(total_pages);
					pagingObjArr[0].curr_page=curr_page;
					$(_pageId+" em[name='curPage']").html(curr_page);
					//显示多少条数据
					$(_pageId+" em[name='total_rows']").html(total_rows);
					$(_pageId + "  span[name='aNextPage']").removeClass("blue");
				}
				else{
					for(var i=0; i<result[i].length;i++){
						/*把账户名存到session*/
						if(result[i].product_id)
						{
							appUtils.setSStorageInfo("product_id"+[i],result[i].product_id);
						}
					}
					attentionItems2(data);
				}
			}
			else if(error_no =="0" && productType=="3")
			{

				if(result.length=="0"){
					layerUtils.iMsg(-1,"您还没有关注的产品!");
					$(_pageId+" .product_bd_title").html('资讯产品总数 : 0');
					$(_pageId+" .product_cont_list").empty();
					var total_pages = data.results[0].totalPages;
					var curr_page = data.results[0].currentPage;
					var total_rows = data.results[0].totalRows;
					total_pages = total_pages ? total_pages:0;
					curr_page = curr_page ? curr_page:0;
					total_rows=total_rows?total_rows:0;
					pagingObjArr[0].total_pages=total_pages;
					$(_pageId+" em[name='totalPage']").html(total_pages);
					pagingObjArr[0].curr_page=curr_page;
					$(_pageId+" em[name='curPage']").html(curr_page);
					//显示多少条数据
					$(_pageId+" em[name='total_rows']").html(total_rows);
					$(_pageId + "  span[name='aNextPage']").removeClass("blue");
				}
				else{
					for(var i=0; i<result[i].length;i++){
						/*把账户名存到session*/
						if(result[i].product_id)
						{
							appUtils.setSStorageInfo("product_id"+[i],result[i].product_id);
						}
					}
					attentionItems3(data);
				}
			}
			else{
				layerUtils.iMsg(-1,error_info);
			}

		});
	}

	//处理理财关注产品
	function attentionItems(data)
	{	
		var total_pages = data.results[0].totalPages;
		var curr_page = data.results[0].currentPage;
		var total_rows = data.results[0].totalRows;
		total_pages = total_pages ? total_pages:0;
		curr_page = curr_page ? curr_page:0;
		total_rows=total_rows?total_rows:0;
		pagingObjArr[0].total_pages=total_pages;
		$(_pageId+" em[name='totalPage']").html(total_pages);
		pagingObjArr[0].curr_page=curr_page;
		$(_pageId+" em[name='curPage']").html(curr_page);
		//显示多少条数据
		$(_pageId+" em[name='total_rows']").html(total_rows);

		var allRecommendStr =  "";
		var list =  data.results[0].data;
		var len = list.length;
		for( idx = 0; idx<len ; idx++)
		{	
			allRecommendStr+=' <li class=\"attentionList\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF">'+list[idx].product_name+'</font></a></span> ' +
			'<span><strong>单位净值：</strong>'+list[idx].current_price+' </span> ' +
			'<span><strong>累计净值：</strong>'+list[idx].cumulative_net+' </span>' +
			' <span style="width:300px"><strong>关注时间：</strong>'+list[idx].create_time+'</span> ' +
			'<a  style="float:right"  href="javascript:;"  class="cancer"  product_id='+list[idx].product_id+' data-idx='+idx+'><img class="im"  src="project/images/hsz.png" width="20px"  style="border:1 red" height="18"></img></a>' +
			'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 

		}
		$(_pageId+" .product_bd_title").html('理财产品总数 : '+data.results[0].totalRows+'');
		$(_pageId+" .product_cont_list").html(allRecommendStr);

		//鼠标移入改变颜色
		appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
			$(this).css("color","red");
		},"mouseenter");

		//鼠标移出改变颜色
		appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
			$(this).css("color","black");
		},"mouseleave");

		//点击名称 进入详情
		appUtils.bindEvent($(_pageId+"  a[product-id]"),function(){
			var param=
			{
				"product_id":$(this).attr("product-id")
			};
			appUtils.pageInit("account/myAttention","mall/itemsFinanInfo",param);
		});

		/* 绑定取消关注事件 */
		appUtils.bindEvent($(_pageId+" .cancer"),function(){
			var product_id = $(this).attr("product_id");
			var index = $(this).attr("data-idx");
			$(this).css("color","red");
			layerUtils.iConfirm("确定是否取消关注？",function () {
				cancelAttention(product_id, index,curr_page);
			});

		});

		// //上一页、下一页disabled效果
		if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
			$(_pageId + " span[name='aNextPage']").removeClass("blue");
			$(_pageId + " span[name='aPrePage']").addClass("blue");
		}
		else if (pagingObjArr[0].curr_page == 1) {
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + " span[name='aNextPage']").addClass("blue");
		}
		else {
			$(_pageId + " span[name='aPrePage']").addClass("blue");
			$(_pageId + " span[name='aNextPage']").addClass("blue");
		}

		if (pagingObjArr[0].total_pages<2) {
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + "  span[name='aNextPage']").removeClass("blue");
		}

		if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
			$(_pageId+" #isNull").html("暂无数据");
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + " span[name='aNextPage']").removeClass("blue");
		}
	}
	//处理基金关注产品
	function attentionItems1(data){

		var total_pages = data.results[0].totalPages;
		var curr_page = data.results[0].currentPage;
		var total_rows = data.results[0].totalRows;
		total_pages = total_pages ? total_pages:0;
		curr_page = curr_page ? curr_page:0;
		total_rows=total_rows?total_rows:0;
		pagingObjArr[0].total_pages=total_pages;
		$(_pageId+" em[name='totalPage']").html(total_pages);
		pagingObjArr[0].curr_page=curr_page;
		$(_pageId+" em[name='curPage']").html(curr_page);
		//显示多少条数据
		$(_pageId+" em[name='total_rows']").html(total_rows);

		var allRecommendStr =  "";
		var list =  data.results[0].data;
		var len = list.length;
		for( idx = 0; idx<len ; idx++)
		{

			allRecommendStr+=' <li class=\"attentionList\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;" product-id='+list[idx].product_id+'><font color="0000FF">'+list[idx].product_name+'</font></a></span>' +
			'<span><strong>单位净值：</strong>'+list[idx].current_price+' </span> ' +
			'<span><strong>累计净值：</strong>'+list[idx].cumulative_net+' </span>' +
			' <span  style="width:300px"><strong>关注时间：</strong>'+list[idx].create_time+'</span> ' +
			'<a  style="float:right"  href="javascript:;"  class="cancer"  product_id='+list[idx].product_id+' data-idx='+idx+'><img src="project/images/hsz.png" width="20px" height="18"></img></a>' +
			'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'   ;

		}

		$(_pageId+" .product_bd_title").html('基金产品总数 : '+data.results[0].totalRows+'');
		$(_pageId+" .product_cont_list").html(allRecommendStr);

		//鼠标移入改变颜色
		appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
			$(this).css("color","red");
		},"mouseenter");

		//鼠标移出改变颜色
		appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
			$(this).css("color","black");
		},"mouseleave");

		//点击名称 进入详情
		appUtils.bindEvent($(_pageId+"  a[product-id]"),function(){
			var param=
			{
				"product_id":$(this).attr("product-id")
			};
			appUtils.pageInit("account/myAttention","mall/itemsFundInfo",param);
		});

		/* 绑定取消关注事件 */
		appUtils.bindEvent($(_pageId+" .cancer"),function(){
			var product_id = $(this).attr("product_id");
			var index = $(this).attr("data-idx");
			layerUtils.iConfirm("确定是否取消关注？",function () {
				cancelAttention(product_id, index,curr_page);
			});

		});

		//上一页、下一页disabled效果
		if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
			$(_pageId + " span[name='aNextPage']").removeClass("blue");
			$(_pageId + " span[name='aPrePage']").addClass("blue");
		}
		else if (pagingObjArr[0].curr_page == 1) {
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + " span[name='aNextPage']").addClass("blue");
		}
		else {
			$(_pageId + " span[name='aPrePage']").addClass("blue");
			$(_pageId + " span[name='aNextPage']").addClass("blue");
		}

		if (pagingObjArr[0].total_pages<2) {
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + "  span[name='aNextPage']").removeClass("blue");
		}

		if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
			$(_pageId+" #isNull").html("暂无数据");
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + " span[name='aNextPage']").removeClass("blue");
		}

	}

	//处理服务关注产品
	function attentionItems2(data){

		var total_pages = data.results[0].totalPages;
		var curr_page = data.results[0].currentPage;
		var total_rows = data.results[0].totalRows;
		total_pages = total_pages ? total_pages:0;
		curr_page = curr_page ? curr_page:0;
		total_rows=total_rows?total_rows:0;
		pagingObjArr[0].total_pages=total_pages;
		$(_pageId+" em[name='totalPage']").html(total_pages);
		pagingObjArr[0].curr_page=curr_page;
		$(_pageId+" em[name='curPage']").html(curr_page);
		//显示多少条数据
		$(_pageId+" em[name='total_rows']").html(total_rows);

		var allRecommendStr =  "";
		var list =  data.results[0].data;
		var len = list.length;
		for( idx = 0; idx<len ; idx++)
		{
			allRecommendStr+=' <li class=\"attentionList\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;" product-id='+list[idx].product_id+'><font color="0000FF">'+list[idx].product_name+'</font></a></span>' +
			'<span><strong>服务价格：</strong>'+list[idx].rules_price+' '+list[idx].rules_explanation+' </span> ' +
			'<span><strong>产品行号：</strong>'+list[idx].rownum_+' </span>' +
			' <span  style="width:300px"><strong>关注时间：</strong>'+list[idx].create_time+'</span> ' +
			'<a  style="float:right"  href="javascript:;"  class="cancer"  product_id='+list[idx].product_id+' data-idx='+idx+'><img src="project/images/hsz.png" width="20px" height="18"></img></a>' +
			'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'   ;

		}

		$(_pageId+" .product_bd_title").html('服务产品总数 : '+data.results[0].totalRows+'');
		$(_pageId+" .product_cont_list").html(allRecommendStr);

		//鼠标移入改变颜色
		appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
			$(this).css("color","red");
		},"mouseenter");

		//鼠标移出改变颜色
		appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
			$(this).css("color","black");
		},"mouseleave");

		//点击名称 进入详情
		appUtils.bindEvent($(_pageId+"  a[product-id]"),function(){
			var param=
			{
				"product_id":$(this).attr("product-id")
			};
				appUtils.pageInit("account/myAttention","mall/itemsServInfo",param);
		});

		/* 绑定取消关注事件 */
		appUtils.bindEvent($(_pageId+" .cancer"),function(){
			var product_id = $(this).attr("product_id");
			var index = $(this).attr("data-idx");
			layerUtils.iConfirm("确定是否取消关注？",function () {
				cancelAttention(product_id, index,curr_page);
			});

		});

		//上一页、下一页disabled效果
		if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
			$(_pageId + " span[name='aNextPage']").removeClass("blue");
			$(_pageId + " span[name='aPrePage']").addClass("blue");
		}
		else if (pagingObjArr[0].curr_page == 1) {
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + " span[name='aNextPage']").addClass("blue");
		}
		else {
			$(_pageId + " span[name='aPrePage']").addClass("blue");
			$(_pageId + " span[name='aNextPage']").addClass("blue");
		}

		if (pagingObjArr[0].total_pages<2) {
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + "  span[name='aNextPage']").removeClass("blue");
		}

		if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
			$(_pageId+" #isNull").html("暂无数据");
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + " span[name='aNextPage']").removeClass("blue");
		}

	}

	//处理资讯关注产品
	function attentionItems3(data){

		var total_pages = data.results[0].totalPages;
		var curr_page = data.results[0].currentPage;
		var total_rows = data.results[0].totalRows;
		total_pages = total_pages ? total_pages:0;
		curr_page = curr_page ? curr_page:0;
		total_rows=total_rows?total_rows:0;
		pagingObjArr[0].total_pages=total_pages;
		$(_pageId+" em[name='totalPage']").html(total_pages);
		pagingObjArr[0].curr_page=curr_page;
		$(_pageId+" em[name='curPage']").html(curr_page);
		//显示多少条数据
		$(_pageId+" em[name='total_rows']").html(total_rows);

		var allRecommendStr =  "";
		var list =  data.results[0].data;
		var len = list.length;
		for( idx = 0; idx<len ; idx++)
		{

			allRecommendStr+=' <li class=\"attentionList\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;" product-id='+list[idx].product_id+'><font color="0000FF">'+list[idx].product_name+'</font></a></span>' +
			'<span><strong>资讯价格：</strong>'+list[idx].rules_price+' '+list[idx].rules_explanation+' </span> ' +
			'<span><strong>产品行号：</strong>'+list[idx].rownum_+' </span>' +
			' <span  style="width:300px"><strong>关注时间：</strong>'+list[idx].create_time+'</span> ' +
			'<a  style="float:right"  href="javascript:;"  class="cancer"  product_id='+list[idx].product_id+' data-idx='+idx+'><img src="project/images/hsz.png" width="20px" height="18"></img></a>' +
			'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'   ;

		}

		$(_pageId+" .product_bd_title").html('资讯产品总数 : '+data.results[0].totalRows+'');
		$(_pageId+" .product_cont_list").html(allRecommendStr);

		//鼠标移入改变颜色
		appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
			$(this).css("color","red");
		},"mouseenter");

		//鼠标移出改变颜色
		appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
			$(this).css("color","black");
		},"mouseleave");

		//点击名称 进入详情
		appUtils.bindEvent($(_pageId+"  a[product-id]"),function(){
			var param=
			{
				"product_id":$(this).attr("product-id")
			};
			     appUtils.pageInit("account/myAttention","mall/itemsInfoDetail",param);
		});

		/* 绑定取消关注事件 */
		appUtils.bindEvent($(_pageId+" .cancer"),function(){
			var product_id = $(this).attr("product_id");
			var index = $(this).attr("data-idx");
			layerUtils.iConfirm("确定是否取消关注？",function () {
				cancelAttention(product_id, index,curr_page);
			});

		});

		//上一页、下一页disabled效果
		if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
			$(_pageId + " span[name='aNextPage']").removeClass("blue");
			$(_pageId + " span[name='aPrePage']").addClass("blue");
		}
		else if (pagingObjArr[0].curr_page == 1) {
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + " span[name='aNextPage']").addClass("blue");
		}
		else {
			$(_pageId + " span[name='aPrePage']").addClass("blue");
			$(_pageId + " span[name='aNextPage']").addClass("blue");
		}

		if (pagingObjArr[0].total_pages<2) {
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + "  span[name='aNextPage']").removeClass("blue");
		}

		if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
			$(_pageId+" #isNull").html("暂无数据");
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + " span[name='aNextPage']").removeClass("blue");
		}

	}

	//处理上一页，下一页
	function handlePreNextPage(direction)
	{	
		var total_pages = pagingObjArr[0].total_pages;
		var   curr_page = pagingObjArr[0].curr_page;
		var   curPageNo = parseInt(curr_page) + direction ;
		var user_id =appUtils.getSStorageInfo("user_id");
		var productType =product_type;
		if(curPageNo>0 && curPageNo <= total_pages && curPageNo != curr_page) //有效执行跳转页面条件
		{
			var param =
			{
				"user_id" :user_id,
				"product_sub_type" :productType,
				"page" :curPageNo,
				"numPerPage" :"4",
			};
			service.queryMyAttention(param,function(data)
				{
				var error_no = data.error_no;
				var error_info = data.error_info;
				if(error_no =="0" && productType=="1")
				{
					attentionItems(data);
				}
				else if(error_no =="0" && productType=="0")
				{
					attentionItems1(data);
				}
				else if(error_no =="0" && productType=="2")
				{
					attentionItems2(data);
				}
				else if(error_no =="0" && productType=="3")
				{
					attentionItems3(data);
				}
				else{
					layerUtils.iMsg(-1,error_info);
				}

				});
		}
	}

	//清除
	function clearPageEvent(){
		$(_pageId+" table .ce_table").html('<tr><th scope="col">产品名称</th>  <th scope="col">产品编号</th> <th scope="col">'+
		' 单位净值</th><th scope="col">关注时间</th>');
	}

	function destroy()
	{
	}

	var myAttention = 
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = myAttention;

});
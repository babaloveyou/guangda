/**
 * 该模块用以处理统一登录 
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils");
	var gconfig = require("gconfig");
	var layerUtils = require("layerUtils");
	var resultVo = ""; // 与原生交互返回的结果集
	var moduleNames = {
		"ggt":"ggt",
		"index":"user-center",
		"mall":"financial-mall",
		"open":"open-account",
		"trade":"trade",
		"xdt":"fund-loan"
	};
	function firstLoadFunc(){
		var projName = gconfig.projName;
		var moduleName = moduleNames[projName];
	    require("external").callMessage({"funcNo": "50100", "moduleName":moduleName});
	} // 进入模块，该方法只加载一次

	/* 处理会话失效，长期未登录操作 */
	function filterLoginOut(data){
		if(data.error_no == "-999") {
			layerUtils.iMsg(-1,"由于长期未操作，请重新登录");
			appUtils.clearSStorage("_isLoginIn");
			appUtils.clearSStorage("_loginInPageCode");
			appUtils.clearSStorage("_loginInPageParam");
			appUtils.clearSStorage("stock_userInfo");
			appUtils.clearSStorage("credit_userInfo");
			appUtils.clearSStorage();
			var projName = gconfig.projName; // 当前模块名
			var moduleName = ""; // 原生定义模块名
			switch(projName){
				case "index":
					moduleName = "user-center";
					break;
				case "mall":
					moduleName = "financial-mall";
					break;
				case "xdt":
					moduleName = "fund-loan";
					break;
				case "ggt":
					moduleName = "ggt";
					break;
				case "trade":
					moduleName = "trade";
					break;
			}

			//toPage = "/mall/index.html#!/account/riskAssessment.html?prePage=fz_marketCon";
			//toPage={"prefix":"www/m/mall","suffix":"account/riskAssessment","prePage":"fz_marketCon"};
			var toPage = "";
			var url = window.location.href;
			var pageCode = url.substring(url.indexOf("#!/") + 3, url.lastIndexOf(".html"));			
			if(gconfig.platform == "2"){
				toPage={"prefix":"www/m/"+projName,"suffix":pageCode};
			}else{
				toPage = "/"+projName+"/index.html#!/"+pageCode+".html";
			}
			/* 发消息给原生，通知打开登陆页面重新登陆 */
            var param_login = {"funcNo":"50101", "moduleName":"login", "params":{"moduleName":moduleName,"toPage":toPage,"session_timeout":true}};
            require("external").callMessage(param_login);
			var param_login = {"funcNo":"50040", "key":"login_state","value":"0"};
			require("external").callMessage(param_login);
		}
	}

	/**
	 * 富尊网统一登陆拦截器
	 */
	function checkPermission_fz(checkInParam){
		var checkLoginPage = gconfig.global.checkLoginPageCode; // 不需要激活的页面
		if(checkLoginPage.indexOf(checkInParam.pageCode)>-1){
			// 获取壳子里的全局登陆状态，1:已经登陆； 0:代表退出
			var param_login = {"funcNo":"50041", "key":"login_state"};
			resultVo = require("external").callMessage(param_login);
			var login_state = resultVo.results[0].value;
			if(login_state == "1"){ // 已经登陆
			    //判断是否切换资金账号
			    //这里账号切换 重置资金账号
                var param_login = {"funcNo":"50041", "key":"switchAccountResults"};
                resultVo = require("external").callMessage(param_login);
                var result = resultVo.results[0].value;
                
                //如果从壳子里面获取的 资金账号不为空，那么说明客户通过原生切换了账户
                if(result != null && result != ""){
                    appUtils.setSStorageInfo("fund_account",result[0].fund_account);
                    appUtils.setSStorageInfo("client_no",result[0].client_no);
                    result = result[0];
                }else{
			        // 获取资金账号登录返回的用户信息
                    var param_info_account = {"funcNo":"50041", "key":"resultsOfAccount"};
                    resultVo = require("external").callMessage(param_info_account);
                    //如果资金账号里面取得是空的，就取E账通
                    if(resultVo.results[0].value == null || resultVo.results[0].value == ""){
                        resultVo = require("external").callMessage({"funcNo":"50041", "key":"resultsOfAccountE"});
                    }
                    result = resultVo.results[0].value[0];
                    var cust_act_flag = appUtils.getSStorageInfo("cust_act_flag"); //获取E账通激活状态
                    if(cust_act_flag != null){
                        result.cust_act_flag = cust_act_flag;
                    }
                }
                appUtils.setSStorageInfo("userinfo",JSON.stringify(result)); // 把登录后的信息存本地
			    /*把用户编号存到session*/
	            if(result.user_id){
	                appUtils.setSStorageInfo("user_id",result.user_id);
	            }
	            /*把资金账号存到session*/
	            if(result.fund_account){
	                appUtils.setSStorageInfo("fund_account",result.fund_account);
	            }
	            /*把客户号存到session*/
	            if(result.client_no){
	                appUtils.setSStorageInfo("client_no",result.client_no);
	            }
	            /*把营业部存到session*/
	            if(result.branch_no){
	                appUtils.setSStorageInfo("branch_no",result.branch_no);
	            }
	            /*把jsessionid存到session*/
	            if(result.jsessionid){
	                appUtils.setSStorageInfo("jsessionid",result.jsessionid);
	            }
	            /*存user_code到session*/
	    		if(result.user_code){
	    			appUtils.setSStorageInfo("cust_code",result.user_code);
//	    			appUtils.setSStorageInfo("custCode",result.user_code,true);
	    			var par_custCode = {"funcNo":"50040","key":"custCode","value":result.user_code};
					require("external").callMessage(par_custCode); //把user_code存在原生壳子 
	    		}
	    		/*存fundlist到session*/
	    		if(result.fundlist){
	    			appUtils.setSStorageInfo("fundlist",result.fundlist);
	    		}
	    		/*存ticket到session*/
	    		if(result.ticket){
	    			appUtils.setSStorageInfo("ticket",result.ticket);
	    		}
	    		/*存cust_type到session*/
	    		if(result.cust_type){
	    			appUtils.setSStorageInfo("cust_type",result.cust_type);
	    			var par_custType = {"funcNo":"50040","key":"custType","value":result.cust_type};
	    			require("external").callMessage(par_custType); //把cust_type存在原生壳子 
	    		}
	    		/*存login_flag到session*/
	    		if(result.login_flag){
	    			appUtils.setSStorageInfo("login_flag",result.login_flag);
	    		}
			}
			else{// 未登录状态，需清理session并且跳到原生登陆页面
				//appUtils.clearSStorage();  // 清空所有的session
				var toPage = checkInParam.pageCode; // 登录完需要跳转的页面code
				if(gconfig.platform == "2"){
					toPage={"prefix":"www/m/index","suffix":toPage};
				}else{
					toPage = "/index/index.html#!/"+toPage+".html";
				}
	            var param_login = {"funcNo":"50101", "moduleName":"login", "params":{"moduleName":"user-center","toPage":toPage}};
	            require("external").callMessage(param_login);
	            return false;
			}
		}
		return true;
	}
	
	/**
	 * 商城统一登陆拦截器
	 */
	function checkPermission_mall(checkInParam){
	    var func_login = function(token){
	        var flag = true;
			var loginPath = gconfig.global.loginPath+"&token="+encodeURIComponent(token); // 商城统一登录链接
			// 发送请求模拟登陆
			appUtils.invokeServer(loginPath, {}, function(data){
				var error_no = data.err_no;
				var error_info = data.err_info;
				var result = data.data;//验证码输入错误
				if(error_no == "0" && result.length != 0){
					var param_data = {"funcNo":"50040","key":"mall_data","value":JSON.stringify(result)};
					require("external").callMessage(param_data); //把result存在原生壳子 
					var param_token = {"funcNo":"50040","key":"mall_token","value":token};
					require("external").callMessage(param_token); //保存token值
					saveData_mall(result,token); // 保存数据
					//这里账号切换 重置资金账号
					var param_login = {"funcNo":"50041", "key":"switchAccountResults"};
					resultVo = require("external").callMessage(param_login);
					var result = resultVo.results[0].value;
					//如果从壳子里面获取的 资金账号不为空，那么说明客户通过原生切换了账户
					if(result != null && result != ""){
						switchInfo_mall(result[0].fund_account,token); // 调用切换资金账号接口，重置用户信息
						appUtils.setSStorageInfo("fund_account",result[0].fund_account);
						appUtils.setSStorageInfo("client_no",result[0].client_no);
					}
					appUtils.setSStorageInfo("_isLoginIn","true");
					var param_lg = {"funcNo":"50040","key":"login_mall","value":true};
                    require("external").callMessage(param_lg); //保存登录状态
                    appUtils.pageInit(checkInParam.prePageCode,checkInParam.pageCode,checkInParam.param);
				}
				else{
					layerUtils.iAlert(error_info);
				}
			},true,true);
			return false;
		};
		var checkLoginPage = gconfig.global.checkLoginPageCode;
		// 判断当前页面是否需要激活才能进入
		if(checkLoginPage.indexOf(checkInParam.pageCode)>-1){
			// 获取壳子里的全局登陆状态，1:已经登陆； 0:代表退出
			var param_login = {"funcNo":"50041", "key":"login_state"};
			resultVo = require("external").callMessage(param_login);
			var login_state = resultVo.results[0].value;
			// 已经统一登陆
			if(login_state == "1"){
			    var param_lg= {"funcNo":"50041","key":"login_mall"};
                var _isLoginIn =  require("external").callMessage(param_lg).results[0].value;
                if(!_isLoginIn){
				    _isLoginIn = appUtils.getSStorageInfo("_isLoginIn");
                }
				var param_mall = {"funcNo":"50041", "key":"APP_SC"};
				resultVo = require("external").callMessage(param_mall);
				var token = resultVo.results[0].value;
				var param_token = {"funcNo":"50041","key":"mall_token"};
				resultVo =  require("external").callMessage(param_token);
				var session_token = resultVo.results[0].value;
				if(!session_token){
					session_token = appUtils.getSStorageInfo("login_token") || "";
				}
				// 本地session为空，需要进行模拟登陆
				if(!_isLoginIn){
					return func_login(token); // 模拟登陆
				}
				else{
					// 比较本地token值与壳子token值是否相同
					if(token == session_token){
						//从原生壳子获取用户缓存
						var param_data = {"funcNo":"50041","key":"mall_data"};
						resultVo =  require("external").callMessage(param_data);
						var res = resultVo.results[0].value;
						//ios 返回的是字符串  android 返回json
						if(res && typeof res === "string"){
							res = JSON.parse(res);
						}
						//将用户缓存存在session中
						saveData_mall(res,session_token);
						//这里账号切换 重置资金账号
						var param_login = {"funcNo":"50041", "key":"switchAccountResults"};
						resultVo = require("external").callMessage(param_login);
						var result = resultVo.results[0].value;
						//如果从壳子里面获取的 资金账号不为空，那么说明客户通过原生切换了账户
						if(result != null && result != ""){
							var naccount = appUtils.getSStorageInfo("naccount");
							var account = result[0].fund_account; // 临时资金账号 
							if(naccount != account){
								appUtils.setSStorageInfo("naccount", account);
								switchInfo_mall(account, token); // 调用切换资金账号接口，重置用户信息
							}
							appUtils.setSStorageInfo("fund_account",result[0].fund_account);
							appUtils.setSStorageInfo("client_no",result[0].client_no);
						}
						return true;
					}
					else{
						return func_login(token); // 模拟登陆
					}
				}
			}
			// 未登录状态，需清理session并且跳到登陆页面
			else{
				//appUtils.clearSStorage();  // 清空所有的session
				// 打开原生左抽屉登录页面
				var toPage = checkInParam.pageCode; // 登录完需要跳转的页面code
				if(gconfig.platform == "2"){
					toPage={"prefix":"www/m/mall","suffix":toPage,"param":JSON.stringify(checkInParam.param)};
				}else{
					toPage = "/mall/index.html#!/"+toPage+".html?param="+JSON.stringify(checkInParam.param);
				}
                var param_login = {"funcNo":"50101", "moduleName":"login", "params":{"moduleName":"financial-mall","toPage":toPage}};
                require("external").callMessage(param_login);
				return false;
			}
		}
		return true;
	}
	
	/* 调用切换资金账号接口，重置用户信息 */
	function switchInfo_mall(account,token){
		var loginPath = gconfig.global.switchPath+"&fund_account="+account;
		// 发送请求模拟登陆
		appUtils.invokeServer(loginPath, {}, function(data){
			var error_no = data.err_no;
			var error_info = data.err_info;
			var result = data.data;//验证码输入错误
			if(error_no == "0" && result.length != 0){
			    var param_data = {"funcNo":"50040","key":"mall_data","value":JSON.stringify(result)};
                require("external").callMessage(param_data); //把result存在原生壳子
                saveData_mall(result, token);  // 将数据保存到 session 中
			}else{
				layerUtils.iAlert(error_info);
			}
		},true,false,true);
	}
	
	/*保存商城统一登陆信息*/
	function saveData_mall(result,token){
		appUtils.setSStorageInfo("login_token",token);
		/*把用户编号存到session*/
		if(result.user_id){
			appUtils.setSStorageInfo("user_id",result.user_id);
		}
		/*把jsessionid存到session*/
		if(result.jsessionid){
			appUtils.setSStorageInfo("jsessionid",result.jsessionid);
		}
		/*把用户名存到session*/
		if(result.user_name){
			appUtils.setSStorageInfo("user_name",result.user_name);
		}
		/*把账户名存到session*/
		if(result.account_name){
			appUtils.setSStorageInfo("account_name",result.account_name);
		}
		/*把资金账号存到session*/
		if(result.fund_account){
			appUtils.setSStorageInfo("fund_account",result.fund_account);
		}
		/*把风险承受能力等级存到session*/
		if(result.risk_level){
			appUtils.setSStorageInfo("risk_level",result.risk_level);
		}
		/*把风险承受能力存到session*/
		if(result.risk_level_txt){
			appUtils.setSStorageInfo("risk_level_txt",result.risk_level_txt);
		}
		/*把手机号码存到session*/
		if(result.mobile_phone){
			appUtils.setSStorageInfo("mobile_phone",result.mobile_phone);
		}
		/*把邮箱地址存到session*/
		if(result.user_mail){
			appUtils.setSStorageInfo("user_mail",result.user_mail);
		}
		/*存user_code到session*/
		if(result.cust_code){
			appUtils.setSStorageInfo("cust_code",result.cust_code);
//			appUtils.setSStorageInfo("custCode",result.cust_code,true);
			var par_custCode = {"funcNo":"50040","key":"custCode","value":result.cust_code};
			require("external").callMessage(par_custCode); //把user_code存在原生壳子 
		}
		/*存fund_list到session*/
			appUtils.setSStorageInfo("fund_list",result.fund_list);
		/*存ticket到session*/
		if(result.ticket){
			appUtils.setSStorageInfo("ticket",result.ticket);
		}
		/*存cust_type到session*/
		if(result.cust_type){
			appUtils.setSStorageInfo("cust_type",result.cust_type);
			var par_custType = {"funcNo":"50040","key":"custType","value":result.cust_type};
			require("external").callMessage(par_custType); //把cust_type存在原生壳子 
		}
		/*存user_type到session*/
		if(result.user_type){
			appUtils.setSStorageInfo("user_type",result.user_type);
		}
	}
	
	/**
	 * 小贷统一登陆拦截器
	 */
	function checkPermission_xdt(checkInParam){
		console.log("@@@@@@页面校验"+JSON.stringify(checkInParam));
	    var func_login = function(token){
	    	var xdt_flag = true;
			var loginPath = gconfig.global.loginPath+"&token="+encodeURIComponent(token)+"&op_source=1";
			// 发送请求模拟登陆
			console.log("@@@@@@请求模拟登陆"+loginPath);
			appUtils.invokeServer(loginPath, {}, function(data){
				var error_no = data.err_no;
				var error_info = data.err_info;
				var result = data.data;//验证码输入错误
				console.log("@@@@@@"+JSON.stringify(data));
				if(error_no == "0" && result.length != 0){
				    var param_data = {"funcNo":"50040","key":"xdt_data","value":JSON.stringify(result)};
					require("external").callMessage(param_data); //把result存在原生壳子 
					var param_token = {"funcNo":"50040","key":"xdt_token","value":token};
					require("external").callMessage(param_token); //保存token值
					saveDataToSession(result, token);  // 将数据保存到 session 中
					//这里账号切换 重置资金账号
					var param_login = {"funcNo":"50041", "key":"switchAccountResults"};
					resultVo = require("external").callMessage(param_login);
					var result = resultVo.results[0].value;
					//如果从壳子里面获取的 资金账号不为空，那么说明客户通过原生切换了账户
					if(result != null && result != ""){
						switchInfo_xdt(result[0].fund_account,token); // 调用切换资金账号接口，重置用户信息
					}
					appUtils.setSStorageInfo("_isLoginIn","true");
					var param_lg = {"funcNo":"50040","key":"login_xdt","value":true};
                    require("external").callMessage(param_lg); //保存登录状态
                    appUtils.pageInit(checkInParam.prePageCode,checkInParam.pageCode,checkInParam.param);
				}
				else{
					appUtils.setSStorageInfo("_isLoginIn","true");
					appUtils.pageInit("","more/firstGuide");
					layerUtils.iMsg(-1,"无股东账户，不能开展富易贷业务!");
					xdt_flag = false;
				}
			},true,true);
//			if(xdt_flag){
//				return true;
//			}else{
//				return false;
//			}
			return false;
		};
		var active_code = ["more/firstGuide"];
		// 判断当前页面是否需要激活才能进入
		if(active_code.indexOf(checkInParam.pageCode) == -1){
			// 获取壳子里的全局登陆状态，1:已经登陆； 0:代表退出
			var param_login = {"funcNo":"50041", "key":"login_state"};
			resultVo = require("external").callMessage(param_login);
			var login_state = resultVo.results[0].value;
			// 已经统一登陆
			if(login_state == "1"){
                var param_lg= {"funcNo":"50041","key":"login_xdt"};
                var _isLoginIn =  require("external").callMessage(param_lg).results[0].value;
                if(!_isLoginIn){
                    _isLoginIn = appUtils.getSStorageInfo("_isLoginIn");
                }
				var param_xdt = {"funcNo":"50041", "key":"APP_XD"};
				resultVo = require("external").callMessage(param_xdt);
				var token = resultVo.results[0].value;
				var param_token = {"funcNo":"50041","key":"xdt_token"};
                resultVo =  require("external").callMessage(param_token);
                var session_token = resultVo.results[0].value;
                if(!session_token){
                    session_token = appUtils.getSStorageInfo("login_token") || "";
                }
				// 本地session为空，需要进行模拟登陆
				if(!_isLoginIn){
					return func_login(token); // 模拟登陆
				}
				else{
					// 比较本地token值与壳子token值是否相同
					if(token == session_token){
						//从原生壳子获取用户缓存
						var param_data = {"funcNo":"50041","key":"xdt_data"};
						resultVo =  require("external").callMessage(param_data);
						var res = resultVo.results[0].value;
						
						//ios 返回的是字符串  android 返回json
						if(res && typeof res === "string"){
							res = JSON.parse(res);
						}
						
						//将用户缓存存在session中
						saveDataToSession(res,session_token);
						//这里账号切换 重置资金账号
						var param_login = {"funcNo":"50041", "key":"switchAccountResults"};
						resultVo = require("external").callMessage(param_login);
						var result = resultVo.results[0].value;
						//如果从壳子里面获取的 资金账号不为空，那么说明客户通过原生切换了账户
						if(result != null && result != ""){
							var naccount = appUtils.getSStorageInfo("naccount");
							var account = result[0].fund_account; // 临时资金账号
							if(naccount != account){
								appUtils.setSStorageInfo("naccount", account);
								switchInfo_xdt(account, token); // 调用切换资金账号接口，重置用户信息
							}
						}
						return true;
					}
					else{
						return func_login(token); // 模拟登陆
					}
				}
			}
			// 未登录状态，需清理session并且跳到登陆页面
			else{
				//appUtils.clearSStorage();  // 清空所有的session
                var toPage = checkInParam.pageCode; // 登录完需要跳转的页面code
                if(gconfig.platform == "2"){
					toPage={"prefix":"www/m/xdt","suffix":toPage};
				}else{
					toPage = "/xdt/index.html#!/"+toPage+".html";
				}
                var param_login = {"funcNo":"50101", "moduleName":"login", "params":{"moduleName":"fund-loan","toPage":toPage}};
                require("external").callMessage(param_login);
                return false;
			}
		}
		return true;
	}


	/* 调用切换资金账号接口，重置用户信息 */
	function switchInfo_xdt(account,token){
		var loginPath = gconfig.global.switchPath+"&account="+encodeURIComponent(account)+"&op_source=1";
		// 发送请求模拟登陆
		appUtils.invokeServer(loginPath, {}, function(data){
			var error_no = data.err_no;
			var error_info = data.err_info;
			var result = data.data;//验证码输入错误
			if(error_no == "0" && result.length != 0){
			    var param_data = {"funcNo":"50040","key":"xdt_data","value":JSON.stringify(result)};
                require("external").callMessage(param_data); //把result存在原生壳子
				saveDataToSession(result, token);  // 将数据保存到 session 中
			}else{
				layerUtils.iAlert(error_info);
			}
		},true,false,true);
	}
	
	/*将数据保存到 session 中*/
	function saveDataToSession(loginResults,token){
		appUtils.setSStorageInfo("login_token",token);
		var userInfo = require("utils").getUserInfoInSession();  // 获取 session 中的用户信息
		userInfo = userInfo ? userInfo : {};  // 取到的 userInfo 为空，就创建一个新对象
		userInfo["accountNo"] = loginResults.fund_account;  // 账号
		userInfo["entrust_way"] = loginResults.entrust_way;  // 客户 id
		userInfo["op_station"] = loginResults.op_station;  // 操作站点
		userInfo["branch_no"]  = loginResults.branch_no;  // 分支机构
		userInfo["user_id"]    = loginResults.user_id;  // 客户名
		userInfo["cust_code"]  = loginResults.cust_code;  // 客户编号	
		userInfo["fund_account"] = loginResults.fund_account;  // 基金帐号
		userInfo["client_name"] = loginResults.client_name;  // 客户姓名
		userInfo["login_id"] = loginResults.login_id;  // 登录id
		userInfo["exchange_type_sz"] = loginResults.exchange_type_sz;  // 深圳交易类型
		userInfo["exchange_type_sh"] = loginResults.exchange_type_sh;  // 上海交易类型
		userInfo["stock_account_sz"] = loginResults.stock_account_sz;  // 深圳的帐号
		userInfo["stock_account_sh"] = loginResults.stock_account_sh;  // 上海的帐号
		userInfo["risk_level"] = loginResults.risk_level;  // 信用等级
		userInfo["identity_num"] = loginResults.identity_num;  // 身份证号码
		userInfo["mobile"] = loginResults.mobile;  // 手机号码
		userInfo["client_name"] = loginResults.client_name;  // 客户姓名
		userInfo["protocolStr"] = loginResults.protocolStr;  //需要签署的协议
		userInfo["signargument"] = loginResults.signargument;  //已签署的协议
		userInfo["zxscore"] = loginResults.zxscore;  //已签署的协议
		userInfo["szzzIsOpen"] = loginResults.szzzIsOpen;  //已签署的协议
		userInfo["shzzIsOpen"] = loginResults.shzzIsOpen;  //已签署的协议
		
//		appUtils.setSStorageInfo("custCode", loginResults.cust_code,true);
		var par_custCode = {"funcNo":"50040","key":"custCode","value":loginResults.cust_code};
		require("external").callMessage(par_custCode); //把user_code存在原生壳子 
		appUtils.setSStorageInfo("userInfo", JSON.stringify(userInfo));
		appUtils.setSStorageInfo("jsessionid", loginResults.jsessionid);  // jsessionid
		appUtils.setSStorageInfo("clientinfo", loginResults.clientinfo);  // clientinfo
		require("external").callMessage({"funcNo":"50040","key":"xdt_userInfo","value":JSON.stringify(userInfo)});
		require("external").callMessage({"funcNo":"50040","key":"xdt_jsessionid","value":loginResults.jsessionid});
		require("external").callMessage({"funcNo":"50040","key":"xdt_isLoginIn","value":"true"});
	}
	
	/**
	 * 港股通开户统一登陆拦截器
	 * */
	function checkPermission_ggt(checkInParam){
	    var func_login = function(token){
			var loginPath = gconfig.global.loginPath+"&token="+encodeURIComponent(token)+"&op_source=1";
			// 发送请求模拟登陆
			appUtils.invokeServer(loginPath, {}, function(data){
				var error_no = data.err_no;
				var error_info = data.err_info;
				var result = data.data;
				if(error_no == "0" && result.length != 0){
				    appUtils.setSStorageInfo("login_token",token);
					saveData(result);  // 将数据保存到 session 中
					//这里账号切换 重置资金账号
					var param_login = {"funcNo":"50041", "key":"switchAccountResults"};
					resultVo = require("external").callMessage(param_login);
					var result = resultVo.results[0].value;
					//如果从壳子里面获取的 资金账号不为空，那么说明客户通过原生切换了账户
					if(result != null && result != ""){
						switchInfo_ggt(result[0].func_account, result[0].branchno, token);
						appUtils.setSStorageInfo("shaaccount",result[0].fund_account);
						appUtils.setSStorageInfo("client_no",result[0].client_no);
					}
					appUtils.setSStorageInfo("_isLoginIn","true");
                    appUtils.pageInit(checkInParam.prePageCode,checkInParam.pageCode,checkInParam.param);
				}
				else{
					layerUtils.iAlert(error_info);
				}
			},true,true);
			return false;
		};
		// 获取壳子里的全局登陆状态，1:已经登陆； 0:代表退出
		var param_login = {"funcNo":"50041", "key":"login_state"};
		resultVo = require("external").callMessage(param_login);
		var login_state = resultVo.results[0].value;
		// 已经统一登陆
		if(login_state == "1"){
			var _isLoginIn = appUtils.getSStorageInfo("_isLoginIn");
			var param_ggt = {"funcNo":"50041", "key":"APP_GGT"};
			resultVo = require("external").callMessage(param_ggt);
			var token = resultVo.results[0].value;
			var session_token = appUtils.getSStorageInfo("login_token") || "";
			// 本地session为空，需要进行模拟登陆
			if(!_isLoginIn){
				return func_login(token); // 模拟登陆
			}
			else{
				// 比较本地token值与壳子token值是否相同
				if(token == session_token){
					//这里账号切换 重置资金账号
					var param_login = {"funcNo":"50041", "key":"switchAccountResults"};
					resultVo = require("external").callMessage(param_login);
					var result = resultVo.results[0].value;
					//如果从壳子里面获取的 资金账号不为空，那么说明客户通过原生切换了账户
					if(result != null && result != ""){
						var naccount = appUtils.getSStorageInfo("naccount");
						var account = result[0].fund_account; // 临时资金账号
						var branch_no = result[0].branchno; // 营业部编号
						if(naccount != account){
							appUtils.setSStorageInfo("naccount", account);
							switchInfo_ggt(account, branch_no, token); // 调用切换资金账号接口，重置用户信息
						}
//						appUtils.setSStorageInfo("shaaccount",result[0].fund_account);
						appUtils.setSStorageInfo("client_no",result[0].client_no);
					}
					return true;
				}
				else{
					return func_login(token); // 模拟登陆
				}
			}
		}
		// 未登录状态，需清理session并且跳到登陆页面
		else{
			//appUtils.clearSStorage();  // 清空所有的session
			var toPage = checkInParam.pageCode; // 登录完需要跳转的页面code
			if(gconfig.platform == "2"){
				toPage={"prefix":"www/m/ggt","suffix":toPage};
			}else{
				toPage = "/ggt/index.html#!/"+toPage+".html";
			}
            var param_login = {"funcNo":"50101", "moduleName":"login" ,"params":{"moduleName":"ggt","toPage":toPage}};
            require("external").callMessage(param_login);
            return false;
		}
		return true;
	}
	
	/* 调用切换资金账号接口，重置用户信息 */
	function switchInfo_ggt(account, branch_no, token){
		// 发送请求模拟登陆
		var loginPath = gconfig.global.switchPath+"&fundacc="+account+"&branch="+branch_no;
		appUtils.invokeServer(loginPath, {}, function(data){
			var error_no = data.err_no;
			var error_info = data.err_info;
			var result = data.data;//验证码输入错误
			if(error_no == "0" && result.length != 0){
                saveData(result);  // 将数据保存到 session 中
			}else{
				layerUtils.iAlert(error_info);
			}
		},true,false,true);
	}

	/**
	 * 港股通模拟登陆成功后保存数据（session）
	 * */
	function saveData(result){
		// 黑名单标志
		appUtils.setSStorageInfo("in_blacklist",result.in_blacklist);
		//沪A账户是否指定交易
		appUtils.setSStorageInfo("is_regTrade",result.is_regTrade);
		//是否需要跑批
		appUtils.setSStorageInfo("is_autoTask",result.is_autoTask);
		//开通港股通备注
		appUtils.setSStorageInfo("ggtopen_remark",result.ggtopen_remark);
		//当前步骤
		appUtils.setSStorageInfo("current_step",result.current_step);
		//证件类型
		appUtils.setSStorageInfo("idtype",result.idtype);
		//证件有效截止日期
		appUtils.setSStorageInfo("idenddate",result.idenddate);
		//证件有效开始日期
		appUtils.setSStorageInfo("idbegindate",result.idbegindate);
		//沪A账号是否加挂
		appUtils.setSStorageInfo("isadd",result.isadd);
		//港股通开立标志
		appUtils.setSStorageInfo("ggtopen_flag",result.ggtopen_flag);
		//风险测评分数
		appUtils.setSStorageInfo("survey_score",result.survey_score);
		//风险测评是否有效
		appUtils.setSStorageInfo("risk_survey_valid",result.risk_survey_valid);
		//风险测评等级
		appUtils.setSStorageInfo("rating_lvl",result.rating_lvl);
		//知识测评分数
		appUtils.setSStorageInfo("knowledge_score",result.knowledge_score);
		//营业部编号
		appUtils.setSStorageInfo("branchno",result.branchno);
		//用户编号
		appUtils.setSStorageInfo("user_id",result.user_id);
		//风险测评等级名称
		appUtils.setSStorageInfo("rating_lvl_name",result.rating_lvl_name);
		//客户姓名
		appUtils.setSStorageInfo("custname",result.custname);
		//沪A账号
		appUtils.setSStorageInfo("shaaccount",result.shaaccount);
		//证券账户资产总值
		appUtils.setSStorageInfo("marketvalue",result.marketvalue);
		//电话号码
		appUtils.setSStorageInfo("mobileno",result.mobileno);
		//客户类型
		appUtils.setSStorageInfo("cust_type",result.cust_type);
		//信用证券账户总资产
		appUtils.setSStorageInfo("net_asset",result.net_asset);
		//联系地址
		appUtils.setSStorageInfo("address",result.address);
		//身份证是否在有效期内
		appUtils.setSStorageInfo("idenddate_valid",result.idenddate_valid);
		//身份证号
		appUtils.setSStorageInfo("idno",result.idno);
	}
	
	/**
	 * 交易模块拦截器
	 */
	function checkPermission_trade(checkInParam){
		return true;
		var func_login = function(token){ 
	        var flag = true;
			var loginPath = gconfig.global.loginPath+"&token="+encodeURIComponent(token); // 交易统一登录链接
			// 发送请求模拟登陆
			appUtils.invokeServer(loginPath, {}, function(data){
				var error_no = data.data.err_no;
				var error_info = data.data.err_info;
				var result = data.data.data;
				if(error_no == "0" && result.length != 0){
					var param_data = {"funcNo":"50040","key":"trade_data","value":JSON.stringify(result)};
					require("external").callMessage(param_data); //把result存在原生壳子
					var param_token = {"funcNo":"50040","key":"trade_token","value":token};
					require("external").callMessage(param_token); //保存token值
					// 保存模拟登陆返回信息至缓存
					appUtils.setSStorageInfo("stock_userInfo",JSON.stringify(data.data.data));
					appUtils.setSStorageInfo("jsessionid",data.data.data.jsessionid);
					appUtils.setSStorageInfo("login_token",token);
					//这里账号切换 重置资金账号
					var param_login = {"funcNo":"50041", "key":"switchAccountResults"};
					resultVo = require("external").callMessage(param_login);
					var result = resultVo.results[0].value;
					//如果从壳子里面获取的 资金账号不为空，那么说明客户通过原生切换了账户
					if(result != null && result != ""){
						switchInfo_mall(result[0].fund_account,token); // 调用切换资金账号接口，重置用户信息
						appUtils.setSStorageInfo("fund_account",result[0].fund_account);
					}
					appUtils.setSStorageInfo("_isLoginIn","true");
					var param_lg = {"funcNo":"50040","key":"login_trade","value":true};
                    require("external").callMessage(param_lg); //保存登录状态
					var _loginInPageCode = appUtils.getSStorageInfo("_loginInPageCode");
					if(_loginInPageCode){
					    if(_loginInPageCode != checkInParam.pageCode){
					        appUtils.pageInit("account/loginIn", _loginInPageCode, JSON.parse(appUtils.getSStorageInfo("_loginInPageParam")));
    						appUtils.clearSStorage("_loginInPageCode");
    						appUtils.clearSStorage("_loginInPageParam");
    						flag = false;
					    }
					}
				}
				else{
					layerUtils.iAlert(error_info);
				}
			},true,false);
			return flag;
		};
		// 获取壳子里的全局登陆状态，1:已经登陆； 0:代表退出
		var param_login = {"funcNo":"50041", "key":"login_state"};
		resultVo = require("external").callMessage(param_login);
		var login_state = resultVo.results[0].value;
		// 已经统一登陆
		if(login_state == "1"){
		    var param_lg= {"funcNo":"50041","key":"login_trade"};
            var _isLoginIn =  require("external").callMessage(param_lg).results[0].value;
            if(!_isLoginIn){
			    _isLoginIn = appUtils.getSStorageInfo("_isLoginIn");
            }
			var param_mall = {"funcNo":"50041", "key":"APP_TRADE"};
			resultVo = require("external").callMessage(param_mall);
			var token = resultVo.results[0].value;
			var param_token = {"funcNo":"50041","key":"trade_token"};
			resultVo =  require("external").callMessage(param_token);
			var session_token = resultVo.results[0].value;
			if(!session_token){
				session_token = appUtils.getSStorageInfo("login_token") || "";
			}
			// 本地session为空，需要进行模拟登陆
			if(!_isLoginIn){
				return func_login(token); // 模拟登陆
			}
			else{
				// 比较本地token值与壳子token值是否相同
				if(token == session_token){
					//从原生壳子获取用户缓存
					var param_data = {"funcNo":"50041","key":"trade_data"};
					resultVo =  require("external").callMessage(param_data);
					var info_result = resultVo.results[0].value;
					// 保存模拟登陆返回信息至缓存
					appUtils.setSStorageInfo("stock_userInfo",JSON.stringify(info_result)); 
					appUtils.setSStorageInfo("login_token",session_token);
					//这里账号切换 重置资金账号
					var param_login = {"funcNo":"50041", "key":"switchAccountResults"};
					resultVo = require("external").callMessage(param_login);
					var result = resultVo.results[0].value;
					//如果从壳子里面获取的 资金账号不为空，那么说明客户通过原生切换了账户
					if(result != null && result != ""){
						var naccount = appUtils.getSStorageInfo("naccount");
						var account = result[0].fund_account; // 临时资金账号 
						if(naccount != account){
							appUtils.setSStorageInfo("naccount", account);
							info_result.fund_account = account;
							info_result.cust_code = account;
							// 保存userInfo里的资金账号
							appUtils.setSStorageInfo("stock_userInfo",JSON.stringify(info_result)); 
						}
						appUtils.setSStorageInfo("fund_account",result[0].fund_account);
						appUtils.setSStorageInfo("client_no",result[0].client_no);
					}
					return true;
				}
				else{
					return func_login(token); // 模拟登陆
				}
			}
		}
		else if(login_state == "2"){ //直接跳到登录页面
			return true;
		}else{ 		// 未登录状态，需清理session并且跳到登陆页面
			//appUtils.clearSStorage();  // 清空所有的session
			// 打开原生左抽屉登录页面
			var toPage = checkInParam.pageCode; // 登录完需要跳转的页面code
			if(gconfig.platform == "2"){
				toPage={"prefix":"www/m/trade","suffix":toPage};
			}else{
				toPage = "/trade/index.html#!/"+toPage+".html";
			}
            var param_login = {"funcNo":"50101", "moduleName":"login", "params":{"moduleName":"trade","toPage":toPage}};
            require("external").callMessage(param_login);
			return false;
		}
		return true;
	}
	
	
	
	
	/**
	 * 校验是否需要登录，并调到登录页面，且登录后调到目标页面
	 * 目标页面和目标页面入参分别从sessionstorage中取_loginInPageCode和_loginInPageParam
	 * 项目中另外需要处理的代码：
	 * 1、在gconfig的global中增加一个配置项checkLoginPageCode，表示那些页面需要校验的页面pageCode
	 * 2、需要在configuration配置 "loginPage": {"pageCode": "person/userLogin", "jsonParam":{}}, //登录页面
	 * 3、登录后设置setSStorageInfo("_isLoginIn","true")，退出时需要clearSStorage("_loginInPageCode")、clearSStorage("_loginInPageParam")
	 */
	function checkLogin(prePageCode, pageCode, param, isLastReq, isShowWait, isShowOverLay){
		//这里就不能用data-siCheckLogin="true"来决定页面是否校验了，而是在global里面增加一个数组来判断，如下：
		gconfig.global.checkLoginPageCode = ["person/serviceTreams"];  //这里演示写死代码，项目中根据需要配置
		var checkLoginPage = gconfig.global.checkLoginPageCode;
		if(checkLoginPage.indexOf(pageCode)>-1) {
			if(appUtils.getSStorageInfo("_isLoginIn")=="true") {
				return true;
			} else {
				var loginPage = gconfig.loginPage;
				if(loginPage && loginPage.pageCode) {
					appUtils.setSStorageInfo("_loginInPageCode", pageCode);
					appUtils.setSStorageInfo("_loginInPageParam", param?JSON.stringify(param):"");
					appUtils.pageInit(prePageCode, loginPage.pageCode, loginPage.jsonParam, isLastReq, isShowWait, isShowOverLay);
					setTimeout(function() {
						layerUtils.iMsg(-1, "请先登录！");
					}, 400);
				} else {
					layerUtils.iAlert("你未登录，且登录页面配置错误！");
				}
				return false;
			}
		} else {
			return true;
		}
	}
	
	var putils = {
		"firstLoadFunc": firstLoadFunc,
		"filterLoginOut": filterLoginOut,
		"checkPermission_fz": checkPermission_fz,
		"checkPermission_mall": checkPermission_mall,
		"checkPermission_xdt": checkPermission_xdt,
		"checkPermission_ggt": checkPermission_ggt,
		"checkPermission_trade": checkPermission_trade
	};
	//暴露对外的接口
	module.exports = putils;
});

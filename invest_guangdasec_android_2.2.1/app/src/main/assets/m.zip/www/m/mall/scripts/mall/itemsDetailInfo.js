/**
 * 资讯详情
 */
define(function(require, exports, module)
	{	
	var service = require("mobileService"); //业务层接口，请求数据
	var appUtils = require('appUtils'),
	putils = require("putils"),
	layerUtils = require("layerUtils"),
	gconfig = require("gconfig"),
	global = gconfig.global;
	var save_value= null;
	var _pageId ="#mall_itemsDetailInfo";
	 
	//1、初始化
	function init() 
	{
		var product_id=appUtils.getPageParam().product_id;
		//防止直接跳到详情页面
		if(product_id==null)
		{
			layerUtils.iMsg(1, "数据加载错误！");
			appUtils.pageInit("mall/itemsFinanInfo","account/mainPage",{});
			return false;
		}
	 
	}


	//添加关注
	function addattention()
	{
		var user_id = appUtils.getSStorageInfo("user_id");//从seesion获得用户编号
		var product_id= save_value.product_id; //获得产品编号
		var product_sub_type = save_value.product_sub_type;//获得产品类别

		var param ={
			"user_id":user_id,
			"product_id":product_id,
			"product_sub_type":product_sub_type
		};
		service.addAttention(param,function(data)
		{
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				return false;
			}
			else
			{
				layerUtils.iMsg(-1,"关注成功！");
			}
		});
	}

	//2、事件绑定
	function bindPageEvent()
	{
		//立即购买
		appUtils.bindEvent($(_pageId+" .icon_buy"),function() {finanbuy(); });

		//增加购买金额
		appUtils.bindEvent($(_pageId+" .icon_add"),function(){addAndMin("add");});

		//减少购买金额
		appUtils.bindEvent($(_pageId+" .icon_less"),function()	{addAndMin("min");	});

		// 点击返回
		appUtils.bindEvent($(_pageId+"  .icon_back"),function(){appUtils.pageBack();});

		//点击 返回顶部
		appUtils.bindEvent($(_pageId+" .back_btn"),function(){$('body,html').animate({crollTop:0},1000);return false;});

		// 点击首页
		appUtils.bindEvent($(_pageId+" #mainPage"),function(){	appUtils.pageInit("mall/itemsFinanInfo","account/mainPage",{});});

		// 点击理财 
		appUtils.bindEvent($(_pageId+" #finan"),function(){	appUtils.pageInit("mall/itemsFinanInfo","mall/itemsFinan",{});});

		// 点击基金
		appUtils.bindEvent($(_pageId+" #fund"),function(){	appUtils.pageInit("mall/itemsFinanInfo","mall/itemsFund",{});});

		//点击 LOGO 
		appUtils.bindEvent($(_pageId+" .logo"),function(){appUtils.pageInit("mall/itemsFundInfo","account/mainPage",{});});

		// 点击 关注 
		appUtils.bindEvent($(_pageId+" .icon_fav"),function(){addattention();});

		//判断输入是否合法
		appUtils.bindEvent($(_pageId+" #buyValue"),function(){putils.numberLimit($(this));},"keyup");

		//控制输入不能为空
		appUtils.bindEvent($(_pageId+" #buyValue"),function(){
			if($(this).val()==null||$(this).val()==""){
				$(this).val(0);
			}
			$(this).val(putils.moneyFormat($(this).val()));

		},"blur");

		// 点击 登录
		appUtils.bindEvent($(_pageId+" .icon_info"),function(){
			appUtils.pageInit("mall/itemsFinanInfo","account/userCenter",{});
		});

	}

	//3、销毁
	function destroy()
	{

	}

	var itemsFinanInfo =
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = itemsFinanInfo;

	});
/**
 * 外链页面
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils");
	var layerUtils = require("layerUtils");
	var gconfig = require("gconfig");
    var global = gconfig.global;
    var common = require("common");
    var service_news = require("service_news");
	var _pageId = "#home_outLink ";
	
    /**
     * 初始化
     */
	function init(){
		if(gconfig.platform == "0"){
			$(_pageId + ".main").height($(window).outerHeight(true) - $(_pageId + ".header").outerHeight(true) - $(_pageId + ".footer_inner").outerHeight(true));
			$(_pageId + ".main").css("overflow-y","auto");
		}else{
			if(gconfig.platform == "2"){
				if(appUtils.getLStorageInfo("h")){
					$(_pageId + ".main").height(appUtils.getLStorageInfo("h"));
				}else{
					var h = $(window).outerHeight(true) - $(_pageId + ".header").outerHeight(true) - $(_pageId + ".footer_inner").outerHeight(true);
					appUtils.setLStorageInfo("h",h);
					$(_pageId + ".main").height(h);
				}
			}else if(gconfig.platform == "1"){
				if(appUtils.getLStorageInfo("h")){
					$(_pageId + ".main").height(appUtils.getLStorageInfo("h"));
				}else{
					var h = $(window).outerHeight(true) - $(_pageId + ".header").outerHeight(true) - $(_pageId + ".footer_inner").outerHeight(true);
					appUtils.setLStorageInfo("h",h);
					$(_pageId + ".main").height(h);
				}
			}
			$(_pageId + ".main").css("overflow-y","auto");
		}
		//获取首页传过来的tabId
		var tabId = appUtils.getPageParam("tabId");
		if(tabId == 1){
			$(_pageId+"#module ul li").eq(1).addClass("current").siblings().removeClass("current");
			$(_pageId+" .main iframe").attr("src",global.importantNews);
		}else if(tabId == 2){
			$(_pageId+"#module ul li").eq(2).addClass("current").siblings().removeClass("current");
			$(_pageId+" .main iframe").attr("src",global.liveBroadcast);
		}else if(tabId == 3){
			$(_pageId+"#module ul li").eq(3).addClass("current").siblings().removeClass("current");
			$(_pageId+" .main iframe").attr("src",global.chance);
		}
	}
	
	/**
	 * 事件绑定
	 */
	function bindPageEvent(){
		//要闻、直播、机会、内参模块间的切换
		appUtils.bindEvent($(_pageId+"#module ul li"), function(e){
			$(this).addClass("current").siblings().removeClass("current");
			if($(this).index() == 0){
				appUtils.pageInit("home/outLink","home/newsHome",{});
			}else{
				if($(this).index() == 1){
					$(_pageId+" .main iframe").attr("src",global.importantNews);
				}else if($(this).index() == 2){
					$(_pageId+" .main iframe").attr("src",global.liveBroadcast);
				}else if($(this).index() == 3){
					$(_pageId+" .main iframe").attr("src",global.chance);
				}
			}
			e.stopPropagation();
		},"click");
	}
	
	/**
	 * 销毁
	 */
	function destroy(){
	}
	var base = {
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};
	module.exports = base;
});
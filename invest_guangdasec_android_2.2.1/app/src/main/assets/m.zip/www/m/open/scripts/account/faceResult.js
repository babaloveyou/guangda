/**
 * 人脸识别结果
*/
define(function(require,exports,module){
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
		service = require("serviceImp").getInstance(),  //业务层接口，请求数据
		global = require("gconfig").global,
		layerUtils = require("layerUtils"),
		validatorUtil = require("validatorUtil"),
		_pageId = "#account_faceResult";
	var external = require("external");
	var platform = require("gconfig").platform;
	/* 私有业务模块的全局变量 end */	

	function init() {
		//window.videoOfflineSuccess = videoOfflineSuccess;
		/*console.log("222"+appUtils.getSStorageInfo("base64Str"));
		var base64Str = appUtils.getSStorageInfo("base64Str");
		$(_pageId+" .pic").append("<img src=\""+base64Str+"\"/>");*/
	}

	function bindPageEvent() {

		/* 绑定返回 */
		appUtils.bindEvent($(_pageId+" .header .icon_back"),function(){
			appUtils.clearSStorage("base64Str");
			appUtils.clearSStorage("pass_flag");
			appUtils.clearSStorage("similarity");
			appUtils.clearSStorage("pass_similarity");
			appUtils.pageInit("account/faceResult","account/takePhoto",{});
		});

		appUtils.bindEvent($(_pageId+" .ct_btn a"),function(){
			// 相机上传的参数
			var param = {
				"userId" : appUtils.getSStorageInfo("user_id"),
				"userName" : appUtils.getSStorageInfo("custname"),
				"jsessionId":appUtils.getSStorageInfo("jsessionid"),
				"shortestTime":"5",  //录制最短时间  单位秒
                "longestTime":"20",  //录制最长时间  单位秒
                "autenticationType":"1",
                "url":global.serverPath,
                "funcNo":"60006"
			};
			//require("shellPlugin").callShellMethod("videoWitnessOffLinePlugin",null,null,param);
			external.callMessage(param);
		});
	}

	function videoOfflineSuccess(data) {
		var video_length = data.mTimeCount;
		var start_time = data.start_time;
		if(appUtils.getSStorageInfo("flag") == "1"){   //1:需要证书   0:不需要证书
			layerUtils.iAlert("视频上传成功，请点击确定进行下一步...", 0 ,function(){
				appUtils.pageInit("account/liveVerify","account/digitalCertificate",{});
			}, "确认");
		}else{
			appUtils.pageInit("account/videoNotice","account/signProtocol",{});
		}
		
	}
	
	function destroy() {
		service.destroy();
	}
	
	var faceResult = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy,
		"videoOfflineSuccess" : videoOfflineSuccess
	};
	
	//暴露接口
	module.exports = faceResult;
});

/**
 * 理财--签署协议
 */
define( function(require, exports, module)
	{	
	var service = require("mobileService"); //业务层接口，请求数据
	var appUtils = require('appUtils'),
	putils = require("putils"),
	layerUtils = require("layerUtils"),
	constants=require("constants");//常量类
	gconfig = require("gconfig"),
	global = gconfig.global;
	var _pageId ="#mall_signProtocol";

	//1、初始化
	function init() 
	{	
		var pageInParam=appUtils.getPageParam();
		var _agreement_title=pageInParam._agreement_title; //协议标题
		var _agreement_id=pageInParam._agreement_id;       //协议编号

		var results=pageInParam.results;

		for (var i  =0; i < results.length; i++)
		{
			if(results[i].agreement_id==_agreement_id)
			{
				$(_pageId+" .agreem_title").html(results[i].agreement_title); //展示协议标题
				$(_pageId+" .agreem_text").html(results[i].agreement_content);//展示协议内容
			}

		} 
	}
	//签署协议
	function showContract()
	{
		var pageInParam  = appUtils.getPageParam();
		var user_id = appUtils.getSStorageInfo("user_id");
		var product_id=pageInParam.product_id;
		var _agreement_id=pageInParam._agreement_id;
		var flag=pageInParam.flag;
 		 var param=
			{
				"user_id":user_id,
				"product_id":product_id,
				"agreement_id":_agreement_id
			}
			service.signAgreement(param,function(data){

				if(data.error_no!= "0") 
				{
					layerUtils.iAlert(data.error_info);
					layerUtils.iLoading(false);
					layerUtils.iMsg(0,"签署失败，请重新签署或联系客户，失败原因："+results[0].getErrorInfo());
					return false;
				}
				if(data.error_info!="调用成功")
				{
					return false;
				}
				$("#mall_finanOrder_confirmOrder #tjdd").show();
				layerUtils.iMsg(0,"签署成功！");
				//签署成功，跳转
 				$("#mall_finanOrder_confirmOrder #signProtocol").attr("checked", "checked") ;
				//签署完成，返回到上一个页面
				appUtils.pageBack();

			})
 
	}
	//2、事件绑定
	function bindPageEvent()
	{	
		//点击签署协议
		appUtils.bindEvent($(_pageId+" .login_btn_ok"),function(){
			//签署协议
			showContract();

		});
		
		//点击返回
		appUtils.bindEvent($(_pageId+" .login_btn_ok1"),function(){
			var pageInParam  = appUtils.getPageParam();
			var product_id=pageInParam.product_id;
			var param={
					"product_id":product_id
			};
			appUtils.pageInit("mall/signProtocol","mall/itemsFinanInfo",param);
//			appUtils.pageBack();
		});

		//点击 返回顶部
		appUtils.bindEvent($(_pageId+" .back_btn"),function(){$('body,html').animate({scrollTop:0},1000);return false;});

	}

	//3、销毁
	function destroy()
	{
	}

	var signProtocol =
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = signProtocol;

	});
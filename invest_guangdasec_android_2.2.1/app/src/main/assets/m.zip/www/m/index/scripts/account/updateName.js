/*
 * 修改登录名
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	_pageId = "#account_updateName ";
	var cust_dname = "";//登录名
	
	/*
	 * 页面初始化
	 */
	function init(){
		cust_dname = appUtils.getPageParam("cust_dname");
		$(_pageId+" #oldLoginName").val(cust_dname);
	}
	
	/*
	 * 绑定页面事件
	 */
	function bindPageEvent(){
		//返回
		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(){
			appUtils.pageBack();
		});
		
		//确认 激活
		appUtils.bindEvent($(_pageId+" .ce_btn>a"),function(){
			var oldLoginName = $.trim($(_pageId+" #oldLoginName").val());
			var newName = $.trim($(_pageId+" #newName").val());
			if(oldLoginName == newName){
				layerUtils.iMsg("-1","原登录名不能与新登录名相同");
				return false;
			}
			else{
				if(isInputLegal(oldLoginName,newName)){
					var result = JSON.parse(appUtils.getSStorageInfo("userinfo"));
					var param = {
							"cust_code":result.user_code,
							"cust_dname":newName,
							"ticket":result.ticket
					};
					service.updateLoginName(param,function(data){
						var  errorNo = data.error_no;
						var errorInfo = data.error_info;
						if(errorNo === "0"){
							var result = data.results[0];
							layerUtils.iMsg(1,"修改成功！",1);
							setTimeout(function(){
								appUtils.pageInit("account/updateName","account/userCenter",{"newName":newName});
							},1000);
						}else{
							layerUtils.iAlert(errorInfo);
						}
					});
				}
			}
		});
	}
	
	/*
	 * 销毁页面
	 */
	function destroy(){
		$(_pageId+" #oldLoginName").val("");
		$(_pageId+" #newName").val("");
	}
	
	/*
	 * 判断输入的数据是否合法
	 */
	function isInputLegal(oldLoginName,newName){
		var check = false;
		if(!newName){
			layerUtils.iMsg(-1,"新登录名不能为空！",1);
			check = false;
		}else if(cust_dname){
			if(oldLoginName === cust_dname){
				check = true;
			}else{
				layerUtils.iMsg(-1,"原登录名输入错误！",1);
				check = false;
			}
		}else{
			check = true;
		}
		return check;
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy
	};
	//暴露方法
	module.exports = base;
});
/*
 * 快速取现
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	_pageId = "#xjb_navigation_fastCash ";
	var max="";//最大可取金额
	var trade_pwd ;
	var _flag = true;
	/*
	 * 页面初始化
	 */
	function init(){
		//设置页面高度
		$(_pageId + " .main").height($(window).height() - $(_pageId + " .header").height());
		$(_pageId + " .main").css("overflow-y","auto");
//		$(_pageId + " .main .definbtn_01").css("background","#1199EE");
		_flag = true;
		$(_pageId + " .main input").val(""); 
		$(_pageId+" .main .select .col_02 span").html("银行卡");
		$(_pageId+" .main .pass").show();
		showMax();
	}
	//密码加密
	function pswEncryption(pass){
		var callBack = function(data){//加密(1000000)
			if(data.error_no == 0){
				var results = data.results[0];
				var modulus = results.modulus;
				var publicExponent = results.publicExponent;
				var endecryptUtils = require("endecryptUtils");
				 trade_pwd = endecryptUtils.rsaEncrypt(modulus,publicExponent,pass);
//				
			}else{
				layerUtils.iAlert(data.error_info);
			}
		};
		var param={};
		service.getRSAKey(param,callBack,{"isLastReq":false,isAsync:false});//2002016
	}
	
	
	//最大可取金额
	function showMax(){
		var callBack = function(data){//2002016
			if(data.error_no == 0){
				var result=data.results[0];
				if(result!=null){
					max=result.maximum_amount.trim();
					max=parseFloat(max).toFixed(2);
					$(_pageId+" .main .cash input").attr("placeholder","最大取现金额:"+max+"元");
				}
			}else{
				layerUtils.iAlert(data.error_info,0,function(){
					appUtils.pageInit("xjb/navigation/fastCash","xjb/navigation/index",{});
				});
			}
		};
		var param = {
				"branch_no":appUtils.getSStorageInfo("branch_no"),
				"pro_code":appUtils.getSStorageInfo("pro_code"),
				"account":appUtils.getSStorageInfo("fund_account"),
				"account_type":appUtils.getSStorageInfo("whichAccount"),
				"entrust_way":"SJWT"
			};
		service.queryMaxCash(param,callBack);//2002016
	}
	
	function execute(){//点击执行取现操作
		var money=$(_pageId+" .main .row_01 .col_04").val();
		// if(money==null||money==""){//金额非空校验
			// layerUtils.iAlert("取现金额不能为空");
			// $(_pageId + " .main .definbtn_01").css("background","#1199EE");
			// $(_pageId + " .main .definbtn_01").addClass("isBlue");
			// return;
		// }
		if($(_pageId+" .main .select .col_02 span").html()== "银行卡"){//取款到银行卡
			var pwd=$(_pageId+" .main .fastcash .pass .hide").val().trim();
			// if(!pwd){
				// layerUtils.iAlert("银行卡密码不能为空");
				// $(_pageId + " .main .definbtn_01").css("background","#1199EE");
				// $(_pageId + " .main .definbtn_01").addClass("isBlue");
				// return;
			// }
			if(pwd.length != 6){
				layerUtils.iAlert("请输入6位资金密码！");
				_flag = true;
				$(_pageId + " .main .definbtn_01").css("background","#1199EE");
				$(_pageId + " .main .definbtn_01").addClass("isBlue");
				return;
			}
			pswEncryption(pwd);
			var par = {
					"branch_no":appUtils.getSStorageInfo("branch_no"),
					"pro_code":appUtils.getSStorageInfo("pro_code"),
					"fund_account":appUtils.getSStorageInfo("fund_account"),
					"account_type":appUtils.getSStorageInfo("whichAccount"),
					"entrust_way":"SJWT"
				};
			service.getCardInfo(par,function(data){//查询银行卡信息作为入参
				if(data.error_no == 0){
					zqSaveCash(function(){//先取现到证券账户
						var result = data.results;
						if(result.length>0){
							var param = {
									"fund_pwd":trade_pwd,
									"fund_amount":money,
									"fund_account":appUtils.getSStorageInfo("fund_account"),
									"bank_no":result[0].bank_no,
									"trans_type":"2",
									"bank_card_no":result[0].bank_card_no,
									"entrust_way":"SJWT"
								};
							if(result[0].flag == "false"){//不支持的三方存管银行
								_flag = true;
								layerUtils.iLoading(false);
								layerUtils.iAlert("您的三方存管银行不支持T+0快速取现。");
								return;
							}
							for(var s in result[0]){
								param[s]=result[0][s];//查询出的银行卡的信息作为参数
							}
							//最后取现到银行卡
							service.saveCash(param,function(data){//1001107
								if(data.error_no == 0){
									var result = data.results;
									if(result.length>0 && result[0].apply_no != ""){
											//取现成功
	//										showMax();
											layerUtils.iLoading(false);
											layerUtils.iAlert("您的申请已提交，编号为:"+result[0].apply_no+"。");
									}
								}else{
	//									$('#trade_pwd1').hide();
									layerUtils.iLoading(false);
									layerUtils.iAlert('快速取现成功但转账到银行卡失败，请重新进行银证转账:'+data.error_info.trim());
								}
								_flag = true
								$(_pageId + " .main .definbtn_01").css("background","#1199EE");
								$(_pageId + " .main .definbtn_01").addClass("isBlue");
							});
						}else{
								_flag = true;
								layerUtils.iLoading(false);	
								layerUtils.iAlert("未查询到银行卡信息");
								$(_pageId + " .main .definbtn_01").css("background","#1199EE");
								$(_pageId + " .main .definbtn_01").addClass("isBlue");
						}
					});
				}else{
					_flag = true;
					layerUtils.iLoading(false);
					layerUtils.iAlert(data.error_info);
					$(_pageId + " .main .definbtn_01").css("background","#1199EE");
					$(_pageId + " .main .definbtn_01").addClass("isBlue");
				}
			},{isLastReq:false,isShowWait:true});
		}
		if($(_pageId+" .main .select .col_02 span").html()== "证券账户"){//取款到证券账户
			zqSaveCash(function(){
				_flag = true;
				layerUtils.iLoading(false);
				layerUtils.iAlert("取现成功");
				$(_pageId + " .main .definbtn_01").css("background","#1199EE");
				$(_pageId + " .main .definbtn_01").addClass("isBlue");
			});
		}
	}
	
	
	//T+0 取现到证券账户2002018
	function zqSaveCash(callBackDo){
		var money=$(_pageId+" .main .row_01 .col_04").val();
		var callBack = function(data){//2002018
			if(data.error_no == 0){
				var result=data.results[0];
				if(result.err_state=='Y'){
					callBackDo();
//					layerUtils.iAlert("取现成功");
				}else{
					_flag = true;
					layerUtils.iLoading(false);
					$(_pageId + " .main .definbtn_01").css("background","#1199EE");
					$(_pageId + " .main .definbtn_01").addClass("isBlue");
				}
			}else{
				_flag = true;
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
				$(_pageId + " .main .definbtn_01").css("background","#1199EE");
				$(_pageId + " .main .definbtn_01").addClass("isBlue");
			}
		};
		var param = {
				"branch_no":appUtils.getSStorageInfo("branch_no"),
				"account":appUtils.getSStorageInfo("fund_account"),
				"cash_amount":$(_pageId+" .main .row_01 .col_04").val(),
				"entrust_way":"SJWT"
			};
		service.getCash(param,callBack,{isLastReq:false,isShowWait:true});//2002018
	}
	
	function clickable(){
		var click_flag=false;
		//判断是取现类型
		if($(_pageId+" .main .select .col_02 span").html()== "银行卡"){//取款到银行卡
			if($(_pageId+" .main .row_01 .col_04").val()!="" && ($(_pageId+" .main .fastcash .pass .hide").val().trim()!="" || $(_pageId+" .main .fastcash .pass .show").val().trim()!="" )){
				click_flag = true;
			}
		}else{//取消到证券账户
			if($(_pageId+" .main .row_01 .col_04").val()!=""){
				click_flag = true;
			}
		}
		if(click_flag){
			$(_pageId + " .main .definbtn_01").css("background","#1199EE");
			$(_pageId + " .main .definbtn_01").addClass("isBlue");
		}else{
			$(_pageId + " .main .definbtn_01").css("background","#bebebe");
			$(_pageId + " .main .definbtn_01").removeClass("isBlue");
		}
	}
	
	/*
	 * 绑定页面事件
	 */
	function bindPageEvent(){
		//监听金额input输入框
		appUtils.bindEvent($(_pageId+" .main .cash input"),function(){
			var value = $(this).val();
			value=value.replace(/[^\d\.]/g,'');
			$(this).val(value);
			var ch = value.substr(value.length - 1,1); //当前输入的字符
			var pattern = /[0-9]+/;
			var reg = /\d+(\.\d{1,2})?/;
			var flag = false;   //当前字符是否合法
			if(value.length == 1){  //是否是第一个字符
				flag = pattern.test(ch);
			}else{
				if(value.substr(0,1) == 0 && value.length == 2){//检测第一个字符为0时,第二个是否是小数点
					flag = ch == ".";
				}else if(ch == "." && value.indexOf(".") ==  value.lastIndexOf(".")){//检测是否出现两个小数点
					flag = true;
				}else if(value.lastIndexOf(".") > 0 && value.lastIndexOf(".") < (value.length - 3)){//检测小数点后的位数
				}else{
					flag = reg.test(ch);
				}
			}
			if(!flag){//删除不合法字符
				value=value.substr(0, value.length - 1);
				$(this).val(value);
			}
			clickable();
		},"input");
		
		//密码输入框监听
		appUtils.bindEvent($(_pageId+" .main .pass input:password"),function(){
			var value = $(this).val();
			if(value.length > 6){
				value=value.substr(0, value.length - 1);
				$(this).val(value);
			}
			$(_pageId+" .main .pass .show").val(value);
			clickable();
		},"input");
		
		//可见密码输入框监听
		appUtils.bindEvent($(_pageId+" .main .pass input:text"),function(){
			var value = $(this).val();
			if(value.length > 6){
				value=value.substr(0, value.length - 1);
				$(this).val(value);
			}
			$(_pageId+" .main .pass .hide").val(value);
			clickable();
		},"input");
		
		//返回
		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(e){
			pageBack();
			e.stopPropagation();
		});
		
		//显示下拉框
		appUtils.bindEvent($(_pageId+" .main .col_02"),function(e){
			$(_pageId+" .masklayer li").removeClass("check");
			if($(_pageId+" .select .col_02 span").html() == "银行卡"){
				$(_pageId+" .masklayer li:first").addClass("check");
			}else{
				$(_pageId+" .masklayer li:last").addClass("check");
			}
			$(_pageId + " .masklayer").show();
			e.stopPropagation();
		});
		
		//取消和确定（下拉框）
		appUtils.bindEvent($(_pageId+" .masklayer .selectcity_top a"),function(e){
			if($(this).index()==1){
				var a = $(_pageId + " .masklayer .selectcity ul .check a").html();
				$(_pageId + " .main .fastcash .select span").html(a);
				if(a=="银行卡"){
					$(_pageId+" .main .pass").show();
				}
				if(a=="证券账户"){
					$(_pageId+" .main .pass").hide();
				}
			}
			$(_pageId + " .masklayer").hide();
			$(_pageId+" .main .row_01 .col_04").val("");
			$(_pageId+" .main .fastcash .pass .hide").val("");
			e.stopPropagation();
		});
		
		//选择取现到银行还是证券帐户（下拉框）
		appUtils.bindEvent($(_pageId + " .masklayer .selectcity ul li"),function(e){
			$(_pageId + " .masklayer .selectcity ul li").removeClass("check");
			if($(this).index()==0){
				$(_pageId + " .masklayer .selectcity ul li:first").addClass("check");
			}else if($(this).index()==1){
				$(_pageId + " .masklayer .selectcity ul li:last").addClass("check");
			}
			e.stopPropagation();
		});
		
		//确定取现
		appUtils.bindEvent($(_pageId+" .main .definbtn_01"),function(e){
			if($(this).hasClass("isBlue")){
				_flag = false;
				$(_pageId+" .main input").blur();
				if(!$(_pageId+" .main .col_05").hasClass("nosee")){
					$(_pageId+" .main .col_05").addClass("nosee");
				}
				$(_pageId+" .main .pass .hide").show();
				$(_pageId+" .main .pass .show").hide();
				$(this).css("background","#bebebe");
				$(this).removeClass("isBlue")
				setTimeout(execute,300);
				// execute();
				e.stopPropagation();
			}
		});
		
		//显示密码
		appUtils.bindEvent($(_pageId+" .main .col_05"),function(e){
			$(this).toggleClass("nosee");
			if($(this).hasClass("nosee")){
				var password = $(_pageId+" .main .pass .show").show().val();
				$(_pageId+" .main .pass .hide").hide().val(password);
				$(_pageId+" .main .pass .hide").show();
				$(_pageId+" .main .pass .show").hide();
			}else{//展示密码
				var password = $(_pageId+" .main .pass .hide").hide().val();
				$(_pageId+" .main .pass .show").show().val(password);
			}
			e.stopPropagation();
		});
		
	}
	
	/*
	 * 销毁页面
	 */
	function destroy(){
		$(_pageId + " .main input").val(""); 
		$(_pageId+" .main .row_01 .col_04").val("");
		$(_pageId + " .masklayer").hide();
		if(!$(_pageId+" .main .col_05").hasClass("nosee")){
			$(_pageId+" .main .col_05").addClass("nosee");
		}
		if($(_pageId + " .main .definbtn_01").hasClass("isBlue")){
			$(_pageId + " .main .definbtn_01").css("background","#bebebe");
			$(_pageId + " .main .definbtn_01").removeClass("isBlue");
		}
		$(_pageId+" .main .pass .hide").show();
		$(_pageId+" .main .pass .show").hide();
		_flag = true;
	}
	
	function pageBack(){
		if(_flag){
			appUtils.pageInit("xjb/navigation/fastCash","xjb/navigation/index",{});
		}
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy,
			"pageBack":pageBack
	};
	//暴露方法
	module.exports = base;
});
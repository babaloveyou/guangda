/**
* 修改电话号码
*/
define(function(require, exports, module){
	var appUtils = require("appUtils"),
		global = require("gconfig").global,
		service = require("investService").getInstance(),  //业务层接口，请求数据
		validatorUtil = require("validatorUtil"),
		utils = require("utils"),
		layerUtils = require("layerUtils"),
		startCountDown = null,
		_pageId = "#account_editNum";
	
	function init(){
		//清空页面信息
		cleanPage();
		/*发送验证码后自动互调该方法*/
		window.getCode = getCode;
		var elements = _pageId +" .mobileno";
		utils.getPhoneNo(elements); // 自动获取手机号，并填充
	}
	
	function bindPageEvent(){
		//绑定发送手机验证码
		appUtils.bindEvent($(_pageId+" .input_mobile a"),function(){
			var mobileno = $(_pageId+" .mobileno").val();
			if(validatorUtil.isMobile(mobileno))
			{
				sendSmsCode(mobileno);  //获取验证码
			}
			else
			{
				// 手机号没通过前端校验，弹出提示，并终止发送验证码的过程
				var times = mobileno.length - 11;
				if(mobileno.length > 11)
				{
					layerUtils.iMsg(-1,"您多输入&nbsp;"+times+"&nbsp;位电话号码，请重新输入！");
				}
				else if(mobileno.length < 11)
				{
					layerUtils.iMsg(-1,"您少输入&nbsp;"+Math.abs(times)+"&nbsp;位电话号码，请重新输入！");
				}else{
					layerUtils.iMsg(-1,"请输入正确的电话号码！");
				} 
				return;
			}
		});
		
		//绑定提交修改的电话号码
		appUtils.bindEvent($(_pageId+" .ce_btn"),function(){
			if($(_pageId+" .mobileno").val().length == 0)
			{
				layerUtils.iAlert("请输入手机号！",-1);
				return;
			}
			if($(_pageId+" .code").val().length == 0)
			{
				layerUtils.iAlert("请输入验证码！",-1);
				return;
			}
			checkSmsCode();  //验证码校验
		});
	}
	
	function destroy(){
		service.destroy();
	}
	
	/* 壳子获取验证码自动填充 */
	function getCode(data)
	{
		if(data)
		{
			$(_pageId+" .code").val(data);
		}	
	}
	
	//发送验证码
	function sendSmsCode(mobileno){
		var param = {
			"mobile_no":mobileno
		};
		service.sendSmsCode(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result = data.results;
			if(error_no == "0")
			{
				// 计时器
				var sumTime = 120;
				//处理获取验证码时发生的动作
				var handleCount = function(){
					// 获取验证码之后按钮隐藏
					$(_pageId+" .blue_code").hide();
					// 显示倒计时
					$(_pageId+" .get_code").show();
					$(_pageId+" .get_code").text(sumTime--+"秒后重发");
				};
				handleCount();
				startCountDown = window.setInterval(function(){
					handleCount();
				}, 1000);
				// 120 秒之后清除计时器
			    var clearCountDown = setTimeout(function(){
					// 显示按钮
					$(_pageId+" .blue_code").show();
					// 隐藏倒计时
					$(_pageId+" .get_code").hide();
					$(_pageId+" .get_code").text(120);
					window.clearInterval(startCountDown);
				},121000);
				 //发送完验证码后，通过判断输入手机号是否一致，否则重新发送验证码
				 var c_phoneNum =mobileno;
				 appUtils.bindEvent($(_pageId+" .mobileno"),function(){
					c_phoneNum =$(_pageId+" .mobileno").val();
				 	if(validatorUtil.isMobile(mobileno)&&validatorUtil.isMobile(c_phoneNum))
				 	{
				 		//用户两次输入的手机号不同，重新获取验证码
				 		if(c_phoneNum!=mobileno)
				 		{
				 			clearInterval(startCountDown);   //清除定时器
				 			clearTimeout(clearCountDown);
							$(_pageId+" .blue_code").show();  // 显示按钮
							$(_pageId+" .get_code").hide();  // 隐藏倒计时
				 		}
				 	}
				 },"input");
				 // 调用读取短信验证码插件
				 //require("shellPlugin").callShellMethod("sMSReceiverPlugin",null,null,null);
			}else
			{
				layerUtils.iAlert(error_info,-1);
				return false;
			}
		});
	}
	
	//检验验证码
	function checkSmsCode(){
		var param ={
			"mobile_no":$(_pageId+" .mobileno").val(),
			"mobile_code" : $(_pageId+" .code").val()
		};
		service.checkSmsCode(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			if(error_no == "0"){
				//验证成功提交电话号码修改
				var param = {
					"user_id":appUtils.getSStorageInfo("user_id"),
					"contact_mobile":$(_pageId+" .mobileno").val()
				};
				service.submitMobileNo(param,function(data){
					var error_no = data.error_no;
					var error_info = data.error_info;
					if(error_no == "0"){
						appUtils.setSStorageInfo("mobileno",$(_pageId+" .mobileno").val());
						appUtils.pageInit("account/editNum","account/result",{});
					}else{
						layerUtils.iAlert(error_info,-1);
					}
				});
			}else{
				layerUtils.iAlert(error_info,-1);
			}
		});
	}
	
	//清空页面信息
	function cleanPage(){
		$(_pageId+" .mobileno").html("");
		$(_pageId+" .code").html("");
		$(_pageId+" .blue_code").show();  // 显示按钮
		$(_pageId+" .get_code").hide();  // 隐藏倒计时
	}
	
	var editNum = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	
	module.exports = editNum;
});
/*
 * 现金宝参与状态设置
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	_pageId = "#xjb_setState ",
	cyzt = -1;//参与状态   1参与  0退出
	isCanOperation = -1;//是否可操作  0不可操作  1可操作
	/*
	 * 页面初始化
	 */
	function init(){
		if($(_pageId).width()<=336){
			$(_pageId+" .mn_tab ul li a").css({"font-size":"10px"});
		}
		cyzt = -1;//参与状态   1参与  0退出
		isCanOperation = -1;//是否可操作  0不可操作  1可操作
		valide();
	}
	
	/*
	 * 绑定页面事件
	 */
	function bindPageEvent(){
		
		//返回
		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(){
//			if(isCanOperation != 1){
//				layerUtils.iMsg(-1,"您还没有参与现金宝");
//				return false;
//			}
			appUtils.pageInit("xjb/setState","account/userCenter",{});
		});
		
		//选择状态
		appUtils.bindEvent($(_pageId+" .sel_list"),function(){
			
			$(_pageId+" .sel").slideToggle();

		});
		
		//参与
		appUtils.bindEvent($(_pageId+" .in"),function(){
			$(_pageId+" .sel_list strong").html("参与");
			$(_pageId+" .sel").slideUp();
		});
		
		//退出
		appUtils.bindEvent($(_pageId+" .out"),function(){
			$(_pageId+" .sel_list strong").html("退出");
			$(_pageId+" .sel").slideUp();
		});
		
		
		
		//我要修改
		appUtils.bindEvent($(_pageId+" .ce_btn a"),function(){
			if($(_pageId+" .sel_list strong").html() == "请选择"){
				layerUtils.iMsg(-1,"请选择参与状态");
			}
			else if(cyzt == 1 && $(_pageId+" .sel_list strong").html() == "参与"){
				layerUtils.iMsg(-1,"您已经是参与状态");
			}else if(cyzt == 0 && $(_pageId+" .sel_list strong").html() == "退出"){
				layerUtils.iMsg(-1,"您已经是退出状态");
			}else if(cyzt == -1){
				layerUtils.iConfirm("初始化状态失败，是否重试？",function(){
					init();
				},null);
			}else{//设置参与状态
				var param = {
					"account":appUtils.getSStorageInfo("fund_account"),
					"market":1,
					"elecstatus":1
				};
				if($(_pageId+" .sel_list strong").html() == "参与"){
					param.elecstatus = 1;
					service.setCyzt2(param,function(data){
						if(data.error_no == 0){
							if($(_pageId+" .sel_list strong").html() == "参与"){
								cyzt = 1;
								isCanOperation = 1;
							}else{
								cyzt = 0;
								isCanOperation = 0;
							}
							layerUtils.iMsg(0,"现金宝状态设置成功");
						}else{
							layerUtils.iLoading(false);
							var error = data.error_info;
							//后台返回的提示信息不友好
							if(error.indexOf("SQL")> -1){
								error = error.split("SQL")[0];
								error = error.substring(0,error.length-2);
							}
							layerUtils.iAlert(error);
						}
					});
				}else{
					param.elecstatus = 0;
					layerUtils.iConfirm("如果现在退出将不享受本季度现金宝收益，仅为活期存款利率，您是否确认退出？",function(){
						service.setCyzt2(param,function(data){
							if(data.error_no == 0){
								if($(_pageId+" .sel_list strong").html() == "参与"){
									cyzt = 1;
									isCanOperation = 1;
								}else{
									cyzt = 0;
									isCanOperation = 0;
								}
								layerUtils.iMsg(0,"现金宝状态设置成功");
							}else{
								layerUtils.iLoading(false);
								var error = data.error_info;
								//后台返回的提示信息不友好
								if(error.indexOf("SQL")> -1){
									error = error.split("SQL")[0];
									error = error.substring(0,error.length-2);
								}
								layerUtils.iAlert(error);
							}
						});
					},null);
				}
			}
		});
		
		//tab0
		appUtils.bindEvent($(_pageId+" .mn_tab .setReservationItem"),function(){
			if(isCanOperation != 1){
				layerUtils.iMsg(-1,"您还没有参与现金宝");
				return false;
			}
			appUtils.pageInit("xjb/setState","xjb/setReservation",{});
		});
		
		//tab1
		appUtils.bindEvent($(_pageId+" .mn_tab .fastCashItem"),function(){
			if(isCanOperation != 1){
				layerUtils.iMsg(-1,"您还没有参与现金宝");
				return false;
			}
			appUtils.pageInit("xjb/setState","xjb/fastCash",{});
		});
		
		//tab2
		appUtils.bindEvent($(_pageId+" .mn_tab .setReserveFundsItem"),function(){
			if(isCanOperation != 1){
				layerUtils.iMsg(-1,"您还没有参与现金宝");
				return false;
			}
			appUtils.pageInit("xjb/setState","xjb/setReserveFunds",{});
		});
		
		//tab3
		appUtils.bindEvent($(_pageId+" .mn_tab .setStateItem"),function(){
			
		});
		
		//tab4
		appUtils.bindEvent($(_pageId+" .mn_tab .queryQuotientItem"),function(){
			if(isCanOperation != 1){
				layerUtils.iMsg(-1,"您还没有参与现金宝");
				return false;
			}
			appUtils.pageInit("xjb/setState","xjb/queryQuotient",{});
		});
		
	}
	
	
	function valide(){
		var user=appUtils.getSStorageInfo("userinfo");
		var userinfo=JSON.parse(user);
		var s="1002";
		if(userinfo.user_type=="0"){
			s="1001";
		}
		var param = {
			"fund_account":appUtils.getSStorageInfo("fund_account"),
			"sign":4,
			"ezt_name":userinfo.user_code,
			"ticket":"",
			"survey_sn":s
		};
		service.isCompleteStep(param,function(data){
			if(data.error_no == 0){
				var result = data.results[0];
				if(result.sfkh == "1"){//已经开户
					if(result.sfqsdzht == "1"){//合同已签署
						var par = {
							"branch_no":appUtils.getSStorageInfo("branch_no"),
							"account":appUtils.getSStorageInfo("fund_account"),
							"market":"1",
							"eztName":userinfo.user_code,
							"ticket":""
						};
						service.queryHtzt(par,function(data){//查询合同状态
							if(data.error_no == 0){
								var result = data.results[0];
								if(result.electronic_contract_status == "1"){//状态为参与，直接进入业务操作
									isCanOperation = 1;
									$(_pageId+" .sel_list strong").html("参与");
									cyzt = 1;
								}else{
									isCanOperation = 0;
									$(_pageId+" .sel_list strong").html("退出");
									cyzt = 0;
								}
							}else{
								layerUtils.iLoading(false);
								layerUtils.iAlert(data.error_info);
							}
						});
					}else{
						layerUtils.iMsg(-1,"您还没有签署合同");
					}
				}else{
					layerUtils.iMsg(-1,"您还没有开TA户");
				}
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		});
	}
	
	
	/*
	 * 销毁页面
	 */
	function destroy(){
		
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy
	};
	//暴露方法
	module.exports = base;
});
/**
 * 转账查询
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils");
	var gconfig = require("gconfig");
	var service = require("mobileService"); //业务层接口，请求数据
	var global = gconfig.global;
	var dateUtils= require("dateUtils");
	var layerUtils = require("layerUtils");
	var validatorUtil = require("validatorUtil");
	var bankCode="";
	var trans_type=1;
	var _pageId="#account_changeQuery";

	/*初始化*/
	function init()
	{
		trans_type= $(_pageId+" .tab_box04 li:eq(0)").val();
	}

	function bindPageEvent() 
	{
		/* 绑定返回事件 */
		appUtils.bindEvent($(_pageId+" .top_title .icon_back"),function(){
			appUtils.pageBack();
		});
		
		/* 隐藏 */
		appUtils.bindEvent($(_pageId+" .trans_type"),function(){
			$(_pageId+" #banktype").hide();
			$(_pageId+" #moneytype").hide();
		});

		/* 绑定LOGO事件 */
		appUtils.bindEvent($(_pageId+" .header .logo"),function(){
			appUtils.pageInit("account/changeQuery","account/mainPage",{});
		});

		/* 绑定返回首页事件 */
		appUtils.bindEvent($(_pageId+" .icon_mall"),function(){
			appUtils.pageInit("account/changeQuery","account/mainPage",{});
		});
		
		/* 绑定银行转证券事件 */
		appUtils.bindEvent($(_pageId+" .bankTofund"),function()
			{
			$(_pageId+" #banktype").hide();
			$(_pageId+" #moneytype").hide();
			trans_type= $(_pageId+" .tab_box04 li:eq(0)").val();
			$(_pageId+" .trade_box input").val("");
			$(_pageId+" .money_type").html("");
			$(_pageId+" .bank_no").html(""); //切换时清除银行

			// 设置样式
			$(_pageId+" .tab_box04 ul li").eq(0).addClass("current");
			$(_pageId+" .tab_box04 ul li").eq(1).removeClass("current");
			$(_pageId+" .bankPassword").hide();
			$(_pageId+" .tradePassword").hide();
			});

		/* 绑定证券转银行事件 */
		appUtils.bindEvent($(_pageId+" .fundTobank"),function()
			{
			$(_pageId+" #banktype").hide();
			$(_pageId+" #moneytype").hide();
			$(_pageId+" .trade_box input").val("");
			trans_type= $(_pageId+" .tab_box04 li:eq(1)").val();
			$(_pageId+" .money_type").html("");
			$(_pageId+" .bank_no").html("");  //切换时清除银行

			// 设置样式
			$(_pageId+" .tab_box04 ul li").eq(1).addClass("current");
			$(_pageId+" .tab_box04 ul li").eq(0).removeClass("current");
			$(_pageId+" .bankPassword").hide();
			$(_pageId+" .tradePassword").hide();

			});

		/* 下一步(确认查询)*/
		appUtils.bindEvent($(_pageId+" .trade_btn .n2") ,function(){

			var param = {
				"trans_type" : trans_type,
				"bank_no" :  bankCode,
				"money_type" :  $(_pageId+" .money_type").val(),
				"start_date" :  $(_pageId+" .start_date").val(),
				"end_date" :  $(_pageId+" .end_date").val()
			};	
			appUtils.pageInit("account/changeQuery","account/changeResults",param);

			//			confirmQuery();
			//			if(verifyInfo()){}
		});

		/* 绑定时间事件 */
		appUtils.bindEvent($(_pageId+" .trade_box .t1_cate"),function(){
			$(_pageId+" #banktype").hide();
			$(_pageId+" #moneytype").hide();
			dateUtils.initDateUI("account_changeQuery");
		});

		/*账户银行*/
		appUtils.bindEvent($(_pageId+" .trade_box .bank_no") ,function(){
			if($(_pageId+" #banktype").is(":hidden")){
				$(_pageId+" #banktype").show();
				$(_pageId+" #moneytype").hide();
			}else{
				$(_pageId+" #banktype").hide();
				$(_pageId+" #moneytype").hide();
			}
			accountBank();
		
		});

		/* 绑定币种列表事件 */
		appUtils.bindEvent($(_pageId+" #moneyType"),function(){
			if($(_pageId+" #moneytype").is(":hidden")){
				$(_pageId+" #banktype").hide();
				$(_pageId+" #moneytype").show();
			}else{
				$(_pageId+" #banktype").hide();
				$(_pageId+" #moneytype").hide();
			}
		});

		/* 重置*/
		appUtils.bindEvent($(_pageId+" .trade_btn .n1") ,function(){
			$(_pageId+" #moneytype").hide();
			$(_pageId+" #banktype").hide();
			destroy();
		});
	}
	/* 查询账户所属银行*/
	function accountBank(){
		var fund_account=appUtils.getSStorageInfo("fund_account");
		var param={"fund_account" : fund_account};

		/*调用转账查询接口*/
		service.accountBank(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result = data.results;
			if(error_no == "0" && result.length != 0)
			{
				var allBankStr="";
				var moneyType="";
				for(i=0; i<result.length;i++){

					// 获取银行枚举
					var bankName=result[i].bank_name;
					var money_type=result[i].money_type;
					var bankCode=result[i].bank_no;
					allBankStr+="<li><span  money_type='"+money_type+"'  bankname='"+bankName+"' id='"+bankCode+"' >"+bankName+"</span></li>";
				}
				$(_pageId+" #banktype ul").html(allBankStr);  // 填充银行信息
			
			/*选中值赋给选择框*/
			appUtils.bindEvent($(_pageId+" #banktype ul li span"),function(){
				    bankAcco = $(this).attr("id");
				    moneyType = $(this).attr("money_type");
					var bankName = $(this).text();  //当前选中银行的值
					$(_pageId+" .bank_no").text(bankName);	  //选中值赋给选择框
					if (moneyType=="0"){
					$(_pageId+" .money_type ").text("人民币");
			    	}
				    else if (moneyType=="1"){
				    	$(_pageId+" .money_type ").text("美元");
			     	}else if(moneyType=="2"){
			     		$(_pageId+" .money_type ").text("港币");
				}
				$(_pageId+" #banktype").hide();
			});
			/*选中值赋给选择框*/
			appUtils.bindEvent($(_pageId+" #moneytype ul li span"),function(){
				var bankName = $(this).text();  //当前选中银行的值
				$(_pageId+" .money_type").text(bankName);	  //选中值赋给选择框
				$(_pageId+" #banktype").hide();
				$(_pageId+" #moneytype").hide();
				if (moneyType==$(this).attr("id")){
				}
				else{
					layerUtils.iMsg(-1,"对不起，银行账户不存在此种货币！");
					$(_pageId+" .money_type").text("");
					return false;
				}
			});
			
			}
			else
			{
				layerUtils.iAlert(error_info);
			}
		});


	}

	/* 信息验证*/
	function verifyInfo(){
		var start_date = $(_pageId+" .start_date").val();
		var end_date = $(_pageId+" .end_date").val();
		// 验证有效期的格式
		var dateReg = /^[1-3]\d{3}-(0|1)\d-[0-3]\d$/;
		if(!(dateReg.test(start_date) && validatorUtil.isDate(start_date)))
		{
			layerUtils.iMsg(-1,"您输入的时间格式有问题，请重新输入!");
			return false;
		}

		if(!(dateReg.test(end_date) && validatorUtil.isDate(end_date)))
		{
			layerUtils.iMsg(-1,"您输入的时间格式有问题，请重新输入!");
			return false;
		}

		if(Date.parse(start_date) > Date.parse(end_date))
		{
			layerUtils.iMsg(-1,"开始时间不能大于结束时间，请重新输入!");
			return false;
		}

		return true;

	}


	function destroy()
	{
		//清除数据
		$(_pageId+" .trade_box input").val("");
		$(_pageId+" .bank_no").html("");
		$(_pageId+" .money_type").html("");
	}

	var changeQuery = 
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = changeQuery;

});
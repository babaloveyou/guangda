/**
 * 主菜单
 */
define(function(require, exports, module){
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
	    service = require("investService").getInstance(),  //业务层接口，请求数据
		global = require("gconfig").global,
		layerUtils = require("layerUtils"),
		fundsFlag = "",  //资金状况
		riskFlag = "",   //风险评测状况
		knowledgeFlag = "", //知识评测状况
		signFlag = "", //协议签署状况
		_pageId = "#account_mainPage";
		
	/* 私有业务模块的全局变量 end */
	
	function init()
	{
		//初始化操作
		initHandle();
	}
	
	function bindPageEvent()
	{
		//绑定资金菜单
		appUtils.bindEvent($(_pageId+" #funds"),function(){
			//重新查询资金
			reQueryMoney();
		});
		//绑定风险等级测试
		appUtils.bindEvent($(_pageId+" #riskTest"),function(){
			appUtils.pageInit("account/mainPage","account/riskInfo",{});
		});
		//绑定知识测评
		appUtils.bindEvent($(_pageId+" #knowledgeTest"),function(){
			appUtils.pageInit("account/mainPage","account/knowledge",{});
		});
		//绑定电子签约
		appUtils.bindEvent($(_pageId+" #elecSign"),function(){
			appUtils.pageInit("account/mainPage","account/signProtocol",{});
		});
		//绑定申请沪A
		appUtils.bindEvent($(_pageId+" #openSha"),function(){
			appUtils.pageInit("account/mainPage","account/mainPage",{});
		});
		appUtils.bindEvent($(_pageId+" .icon_back"),function(){
					//清楚所有缓存
		//			appUtils.clearSStorage();
					$("#bodyContent .page").each(function(){
						$(this).remove();
					});
					appUtils.pageInit("account/mainPage","business/index",{});
				});
	}
		//处理返回
		

	
	//初始化操作
	function initHandle(){
		var	rating_lvl_name = appUtils.getSStorageInfo("rating_lvl_name"),    //在主菜单显示风险评测等级
			knowledgeScore = appUtils.getSStorageInfo("knowledge_score"),   //在主菜单显示知识评测分数
			risk_survey_valid = appUtils.getSStorageInfo("risk_survey_valid");
		
		//判断有没有沪A账户
		var shaaccount = appUtils.getSStorageInfo("shaaccount"),
			isregTrade = appUtils.getSStorageInfo("is_regTrade"),
			isadd = appUtils.getSStorageInfo("isadd"),
			in_blacklist = appUtils.getSStorageInfo("in_blacklist"),
			_prePageCode = appUtils.getSStorageInfo("_prePageCode");
		
		var value = "";
		if(_prePageCode == "account/netInfo"){
			value = parseFloat(appUtils.getSStorageInfo("value")).toFixed(2);   //在主菜单显示账户资金
		} else if (_prePageCode == "account/fundsInfo") {
			value = parseFloat(appUtils.getSStorageInfo("marketvalue")).toFixed(2);   //在主菜单显示账户资金
		}
			
		if(shaaccount == "" || shaaccount == undefined || shaaccount == null){
				layerUtils.iAlert("你当前尚未在我司开通沪A账户,不能办理港股通业务。",-1,function(){
				//require("external").sendMessage("usercenter","","50002","");
					var param_index = {"funcNo":"50101","moduleName":"main"};
					require("external").callMessage(param_index);
					
			},"退出");
		}
		else{
			if(isregTrade == "3"||isregTrade==""||isregTrade==undefined||isregTrade==null){
				layerUtils.iAlert("您的账户状态未通过，账户属于非股票交易账户。",-1,function(){
						//返回到我的富尊。
						//require("external").sendMessage("usercenter","","50002","");
					     var param_index = {"funcNo":"50101","moduleName":"main"};
					     require("external").callMessage(param_index);
					},"退出");
			}
			else {
				if(isadd == "0"||isadd==""||isadd==undefined||isadd==null){
					layerUtils.iAlert("您的账户状态未通过，未指定交易。",-1,function(){
						//返回到我的富尊。
							//require("external").sendMessage("usercenter","","50002","");
						var param_index = {"funcNo":"50101","moduleName":"main"};
						require("external").callMessage(param_index);
					},"退出");
				}
				else {
					if(isregTrade == "0"||isregTrade==""||isregTrade==undefined||isregTrade==null){
						layerUtils.iAlert("您的账户未指定交易。",-1,function(){
							//返回到我的富尊。
							//	require("external").sendMessage("usercenter","","50002","");
							var param_index = {"funcNo":"50101","moduleName":"main"};
							require("external").callMessage(param_index);
						},"退出");
					}
					else{
							if(in_blacklist == "0"){}
							else{
								layerUtils.iAlert("您的资质审核结果不符合在线开通港股通的要求，请联系您所在的营业部现场开通办理。",-1,function(){
								//返回到我的富尊。
									//require("external").sendMessage("usercenter","","50002","");
									var param_index = {"funcNo":"50101","moduleName":"main"};
									require("external").callMessage(param_index);
							},"退出");
						}
					}
				}
			}
		}

		//判断从子页面跳到主菜单
		if(_prePageCode == "account/fundsInfo" || _prePageCode == "account/netInfo"){
			fundsFlag =  appUtils.getPageParam("fundsFlag");
			fundsClass(fundsFlag,value);
		}
		else if(_prePageCode == "account/riskInfo"){
			riskFlag =  appUtils.getPageParam("riskFlag");
			 riskClass(riskFlag,rating_lvl_name,risk_survey_valid);
		}
		else if(_prePageCode == "account/knowledgeInfo"){
			knowledgeFlag =  appUtils.getPageParam("knowledgeFlag");
			knowledgeClass(knowledgeFlag,knowledgeScore);
		}
		else if(_prePageCode == "account/signProtocol"){
			signFlag =  appUtils.getPageParam("signFlag");
			signClass(signFlag);
		}
		else if(_prePageCode == "business/index"){
			
				$(_pageId+" .must_list ul li:eq(0)").removeClass();
				$(_pageId+" #funds span").removeClass();
				$(_pageId+" #funds span").html("");
				
				$(_pageId+" .must_list ul li:eq(1)").removeClass();
				$(_pageId+" #riskTest span").removeClass();
				$(_pageId+" #riskTest span").html("");
				
				$(_pageId+" .must_list ul li:eq(2)").removeClass();
				$(_pageId+" #knowledgeTest span").removeClass();
				$(_pageId+" #knowledgeTest span").html("");
				
				$(_pageId+" .must_list ul li:eq(3)").removeClass();
				
				$(_pageId+" .ce_btn").addClass("disable");
		}
		else{
			//签署超风协议跳转过来时
			 riskFlag =  appUtils.getPageParam("riskFlag");
			 riskClass(riskFlag);
		}
		//判断提交港股通权限按钮的功能
		if(fundsFlag == "1" && riskFlag == "1" && knowledgeFlag == "1" && signFlag == "1"){
			$(_pageId+" .ce_btn").removeClass("disable");
		}
		//绑定提交港股通权限的按钮
		if(!$(_pageId+" .ce_btn").hasClass("disable")){
			//绑定提交按钮
			appUtils.bindEvent($(_pageId+" .ce_btn"),function(){
				var is_autoTask = appUtils.getSStorageInfo("is_autoTask");
				//直接开通港股通权限
				if(is_autoTask == 0){
					var param = {
						"user_id":appUtils.getSStorageInfo("user_id"),
                        "trade_pwd":"123321"
                        };
					//开通港股通权限
					service.openAccount(param,function(data){
						var error_no = data.error_no;
						var error_info = data.error_info;
						if(error_no == "0"){
							var params = {
								"user_id":appUtils.getSStorageInfo("user_id"),
								"current_step":"ktha/Success" 
							};
							service.saveUserTemp(params,function(data){
								var error_no = data.error_no;
								var error_info = data.error_info;
								if(error_no == "0"){
									appUtils.pageInit("account/mainPage","account/result",{});
								}else{
									layerUtils.iAlert(error_info,-1);
								}
							});
						}else{
							layerUtils.iAlert(error_info,-1);
						}
					});
				}
				else{
					var param = {
						"user_id":appUtils.getSStorageInfo("user_id")
                        };
					//加入开通港股通跑批队列
					service.joinBatch(param,function(data){
						var error_no = data.error_no;
						var error_info = data.error_info;
						if(error_no == "0"){
							var params = {
								"user_id":appUtils.getSStorageInfo("user_id"),
								"current_step":"ktha/Success" 
							};
							service.saveUserTemp(params,function(data){
								var error_no = data.error_no;
								var error_info = data.error_info;
								if(error_no == "0"){
									appUtils.pageInit("account/mainPage","account/result",{});
								}else{
									layerUtils.iAlert(error_info,-1);
								}
							});
						}else{
							layerUtils.iAlert(error_info,-1);
						}
					});
				}
				
			});
		}
	}
	
	function fundsClass(flag,value){
			//资金状况
			if(fundsFlag == "1"){
				$(_pageId+" .must_list ul li:eq(0)").removeClass("lost");
				$(_pageId+" .must_list ul li:eq(0)").addClass("over");
				if(value != null || value != undefined || value != ""){
					$(_pageId+" #funds span").removeClass("ared");
					$(_pageId+" #funds span").html(value);
				}
			}else if(fundsFlag == "2"){
				$(_pageId+" .must_list ul li:eq(0)").removeClass("over");
				$(_pageId+" .must_list ul li:eq(0)").addClass("lost");
				if(value != null || value != undefined || value != ""){
					$(_pageId+" #funds span").addClass("ared");
					$(_pageId+" #funds span").html(value);
				}
			}
	
	}
	
	function riskClass(flag,rating_lvl_name,risk_survey_valid){
		
	//风险评测
		if(riskFlag == "1"){
			$(_pageId+" .must_list ul li:eq(1)").removeClass("lost");
			$(_pageId+" .must_list ul li:eq(1)").addClass("over");
			if(rating_lvl_name != null || rating_lvl_name != undefined || rating_lvl_name != ""){
				$(_pageId+" #riskTest span").removeClass("ared");
				$(_pageId+" #riskTest span").html(rating_lvl_name);
			}
		}else if(riskFlag == "2"){
			$(_pageId+" .must_list ul li:eq(1)").removeClass("over");
			$(_pageId+" .must_list ul li:eq(1)").addClass("lost");
			if(rating_lvl_name != null || rating_lvl_name != undefined || rating_lvl_name != ""){
				$(_pageId+" #riskTest span").addClass("ared");
				$(_pageId+" #riskTest span").html(rating_lvl_name);
				if(risk_survey_valid == "0"){
					$(_pageId+" #riskTest span").html("");
				}
			}
		}
}
function knowledgeClass(flag,knowledgeScore){
		
//知识评测
		if(knowledgeFlag == "1"){
			$(_pageId+" .must_list ul li:eq(2)").removeClass("lost");
			$(_pageId+" .must_list ul li:eq(2)").addClass("over");
			if(knowledgeScore != null || knowledgeScore != undefined || knowledgeScore != ""){
				$(_pageId+" #knowledgeTest span").removeClass("ared");
				$(_pageId+" #knowledgeTest span").html(knowledgeScore);
			}
		}else if(knowledgeFlag == "2"){
			$(_pageId+" .must_list ul li:eq(2)").removeClass("over");
			$(_pageId+" .must_list ul li:eq(2)").addClass("lost");
			if(knowledgeScore != null || knowledgeScore != undefined || knowledgeScore != ""){
				$(_pageId+" #knowledgeTest span").addClass("ared");
				$(_pageId+" #knowledgeTest span").html(knowledgeScore);
			}
		}

}

function signClass(flag){
//协议签署
	
		if(signFlag == "1"){
			$(_pageId+" .must_list ul li:eq(3)").removeClass("lost");
			$(_pageId+" .must_list ul li:eq(3)").addClass("over");
		}else if(signFlag == "2"){
			$(_pageId+" .must_list ul li:eq(3)").removeClass("over");
			$(_pageId+" .must_list ul li:eq(3)").addClass("lost");
		}
}
	function destroy()
	{
		service.destroy();
	}

	//重新查询证券资产
	function reQueryMoney () {
		var checkLoginPath = global.checkLoginPath;
		// 检测是否登录，保存返回值
		appUtils.invokeServer(checkLoginPath,{}, function(data){
			var result = data.data;
			if(result != undefined){
				saveData(result);  // 将数据保存到 session 中
				appUtils.pageInit("account/mainPage","account/fundsInfo",{});
			}
			else{
				layerUtils.iMsg(-1,data.err_info);
				layerUtils.iLoading(false);
			}
		});
	}
	
	/**
	 * 港股通模拟登陆成功后保存数据（session）
	 * */
	function saveData(result)
	{
		// 黑名单标志
		appUtils.setSStorageInfo("in_blacklist",result.in_blacklist);
		//沪A账户是否指定交易
		appUtils.setSStorageInfo("is_regTrade",result.is_regTrade);
		//是否需要跑批
		appUtils.setSStorageInfo("is_autoTask",result.is_autoTask);
		//开通港股通备注
		appUtils.setSStorageInfo("ggtopen_remark",result.ggtopen_remark);
		//当前步骤
		appUtils.setSStorageInfo("current_step",result.current_step);
		//证件类型
		appUtils.setSStorageInfo("idtype",result.idtype);
		//证件有效截止日期
		appUtils.setSStorageInfo("idenddate",result.idenddate);
		//证件有效开始日期
		appUtils.setSStorageInfo("idbegindate",result.idbegindate);
		//沪A账号是否加挂
		appUtils.setSStorageInfo("isadd",result.isadd);
		//港股通开立标志
		appUtils.setSStorageInfo("ggtopen_flag",result.ggtopen_flag);
		//风险测评分数
		appUtils.setSStorageInfo("survey_score",result.survey_score);
		//风险测评是否有效
		appUtils.setSStorageInfo("risk_survey_valid",result.risk_survey_valid);
		//风险测评等级
		appUtils.setSStorageInfo("rating_lvl",result.rating_lvl);
		//知识测评分数
		appUtils.setSStorageInfo("knowledge_score",result.knowledge_score);
		//营业部编号
		appUtils.setSStorageInfo("branchno",result.branchno);
		//用户编号
		appUtils.setSStorageInfo("user_id",result.user_id);
		//风险测评等级名称
		appUtils.setSStorageInfo("rating_lvl_name",result.rating_lvl_name);
		//客户姓名
		appUtils.setSStorageInfo("custname",result.custname);
		//沪A账号
		appUtils.setSStorageInfo("shaaccount",result.shaaccount);
		//证券账户资产总值
		appUtils.setSStorageInfo("marketvalue",result.marketvalue);
		//电话号码
		appUtils.setSStorageInfo("mobileno",result.mobileno);
		//客户类型
		appUtils.setSStorageInfo("cust_type",result.cust_type);
		//信用证券账户总资产
		appUtils.setSStorageInfo("net_asset",result.net_asset);
		//联系地址
		appUtils.setSStorageInfo("address",result.address);
		//身份证是否在有效期内
		appUtils.setSStorageInfo("idenddate_valid",result.idenddate_valid);
		//身份证号
		appUtils.setSStorageInfo("idno",result.idno);
	}
	
	/* 清理界面元素*/
	/*function cleanPageElement()
	{
		
	}*/
	
	var mainPage = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	
	module.exports = mainPage;
});

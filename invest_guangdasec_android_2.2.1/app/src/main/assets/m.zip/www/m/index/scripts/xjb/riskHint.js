/*
 * 风险揭示书
 */
define(function(require,exports,module){

   	var appUtils = require("appUtils"),
   	layerUtils = require("layerUtils"),
   	global = require("gconfig").global,
   	service = require("serviceImp"), //业务层接口，请求数据
   	_pageId = "#xjb_riskHint ",
   	category_englishname = null;
   	var external = require("external");
   	/*
   	 * 页面初始化
   	 */
   	function init(){
   		var protocols = [];
   		category_englishname = appUtils.getPageParam("category_englishname");
   		if(category_englishname == "" || category_englishname == null || category_englishname == undefined){
   			layerUtils.iAlert("没有找到协议英文名");
   			return;
   		}
   		if(category_englishname == "xjbdzqmyds"){
   			protocols.push(appUtils.getSStorageInfo("pro_code_qys"));
   			showDzht(protocols);
   		}else if(category_englishname == "xjbqyxgxy"){
   			protocols.push(appUtils.getSStorageInfo("pro_code_fxjss"));
   			protocols.push(appUtils.getSStorageInfo("pro_code_ht"));
   			showDzht(protocols);
   		}else if(category_englishname == "xjbxykh"){
   			showFxjss()
   		}
   	}

   	//显示电子合同，电子协议，风险揭示书
   	function showDzht(protocols){
   		$(_pageId+" .risk_entry").html("");
   		var $ulobj =$("<ul>").appendTo($(_pageId+" .risk_entry"));
   		$ulobj.html("");
   		$.each(protocols,function(i){
   			var me = this.toString();
   			service.queryProtocolAttr({"pro_code":me},function(data){
   				if(data.error_no == 0){
   					if(i == 0)layerUtils.iLoading(true);
   					//$(_pageId+" .risk_entry").html("");
   					var $liobj = $("<li>").css("color","red");
   					$ulobj.append($liobj.text(data.results[0].pro_title));
   					appUtils.bindEvent($liobj,function(){
   						var param = {
   							"pro_content":data.results[0].pro_content,
   							"pro_code":data.results[0].pro_code,
   							"file_name":data.results[0].file_name
   						};
   						service.getProtocolContent(param,function(data){
   							if(data.error_no == 0){
   								var pdfUrl = global.pdfUrl + "/" + data.results[0].pdf_url;
   								//var pdfUrl = "http://192.168.5.251:2227/452345324.pdf";
   								var results = external.callMessage({"funcNo":"50240","url":pdfUrl});
   								console.log(JSON.stringify(results));
   							}else{
   								layerUtils.iLoading(false);
   								layerUtils.iAlert(data.error_info);
   							}
   						});
   					});
   					if(i == protocols.length - 1)layerUtils.iLoading(false);
   				}else{
   					layerUtils.iLoading(false);
   					layerUtils.iAlert(data.error_info);
   				}
   			});
   		});
   	}

   	//显示风险揭示书
   	function showFxjss(){
   		$(_pageId+" .risk_entry").html("");
   		service.queryXyname({"category_englishname":category_englishname},function(data){
   			if(data.error_no == 0){
   				$.each(data.results,function(i){
   					var xy_result = data.results[i];
   					service.queryXyInfo({"econtract_no":xy_result.econtract_no},function(data){
   						if(data.error_no == 0){
   							var result = data.results[0];
   							var content = result.econtract_content;
   							$(_pageId+" .risk_entry").append(content);
   						}else{
   							layerUtils.iLoading(false);
   							layerUtils.iAlert(data.error_info);
   						}
   					});
   				});
   			}else{
   				layerUtils.iLoading(false);
   				layerUtils.iAlert(data.error_info);
   			}
   		});
   	}
   	/*
   	 * 绑定页面事件
   	 */
   	function bindPageEvent(){

   		//返回
   		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(){
   			appUtils.pageBack();
   		});

   		//同意
   		appUtils.bindEvent($(_pageId+" .two_btn a:eq(0)"),function(){
   			if(category_englishname == "xjbxykh"){//风险揭示书
   				openTAAccount();//开通ta账户
   			}else if(category_englishname == "xjbdzqmyds"){//电子协议
   				signDzxy();
   			}else if(category_englishname == "xjbqyxgxy"){//电子合同
   				setCyzt();
   			}else{
   				layerUtils.iAlert("协议英文名没有找到");
   			}
   		});

   		//不同意
   		appUtils.bindEvent($(_pageId+" .two_btn a:eq(1)"),function(){
   			layerUtils.iMsg(-1,"不同该协议将无法进入下一步",1);
   		});
   	}

   	/**
   	 * 开通TA账户
   	 */
   	function openTAAccount(){
   		var user=appUtils.getSStorageInfo("userinfo");
   		var userinfo=JSON.parse(user);
   		var s="1002";
   		if(userinfo.user_type=="0"){
   			s="1001";
   		}
   		var param = {
   			"branch_no":appUtils.getSStorageInfo("branch_no"),
   			"account":appUtils.getSStorageInfo("fund_account"),
   			"ezt_name":userinfo.user_code,
   			"ticket":"",
   			"survey_sn":s
   		};
   		service.openTAAccount(param,function(data){
   			if(data.error_no == 0){
   				layerUtils.iMsg(0,"已为您开通了TA账户，马上进入下一步...");
   				setTimeout(function(){
   					stepCheck();
   				},2000);

   			}else{
   				layerUtils.iLoading(false);
   				var error = data.error_info;
   				//后台返回的提示信息不友好
   				if(error.indexOf("SQL")> -1){
   					error = error.split("SQL")[0];
   					error = error.substring(0,error.length-2);
   				}
   				layerUtils.iAlert(error);
   			}
   		});
   	}

   	/**
   	 * 签署电子协议
   	 */
   	function signDzxy(){
   		var user=appUtils.getSStorageInfo("userinfo");
   		var userinfo=JSON.parse(user);
   		var s="1002";
   		if(userinfo.user_type=="0"){
   			s="1001";
   		}
   		var param = {
   			"account":appUtils.getSStorageInfo("fund_account"),
   			"ezt_name":userinfo.user_code,
   			"ticket":"",
   			"risk_uncover":0,
   			"com_sign":0,
   			"survey_sn":s,
   			"entrust_way":"SJWT"
   		};
   		service.signDzxy(param,function(data){
   			var result = data.results[0];
   			layerUtils.iMsg(-1,result.retval);//提示签署信息
   			//查询电子协议状态
   			var user=appUtils.getSStorageInfo("userinfo");
   			var userinfo=JSON.parse(user);
   			var p = {
   				"account":appUtils.getSStorageInfo("fund_account"),
   				"eztName":userinfo.user_code,
   				"ticket":""
   			};
   			service.queryDzxyState(p,function(data){
   				setTimeout(function(){
   					if(data.results[0].signdate != "None"){
   						// 是否完成了步奏 查询标识（1,2,3,4分别代表查询是否开户，是否签署电子约定书，是否进行风险测评，是否签署电子合同 ）
   						var user=appUtils.getSStorageInfo("userinfo");
   						var userinfo=JSON.parse(user);
   						var s="1002";
   						if(userinfo.user_type=="0"){
   							s="1001";
   						}
   						var par = {
   							"fund_account":appUtils.getSStorageInfo("fund_account"),
   							"sign":3,
   							"ezt_name":userinfo.user_code,
   							"ticket":"",
   							"survey_sn":s
   						};
   						service.isCompleteStep(par,function(data){
   							if(data.error_no == 0){
   								var result = data.results[0];
   								if(result.sffxcp == "1"){//已经测评过
   									appUtils.pageInit("xjb/riskHint","xjb/electronicContract");//已经测评过
   								}else{
   									appUtils.pageInit("xjb/riskHint","xjb/riskAssessment");
   								}
   							}else{
   								layerUtils.iLoading(false);
   								//后台返回的提示信息不友好
   								var error = data.error_info;
   								if(error.indexOf("SQL")> -1){
   									error = error.split("SQL")[0];
   									var len = error.length;
   									error = error.substring(0,len-2);
   								}
   								layerUtils.iAlert(error);
   							}
   						});
   					}
   				},2000);
   			});
   		});
   	}

   	/**
   	 * 设置参与状态
   	 */
   	function setCyzt(){
   		var user=appUtils.getSStorageInfo("userinfo");
   		var userinfo=JSON.parse(user);
   		var s="1002";
   		if(userinfo.user_type=="0"){
   			s="1001";
   		}
   		var param = {
   			"account":appUtils.getSStorageInfo("fund_account"),
   			"market":1,
   			"elecstatus":1,
   			"ezt_name":userinfo.user_code,
   			"ticket":"",
   			"risk_uncover":0,
   			"com_sign":0,
   			"survey_sn":s,
   			"entrust_way":"SJWT"
   		};

   		service.setCyzt(param,function(data){
   			if(data.error_no == 0){
   				stepCheck();
   			}else{
   				layerUtils.iLoading(false);
   				var error = data.error_info;
   				//后台返回的提示信息不友好
   				if(error.indexOf("SQL")> -1){
   					error = error.split("SQL")[0];
   					var len = error.length;
   					error = error.substring(0,len-2);
   				}
   				layerUtils.iAlert(error);
   			}
   		});
   	}
   	/**
   	 * 流程检测 --- 现金宝
   	 */
   	function stepCheck(){
   		var user=appUtils.getSStorageInfo("userinfo");
   		var userinfo=JSON.parse(user);
   		var s="1002";
   		if(userinfo.user_type=="0"){
   			s="1001";
   		}
   		var param = {
   			"fund_account":appUtils.getSStorageInfo("fund_account"),
   			"sign":4,
   			"ezt_name":userinfo.user_code,
   			"ticket":"",
   			"survey_sn":s
   		};
   		service.isCompleteStep(param,function(data){
   			if(data.error_no == 0){
   				var result = data.results[0];
   				if(result.sfkh == "1"){//已经开户
   					if(result.sfqsdzqmyds == "1"){//是否签署电子协议
   						if(result.sffxcp == "1"){//是否风险测评
   							if(result.sfqsdzht == "1"){//合同已签署
   								var par = {
   									"branch_no":appUtils.getSStorageInfo("branch_no"),
   									"account":appUtils.getSStorageInfo("fund_account"),
   									"market":"1",
   									"eztName":userinfo.user_code,
   									"ticket":""
   								};
   								service.queryHtzt(par,function(data){//查询合同状态
   									if(data.error_no == 0){
   										var result = data.results[0];
   										if(result.electronic_contract_status == "1"){//状态为参与，直接进入业务操作
   											appUtils.pageInit("account/userCenter","xjb/setReservation",{});
   										}else{//修改状态
   											appUtils.pageInit("account/userCenter","xjb/setState",{});
   										}
   									}else{
   										layerUtils.iLoading(false);
   										layerUtils.iAlert(data.error_info);
   									}
   								});
   							}else{//没有签署合同
   								appUtils.pageInit("account/userCenter","xjb/electronicContract",{});//签署电子合同
   							}
   						}else{//没有风险测评
   							appUtils.pageInit("account/userCenter","xjb/fxcp",{});//风险测评
   						}
   					}else{//没有签署电子协议
   						appUtils.pageInit("account/userCenter","xjb/electronicAgreement",{});//签署电子协议
   					}
   				}else{//没有开TA账户
   					appUtils.pageInit("account/userCenter","xjb/index");//走开户
   				}
   			}else{
   				layerUtils.iLoading(false);
   				layerUtils.iAlert(data.error_info);
   			}
   		});
   	}

   	/*
   	 * 销毁页面
   	 */
   	function destroy(){

   	}

   	var base = {
   			"init":init,
   			"bindPageEvent":bindPageEvent,
   			"destroy":destroy
   	};
   	//暴露方法
   	module.exports = base;
   });
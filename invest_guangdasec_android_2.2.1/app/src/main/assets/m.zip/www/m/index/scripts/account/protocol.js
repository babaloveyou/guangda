/**
 * 光大富尊
 */
define(function(require, exports, module){ 
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
		layerUtils = require("layerUtils"),
		gconfig = require("gconfig"),
		global = gconfig.global,
		_pageId = "#account_protocol ";
	/* 私有业务模块的全局变量 end */
	
	function init(){}
	
	function bindPageEvent(){
		/* 返回  */
		appUtils.bindEvent($(_pageId+".icon_back span"),function(e){
			appUtils.pageBack();
		});
	}
	
	function destroy(){}
	
	var index = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	module.exports = index;
});
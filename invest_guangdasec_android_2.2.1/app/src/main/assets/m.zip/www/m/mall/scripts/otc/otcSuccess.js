/**
 * 风险测评结果
 */
define(function(require, exports, module) 
	{
	var appUtils = require("appUtils");
	var gconfig = require("gconfig");
	var service = require("mobileService");//业务层接口，请求数据
	var global = gconfig.global;
	var layerUtils = require("layerUtils");
	var _pageId ="#otc_otcSuccess ";

	/*初始化*/
	function init()
	{
		
	}

	function bindPageEvent() 
	{

		/* 绑定返回事件 */
		appUtils.bindEvent($(_pageId+" .top_title .icon_back"),function(){
			appUtils.pageBack();
		});
		
		/*立即绑卡 */
		appUtils.bindEvent($(_pageId+" #bandCard"),function(){
			
		});
		
		/*下一步 */
		appUtils.bindEvent($(_pageId+" #complete"),function(){
			appUtils.pageInit("otc/otcSuccess","account/userCenter",{});
		});
	}

	function destroy()
	{
		service.destroy();
	}

	var otcSuccess = 
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = otcSuccess;

	});
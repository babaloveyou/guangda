/**
 * 
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils");
	var layerUtils = require("layerUtils");
	var gconfig = require("gconfig");
    var global = gconfig.global;
    var common = require("common");
    var service_news = require("service_news");
    //上下滑动组件
    var VIscroll = require("vIscroll");
    var vIscroll = {"scroll":null,"_init":false}; 
    var _pageId = "#details_newsList ";
    var _catalogId = "5";   //栏目编号
    
    var _current_page = 1;   //当前第几页
    var _num_page=global.num_page;   //每页多少条数据
    var _upHandleFlag=false;  //记录是否能上拉加载下一页
	var _jumpDetails = false;
    
    /**
     * 初始化
     */
	function init(){
		$(_pageId + ".main").height($(window).height() - $(_pageId + ".header").height());
		$(_pageId + ".main").css("overflow-y","auto ");
		
		_catalogId = appUtils.getPageParam("catalogId");   //首页传过来的栏目编号
		
		if(!_catalogId || _catalogId == null || _catalogId == "undefined"){
			layerUtils.iMsg(-1,"获取栏目编号失败!");
			return;
		}
		//初始化顶部标题
		$(_pageId + ".title").text("内参 · " + appUtils.getSStorageInfo("catalogTit"));
		initVIScroll();   //上下滑动组件初始化
		if(!appUtils.getSStorageInfo("flag")){
			_current_page = 1;
			$(_pageId + ".w_list").html("").css("background-color","#fff");
			queryInformationList(_current_page);   //查询微资讯列表,初始化查询第一页
		}else if($(_pageId + ".w_list ul").length == 0){
			queryInformationList(_current_page);
		}else{
			var articleId=appUtils.getPageParam("articleId");  //获取文章详情页面传回的文章id
			var li=$(_pageId + ".w_list ul li");
			for(var i=0;i<li.length;i++){
				if($(li[i]).attr("articleid") == articleId){
					var em=$(_pageId + ".w_list ul li").eq(i);
					if(common.queryLikeStatus(articleId)>-1){ //加点赞状态
						//修改点赞数和点赞状态
						em.find(".w_bot .praise").addClass("on");
						common.queryBrowseLikeNum(articleId,em);
					}else{//取消点赞状态
						em.find(".w_bot .praise").removeClass("on");
						common.queryBrowseLikeNum(articleId,em);
					}
				}
			}
		}
		appUtils.setSStorageInfo("flag",false);
		
		//列表回顶部事件
		common.backTop(_pageId);
    }
	
	/**
	 * 事件绑定
	 */
	function bindPageEvent(){
		//返回按钮
		appUtils.bindEvent($(_pageId + ".header_inner .icon_back"), function(e){
//			_catalogId = "";
			_current_page = 1;
			$(_pageId + ".w_list").html("").css("background-color","#fff");
			if(vIscroll._init){
				vIscroll.scroll.destroy();
				vIscroll.scroll = null;
				vIscroll._init = false;
			}
			appUtils.pageInit("details/newsList","home/newsHome",{});
			e.stopPropagation();
		});
	}
	
	/**
	 * 销毁
	 */
	function destroy(){
		_catalogId = "";
		if(!_jumpDetails){//不是跳转文章详情
			$(_pageId + ".w_list").html("").css("background-color","#fff");
			_current_page = 1;
			if(vIscroll._init){
				vIscroll.scroll.destroy();
				vIscroll.scroll = null;
				vIscroll._init = false;
			}
		}
		_jumpDetails=false;
	}
	
	
	//查询微资讯列表
	function queryInformationList(_current_page){
		var param = {
			"catalog_id":_catalogId,
			"current_page":_current_page,    //第几页
			"num_page":_num_page             //每页多少条
		};
		service_news.queryInformationListPage(param,queryInformationListCallBack,{"isLastReq":true,"isShowWait":true});
//		service_news.queryInformationList(param,queryInformationListCallBack,{"isLastReq":true,"isShowWait":true});
	}
	//查询微资讯列表回调
	function queryInformationListCallBack(data){
		if(data.error_no == 0){
			var results = data.results;
			var strHTML = "";
			if(results.length>0){
				if(_current_page == 1){
					strHTML += "<ul>";
					for (var i=0;i<results.length;i++){ 
						strHTML += createHTML(results[i]);
					}
					strHTML += "</ul>";
					$(_pageId + ".w_list").html(strHTML).css("background-color","#fff");
				}else{
					for (var i=0;i<results.length;i++){ 
						strHTML += createHTML(results[i]);
					}
					$(_pageId + ".w_list ul").append(strHTML);
				}
				//文章点赞
				common.addLike(_pageId);
				
				//点击跳转文章内容
				appUtils.bindEvent($(_pageId + ".w_list ul li"), function(e){
					 _jumpDetails = true;
					var articleId = $(this).attr("articleId");   //文章编号
					var author=$(this).attr("author");
					appUtils.pageInit("details/newsList","details/detailsShare",{"returnPage":"details/newsList","catalogId":_catalogId,"articleId":articleId,"author":author});
					e.stopPropagation();
				},"click");
				//如果加载文章数目不小于每页显示数目
				if(results.length>=_num_page){
					$(_pageId + ".visc_pullUp").show();   //展示上拉加载下一页
					_upHandleFlag = true;   //能上拉加载下一页
					_current_page++;        //页数+1
				}else{
					_upHandleFlag = false;   //不能上拉加载下一页
					$(_pageId + ".visc_pullUp").css("display","none");  //隐藏上拉加载下一页
				}
			}else{
				if(_current_page == 1){  //第一页没有内容则显示
					strHTML += "<div class='no_data' style='margin:50% auto;'>";
					strHTML += "<span class='icon'></span>";
					strHTML += "<p style='text-align:center;'>暂无列表信息</p>";
					strHTML += "</div>";
					$(_pageId + ".w_list").html(strHTML).css("background-color","#F4F4F4");
					layerUtils.iAlert("未查询到相应的文章列表信息");
				}
				_upHandleFlag = false;   //不能上拉加载下一页
				$(_pageId + ".visc_pullUp").css("display","none");  //隐藏上拉加载下一页
			}
			//设置文章列表，标题和摘要超过指定行数用...显示titLineNum
			common.setArticleList(_pageId,global.titLineNum,global.synopsisLineNum);
		}else{
			layerUtils.iAlert(data.error_info);
		}
		initVIScroll();   //上下滑动组件初始化
	}
	
	//生成资讯列表HTML
	function createHTML(element){
		var strHTML = "";
		strHTML += "<li articleId='"+element.article_id+"' author='"+element.author+"'>";   		//编号
		strHTML += "<h6>"+element.title+"</h6>";   						//标题
		strHTML += "<p>"+element.brief+"</p>";   						//简介
		strHTML += "<div class='w_bot clearfix'>";
		strHTML += "<time><nobr>"+element.publish_date+"</nobr></time>";
		strHTML += "<em class='focus' focusNum='"+element.browse_num+"'>"+common.overAMillion(element.browse_num)+"</em>";		//浏览数
		if(common.queryLikeStatus(element.article_id)>-1){
			strHTML += "<em class='praise on' praiseNum='"+element.support_num+"'>"+common.overAMillion(element.support_num)+"</em>";   //点赞数
		}else{
			strHTML += "<em class='praise' praiseNum='"+element.support_num+"'>"+common.overAMillion(element.support_num)+"</em>";   //点赞数
		}
		strHTML += "</div>";
		strHTML += "</li>";
		return strHTML;
	}
	
	
	/**
	 * 初始化上下滑动组件（在初始化的时候调用这个）
	 */
	function initVIScroll(){
		if(!vIscroll._init){
			var config = {
				"isPagingType": false,		//false表示是微博那种累加形式，true表示分页形式
				"visibleHeight": $(window).height() - $(_pageId+".top_title").height() - 6  ,//显示内容区域的高度，当isPaingType为false时传
				"container": $(_pageId+" #v_container_funds_jj"),	
				"wrapper":$(_pageId+" #v_wrapper_funds_jj"),	
				"downHandle": function() {				//下拉获取上一页数据方法
					_current_page = 1;
					queryInformationList(_current_page);   //查询微资讯列表,下拉获取第一页
				},
				"upHandle": function() {    //上拉加载下一页数据方法
					if(_upHandleFlag){
						queryInformationList(_current_page);
					}
				},
				"wrapperObj": null
			};
			vIscroll.scroll = new VIscroll(config); 	//初始化，需要做if(!hIscroll._init)判断
			vIscroll._init = true; 						//尽量只初始化一次，保持性能
		}else{
			vIscroll.scroll.refresh();
		}
//		$(_pageId + ".visc_pullUp").css("display","none");
	}
	
	function pageBack(){
		_current_page = 1;
		$(_pageId + ".w_list").html("").css("background-color","#fff");
		if(vIscroll._init){
			vIscroll.scroll.destroy();
			vIscroll.scroll = null;
			vIscroll._init = false;
		}
		appUtils.pageInit("details/newsList","home/newsHome",{});
	}
	
	var base = {
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy,
		"pageBack": pageBack
	};
	module.exports = base;
});
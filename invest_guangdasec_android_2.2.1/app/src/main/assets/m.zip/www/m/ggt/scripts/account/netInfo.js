/**
 * 信用资产审核
 */
define(function(require, exports, module){
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
	    service = require("investService").getInstance(),  //业务层接口，请求数据
		global = require("gconfig").global,
		layerUtils = require("layerUtils"),
		marketvalue = "",  //证券账户资产
		net_asset = "",  //信用账户资产
		totalValue = "",
		fundsFlag = "",  //等于1的时候满足资金条件   等于2的时候不满足资金条件
		_pageId = "#account_netInfo";
	/* 私有业务模块的全局变量 end */
	
	function init()
	{
		marketvalue = parseFloat(appUtils.getSStorageInfo("marketvalue")).toFixed(2);   //证券账户资产
		net_asset = parseFloat(appUtils.getSStorageInfo("net_asset")).toFixed(2);   //信用账户资产
		totalValue = parseFloat(marketvalue) + parseFloat(net_asset);   //总资产
		$(_pageId+" .ver_value ul li:eq(0) strong").html(marketvalue);
		$(_pageId+" .ver_value ul li:eq(1) strong").html(net_asset);
		$(_pageId+" .value_box h5").html(parseFloat(totalValue).toFixed(2)+"<small>/元</small>");
		if(totalValue >= 500000){
			$(_pageId+" .ver_notice p").html("您的证券账户资产已满足≥50万要求，请继续满足其他条件。");
			$(_pageId+" #confirm").show();
			$(_pageId+" #cancel").hide();
			fundsFlag = "1";
		}else{
			$(_pageId+" .ver_notice p").html("您的证券账户资产未满足≥50万要求，暂时无法开通港股通业务。");
			$(_pageId+" #confirm").hide();
			$(_pageId+" #cancel").show();
			fundsFlag = "2";
		}
	}
	
	function bindPageEvent()
	{
		//绑定确认按钮
		appUtils.bindEvent($(_pageId+" #confirm"),function(){
			appUtils.setSStorageInfo("value",totalValue);
			appUtils.pageInit("account/netInfo","account/mainPage",{"fundsFlag":fundsFlag});
		});
		
		//绑定返回
		appUtils.bindEvent($(_pageId+" .icon_back"),function(){
			appUtils.setSStorageInfo("value",totalValue);
			appUtils.pageInit("account/netInfo","account/mainPage",{"fundsFlag":fundsFlag});
		});
		
		//绑定退出
		appUtils.bindEvent($(_pageId+" #cancel"),function(){
			appUtils.setSStorageInfo("value",totalValue);
			appUtils.pageInit("account/netInfo","account/mainPage",{"fundsFlag":fundsFlag});
		});
	}
	
	function destroy()
	{
		service.destroy();
	}

	
	/* 清理界面元素*/
	function cleanPageElement()
	{
		
	}
	
	var netInfo = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	
	module.exports = netInfo;
});
﻿/**
 * 程序入口配置读取
 * 项目开发时需要的自定义配置
 * 另外：configuration为系统配置模块或者配置模板
 * 这里可以扩展，支持多个系统共用一个项目：
 * 思路：在最开始的地方做一个sysCode的获取，然后在这个模块初始化时赋不同系统的configuration配置模块的引用，
 * 当然还要做修改的地方，比如地址栏hash处理，需要增加sysCode（涉及到的模块main和appUtils）
 */
define(function(require, exports, module) {
	var configuration = {
		"defaultPage": {"pageCode": "account/userCenter", "jsonParam":{}},
		"projName": "index",
		"firstLoadCss": ["/css/style.css","/css/css.css"],
		"layerTheme": "d",
		"resultsParser": {"error_no": "error_no", "error_info": "error_info"},
		"filters": {
//			"-999": {"pageCode": /"account/loginIn", "jsonParam": {}, "error_info":"请先登录"} //用户没有登陆
			"-999": {"moduleAlias":"common", "moduleFuncName":"filterLoginOut"} //用户没有登陆或者登陆超时
		},
//		"loginPage": {"pageCode": "account/loginIn", "jsonParam":{}},
		// 引导页配置
//		"guidePage": {"pageCode": "account/guide", "jsonParam":{}},
		// 项目别名配置
		"pAlias": {
			"putils": "index/scripts/common/putils",
			"serviceImp": "index/service/scripts/mobileService_fz",
			"keyPanel": "index/scripts/keypanel_xf/scripts/keyTelPanel",
			"keyAbcPanel": "index/scripts/keypanel_xf/scripts/keyAbcPanel",
			"globalFunc": "common/globalFunc",
			"common": "common/common"
		},
		"checkPermission": {"moduleAlias":"common", "moduleFuncName":"checkPermission_fz"},
		"firstLoadIntf": {"moduleAlias":"common", "moduleFuncName":"firstLoadFunc"},
		"global": {
			"hardId" : "",
			"phone" : "",
			"checkLoginPageCode":["account/userCenter","account/cybzq","account/cybFxcp","account/wdcc","account/drcj","account/drwt","account/drzj","account/riskCautionPage","account/marketCon","xjb/index","xjb/electronicAgreement","xjb/electronicContract","xjb/fxcp","xjb/queryQuotient","xjb/riskAssessment","xjb/riskHint","xjb/riskResult","xjb/setReservation","xjb/setReserveFunds","xjb/setState","otc/riskDisclosure"],
			"aesKey" : "thinkive", //加密key，位数必须为4的倍数
			"protocol" : "ajax", //协议
			"rzxqPath" : "http://116.236.247.175:80/servlet/json", // 融资行权接入地址
			"backList":"http://www.ebscn-am.com/aboutusContent.html?msgId=6m0MKRYEMJ",  //T+0 可签约银行列表 


		   // 仿真外网测试环境
//			"imgUrl" : "http://10.0.29.154:63/servlet/Image", // 验证码地址
//			"pdfUrl" : "http://10.0.29.154:63", //pdf地址
//			"serverPath" : "http://10.0.29.154:63/servlet/json", // 富尊网接入地址
//			"serverPath_open" : "http://10.0.29.154:81/servlet/json", // 激活接入地址
//			"serverPath_mall" : "http://10.0.29.154:60/servlet/json", // 商城接入地址
//			"serverPath_xdt" : "http://10.0.29.154:62/erz/servlet/json", // 小贷接入地址
//			"serverPath_ggt": "http://10.0.29.154:64/ggtqy/servlet/json", // 港股通环境
//			"loginPath" : "http://10.0.29.154:63/servlet/TokenAction?function=tokenAuth",// 统一登陆
//			"ggtExistPath" : "http://10.0.29.154:64/ggtqy/servlet/TokenAction?function=loginOut",// 港股通退出登录

			// 仿真外网测试环境
//			"imgUrl" : "http://116.236.247.175:84/servlet/Image", // 验证码地址
//			"pdfUrl" : "http://116.236.247.175:84", //pdf地址
//			"serverPath" : "http://116.236.247.175:84/servlet/json", // 富尊网接入地址
//			"serverPath_open" : "http://116.236.247.175:81/servlet/json", // 激活接入地址
//			"serverPath_mall" : "http://116.236.247.175:83/servlet/json", // 商城接入地址
//			"serverPath_xdt" : "http://116.236.247.175:82/erz/servlet/json", // 小贷接入地址
//			"serverPath_ggt": "http://116.236.247.175:88/ggtqy/servlet/json", // 港股通环境
//			"loginPath" : "http://116.236.247.175:84/servlet/TokenAction?function=tokenAuth",// 统一登陆
//			"ggtExistPath" : "http://116.236.247.175:88/ggtqy/servlet/TokenAction?function=loginOut",// 港股通退出登录
//
			//仿真内网测试环境
//			"imgUrl" : "http://10.84.134.24:84/servlet/Image", // 验证码地址
//			"pdfUrl" : "http://10.84.134.24:84", //pdf地址
//			"serverPath" : "http://10.84.134.24:84/servlet/json", // 富尊网接入地址
//			"serverPath_open" : "http://10.84.134.24:81/servlet/json", // 激活接入地址
//			"serverPath_mall" : "http://10.84.134.24:83/servlet/json", // 商城接入地址
//			"serverPath_xdt" : "http://10.84.134.24:82/erz/servlet/json", // 小贷接入地址
//			"serverPath_ggt": "http://10.84.134.24:88/ggtqy/servlet/json", // 港股通环境
//			"loginPath" : "http://10.84.134.24:84/servlet/TokenAction?function=tokenAuth", // 统一登陆
//			"ggtExistPath" : "http://10.84.134.24:88/ggtqy/servlet/TokenAction?function=loginOut"// 港股通退出登录
//
	        //内网测试环境
//			"imgUrl" : "http://10.0.39.118:8080/servlet/Image", // 验证码地址
//			"pdfUrl" : "http://10.0.39.118:8080", //pdf地址
//			"serverPath" : "http://10.0.39.118:8080/servlet/json", // 富尊网接入地址
//			"serverPath_open" : "http://10.0.39.112:8080/servlet/json", // 激活接入地址
//			"serverPath_mall" : "http://10.0.39.116:8081/servlet/json", // 商城接入地址
//			"serverPath_xdt" : "http://10.0.39.115:8081/erz/servlet/json", // 小贷接入地址
//		    "serverPath_ggt": "http://10.0.39.112:8080/ggtqy/servlet/json", // 港股通环境
//			"loginPath" : "http://10.0.39.118:8080/servlet/TokenAction?function=tokenAuth",// 统一登陆
//			"ggtExistPath" : "http://10.0.39.112:8080/ggtqy/servlet/TokenAction?function=loginOut"// 港股通退出登录

			//生产环境
			"imgUrl" : "https://e.ebscn.com/servlet/Image", // 验证码地址
			"pdfUrl" : "https://e.ebscn.com", //pdf地址
			"serverPath" : "https://e.ebscn.com/servlet/json", // 富尊网接入地址
			"serverPath_open" : "https://ekh.ebscn.com/servlet/json", // 激活接入地址
			"serverPath_mall" : "https://sc.ebscn.com/servlet/json", // 商城接入地址
			"serverPath_xdt" : "https://e.ebscn.com/rz/servlet/json", // 小贷接入地址
		    "serverPath_ggt": "https://ekh.ebscn.com/ggtqy/servlet/json", // 港股通环境
			"loginPath" : "https://e.ebscn.com/servlet/TokenAction?function=tokenAuth", // 统一登陆
			"ggtExistPath" : "https://ekh.ebscn.com/ggtqy/servlet/TokenAction?function=loginOut"// 港股通退出登录

		
			//全真
//			"imgUrl" : "http://10.0.74.49:84/servlet/Image", // 验证码地址
//			"pdfUrl" : "http://10.0.74.49:84", //pdf地址
//			"serverPath" : "http://10.0.74.49:84/servlet/json", // 富尊网接入地址
//			"serverPath_open" : "http://10.0.74.49:81/servlet/json", // 激活接入地址
//			"serverPath_mall" : "http://10.0.74.49:83/servlet/json", // 商城接入地址
//			"serverPath_xdt" : "http://10.0.74.49:82/rz/servlet/json", // 小贷接入地址
//			"serverPath_ggt": "http://10.0.74.49:88/ggtqy/servlet/json", // 港股通环境
//			"loginPath" : "http://10.0.74.49:84/servlet/TokenAction?function=tokenAuth", // 统一登陆
//			"ggtExistPath" : "http://10.0.74.49:88/ggtqy/servlet/TokenAction?function=loginOut"// 港股通退出登录

		},
		"isDirectExit": false,
		"ajaxTimeout": 30,
		"isClickShadeHide": false
	};
	//暴露对外的接口
	module.exports = window.configuration = configuration;
});

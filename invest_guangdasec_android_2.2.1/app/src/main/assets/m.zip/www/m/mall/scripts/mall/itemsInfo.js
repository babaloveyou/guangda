/**
 * 咨询列表
 */
define(function(require, exports, module)
	{	
	var service = require("mobileService"); //业务层接口，请求数据
	var appUtils = require('appUtils'),
	putils = require("putils"),
	layerUtils = require("layerUtils"),
	gconfig = require("gconfig"),
	global = gconfig.global,
	platform=gconfig.platform,
	convDict = require("convDict"),
	VIscroll = require("vIscroll");
	var _pageId ="#mall_itemsInfo";
	var constants=require("constants");//常量类
	var pagingObjArr = [{"total_pages":0,"curr_page":0}]; //消息分页对象数组，这个页面只有一个分页，简单分页
	var URL=global.url;
	var globalFunc = require("globalFunc");
	//1、初始化
	function init() 
	{
		configInfo(); 
		//globalFunc.backIndex($(_pageId+" .back_app")); // 返回App首页
		$(_pageId+" .tab_nav ul li:eq(4)").addClass(" active").siblings("li").removeClass(" active");
	}

	//初始化咨询产品
	function configInfo ()
	{
		var param=
		{
			"product_shelf":constants.product_shelf.SHELF_ON,
			"page":"1",
			"numPerPage":"4",
			"recommend_type":"",//推荐属性
			"brand_id":"",		//品牌编号
			"is_hot_sale":"",//是否按照热销排序  1排序 0或其他不排
			"info_type":"",
			"father_product_id":""
		}

		service.findInfo(param,function(data){
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}

			infoItems(data);

		});
	}

	//处理咨询产品
	function infoItems(data)
	{
		var total_pages = data.results[0].totalPages;
		var curr_page = data.results[0].currentPage;
		var total_rows = data.results[0].totalRows;
		total_pages = total_pages ? total_pages:0;
		curr_page = curr_page ? curr_page:0;
		total_rows=total_rows?total_rows:0;
		pagingObjArr[0].total_pages=total_pages;
		$(_pageId+" em[name='totalPage']").html(total_pages);
		pagingObjArr[0].curr_page=curr_page;
		$(_pageId+" em[name='curPage']").html(curr_page);
		//显示多少条数据
		$(_pageId+" em[name='total_rows']").html(total_rows);

		var allRecommendStr ="";
		var list =  data.results[0].data;
		var len = list.length;
		for( var i = 0; i<len ; i++)
		{
			var perData = list[i];
			allRecommendStr += handlePerItem(perData,i);
		}
		$(_pageId+" .pro_list02").html(allRecommendStr);

		//绑定跳转详情事件
		appUtils.bindEvent($(_pageId+" .pro_list02  li[product_id]"),function()
			{
			var pageInParam=
			{
				"product_id" : $(this).attr("product_id")
			};
			appUtils.pageInit("mall/itemsInfo", "mall/itemsInfoDetail", pageInParam);
			});

		//上一页、下一页disabled效果
		if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
			$(_pageId + " span[name='aNextPage']").removeClass("blue");
			$(_pageId + " span[name='aPrePage']").addClass("blue");
		}
		else if (pagingObjArr[0].curr_page == 1) {
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + " span[name='aNextPage']").addClass("blue");
		}
		else {
			$(_pageId + " span[name='aPrePage']").addClass("blue");
			$(_pageId + " span[name='aNextPage']").addClass("blue");
		}

		if (pagingObjArr[0].total_pages<2) {
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + "  span[name='aNextPage']").removeClass("blue");
		}

		if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
			$(_pageId+" #isNull").html("暂无数据");
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + " span[name='aNextPage']").removeClass("blue");
		}

	}

	//显示咨询产品  
	function handlePerItem(perData, idx)
	{
		var product_id = perData.product_id;//ID
		var product_name= perData.product_name;//产品名称
		var product_description=perData.product_description; //产品详情
		var rules_price=perData.rules_price;//价格
		var img_url_l=perData.img_url_l//图片地址
		var rules_explanation=perData.rules_explanation;//元/月
		var img_url_m=perData.img_url_m;

		if(platform=="2"){
			if(product_description.length>=30){
				var oneRecommendStr="<li class='pro_list_item' product_id="+product_id+">"+"<i class='new'>热销</i>"+"<div class='pic'>"+"<a href='javascript:;'>"+"<img src="+URL+img_url_l+"/>"+
				"<p class='p5-0-0-15'><span class='star'><em class='level level4'></em></span></p>"+"</a>"+"</div>"+"<div class='text' style='border:none;height:auto;line-height:22px;'>"+
				"<a href='javascript:;'>"+"<h2>"+product_name+"</h2>"+"<span><em>"+rules_price+"</em>"+rules_explanation+"</span>"+"<p>"+product_description.substring(0,30)+"......</p>"+
				"</a>"+"</div>"+"</li>";
			}else{
				var oneRecommendStr="<li class='pro_list_item' product_id="+product_id+">"+"<i class='new'>热销</i>"+"<div class='pic'>"+"<a href='javascript:;'>"+"<img src="+URL+img_url_l+"/>"+
				"<p class='p5-0-0-15'><span class='star'><em class='level level4'></em></span></p>"+"</a>"+"</div>"+"<div class='text' style='border:none;height:auto;line-height:22px;'>"+
				"<a href='javascript:;'>"+"<h2>"+product_name+"</h2>"+"<span><em>"+rules_price+"</em>"+rules_explanation+"</span>"+"<p>"+product_description+"</p>"+
				"</a>"+"</div>"+"</li>";
			}
		}
		else{
			if(product_description.length>=43){
				var oneRecommendStr="<li class='pro_list_item' product_id="+product_id+">"+"<i class='new'>热销</i>"+"<div class='pic'>"+"<a href='javascript:;'>"+"<img src="+URL+img_url_l+"/>"+
				"<p class='p5-0-0-15'><span class='star'><em class='level level4'></em></span></p>"+"</a>"+"</div>"+"<div class='text' style='border:none;height:auto;line-height:22px;'>"+
				"<a href='javascript:;'>"+"<h2>"+product_name+"</h2>"+"<span><em>"+rules_price+"</em>"+rules_explanation+"</span>"+"<p>"+product_description.substring(0,43)+"......</p>"+
				"</a>"+"</div>"+"</li>";
			}else{
				var oneRecommendStr="<li class='pro_list_item' product_id="+product_id+">"+"<i class='new'>热销</i>"+"<div class='pic'>"+"<a href='javascript:;'>"+"<img src="+URL+img_url_l+"/>"+
				"<p class='p5-0-0-15'><span class='star'><em class='level level4'></em></span></p>"+"</a>"+"</div>"+"<div class='text' style='border:none;height:auto;line-height:22px;'>"+
				"<a href='javascript:;'>"+"<h2>"+product_name+"</h2>"+"<span><em>"+rules_price+"</em>"+rules_explanation+"</span>"+"<p>"+product_description+"</p>"+
				"</a>"+"</div>"+"</li>";
			}
		}

		return oneRecommendStr;
	}

	//处理上一页，下一页
	function handlePreNextPage(direction)
	{	
		var total_pages = pagingObjArr[0].total_pages;
		var   curr_page = pagingObjArr[0].curr_page;
		var   curPageNo = parseInt(curr_page) + direction ;
		if(curPageNo>0 && curPageNo <= total_pages && curPageNo != curr_page) //有效执行跳转页面条件
		{
			var param=
			{
				"product_shelf":constants.product_shelf.SHELF_ON,
				"page":curPageNo,
				"numPerPage":"4",
				"recommend_type":"",//推荐属性
				"brand_id":"",		//品牌编号
				"is_hot_sale":"",  //是否按照热销排序  1排序 0或其他不排
				"info_type":"",
				"father_product_id":""
			}
			service.findInfo(param,function(data)
				{
				if(data.error_no!="0")
				{
					layerUtils.iAlert(data.error_info);
					layerUtils.iLoading(false);
					return false;
				}
				infoItems(data);

				});
		}
		else
		{	 
			return false;
			customVIscroll.scroll.refresh();
		}
	}


	//2、事件绑定
	function bindPageEvent()
	{

        /* 绑定返回我的富尊主页 */
        appUtils.bindEvent($(_pageId+" .header .back_app"),function(e){
            var param_index = {"funcNo":"50101","moduleName":"main"};
            require("external").callMessage(param_index);
            e.stopPropagation();
        });
		// 点击上一页、下一页 
		appUtils.bindEvent($(_pageId+" span[name='aPrePage']"),function(){	handlePreNextPage(-1);});
		appUtils.bindEvent($(_pageId+" span[name='aNextPage']"),function(){handlePreNextPage(1);});

		// 点击首页 
		appUtils.bindEvent($(_pageId+" #mainPage"),function(){appUtils.pageInit("mall/itemsInfo","account/mainPage",{});});

		// 点击理财
		appUtils.bindEvent($(_pageId+" #finan"),function(){appUtils.pageInit("mall/itemsInfo","mall/itemsFinan",{});});

		//点击资讯
		appUtils.bindEvent($(_pageId+" #info"),function()	{appUtils.pageInit("mall/itemsInfo","mall/itemsInfo",{});});

		// 点击基金 
		appUtils.bindEvent($(_pageId+" #fund"),function(){appUtils.pageInit("mall/itemsInfo","mall/itemsFund",{});});

		// 点击服务 
		appUtils.bindEvent($(_pageId+" #serv"),function(){appUtils.pageInit("mall/itemsInfo","mall/itemsServ",{});});
		
		//点击OTC
		appUtils.bindEvent($(_pageId+" #otc"),function(){appUtils.pageInit("mall/itemsInfo","mall/itemsOTC",{});});

		//点击 LOGO 
		appUtils.bindEvent($(_pageId+" .logo"),function(){appUtils.pageInit("mall/itemsInfo","account/mainPage")});

		//点击 返回顶部
		appUtils.bindEvent($(_pageId+" .back_btn"),function(){$('body,html').animate({scrollTop:0},1000);return false;});
		
		//点击搜索图标 
		appUtils.bindEvent($(_pageId+" .icon_search"),function(){appUtils.pageInit("mall/itemsInfo","mall/fundSearch",{"product_sub_type":"2"})});

		//点击 个人中心 
		appUtils.bindEvent($(_pageId+"  .icon_info"),function()
			{
				appUtils.pageInit("mall/itemsInfo","account/userCenter",{});
			});

	}

	//3、销毁
	function destroy()
	{

	} 

	var itemsInfo =
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};
	module.exports = itemsInfo;

	});
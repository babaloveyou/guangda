/**
* 查看协议
*/
define(function(require, exports, module){
	var appUtils = require("appUtils"),
		global = require("gconfig").global,
		service = require("investService").getInstance(),  //业务层接口，请求数据
		layerUtils = require("layerUtils"),
		_pageId = "#account_showProtocol",
		 protocol_id="",
		 util=require("utils"),
		 summary="",
		 _prePageCode="";
	
	function init(){
		 _prePageCode = appUtils.getPageParam("_prePageCode");
		// 清除原有数据
//		$(_pageId+" .top_title h2").text("");
		$(_pageId+" .rule_entry p").text("");
		protocol_id = appUtils.getPageParam("protocol_id");
		 summary = appUtils.getPageParam("summary");
		var param = {
			"econtract_no" : protocol_id,
			"econtract_version":""
		}
		//查询协议内容
		service.getProtocolInfo(param,function(data){
			if(error_no = data.error_no)
			{
				$(_pageId+" .top_title h2").text(data.results[0].econtract_name);
				$(_pageId+" .rule_entry p").append(data.results[0].econtract_content);
			}
			else
			{
				layerUtils.iAlert(data.error_info,-1);
			}
		});
		util.setContentHeight(_pageId +" .main",_pageId+" .header");
	}
	function bindPageEvent(){
		// 绑定返回
		appUtils.bindEvent($(_pageId+" .header .icon_back"),function(){
			appUtils.pageBack();
		});
		
		//绑定返回按钮
		appUtils.bindEvent($(_pageId+" .ce_btn"),function(){
			
			if(_prePageCode == "account/riskInfo"){
				submitRiskProtocol();
			}
			else{
				appUtils.pageInit("account/showProtocol","account/signProtocol",{});
			}
		});
	}
	
	
	// 提交协议
	function submitRiskProtocol(){
		var protocol = {
				"protocol_id" : protocol_id,
				"summary" : summary
			}
	    var  protocolArray=new Array();
	    protocolArray.push(protocol);
		var signProtocolParam = {
				"user_id" : appUtils.getSStorageInfo("user_id"),
				"jsondata" : JSON.stringify(protocolArray),
				"ipaddr" : "",
				"macaddr" : "",
				"checksign" : "0"
		};
		service.queryOpenCheckSign(signProtocolParam,function(data){
			var error_no = data.error_no,
				error_info = data.error_info;
			if(error_no == "0"){
				riskFlag= "1";
				appUtils.setSStorageInfo("riskFlag",riskFlag);
				appUtils.pageInit("account/showProtocol","account/mainPage",{"riskFlag":riskFlag});
			}else{
				layerUtils.iAlert(error_info,-1);
			}
		});
	}
	
	function destroy(){
		// 将协议内容置空
//		$(_pageId+" .top_title h2").text("");
		$(_pageId+" .rule_entry p").text("");
		service.destroy();
	}
	
	var showProtocol = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	
	module.exports = showProtocol;
});
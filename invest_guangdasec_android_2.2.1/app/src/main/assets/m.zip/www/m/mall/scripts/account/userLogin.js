/**
 * 会员登录
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils");
	var gconfig = require("gconfig");
	var putils = require("putils");
	var service = require("mobileService"); //业务层接口，请求数据
	var global = gconfig.global;
	var validata = require("validatorUtil");
	var layerUtils = require("layerUtils");	
	var globalFunc = require("globalFunc");
	var keyPanel = require("keyPanel");//软键盘
	var _pageId ="#account_userLogin ";

	function init() {
		document.getElementById('trade_id').focus();
		$(_pageId+" #trade_pwd").val("");  // 清除密码
		$(_pageId+" #password em").html("交易密码");
		$(_pageId+" .input_custom").removeClass(" active");
		getCode();
		//globalFunc.backIndex($(_pageId+" .back_app")); // 返回App首页
		keyPanel.closeKeyPanel();
		$(_pageId+" #trade_pwd").val("111111");  // 清除密码
	}

	function bindPageEvent() {

		/*初始化键盘*/
		appUtils.bindEvent($(_pageId+" #password") ,function(e){
			var input_pwd = $(this);
			input_pwd.find("em").html("");  // 清空密码
			input_pwd.attr("data-password","");  // 清空密码值
			$(_pageId+" .input_custom").addClass("active");
			keyPanel.init_keyPanel(function(value){
				var curEchoText = input_pwd.find("em").html();  // 密码回显文本
				var input_pass_curPwd = input_pwd.attr("data-password") || "";  // 密码值
				var valInput=$(_pageId+" #trade_pwd");
				if(value == "del")
				{
					input_pwd.find("em").html(curEchoText.slice(0, -1));
					input_pwd.attr("data-password", input_pass_curPwd.slice(0, -1));
				}
				else
				{
					if(input_pass_curPwd.length < 6)
					{
						input_pwd.attr("data-password", input_pass_curPwd + value);  // 设置密码值
						input_pwd.find("em").html(curEchoText + "*");
						valInput.val(input_pass_curPwd + value);
					}
					else
					{
						layerUtils.iMsg(-1, "交易密码最多 6位!");
					}
				}
			}, input_pwd);
			e.stopPropagation();
//			$(_pageId+" #password em").html("");
//			$(_pageId+" .input_custom").addClass(" active");
//			$(_pageId+" #trade_pwd").val("");
//			var passwordInput=$(_pageId+" #password em");
//			var valInput=$(_pageId+" #trade_pwd");
//			keyPanel.init_keyPanel(_pageId,valInput.val(),valInput,function(pw)
//				{
//				var ch="";
//				for(var i=0;i<pw.length;i++){
//					ch+="*";
//				}
//				passwordInput.html(ch);
//				valInput.val(pw);
//				valInput.text("");
//				},"num","密码");
//			e.stopPropagation();	
		});

		//点击页面关闭软键盘
		appUtils.bindEvent($(_pageId),function(){
			$(_pageId+" .input_custom").removeClass(" active");
			var mesTrade = $(_pageId+"em").html();
			if(mesTrade ==""){
				$(_pageId+"em").html("交易密码");
			}
			keyPanel.closeKeyPanel();
		});

		/*重新获取验证码*/
		appUtils.bindEvent($(_pageId+" .code_pic") ,function(){
			getCode();  //获取验证码
		});

		/* 绑定返回首页事件 */
		appUtils.bindEvent($(_pageId+" .header .back_app"),function(){
			appUtils.pageInit("account/userLogin","account/mainPage",{});
		});

		/* 下一步 */
		appUtils.bindEvent($(_pageId+" .login_forget .login_btn") ,function(){
			var fund_account = $.trim($(_pageId+" #trade_id").val());
			var code = $.trim($(_pageId+" .code").val()); 
			if(fund_account == ""|| trade_pwd == "")
			{
				layerUtils.iMsg(-1,"账号不能为空！！！");
				return false;
			}
			if($.trim($(_pageId+" #trade_pwd").val())==""||$.trim($(_pageId+" #trade_pwd").val())==null)
			{
				layerUtils.iMsg(-1,"密码不能为空！！！");
				return false;
			}
			else if(code=="")
			{
				layerUtils.iMsg(-1,"验证码不能为空！！！");
				return false;
			}
			
			//加密
			service.getRSAKey({},function(data){
				if(data.error_no=="0")
				{
					var modulus = data.results[0].modulus;
					var publicExponent =data.results[0].publicExponent;
					var endecryptUtils = require("endecryptUtils");
					var trade_pwd=endecryptUtils.rsaEncrypt(modulus,publicExponent,$.trim($(_pageId+" #trade_pwd").val()));

						/*var param  = {
							"fund_account": fund_account,
							"trade_pwd": trade_pwd,
							"vf_code": code
						};*/
					   var param  = {
							"ezt_account": fund_account,
							"login_type":"E",
							"trade_pwd": trade_pwd,
							"vf_code": code
						};
						service.eztLogin(param,function(data){
							var error_no = data.error_no;
							var error_info = data.error_info;
							var result = data.results;//验证码输入错误
							if(error_info=='验证码输入错误')
							{	 
//								$(_pageId+" #password em").html("");  // 清除密码
//								$(_pageId+" #trade_pwd").val('');  //清除密码
								$(_pageId+" #code").val("");       // 清除验证码

								getCode();
								layerUtils.iMsg(0,"验证码输入错误");
								return false;

							}
							if(error_info!='调用成功')
							{	 
								$(_pageId+" #password em").html("");  // 清除密码
								$(_pageId+" #trade_pwd").val('');  //清除密码
								$(_pageId+" #code").val("");       // 清除验证码
								getCode();

							}
							if(error_no == "0" && result.length != 0){
								var token=result.token//富尊网token
								var eb_fortune_token=result.eb_fortune_token//富尊网token
								var trade_token=result.trade_token//快速交易token
								var xdt_token=result.xdt_token//小贷token
//								external.callFunction("55400",{key:"APP_XD",value:xdt_token});
//								external.callFunction("55400",{key:"APP_FZ",value:eb_fortune_token});
								/*把用户编号存到session*/
								if(result[0].user_id)
								{
									appUtils.setSStorageInfo("user_id",result[0].user_id);
								}
								/*把jsessionid存到session*/
								if(result[0].jsessionid)
								{
									appUtils.setSStorageInfo("jsessionid",result[0].jsessionid);
								}
								/*把用户名存到session*/
								if(result[0].user_name)
								{
									appUtils.setSStorageInfo("user_name",result[0].user_name);
								}
								/*把账户名存到session*/
								if(result[0].account_name)
								{
									appUtils.setSStorageInfo("account_name",result[0].account_name);
								}
								/*把资金账号存到session*/
								if(result[0].fund_account)
								{
									appUtils.setSStorageInfo("fund_account",result[0].fund_account);
								}
								/*把风险承受能力等级存到session*/
								if(result[0].risk_level)
								{
									appUtils.setSStorageInfo("risk_level",result[0].risk_level);
								}
								/*把风险承受能力存到session*/
								if(result[0].risk_level_txt)
								{
									appUtils.setSStorageInfo("risk_level_txt",result[0].risk_level_txt);
								}
								/*把手机号码存到session*/
								if(result[0].mobile_phone)
								{
									appUtils.setSStorageInfo("mobile_phone",result[0].mobile_phone);
									
//									alert(sessionStorage["project|mobile_phone"]);
								}
								/*把邮箱地址存到session*/
								if(result[0].user_mail)
								{
									appUtils.setSStorageInfo("user_mail",result[0].user_mail);
								}
								/*存cust_type到session*/
					    		if(result[0].cust_type){
					    			appUtils.setSStorageInfo("cust_type",result[0].cust_type);
					    		}
					    		appUtils.setSStorageInfo("fund_list",result.fund_list);
								appUtils.setSStorageInfo("ticket",result[0].ticket);
								appUtils.setSStorageInfo("cust_code",result[0].user_code);
								var param = {
//										"fund_list": ["40312002"]//880003167966
//										"fund_list": ["40636115"]//880001590147
//										"fund_list": ["40636114"]//880001590147
//										"fund_list": ["40636117"]
//										"fund_list": ["40636124"]//x 
//										"fund_list": ["600446"]//880000203991
//										"fund_list": ["40636127"]//880002159488
//										"fund_list": ["40636128"]//880001423617
//									    "fund_list": ["40356570"]//880000969135
//										"fund_list": ["40356575"]//880000684158
//										"fund_list": ["40356573"]//880001106652
//										"fund_list": ["88882569"]//880001314838
//										"fund_list": ["40364246"]//889003455358
//										"fund_list": ["40358427"]//880001959199
//										"fund_list": ["40367562"]//889003705536
//										"fund_list": ["40600260"]//880000154287
//										"fund_list": ["40628114"]//880000840215
//										"fund_list": ["40640375"]//889003631692
										"fund_list": ["40358111"]//880001692231
										
								};
								appUtils.setSStorageInfo("fund_list",param.fund_list);
								appUtils.setSStorageInfo("_isLoginIn","true");
								if(appUtils.getSStorageInfo("_loginInPageCode")){
									appUtils.pageInit("account/userLogin", appUtils.getSStorageInfo("_loginInPageCode"), JSON.parse(appUtils.getSStorageInfo("_loginInPageParam")));
									appUtils.clearSStorage("_loginInPageCode");
									appUtils.clearSStorage("_loginInPageParam");
								}
								else
								{
									appUtils.pageInit("account/userLogin","otc/riskAssessment",{});
								}
							}

							else
							{
								layerUtils.iLoading(false);
								layerUtils.iAlert(error_info);
								return false;
							}
						});
					
				}
			},{"isLastReq":false});

		});

	}

	/*重新 获取验证码*/
	function getCode(){	 
		var url=global.validateimg +"?v="+Math.random();
		$(_pageId+' .code_pic').click( 
			function(){ 
				$(_pageId+' .code_pic').attr('src',url); 
			}); 
		$(_pageId+' .code_pic').attr('src',url);//验证码错误，刷新获得验证码
	}

	function destroy(){
		keyPanel.closeKeyPanel();
		$(_pageId+" #trade_id").val("");  // 清除账号
		$(_pageId+" #trade_pwd").val("");  // 清除密码
		$(_pageId+" .input_text .code").val("");   // 清除验证码
		service.destroy();
	}

	var userLogin = {
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};
	module.exports = userLogin;
});
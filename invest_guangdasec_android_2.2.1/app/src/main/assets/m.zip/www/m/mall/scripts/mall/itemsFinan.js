/**
 * 理财列表
 */
define(function(require, exports, module)
	{	
	var service = require("mobileService");//业务层接口，请求数据
	var appUtils = require('appUtils'),
	putils = require("putils"),
	layerUtils = require("layerUtils"),
	gconfig = require("gconfig"),
	global = gconfig.global,
	convDict = require("convDict"),
	VIscroll = require("vIscroll");
	var _pageId ="#mall_itemsFinan";
	var constants=require("constants");//常量类
	//var customVIscroll = {"scroll":null, "_init":false}; // 上下滑动
	var pagingObjArr = [{"total_pages":0,"curr_page":0}]; //消息分页对象数组，这个页面只有一个分页，简单分页
	var URL=global.url;
	var globalFunc = require("globalFunc");
	//1、初始化
	function init() 
	{
		//初始化理财列表
		configFinan();
		//globalFunc.backIndex($(_pageId+" .back_app")); // 返回App首页
		$(_pageId+" .tab_nav ul li:eq(1)").addClass(" active").siblings("li").removeClass(" active");
	}

	//初始化理财列表
	function configFinan()
	{

		var param =
		{
			"product_shelf":constants.product_shelf.SHELF_ON,
			"page":"1",
			"numPerPage":"4",
			"recommend_type":"",
			"fina_type":"",
			"is_hot_sale":""
		};

		service.findFinan(param,function(data)
			{
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}

			finanItems(data);


			});
	}

	//处理理财
	function finanItems(data)
	{	
		var total_pages = data.results[0].totalPages;
		var curr_page = data.results[0].currentPage;
		var total_rows = data.results[0].totalRows;
		total_pages = total_pages ? total_pages:0;
		curr_page = curr_page ? curr_page:0;
		total_rows=total_rows?total_rows:0;
		pagingObjArr[0].total_pages=total_pages;
		$(_pageId+" em[name='totalPage']").html(total_pages);
		pagingObjArr[0].curr_page=curr_page;
		$(_pageId+" em[name='curPage']").html(curr_page);
		//显示多少条数据
		$(_pageId+" em[name='total_rows']").html(total_rows);

		var allRecommendStr =  "";
		var list =  data.results[0].data;
		var len = list.length;
		for( var i = 0; i<len ; i++)
		{
			var perData = list[i];
			allRecommendStr += handlePerItem(perData,i);
		}
		$(_pageId+" .pro_list02").html(allRecommendStr);

		//绑定跳转详情事件
		appUtils.bindEvent($(_pageId+" .pro_list02  span[product-id]"),function()
			{
			var pageInParam=
			{
				"product_id" : $(this).attr("product-id")
			};
			appUtils.pageInit("mall/itemsFinan", "mall/itemsFinanInfo", pageInParam);
			});

		//上一页、下一页disabled效果
		if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
			$(_pageId + " span[name='aNextPage']").removeClass("blue");
			$(_pageId + " span[name='aPrePage']").addClass("blue");
		}
		else if (pagingObjArr[0].curr_page == 1) {
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + " span[name='aNextPage']").addClass("blue");
		}
		else {
			$(_pageId + " span[name='aPrePage']").addClass("blue");
			$(_pageId + " span[name='aNextPage']").addClass("blue");
		}

		if (pagingObjArr[0].total_pages<2) {
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + "  span[name='aNextPage']").removeClass("blue");
		}

		if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
			$(_pageId+" #isNull").html("暂无数据");
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + " span[name='aNextPage']").removeClass("blue");
		}
	}


	//处理每条数据
	function handlePerItem(perData, idx)
	{
		var product_id = perData.product_id;//ID
		var product_name= perData.product_name;//产品名称
		var current_price=perData.current_price; //当前净值
		var img_url_l=perData.img_url_l;  //图片
		var fina_type=perData.fina_type;//产品类型

		if(fina_type=="3"){
			var oneRecommendStr=' <span id="qq" product-id='+product_id+' > <li class="pro_list_item">    <i class="new">热销</i><div class="pic">  <a href="javascript:;"><img src='+URL+img_url_l+' />'+
			' <p class="p5-0-0-15"><span class="star"><em class="level level4"></em></span></p> </a>  </div>'+
			'<div class="text" style="border:none;"> <a href="javascript:;">  <h2>'+product_name+'</h2>'+
			'<p></p>   </a> </div>  </li></span>';  
		}else{
			var oneRecommendStr=' <span id="qq" product-id='+product_id+' > <li class="pro_list_item">    <i class="new">热销</i><div class="pic">  <a href="javascript:;"><img src='+URL+img_url_l+' />'+
			' <p class="p5-0-0-15"><span class="star"><em class="level level4"></em></span></p> </a>  </div>'+
			'<div class="text" style="border:none;"> <a href="javascript:;">  <h2>'+product_name+'</h2> <span>当前净值 (元)：<em>'+current_price
			+'</em></span>'+
			'<p></p>   </a> </div>  </li></span>';
		}

		return oneRecommendStr;

	}

	//处理上一页，下一页
	function handlePreNextPage(direction)
	{	
		var total_pages = pagingObjArr[0].total_pages;
		var   curr_page = pagingObjArr[0].curr_page;
		var   curPageNo = parseInt(curr_page) + direction ;
		var fina_type =$(_pageId+" #finanType").val();
		if(curPageNo>0 && curPageNo <= total_pages && curPageNo != curr_page) //有效执行跳转页面条件
		{
			var param =
			{
				"product_shelf":constants.product_shelf.SHELF_ON,
				"page":curPageNo,
				"numPerPage":"4",
				"recommend_type":"",
				"fina_type":fina_type,
				"is_hot_sale":""
			};
			service.findFinan(param,function(data)
				{
				if(data.error_no!="0")
				{
					layerUtils.iAlert(data.error_info);
					layerUtils.iLoading(false);
					return false;
				}
				finanItems(data);

				});
		}
		else
		{	 
			return false;
			customVIscroll.scroll.refresh();
		}
	}


	//2、事件绑定
	function bindPageEvent()
	{
        /* 绑定返回我的富尊主页 */
        appUtils.bindEvent($(_pageId+" .header .back_app"),function(e){
            var param_index = {"funcNo":"50101","moduleName":"main"};
            require("external").callMessage(param_index);
            e.stopPropagation();
        });

		//理财分类
		appUtils.bindEvent($(_pageId+" #finanType"),function()
			{
			var fina_type =$(_pageId+" #finanType").val();

			var param =
			{
				"product_shelf":constants.product_shelf.SHELF_ON,
				"page":"",
				"numPerPage":"4",
				"recommend_type":"",
				"fina_type":fina_type,
				"is_hot_sale":""

			};

			service.findFinan(param,function(data)
				{
				if(data.error_no!="0")
				{
					layerUtils.iAlert(data.error_info);
					layerUtils.iLoading(false);
					return false;
				}

				finanItems(data);

				});

			},"change");

		//点击首页
		appUtils.bindEvent($(_pageId+" #mainPage"),function(){appUtils.pageInit("mall/itemsFinan","account/mainPage",{});});

		//点击理财
		appUtils.bindEvent($(_pageId+" #finan"),function(){appUtils.pageInit("mall/itemsFinan","mall/itemsFinan",{});});

		//点击基金
		appUtils.bindEvent($(_pageId+" #fund"),function()	{appUtils.pageInit("mall/itemsFinan","mall/itemsFund",{});});

		//点击资讯
		appUtils.bindEvent($(_pageId+" #info"),function()	{appUtils.pageInit("mall/itemsFinan","mall/itemsInfo",{});});

		//点击服务
		appUtils.bindEvent($(_pageId+" #serv"),function()	{appUtils.pageInit("mall/itemsFinan","mall/itemsServ",{});});
		
		//点击OTC
		appUtils.bindEvent($(_pageId+" #otc"),function(){appUtils.pageInit("mall/itemsFinan","mall/itemsOTC",{});});
		
		//点击 LOGO 
		appUtils.bindEvent($(_pageId+" .logo"),function(){appUtils.pageInit("mall/itemsFinan","account/mainPage",{});});

		//点击 返回顶部
		appUtils.bindEvent($(_pageId+" .back_btn"),function(){$('body,html').animate({scrollTop:0},1000);return false;});
		
		//点击搜索图标 
		appUtils.bindEvent($(_pageId+" .icon_search"),function(){appUtils.pageInit("mall/itemsFinan","mall/fundSearch",{"product_sub_type":"1"})});

		// 点击上一页、下一页 
		appUtils.bindEvent($(_pageId+" span[name='aPrePage']"),function(){	handlePreNextPage(-1);});
		appUtils.bindEvent($(_pageId+" span[name='aNextPage']"),function(){handlePreNextPage(1);});


		// 点击 个人中心 
		appUtils.bindEvent($(_pageId+"  .icon_info"),function()
			{
				appUtils.pageInit("mall/itemsFinan","account/userCenter",{});
			});

	}

	//3、销毁
	function destroy()
	{

	} 

	var itemsFinan =
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = itemsFinan;

	});
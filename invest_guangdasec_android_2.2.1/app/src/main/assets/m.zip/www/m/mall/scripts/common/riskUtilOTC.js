/**
 * 风险测评-弹出处理方式
 * 
 * @author HUANGRONALDO
 * @time 2014.3.25
 */
define( function(require, exports, module) {
	// 加载依赖模块
	require("jquery");
	require("ext");
	require("gconfig");
	layerWeb = require("/mall/scripts/utils/layer/layerWeb");
	require("/mall/scripts/utils/juicer/juicerUtil") ;
	riskService = require("/mall/scripts/service/risk/riskService");
	serviceConstants = require("/mall/scripts/constants/serviceConstants");
    otcservice = require("/mall/scripts/service/otcfinanService");
	/**
	 * @功能
	 * @author HUANGRONALDO
	 * @time 2014.3.27
	 */

	var _total = 0 ; // 总题目数
	var _fCallBack = null;
	var risk_type_id = "";
	$.extend({
		riskShowOTC : function(type_id,fCallBack,survey_sn){ //agency_id ：机构编号，不传默认为0
			_fCallBack = fCallBack;
			risk_type_id = type_id;
			var funcCallBack = function(resultVo){
				var dataList = result.getResultList(resultVo);
				_total = dataList.length;
				if(risk_type_id.indexOf("question") != -1){
				// if(risk_type_id == "question"){
					layerWeb.showPageCode("risk/wjdc", "", "400px", "580px") ;
					$("#risk_question").getTemplateHtml("risk/risk_otc_question",dataList);
					$(" .xubox_close0").hide();
				}else{
					layerWeb.showPageCode("risk/risk", "", "400px", "580px") ;
					$("#risk_question").getTemplateHtml("risk/risk_otc_question",dataList);
				}
				$("#risk_question").children().eq(0).show(); //slideDown("slow") ;
                var j = -1;
				$("#risk_question").children().find("[id^=answers]").each(function(){
					var answers = $.strToAarry($(this).val()) ;
					var answer ;
                    j++;
					for(var i = 0; i < answers.length; i ++){
						answer = answers[i] ;
						var inputType = $(this).attr("data-question-type")=="1"?"checkbox":"radio" ;//试题类型(0单选题、1多选择题)
						var question_no = $(this).attr("data-no") ;
						var question_id = $(this).attr("data-qid") ;
						//下面创建题目的选项 <dd><input type='radio' name='question_1' value='1_1' />XXXXXXXXXXXXXX</dd>
                        $("#list_answer_"+question_no).append("<li  style='list-style: none;'><input type='"+inputType
                            +"' id='question_op_"+question_no+"_"+answer.selection_mark
                            +"' name='question_"+j+"' value='" + question_no + "_" 
                            + answer.option_no+"' style='cursor:pointer' for='question_op_"
                            +question_no+"_"+answer.option_no+"'>&nbsp;&nbsp;&nbsp;"
                            +answer.description+"</li>") ;
						//$("#list_answer_"+question_no).append("<dd><input type='"+inputType+"' id='question_op_"+question_no+"_"+answer.option_id+"' name='question_"+question_no+"' value='" + question_id + "_" + answer.option_id+"' /><label style='cursor:pointer' for='question_op_"+question_no+"_"+answer.option_id+"'>"+answer.description+"</label></dd>") ;
					}
					$("#pre_question").hide();
					$("#submit_step").hide();
					
				});
				
				pre_click() ;//上一题
				nxt_click() ;//下一题
				
				$("#submit_step").bind("click",function(){ //完成提交
                    riskSubmit(risk_type_id,survey_sn) ;
				});

			};
			if(risk_type_id.indexOf("question") != -1){//问卷调查
				riskService.otc_getRiskQuestion(funcCallBack, survey_sn) ;
			}else if(risk_type_id == 0){//个人风险测评
			    riskService.otc_getRiskQuestion(funcCallBack, "1001") ;
            }else{						//机构风险测评
                riskService.otc_getRiskQuestion(funcCallBack, "1002") ;
            }
				
		}
	});
	
	function pre_click(){
		$("#pre_question").bind("click",function(){ //上一题
			nxt_question(-1);
			$("#pre_question").unbind(); 
			setTimeout(pre_click,800) ;
		});
	}
	
	function nxt_click(){
		$("#nxt_question").bind("click",function(){ //下一题
			nxt_question(1);
			$("#nxt_question").unbind(); 
			setTimeout(nxt_click,800) ;
		});
	}
	function nxt_question(step){
		var obj = $("[id^=question_no_div_]:visible") ;
		var objId=$(obj).attr("id");
        if(objId=="question_no_div_1"&&step==-1){
		//if(objId=="question_no_div_2"&&step==-1){
			$("#pre_question").hide();
		}else{
			$("#pre_question").show();
		}
		if(objId==("question_no_div_"+(_total-2))&&step==1){
			$("#nxt_question").hide();
			$("#submit_step").show();
		}else{
			$("#submit_step").hide();
			$("#nxt_question").show();
		}
		var question_no = obj.index() + step;
		if($(this).is(":visible")){
            if(question_no==-1){
                return ;
            }
            if(question_no<_total){
                $(obj).slideUp("slow") ;
                if(step>0){
                    $(obj).next().slideDown("slow") ;
                }else{
                    $(obj).prev().slideDown("slow") ;
                }
                //return false ;
            }
		}
	}
	//风险测评回调函数
	function showRiskResult(resultVo){
		if(result.getResultFlag(resultVo)){
			var dataRow = result.getResultList(resultVo);
			layerWeb.closeAll() ;
			var message = "风险测评提交成功！<br/>您的风险分数：" + dataRow[0].risk_fraction + "<br/>您的风险等级：" + dataRow[0].risk_name ;
			//重新测评之后，将风险等级更新到本地的用户信息中
			var user = $.session.getPresistObj(serviceConstants.session.USER) ;
			user.risk_level_txt = dataRow.risk_name ;
			$.session.presistObj(serviceConstants.session.USER, user);
			
			layerWeb.alert(message,1,"风险测评提示信息",_fCallBack) ;
		}
	}

	//问卷调查回调函数
	function showQuesResult(resultVo){
		if(resultVo.getErrorNo() == '0'){
			var datalist = result.getResultList(resultVo);
			var message = "";
			if(datalist[0].risk_name == $.gconfig.global.quesScore){
				message = "知识问卷测评合格！<br/>您的分数：" + datalist[0].risk_fraction;
        		layerWeb.alert(message,1,"知识问卷提示信息",finansure);
			}else{
				layerWeb.closeAll();
				message = "知识问卷测评不合格！<br/>您的分数：" + datalist[0].risk_fraction;
				if(risk_type_id.indexOf("otc") != -1){//otc
					_fCallBack();
					layerWeb.alert(message,1,"知识问卷提示信息",finansure,"","","");
				}else{//非otc
					$("#orderSubmit").removeClass("save_btn").addClass("gray_btn") ;
					$("#orderSubmit").css("cursor","wait").unbind("click");
					layerWeb.confirm(message,"0","测评提醒",finansure,finanCanle,"","");
				}
			}
		}else{
			layerWeb.closeAll();
			if(risk_type_id.indexOf("otc") !== -1){//otc
				_fCallBack();
			}else{//理财
				finanCanle();
			}
			layerWeb.msg(resultVo.getErrorInfo(),2,3);
		}
	}

	function finansure(){
		location.reload();
	}
	function finanCanle(){
		layerWeb.closeAll();
		$("#orderSubmit").removeClass("save_btn").addClass("gray_btn") ;
		$("#orderSubmit").css("cursor","wait").unbind("click") ;
	}

	function riskSubmit(risk_type_id,survey_sn){
        if(isChecked()){ //检查是否已经全部选中
            var answerArry = [];
            $("input[name^='question_']:checked").each(function () {
                answerArry.push($(this).val());
            });
            var user = $.session.getPresistObj(serviceConstants.session.USER);
            var cust_code = user.user_code ? user.user_code : user.cust_code;
            var ticket = user.ticket;
            if(risk_type_id === "question"){//理财产品问卷提交
                otcservice.otc_riskSubmit(showQuesResult,cust_code,answerArry.join("|"),ticket,survey_sn);//理财问卷提交
            }else if(risk_type_id.indexOf("otc") !==-1){//otc理财产品问卷提交
                otcservice.otc_riskSubmit(showQuesResult,cust_code,answerArry.join("|"),ticket,survey_sn);//otc理财问卷提交
            }else if(risk_type_id.indexOf("append") !==-1){//otc理财产品问卷提交
                otcservice.otc_riskSubmit(appendQuesResult,cust_code,answerArry.join("|"),ticket,survey_sn);//otc理财问卷提交(附加题)
            }else if(risk_type_id.indexOf("other") !==-1){//其他类型问卷提交
                otcservice.otc_riskSubmit(otherQuesResult,cust_code,answerArry.join("|"),ticket,survey_sn);//otc其他类型问卷提交
            }else if(risk_type_id == 0){//风测提交
                otcservice.otc_riskSubmit(showRiskResult,cust_code,answerArry.join("|"),ticket,"1001");//个人提交风险测评
            }else{
                otcservice.otc_riskSubmit(showRiskResult,cust_code,answerArry.join("|"),ticket,"1002","1");//机构户提交风险测评
            }
        }
	}
	
	/*------其他类型问卷结果显示 start------*/
	function otherQuesResult(resultVo){
		if(resultVo.getErrorNo() === '0'){
			var datalist = result.getResultList(resultVo);
			var message="";
			if(parseInt(datalist[0].risk_level)>parseInt($.gconfig.global.other_level)){
				message = "您的等级:"+datalist[0].risk_name+"<br/>问卷测评结果匹配!";
			}else{
				message = "您的等级:"+datalist[0].risk_name+"<br/>问卷测评结果不匹配!";
			}
    		layerWeb.alert(message,1,"知识问卷提示信息",finansure);
		}else{
			layerWeb.msg("提交答案失败:"+resultVo.getErrorInfo(),2,3);
		}
	}
	/*------其他类型问卷结果显示 end------*/

	/*------otc附加题类型问卷结果显示 start------*/
	function appendQuesResult(resultVo){
		if(resultVo.getErrorNo() === '0'){
			var answerArry = [];
			var answerText = [];
			var invePeri = [];
			var inveVari = [];
			//var answerArryFirst = [];
			$("input[name^='question_']:checked").each(function () {
				//answerArryFirst.push($(this).val().split("_")[0]);
                answerArry.push($(this).val().split("_")[0]);
                answerText.push($.trim($(this).parent().text()));
				// answerText.push($(this).parent().text().trim(/(\s*$)/g,""));//答案全都放进去
            });
			var temp=answerArry[0];
			$.each(answerArry,function(i,val){
				if(val==temp){
					invePeri.push(answerText[i]);
				}else{
					inveVari.push(answerText[i]);
				}
			});
			// message = "答案提交成功!请您确认选择包含了产品的<br/>投资期限:" + invePeri + "<br/>投资品种:" + inveVari;
			message = "答案提交成功！请确认您的选择包含了该产品的投资期限与投资品种。";
			layerWeb.alert(message,1,"附加题提示信息",finansure);
		}else{
			layerWeb.msg("提交答案失败:"+resultVo.getErrorInfo(),2,3);
		}
	}
	/*------otc附加题类型问卷结果显示 end------*/

	function isChecked(){
        if ($("input[name^='question_']:checked").length < _total) { //判断是否所有题目已选择
            for (var i = 0; i <= _total; i++) { //循环查找哪一题没有选择
                var length = $("input[name='question_" + i + "']:checked").length;
                if (length == 0) {
                    if(i==0){
                	//if(i==1){
            			$("#pre_question").hide();
            		}else{
            			$("#pre_question").show();
            		}
            		if(i==(_total)){
            			$("#nxt_question").hide();
            			$("#submit_step").show();
            		}else{
            			$("#submit_step").hide();
            			$("#nxt_question").show();
            		}
                    var obj = $("[id^=question_no_div_]:visible");
                    if(obj.index()!=i){
                        obj.slideUp("fast"); //当前题目隐藏
                        $("#question_no_div_" + i).slideDown("fast");
                    }
                    $("#nxt_question").showTips("第"+ (++i) +"题还未作答，请作答！");
                    $("#question_no_div_" + (--i)).click(function(){
                        $("#risk_div").find(".err_tip").remove();
                    });
                    break;
                }
            }
            return false;
        }
        return true ;
	}
	riskAssessment = {
			
	};

	// 暴露对外的接口
	module.exports = riskAssessment ;
});
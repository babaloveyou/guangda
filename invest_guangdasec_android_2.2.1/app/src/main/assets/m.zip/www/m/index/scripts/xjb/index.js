/*
 * 现金宝开通首页
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	_pageId = "#xjb_index ";
	
	/*
	 * 页面初始化
	 */
	function init(){
		service.getAllProtocolId("",function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			if(error_no == "0"){
				var result = data.results[0];
				appUtils.setSStorageInfo("pro_code_fxjss",result.pro_code_fxjss);
				appUtils.setSStorageInfo("pro_code_ht",result.pro_code_ht);
				appUtils.setSStorageInfo("pro_code_qys",result.pro_code_qys);
				appUtils.setSStorageInfo("pro_code_t0_fwxy",result.pro_code_t0_fwxy);
				appUtils.setSStorageInfo("pro_code_t0_fxjs",result.pro_code_t0_fxjs);
			}else{
				layerUtils.iAlert(error_info);
				return false;
			}
		});
		if(!(appUtils.getSStorageInfo("_prePageCode")=="account/userCenter")){
			stepCheck(); 
		}
	}
	
	/*
	 * 绑定页面事件
	 */
	function bindPageEvent(){
		
		//返回
		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(){
			var fromPage = appUtils.getPageParam("fromPage");
			if(fromPage && fromPage=="userCenter"){
				appUtils.pageInit("xjb/index","account/userCenter",{});
			}else{
				var param_index = {"funcNo":"50101","moduleName":"main"};
				require("external").callMessage(param_index);
			}
		});
		
		//我要开户
		appUtils.bindEvent($(_pageId+" #kaihu"),function(){
			var today=new Date();
			var h=today.getHours();
			var m=today.getMinutes();
			var s=today.getSeconds();
			//var str=h+":"+m+":"+s;
			var str=h*60*60+m*60+s;
			if(str>=34200 && str<=54000){
				appUtils.pageInit("xjb/index","xjb/riskHint",{"category_englishname":"xjbxykh"});
			}else{
				layerUtils.iAlert("请在09:30:00与15:00:00之间开户!");
			}
		});
		
		//重新进入
		appUtils.bindEvent($(_pageId+" .retry_btn"),function(){
			stepCheck();
		});
		
	}
	
	/*
	 * 销毁页面
	 */
	function destroy(){
		
	}

	/**
	 * 流程检测 --- 现金宝
	 */
	function stepCheck(){
		//记录进入现金宝的信息
		var par = {
			"fund_account":appUtils.getSStorageInfo("fund_account"),
			"branch_no":appUtils.getSStorageInfo("branch_no"),
			"entrust_way":"SJWT",
			"mac":appUtils.getSStorageInfo("mac"),
			"ip":appUtils.getSStorageInfo("ip"),
		};
		service.recordInfo(par,function(data){
			if(data.error_no == 0){
				//用E帐通登录时没有营业部编号
				if(appUtils.getSStorageInfo("branch_no")==null || appUtils.getSStorageInfo("branch_no") ==undefined){
					appUtils.setSStorageInfo("branch_no",data.results[0].branch_no);
				}
				var user=appUtils.getSStorageInfo("userinfo");
				var userinfo=JSON.parse(user);
				var s="1002";
				if(userinfo.user_type=="0"){
					s="1001";
				}
				var param = {
					"fund_account":appUtils.getSStorageInfo("fund_account"),
					"sign":4,
					"ezt_name":userinfo.user_code,
					"ticket":"",
					"survey_sn":s
				};
				service.isCompleteStep(param,function(data){
					if(data.error_no == 0){
						var result = data.results[0];
						if(result.sfkh == "1"){//已经开户
							if(result.sfqsdzht == "1"){//合同已签署
								var par = {
									"branch_no":appUtils.getSStorageInfo("branch_no"),
									"account":appUtils.getSStorageInfo("fund_account"),
									"market":"1",
									"eztName":userinfo.user_code,
									"ticket":""
								};
								service.queryHtzt(par,function(data){//查询合同状态
									if(data.error_no == 0){
										var result = data.results[0];
										if(result.electronic_contract_status == "1"){//状态为参与，直接进入业务操作
											appUtils.pageInit("account/userCenter","xjb/setReservation",{});
										}else{//修改状态
											appUtils.pageInit("account/userCenter","xjb/setState",{});
										}
									}else{
										layerUtils.iLoading(false);a
										layerUtils.iAlert(data.error_info);
									}
								});
							}else if(result.sfqsdzqmyds == "1"){//是否签署电子协议
								if(result.sffxcp == "1"){//是否风险测评
									appUtils.pageInit("account/userCenter","xjb/electronicContract",{});//签署电子合同
								}else{//没有风险测评
									appUtils.pageInit("account/userCenter","xjb/riskAssessment",{});//风险测评
								}
							}else{//没有签署电子协议
								appUtils.pageInit("account/userCenter","xjb/electronicAgreement",{});//签署电子协议
							}
						}else{//没有开TA账户
						//	appUtils.pageInit("account/userCenter","xjb/index");//走开户
						}
					}else{
						layerUtils.iLoading(false);
						layerUtils.iAlert(data.error_info);
					}
				});
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		});
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy
	};
	//暴露方法
	module.exports = base;
});
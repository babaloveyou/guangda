/**
 * 人脸识别
*/
define(function(require,exports,module){
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
		service = require("serviceImp").getInstance(),  //业务层接口，请求数据
		global = require("gconfig").global,
		layerUtils = require("layerUtils"),
		validatorUtil = require("validatorUtil"),
		_pageId = "#account_backTakePhoto";
	var external = require("external");
    var gconfig = require("gconfig");
	/* 私有业务模块的全局变量 end */
	
	function init() {
		//window.imgState = imgState;  // 照片上传完成后自动调用该方法
		//window.videoOfflineSuccess = videoOfflineSuccess;
	}
	function bindPageEvent() {
		
		//双向视频
		appUtils.bindEvent($(_pageId+" .fix_bot .ct_btn :eq(1) a"),function(){
			appUtils.pageInit("account/takePhoto","account/videoNotice",{});
		});
		
		//单向视频
		appUtils.bindEvent($(_pageId+"  .fix_bot .ct_btn :eq(0) a"),function(){
			//修改用户当前视频方式
			var param = {
				"user_id" : appUtils.getSStorageInfo("user_id"),
				"witness_way" : "1"   //当前为单向视频
			};
			service.changeMethod(param,function(data) {
				var error_no = data.error_no;
				var error_info = data.error_info;
				var result = data.results;
				if (error_no == "0" && result.length != 0) {
					var similarity = result[0].similarity;
					var pass_flag = result[0].pass_flag;
					if (pass_flag == "1") {
						// 相机上传的参数
//						var param = {
//							"user_id" : appUtils.getSStorageInfo("user_id"),
//							"user_name" : appUtils.getSStorageInfo("custname"),
//							"jsessionid":appUtils.getSStorageInfo("jsessionid"),
//							"shortestTime":"5",  //录制最短时间  单位秒
//							"longestTime":"60"  //录制最长时间  单位秒
//						};
//						require("shellPlugin").callShellMethod("videoWitnessOffLinePlugin",null,null,param);
						var param = {
							"userId" : appUtils.getSStorageInfo("user_id"),
							"userName" : appUtils.getSStorageInfo("custname"),
							"jsessionId":appUtils.getSStorageInfo("jsessionid"),
							"shortestTime":"5",  //录制最短时间  单位秒
							"longestTime":"20",  //录制最长时间  单位秒
							"autenticationType":"1",
							"url":global.serverPath,
							"funcNo":"60006"
						};
						//require("shellPlugin").callShellMethod("videoWitnessOffLinePlugin",null,null,param);
						external.callMessage(param);
					}else if (pass_flag == "0") {
						// 相机上传的参数
						var paiConfig = {
							"funcNum" : "501526" ,
							"uuid" : "index",
							"r" : Math.random(),
							"userId" : appUtils.getSStorageInfo("user_id"),
							"photoType" : "人像正面" ,	// 影像名称
							"action" : "pai",	// 照片来源类别，phone 相册，pai 相机
							"imgType" : "3",
							"key" : "index",	// key 和 uuid 只需要写一个
							"url" : global.serverPath,
							"idNo" : appUtils.getSStorageInfo("idCardNo"), //身份证号
							"clientInfo" : appUtils.getSStorageInfo("clientinfo"), 	// 从 session 中将 clientinfo 取出
							"jsessionId" : appUtils.getSStorageInfo("jsessionid"),	// 从 session 中将 jsessionid 取出
							"funcNo":"60008",
							"moduleName":"open"
						};
						external.callMessage(paiConfig);
						//require("shellPlugin").callShellMethod("faceRecognitionPlugin",null,null,paiConfig);
					}
				}
			});
		});
	}

	function imgState(data) {
		var pass_flag = data.pass_flag;
		var similarity = data.similarity;
		var pass_similarity = data.pass_similarity;
		if(data.error_no != 0 && data.error_no != undefined)
		{
			layerUtils.iAlert(data.error_info);
			return false;
		}
		appUtils.setSStorageInfo("pass_flag",pass_flag);
		appUtils.setSStorageInfo("similarity",similarity);
		appUtils.setSStorageInfo("pass_similarity",pass_similarity);
		if (pass_flag == "1") {
			layerUtils.iAlert("人脸识别完成，请点击确定进行下一步...", 0, function(){
				appUtils.pageInit("account/takePhoto","account/faceResult",{});
			}, "确认");
		} else if (pass_flag == "0") {
			ispass++;
			if(ispass>=3)
			{
				layerUtils.iAlert("人脸识别失败3次，点击确定进入双向视频！",-1,function(){
				   appUtils.pageInit("account/takePhoto","account/videoNotice",{});
				});
			}
			else
			{
//				layerUtils.iAlert("人脸识别失败，请再次尝试！");
//				layerUtils.iConfirm("人脸识别失败，你可以选择...",function(){return false;},
//			   function(){
//				appUtils.pageInit("account/takePhoto","account/videoNotice",{});
//			  },"重新验证", "双向视频");
			}

		}
	}

	function videoOfflineSuccess(data) {
		var video_length = data.mTimeCount;
        var start_time = data.start_time;
        //调用提交补全资料接口
					var notifyParam = {
						"user_id" : appUtils.getSStorageInfo("user_id"),
						"fieldname" : "video_one"  // 通知图片已补全
					};
					service.rejectStep(notifyParam,function(data){
						if(data.error_no == 0)
						{
							appUtils.setSStorageInfo("isBack", "backInfo");  //标志重新提交资料成功
							var accountParam = appUtils.getSStorageInfo("accountParam");
							var pwdParam = appUtils.getSStorageInfo("pwdParam");
							var thirdParam = appUtils.getSStorageInfo("thirdParam");
							accountParam = JSON.parse(accountParam);
							pwdParam = JSON.parse(pwdParam);
							thirdParam = JSON.parse(thirdParam);
							// 需要继续驳回到开股东卡
							if(accountParam.need_account == 1)
							{
								appUtils.pageInit("account/backUploadPhoto","account/backSignProtocol",accountParam);
							}
							// 需要驳回资金或交易密码
							else if(pwdParam.needBusinessPwd ==1 || pwdParam.needFundPwd == 1)
							{
								appUtils.pageInit("account/backUploadPhoto","account/backSetPwd",pwdParam);  //跳转设置密码页面
							}
							// 需要驳回到三方存管
							else if(thirdParam.needThirdDeposit == 1)
							{
								appUtils.pageInit("account/backUploadPhoto","account/backThirdDepository",thirdParam);  //返回结果页
							}
							else
							{
								appUtils.pageInit("account/backUploadPhoto","account/accountResult",{});
							}
						}
						else
						{
							layerUtils.iAlert(data.error_info,-1);
						}
					});
	}
	
	function destroy() {
		service.destroy();
	}
	
	var backTakePhoto = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy,
		"videoOfflineSuccess" : videoOfflineSuccess,
		"imgState" : imgState
	};
	
	//暴露接口
	module.exports = backTakePhoto;
});

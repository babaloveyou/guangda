/**
 * 转账查询-结果
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils");
	var gconfig = require("gconfig");
	var service = require("mobileService"); //业务层接口，请求数据
	var global = gconfig.global;
	var layerUtils = require("layerUtils");
	var _pageId="#account_changeResults";
	var pagingObjArr = [{"total_pages":0,"curr_page":0}]; //消息分页对象数组，这个页面只有一个分页，简单分页

	/*初始化*/
	function init()
	{
		$(_pageId+" .results").html("");
		confirmQuery();
	}

	function bindPageEvent() 
	{
		/* 绑定返回事件 */
		appUtils.bindEvent($(_pageId+" .top_title .icon_back"),function(){
			appUtils.pageBack();
			});
		
		/* 绑定购物图标事件 */
		appUtils.bindEvent($(_pageId+" .icon_mall"),function(){
			appUtils.pageInit("account/changeResults","account/mainPage",{});
		});
		
		//上一页、下一页
		appUtils.bindEvent($(_pageId+" span[name='aPrePage']"),function()
			{  
			if(pagingObjArr[0].curr_page==1){
				handlePreNextPage(-1);
			}
			else{
				handlePreNextPage(-1);
			}
			});
		appUtils.bindEvent($(_pageId+" span[name='aNextPage']"),function()
			{
			if(pagingObjArr[0].total_pages==pagingObjArr[0].curr_page){
				handlePreNextPage(1);
			}
			else{
				handlePreNextPage(1);
			}
			});
	}
	
	/* 转账查询*/
	function confirmQuery(){
		var allChangeResultsStr="";
		var fund_account=appUtils.getSStorageInfo("fund_account");
		/*var trans_type=appUtils.getPageParam("trans_type");
		var bank_no=appUtils.getPageParam("bank_no");
		var money_type=appUtils.getPageParam("money_type");
		var start_date=appUtils.getPageParam("start_date");
		var end_date=appUtils.getPageParam("end_date");*/
		var param = {
			"fund_account" : fund_account,
			"page" : "1",
			"numPerPage" : "4",
			"trans_type" : "",
			"bank_no" :  "",
			"money_type" :  "",
			"start_date" :  "",
			"end_date" :  ""
		};	
		/*调用转账查询接口*/
		service.changeQuery(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result = data.results[0].data;

		 if(error_no == "0")
			{
			 if(result.length=="0"){
				 layerUtils.iMsg(-1,"暂无相关数据!");
				 var total_pages = data.results[0].totalPages;
					var curr_page = data.results[0].currentPage;
					var total_rows = data.results[0].totalRows;
					total_pages = total_pages ? total_pages:0;
					curr_page = curr_page ? curr_page:0;
					total_rows=total_rows?total_rows:0;
					pagingObjArr[0].total_pages=total_pages;
					$(_pageId+" em[name='totalPage']").html(total_pages);
					pagingObjArr[0].curr_page=curr_page;
					$(_pageId+" em[name='curPage']").html(0);
					//显示多少条数据
					$(_pageId+" em[name='total_rows']").html(total_rows);
					$(_pageId + "  span[name='aNextPage']").removeClass("blue");
			 }else{
				var total_pages = data.results[0].totalPages;
				var curr_page = data.results[0].currentPage;
				var total_rows = data.results[0].totalRows;
				total_pages = total_pages ? total_pages:0;
				curr_page = curr_page ? curr_page:0;
				total_rows=total_rows?total_rows:0;
				pagingObjArr[0].total_pages=total_pages;
				$(_pageId+" em[name='totalPage']").html(total_pages);
				pagingObjArr[0].curr_page=curr_page;
				$(_pageId+" em[name='curPage']").html(curr_page);
				//显示多少条数据
				$(_pageId+" em[name='total_rows']").html(total_rows);
				for(var i = 0;i<result.length;i++){
					var trans_type=result[i].trans_type;
					var trans_typeLabel  = "";
					if(trans_type == "1")
					{
						trans_typeLabel ="银行转存";
					}else if(trans_type == "2"){
						trans_typeLabel ="存转银行";
					}
					allChangeResultsStr +='<tr >'+
					  '<td width="22%">'+trans_typeLabel+'</td>'+
				      '<td>'+parseFloat(result[i].fund_amount).toFixed(2)+'</td>'+
				      '<td>'+result[i].bank_name+'</td>'+
				      '<td width="28%">'+result[i].trans_date+'</td>'+
				      '</tr>';
				}
				 $(_pageId+" .results").html(allChangeResultsStr);  // 填充个人信息
				// //上一页、下一页disabled效果
					if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
						$(_pageId + " span[name='aNextPage']").removeClass("blue");
						$(_pageId + " span[name='aPrePage']").addClass("blue");
					}
					else if (pagingObjArr[0].curr_page == 1) {
						$(_pageId + " span[name='aPrePage']").removeClass("blue");
						$(_pageId + " span[name='aNextPage']").addClass("blue");
					}
					else {
						$(_pageId + " span[name='aPrePage']").addClass("blue");
						$(_pageId + " span[name='aNextPage']").addClass("blue");
					}

					if (pagingObjArr[0].total_pages<2) {
						$(_pageId + " span[name='aPrePage']").removeClass("blue");
						$(_pageId + "  span[name='aNextPage']").removeClass("blue");
					}

					if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
						$(_pageId+" #isNull").html("暂无数据");
						$(_pageId + " span[name='aPrePage']").removeClass("blue");
						$(_pageId + " span[name='aNextPage']").removeClass("blue");
					}
				
			  }
			}
			else
			{
				layerUtils.iAlert(error_info);
			}
		});

	}
	
	//处理上一页，下一页
	function handlePreNextPage(direction)
	{	
		var total_pages = pagingObjArr[0].total_pages;
		var   curr_page = pagingObjArr[0].curr_page;
		var   curPageNo = parseInt(curr_page) + direction ;
		if(curPageNo>0 && curPageNo <= total_pages && curPageNo != curr_page) //有效执行跳转页面条件
		{
			var allChangeResultsStr="";
			var fund_account=appUtils.getSStorageInfo("fund_account");
			var trans_type=appUtils.getPageParam("trans_type");
			var bank_no=appUtils.getPageParam("bank_no");
			var money_type=appUtils.getPageParam("money_type");
			var start_date=appUtils.getPageParam("start_date");
			var end_date=appUtils.getPageParam("end_date");
			var param = {
				"fund_account" : fund_account,
				"page" : curPageNo,
				"numPerPage" : "4",
				"trans_type" : trans_type,
				"bank_no" :  bank_no,
				"money_type" :  money_type,
				"start_date" :  start_date,
				"end_date" :  end_date
			};	
			/*调用转账查询接口*/
			service.changeQuery(param,function(data){
				var error_no = data.error_no;
				var error_info = data.error_info;
				var result = data.results[0].data;
//				var result1 = data.DataSet1; class=\"part\"

				if(error_no == "0")
				{
					var total_pages = data.results[0].totalPages;
					var curr_page = data.results[0].currentPage;
					var total_rows = data.results[0].totalRows;
					total_pages = total_pages ? total_pages:0;
					curr_page = curr_page ? curr_page:0;
					total_rows=total_rows?total_rows:0;
					pagingObjArr[0].total_pages=total_pages;
					$(_pageId+" em[name='totalPage']").html(total_pages);
					pagingObjArr[0].curr_page=curr_page;
					$(_pageId+" em[name='curPage']").html(curr_page);
					//显示多少条数据
					$(_pageId+" em[name='total_rows']").html(total_rows);
					for(var i = 0;i<result.length;i++){
						var trans_type=result[i].trans_type;
						var trans_typeLabel  = "";
						if(trans_type == "1")
						{
							trans_typeLabel ="银行转存";
						}else if(trans_type == "2"){
							trans_typeLabel ="存转银行";
						}
						allChangeResultsStr +='<tr >'+
						  '<td width="22%">'+trans_typeLabel+'</td>'+
					      '<td>'+result[i].fund_amount+'</td>'+
					      '<td>'+result[i].bank_name+'</td>'+
					      '<td width="28%">'+result[i].trans_date+'</td>'+
					      '</tr>';
					}
					 $(_pageId+" .results").html(allChangeResultsStr);  // 填充个人信息
					// //上一页、下一页disabled效果
						if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
							$(_pageId + " span[name='aNextPage']").removeClass("blue");
							$(_pageId + " span[name='aPrePage']").addClass("blue");
						}
						else if (pagingObjArr[0].curr_page == 1) {
							$(_pageId + " span[name='aPrePage']").removeClass("blue");
							$(_pageId + " span[name='aNextPage']").addClass("blue");
						}
						else {
							$(_pageId + " span[name='aPrePage']").addClass("blue");
							$(_pageId + " span[name='aNextPage']").addClass("blue");
						}

						if (pagingObjArr[0].total_pages<2) {
							$(_pageId + " span[name='aPrePage']").removeClass("blue");
							$(_pageId + "  span[name='aNextPage']").removeClass("blue");
						}

						if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
							$(_pageId+" #isNull").html("暂无数据");
							$(_pageId + " span[name='aPrePage']").removeClass("blue");
							$(_pageId + " span[name='aNextPage']").removeClass("blue");
						}
					
				}
				else
				{
					layerUtils.iAlert(error_info);
				}
			});

		}
	}


	function destroy()
	{
		//清除数据
		$(_pageId+" .trade_box input").val("");
		service.destroy();
	}

	var changeResults = 
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = changeResults;

	});
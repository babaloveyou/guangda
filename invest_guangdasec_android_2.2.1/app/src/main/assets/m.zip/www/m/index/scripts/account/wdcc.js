/**
 * 我的持仓
 */
define(function(require, exports, module){
	/*模块内部全局变量*/
	var appUtils = require("appUtils"),
		layerUtils = require("layerUtils"),
		gconfig = require("gconfig"),
		global = gconfig.global,
		service = require("serviceImp"), //业务层接口，请求数据
		_pageId = "#account_wdcc ";
	
	/*页面初始化方法*/
	function init(){
		$(_pageId+" .hold_main").html("");
		var ext_syscode = appUtils.getPageParam("ext_syscode");
		if(ext_syscode === "1"){
			// 获取我的股票持仓
			getFundMycc(); 
		}else if(ext_syscode === "2"){
			// 获取我的融资融券持仓
			getMarginMycc(); 
		}else if(ext_syscode === "3"){
			// 获取我的OTC持仓
			
		}else if(ext_syscode === "4"){
			// 获取我的期权持仓
			
		}else{
			getFundMycc(); // 获取我的持仓
		}
	}
	
	/*绑定页面事件的方法*/
	function bindPageEvent()
	{
		/*返回*/
		appUtils.bindEvent($(_pageId+" .icon_back"), function(e){
			appUtils.pageInit("account/wdcc", "account/userCenter");
			e.stopPropagation();
		});
	}
	/*页面销毁方法*/
	function destroy()
	{
		service.destroy();
	}
	
	/* 查询我的持仓 */
	function getFundMycc(){
		var entrust_way = "SJWT";
		var branch_no = appUtils.getSStorageInfo("branch_no");
		var fund_account = appUtils.getSStorageInfo("fund_account");
		var cust_code = appUtils.getSStorageInfo("client_no");
		var param = {
			"entrust_way":entrust_way,
			"branch_no":branch_no,
			"fund_account":fund_account,
			"cust_code":cust_code,
		};
		service.queryStockData(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var res = data.results;
			if(error_no == "0" && res != undefined)
			{
				var len = res.length;
				$(_pageId+".len").html("("+len+")");
				var shtml = "";
				if(len == 0){
					shtml = "<ul class='hold_info clearfix'><li style='width:100%;text-align:center'>暂无数据</li></ul>";
				}
				for(var i = 0; i<len; i++)
				{
					var stock_name = res[i].stock_name; // 股票名
					var stock_code = res[i].stock_code; // 股票代码
					var market_value = Number(res[i].market_value).toFixed(2); // 市值
					var cost_amount = res[i].cost_amount; // 持仓数目
					var cost_price = Number(res[i].cost_price).toFixed(2); // 成本价
					var last_price = Number(res[i].last_price).toFixed(2); // 市价
					var float_yk = Number(res[i].float_yk).toFixed(2); // 盈亏金额
					var enable_amount = res[i].enable_amount; // 可卖数量
					var float_yk_per = res[i].float_yk_per; // 盈亏比例
					float_yk_per = Number(float_yk_per).toFixed(2)+"%";
					shtml += "<ul class='hold_info clearfix'>";
					shtml += "<li><strong>"+stock_name+"<small>（"+stock_code+"）</small></strong></li>";
					shtml += "<li><span>市值：</span>"+market_value+"</li>";
					shtml += "<li><span>持有数量：</span>"+cost_amount+"</li>";
					shtml += "<li><span>成本价：</span>"+cost_price+"</li>";
					shtml += "<li><span>市价：</span>"+last_price+"</li>";
					shtml += "<li><span>盈亏金额：</span>"+float_yk+"</li>";
					shtml += "<li><span>可卖数量：</span>"+enable_amount+"</li>";
					shtml += "<li><span>盈亏比例：</span>"+float_yk_per+"</li>";
					shtml += "</ul>";
				}
				$(_pageId+" .hold_main").html(shtml);
			}
			else
			{
				layerUtils.iAlert(error_info);
			}
		});
	}
	
	/*
	 * 获取我的融资融券持仓
	 */
	function getMarginMycc(){
		var fund_account = appUtils.getSStorageInfo("fund_account");
		var param = {
				"branchno":"",
				"account":fund_account
		};
		service.getMarginOp(param,function(data){
			var errorNo = data.error_no;
			var errorInfo = data.error_info;
			if(errorNo === "0"){
				var result = data.results;
				$(_pageId+".len").html("("+result.length+")");
				if(result.length > 0){
					var arr = new Array();
					for(var i=0;i<result.length;i++){
						var item = result[i];
						var ssecurities_name = item.ssecurities_name;//证券名称
						var ssecurities_code = item.ssecurities_code;//证券代码
						var market_value = (+item.market_value).toFixed(2);// 市值（当日）
						var balance = (+item.balance).toFixed(2);//余额 (加上当日 成交 )
						var cost_price = (+item.cost_price).toFixed(2);//成本价格
						var latest_price = (+item.latest_price).toFixed(2);//行情最新价（国 行情最新价）
						var profit_loss = (+item.profit_loss).toFixed(2);//浮动盈亏(当日)
						var available_balance = item.available_balance;//昨日库存数量
						var float_yk_per = (+item.float_yk_per).toFixed(2) + "%";//股票市值 (昨日 库存 )
						arr[i] = "<ul class='hold_info clearfix'><li><strong>"+ssecurities_name+"<small>（"+ssecurities_code+"）</small></strong></li>" +
								"<li><span>市值：</span>"+market_value+"</li><li><span>持有数量：</span>"+balance+"</li><li><span>成本价：</span>"+cost_price+"</li>" +
										"<li><span>市价：</span>"+latest_price+"</li><li><span>盈亏金额：</span>"+profit_loss+"</li><li><span>可卖数量：</span>"+available_balance+"</li>" +
												"<li><span>盈亏比例：</span>"+float_yk_per+"</li></ul>";
					}
					$(_pageId+" .hold_main").html(arr.join(""));
				}else{
					$(_pageId+" .hold_main").html("<ul class='hold_info clearfix'><li style='width:100%;text-align:center'>暂无数据</li></ul>");
				}
			}else{
				layerUtils.iAlert(errorInfo);
			}
		});
	}
	
	/*向外暴露的 JSON 对象*/
	var wdcc = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	
	/*对外暴露 JSON 对象*/
	module.exports = wdcc;
});
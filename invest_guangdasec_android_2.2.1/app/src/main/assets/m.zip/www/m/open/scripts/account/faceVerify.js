/**
 * 人脸识别
*/
define(function(require,exports,module){
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
		service = require("serviceImp").getInstance(),  //业务层接口，请求数据
		global = require("gconfig").global,
		layerUtils = require("layerUtils"),
		validatorUtil = require("validatorUtil"),
		_pageId = "#account_faceVerify";
	var external = require("external");
	/* 私有业务模块的全局变量 end */	
	
	function init() {
		//window.verifyInfo = verifyInfo;
	}
	
	function bindPageEvent() {

		/* 绑定返回 */
		appUtils.bindEvent($(_pageId+" .header .icon_back"),function(){
			appUtils.pageInit("account/liveVerify","account/personInfo",{});
		});
		/* 绑定打开活体识别 */
		appUtils.bindEvent($(_pageId+" .fix_bot .ct_btn"),function(){

			//修改用户当前视频方式
			var param = {
				"user_id" : appUtils.getSStorageInfo("user_id"),
				"witness_way" : "1"   //当前为单向视频
			};
			service.changeMethod(param,function(data) {
				var error_no = data.error_no;
				var error_info = data.error_info;
				var result = data.results;
				if (error_no == "0" && result.length != 0) {
					// 活体识别 人脸识别
					var param = {
						"userId" : appUtils.getSStorageInfo("user_id"),
						"idNo" : appUtils.getSStorageInfo("idCardNo"), //身份证号
						"url":global.serverPath+"?",
						"jsessionId":appUtils.getSStorageInfo("jsessionid"),
						"funcNo":"60007"
					}
					//require("shellPlugin").callShellMethod("liveVerifyPlugin",null,null,param);
					external.callMessage(param);
//					var similarity = result[0].similarity;
//					var pass_flag = result[0].pass_flag;
//					if (pass_flag == "1") {
//					//活体识别，人脸识别通过
//						//faceVerifySuccess()
//					}else if (pass_flag == "0") {
//						// 活体识别 人脸识别
//						var param = {
//							"userId" : appUtils.getSStorageInfo("user_id"),
//							"idNo" : appUtils.getSStorageInfo("idCardNo"), //身份证号
//							"url":global.serverPath+"?",
//							"jsessionId":appUtils.getSStorageInfo("jsessionid"),
//							"funcNo":"60007"
//						}
//						//require("shellPlugin").callShellMethod("liveVerifyPlugin",null,null,param);
//						external.callMessage(param);
//					}
				}
			});
		});
	}

	function verifyInfo(data) {
		var flag = data.data;
		var pass_flag = data.pass_flag;
		//活体识别，人脸识别成功跳到离线视频
		if(flag == "1" && pass_flag == "1") {
			appUtils.pageInit("account/videoNotice","account/signProtocol",{});
		} else {
			layerUtils.iAlert("识别失败，请点击确定进行双向视频...", 0, function(){
				appUtils.pageInit("account/faceVerify","account/videoNotice",{});
			}, "确定");
		}
	}

	//单向视频通过操作
	function faceVerifySuccess() {
		var param = {
			"user_id":appUtils.getSStorageInfo("user_id"),
			"videoExist":"0",
			"fileType":"VIDEO",
			"videoPath":"",
			"start_time":"",
			"video_length":"",
			"autentication_type":"1"
		};
		service.singleVideoPass(param,function(data) {
			var error_no = data.error_no;
			var error_info = data.error_info;
			if (error_no == "0") {	
				if(appUtils.getSStorageInfo("flag") == "1"){   //1:需要证书   0:不需要证书
						layerUtils.iAlert("识别成功，请点击确定进行下一步...", 0, function(){
							appUtils.pageInit("account/faceVerify","account/digitalCertificate",{});
						}, "确定");
				}else{
					appUtils.pageInit("account/videoNotice","account/signProtocol",{});
				}
			} else {
				layerUtils.iMsg(-1,error_info);
			}
		});
	}

	function destroy() {
		service.destroy();
	}
	
	var faceVerify = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy,
		"verifyInfo" : verifyInfo
	};
	
	//暴露接口
	module.exports = faceVerify;
});

/*
 * 现金宝份额查询
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	_pageId = "#xjb_queryQuotient ";
	
	/*
	 * 页面初始化
	 */
	function init(){
		if($(_pageId).width()<=336){
			$(_pageId+" .mn_tab ul li a").css({"font-size":"10px"});
		}
		var par = {
			"branch_no":appUtils.getSStorageInfo("branch_no"),
			"fund_account":appUtils.getSStorageInfo("fund_account"),
			"market":"1",
			"fund_code":"270004"
		};
		service.queryFe(par,function(data){
			if(data.error_no == 0){
				var results = data.results[0].data;
				if(results.length == 0){
				//	layerUtils.iAlert("无返回数据");
					$(_pageId+" .nondata").show();
					return ;
				}
				$(_pageId+" .nondata").hide();
				var html = "";
				for(var i = 0;i<results.length;i++){
					html += "<div class='part'><h5><span>"+results[i].product_code+"</span><em>"+(i+1)+"</em>"+results[i].ta_code_txt+"</h5>";
					html += "<ul class='clearfix'><li><span>当前份额</span>"+results[i].share_amount+"</li>";
					html += "<li><span>可用数量</span>"+results[i].fund_avl+"</li>";
					html += "<li><span>筹码原值</span>"+results[i].cost_price+"</li>";
					html += "<li><span>市&#160;&#160;&#160;&#160;&#160;&#160;值</span>"+results[i].total_money+"</li>";
					html += "<li><span>盈&#160;&#160;&#160;&#160;&#160;&#160;利</span>"+results[i].income_balance+"</li></ul></div>";
				}
				$(_pageId + " .list_box").append(html);
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		});

	}
	
	/*
	 * 绑定页面事件
	 */
	function bindPageEvent(){
		
		//返回
		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(){
			appUtils.pageInit("xjb/queryQuotient","account/userCenter",{});
		});
		
		//tab0
		appUtils.bindEvent($(_pageId+" .mn_tab .setReservationItem"),function(){
			appUtils.pageInit("xjb/queryQuotient","xjb/setReservation",{});
		});
		
		//tab1
		appUtils.bindEvent($(_pageId+" .mn_tab .fastCashItem"),function(){
			appUtils.pageInit("xjb/queryQuotient","xjb/fastCash",{});
		});
		
		//tab2
		appUtils.bindEvent($(_pageId+" .mn_tab .setReserveFundsItem"),function(){
			appUtils.pageInit("xjb/queryQuotient","xjb/setReserveFunds",{});
		});
		
		//tab3
		appUtils.bindEvent($(_pageId+" .mn_tab .setStateItem"),function(){
			appUtils.pageInit("xjb/queryQuotient","xjb/setState",{});
		});
		
		//tab4
		appUtils.bindEvent($(_pageId+" .mn_tab .queryQuotientItem"),function(){

		});
		
	}
	
	/*
	 * 销毁页面
	 */
	function destroy(){
		$(_pageId + " .list_box").html("");
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy
	};
	//暴露方法
	module.exports = base;
});
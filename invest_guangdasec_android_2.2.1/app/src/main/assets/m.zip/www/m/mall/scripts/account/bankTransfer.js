/**
 * 银行转账
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils");
	var gconfig = require("gconfig");
	var service = require("mobileService"); //业务层接口，请求数据
	var global = gconfig.global;
	var layerUtils = require("layerUtils");
	var putils = require("putils");
	var bankAcco="";
	var trans_type=1;
	var _pageId="#account_bankTransfer";
	var keyPanel = require("keyPanel");//软键盘
	var order_id=null;
	var useable_money="";
	var is_bank_pwd="";
	var is_fund_pwd="";
	var is_trade_pwd="";
	var prePage = "";

	/*初始化*/
	function init()
	{
		//清除数据
		$(_pageId+" .trade_box input").val("");
		$(_pageId+" .money_type").html("");
		$(_pageId+" #password em").html("");//切换时清除密码
		$(_pageId+" .bank_no").html("");  //切换时清除银行
		$(_pageId+" #bankPwd em").html("");
		$(_pageId+" #fundPwd em").html("");
		var pageInParam  = appUtils.getPageParam();
        	prePage = pageInParam.prePage;
		queryAsset();
		accountBank();
		order_id=appUtils.getPageParam().order_id;//订单编号
	}

	function bindPageEvent() 
	{
		/*初始化交易密码键盘*/
		appUtils.bindEvent($(_pageId+" #password") ,function(e){
			$(_pageId+" #banktype").hide();
			$(_pageId+" #moneytype").hide();
//			$(_pageId+" #password em").html("");
//			$(_pageId+" #trade_pwd").val("");
			$(_pageId+" .trade_pwd").addClass(" active");
			$(_pageId+" .bank_pwd").removeClass(" active");
			$(_pageId+" .fund_pwd").removeClass(" active");
			
			var input_pwd = $(this);
			input_pwd.find("em").html("");  // 清空密码
			input_pwd.attr("data-password","");  // 清空密码值
			$(_pageId+" .input_custom").addClass("active");
			keyPanel.init_keyPanel(function(value){
				var curEchoText = input_pwd.find("em").html();  // 密码回显文本
				var input_pass_curPwd = input_pwd.attr("data-password") || "";  // 密码值
				var valInput=$(_pageId+" #trade_pwd");
				if(value == "del")
				{
					input_pwd.find("em").html(curEchoText.slice(0, -1));
					input_pwd.attr("data-password", input_pass_curPwd.slice(0, -1));
				}
				else
				{
					if(input_pass_curPwd.length < 6)
					{
						input_pwd.attr("data-password", input_pass_curPwd + value);  // 设置密码值
						input_pwd.find("em").html(curEchoText + "*");
						valInput.val(input_pass_curPwd + value);
					}
					else
					{
						layerUtils.iMsg(-1, "交易密码最多 6位!");
					}
				}
			}, input_pwd);
			e.stopPropagation();
//			var passwordInput=$(_pageId+" #password em");
//			var valInput=$(_pageId+" #trade_pwd");
//			keyPanel.init_keyPanel(_pageId,valInput.val(),valInput,function(pw)
//				{
//				var ch="";
//				for(var i=0;i<pw.length;i++){
//					ch+="*";
//				}
//				passwordInput.html(ch);
//				valInput.val(pw);
//				valInput.text("");
//				},"num","密码");
//			e.stopPropagation();	
		});

		/*初始化银行密码键盘*/
		appUtils.bindEvent($(_pageId+" #bankPwd") ,function(e){
			$(_pageId+" #banktype").hide();
			$(_pageId+" #moneytype").hide();
//			$(_pageId+" #bankPwd em").html("");
//			$(_pageId+" #bank_pwd").val("");
			$(_pageId+" .bank_pwd").addClass(" active");
			$(_pageId+" .fund_pwd").removeClass(" active");
			$(_pageId+" .trade_pwd").removeClass("active");
			
			var input_pwd = $(this);
			input_pwd.find("em").html("");  // 清空密码
			input_pwd.attr("data-password","");  // 清空密码值
			$(_pageId+" .input_custom").addClass("active");
			keyPanel.init_keyPanel(function(value){
				var curEchoText = input_pwd.find("em").html();  // 密码回显文本
				var input_pass_curPwd = input_pwd.attr("data-password") || "";  // 密码值
				var valInput=$(_pageId+" #bank_pwd");
				if(value == "del")
				{
					input_pwd.find("em").html(curEchoText.slice(0, -1));
					input_pwd.attr("data-password", input_pass_curPwd.slice(0, -1));
					valInput.val(input_pwd.attr("data-password"));
				}
				else
				{
					if(input_pass_curPwd.length < 6)
					{
						input_pwd.attr("data-password", input_pass_curPwd + value);  // 设置密码值
						input_pwd.find("em").html(curEchoText + "*");
						valInput.val(input_pass_curPwd + value);
					}
					else
					{
						layerUtils.iMsg(-1, "银行密码最多 6位!");
					}
				}
			}, input_pwd);
			e.stopPropagation();
//			var passwordInput=$(_pageId+" #bankPwd em");
//			var valInput=$(_pageId+" #bank_pwd");
//			keyPanel.init_keyPanel(_pageId,valInput.val(),valInput,function(pw)
//				{
//				var ch="";
//				for(var i=0;i<pw.length;i++){
//					ch+="*";
//				}
//				passwordInput.html(ch);
//				valInput.val(pw);
//				valInput.text("");
//				},"num","密码");
//			e.stopPropagation();	
		});
		
		/*初始化资金密码键盘*/
		appUtils.bindEvent($(_pageId+" #fundPwd") ,function(e){
			$(_pageId+" #banktype").hide();
			$(_pageId+" #moneytype").hide();
//			$(_pageId+" #fundPwd em").html("");
//			$(_pageId+" #fund_pwd").val("");
			$(_pageId+" .fund_pwd").addClass(" active");
			$(_pageId+" .trade_pwd").removeClass("active");
			$(_pageId+" .bank_pwd").removeClass("active");
			
			var input_pwd = $(this);
			input_pwd.find("em").html("");  // 清空密码
			input_pwd.attr("data-password","");  // 清空密码值
			$(_pageId+" .input_custom").addClass("active");
			keyPanel.init_keyPanel(function(value){
				var curEchoText = input_pwd.find("em").html();  // 密码回显文本
				var input_pass_curPwd = input_pwd.attr("data-password") || "";  // 密码值
				var valInput=$(_pageId+" #fund_pwd");
				if(value == "del")
				{
					input_pwd.find("em").html(curEchoText.slice(0, -1));
					input_pwd.attr("data-password", input_pass_curPwd.slice(0, -1));
				}
				else
				{
					if(input_pass_curPwd.length < 6)
					{
						input_pwd.attr("data-password", input_pass_curPwd + value);  // 设置密码值
						input_pwd.find("em").html(curEchoText + "*");
						valInput.val(input_pass_curPwd + value);
					}
					else
					{
						layerUtils.iMsg(-1, "资金密码最多 6位!");
					}
				}
			}, input_pwd);
			e.stopPropagation();
//			var passwordInput=$(_pageId+" #fundPwd em");
//			var valInput=$(_pageId+" #fund_pwd");
//			keyPanel.init_keyPanel(_pageId,valInput.val(),valInput,function(pw)
//				{
//				var ch="";
//				for(var i=0;i<pw.length;i++){
//					ch+="*";
//				}
//				passwordInput.html(ch);
//				valInput.val(pw);
//				valInput.text("");
//				},"num","密码");
//			e.stopPropagation();	
		});

		//点击页面关闭软键盘
		appUtils.bindEvent($(_pageId),function(){
			keyPanel.closeKeyPanel();
			$(_pageId+" .input_custom").removeClass("active");
		});

		appUtils.bindEvent($(_pageId+" .fund_amount"),function(){
			var value =putils.moneyFormat($(this).val());
			$(this).val(value);
			if(value <=0){
				 layerUtils.iMsg(-1,"请输入合法金额数字且小数点最多保留两位!");
				 $(_pageId+" .fund_amount").val("");
			}
		},"keyup");
		/*//判断输入是否合法
		appUtils.bindEvent($(_pageId+" .fund_amount"),function(){
			var buyNum =$(_pageId+" .fund_amount").val();
			if(buyNum!="0"){
				if(!/^((0\.)|[1-9])\.?\d{0,2}$/.test(buyNum)){
					 layerUtils.iMsg(-1,"请输入合法金额数字且小数点最多保留两位!");
					 $(_pageId+" .fund_amount").val("");
				 }
				}
			},"keyup");*/
		//
		appUtils.bindEvent($(_pageId+" .fund_amount"),function(){
			$(_pageId+" #banktype").hide();
			$(_pageId+" #moneytype").hide();
			$(_pageId+" .trade_pwd").removeClass(" active");
			$(_pageId+" .bank_pwd").removeClass(" active");
			$(_pageId+" .fund_pwd").removeClass(" active");
			});

		/* 绑定账户类型事件 */
		appUtils.bindEvent($(_pageId+" .money_type"),function(){
			$(_pageId+" #banktype").hide();
		});
		
		/* 绑定返回事件 */
		appUtils.bindEvent($(_pageId+" .icon_back"),function(){
			if(prePage == "fz_marketCon"){
				if(gconfig.platform == "2"){
					toPage={"prefix":"www/m/index","suffix":"account/marketCon","prePage":"mall_bankTransfer"};
				}else{
					toPage = "/index/index.html#!/account/marketCon.html?prePage=mall_bankTransfer";
				}
				var param = {"funcNo":"50101","moduleName":"financial-mall","params":{"moduleName":"user-center","toPage":toPage}};
				require("external").callMessage(param);
			}else{
				appUtils.pageBack();
			}
		});

		/* 绑定返回首页事件 */
		appUtils.bindEvent($(_pageId+" .icon_mall"),function(){
			appUtils.pageInit("account/bankTransfer","account/mainPage",{});
		});


		/* 下一步(确认查询)*/
		appUtils.bindEvent($(_pageId+" .trade_btn .n2") ,function(){
			if(verifyInfo()){
				bankTrans();
			}
		});

		/* 绑定银行转证券事件 */
		appUtils.bindEvent($(_pageId+" .bankTofund"),function()
			{
			accountBank();
			$(_pageId+" #banktype").hide();
			$(_pageId+" #moneytype").hide();
			trans_type= $(_pageId+" .tab_box04 li:eq(0)").val();
			$(_pageId+" .trade_box input").val("");
			$(_pageId+" .money_type").html("");
			$(_pageId+" #password em").html("");//切换时清除密码
			$(_pageId+" .bank_no").html(""); //切换时清除银行
			$(_pageId+" #bankPwd em").html("");
			$(_pageId+" #fundPwd em").html("");

			// 设置样式
			$(_pageId+" .tab_box04 ul li").eq(0).addClass("current");
			$(_pageId+" .tab_box04 ul li").eq(1).removeClass("current");
			$(_pageId+" .bankPassword").hide();
			$(_pageId+" .tradePassword").hide();
			});

		/* 绑定证券转银行事件 */
		appUtils.bindEvent($(_pageId+" .fundTobank"),function()
			{
			accountBank();
			$(_pageId+" #banktype").hide();
			$(_pageId+" #moneytype").hide();
			$(_pageId+" .trade_box input").val("");
			trans_type= $(_pageId+" .tab_box04 li:eq(1)").val();
			$(_pageId+" .money_type").html("");
			$(_pageId+" #password em").html("");//切换时清除密码
			$(_pageId+" .bank_no").html("");  //切换时清除银行
			$(_pageId+" #bankPwd em").html("");
			$(_pageId+" #fundPwd em").html("");

			// 设置样式
			$(_pageId+" .tab_box04 ul li").eq(1).addClass("current");
			$(_pageId+" .tab_box04 ul li").eq(0).removeClass("current");
			$(_pageId+" .bankPassword").hide();
			$(_pageId+" .tradePassword").hide();

			});

		/* 绑定银行列表事件 */
		appUtils.bindEvent($(_pageId+" #banks"),function(){
			if($(_pageId+" #banktype").is(":hidden")){
				$(_pageId+" #banktype").show();
				$(_pageId+" #moneytype").hide();
			}else{
				$(_pageId+" #banktype").hide();
				$(_pageId+" #moneytype").hide();
			}
			accountBank();
		});
		
		/* 绑定币种列表事件 */
		/*appUtils.bindEvent($(_pageId+" #moneyType"),function(){
			if($(_pageId+" #moneytype").is(":hidden")){
				$(_pageId+" #banktype").hide();
				$(_pageId+" #moneytype").show();
			}else{
				$(_pageId+" #banktype").hide();
				$(_pageId+" #moneytype").hide();
			}
		});*/
		
		/* 重置*/
		appUtils.bindEvent($(_pageId+" .trade_btn .n1") ,function(){
			destroy();
		});
	}
	
	function queryAsset(){
		var fund_account=appUtils.getSStorageInfo("fund_account");
		var param={"fund_account" : fund_account};

		/*调用查询资金接口*/
		service.queryAsset(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result = data.results;
			if(error_no == "0" && result.length != 0)
			{
				if(result[0].money_type ==0){
					useable_money=result[0].useable_money;
				}
			}
			else
			{
				layerUtils.iAlert(error_info);
			}
		});
	}
	
	/* 查询账户所属银行*/
	function accountBank(){
		var fund_account=appUtils.getSStorageInfo("fund_account");
		var param={"fund_account" : fund_account};

		/*调用转账查询接口*/
		service.accountBank(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result = data.results;
			if(error_no == "0" && result.length != 0)
			{
				var allBankStr="";
				var moneyType="";
				for(var i=0; i<result.length;i++){

					// 获取银行枚举
					var money_type=result[i].money_type;
//					bankAcco=bankCode;
					if(money_type==0){
						var bankCode=result[i].bank_no;
						var bankName=result[i].bank_name;
						bankAcco=bankCode;
						moneyType=money_type;
						allBankStr+="<li style='color:#fff;margin-left:10px;font-size:18px;'>请选择银行:</li>";
						allBankStr+="<li><span  money_type='"+money_type+"'  bankname='"+bankName+"' id='"+bankCode+"' >"+bankName+"</span></li>";
					}
					
				}
				$(_pageId+" .bank_no").text(bankName);
				if (moneyType=="0"){
					$(_pageId+" .money_type ").text("人民币");
			    	}
				    else if (moneyType=="1"){
				    	$(_pageId+" .money_type ").text("美元");
			     	}else if(moneyType=="2"){
			     		$(_pageId+" .money_type ").text("港币");
			    	}
				$(_pageId+" #banktype ul").html(allBankStr);  // 填充银行信息
				queryPwd(bankAcco);
			
			/*选中值赋给选择框*/
			appUtils.bindEvent($(_pageId+" #banktype ul li span"),function(){
			    bankAcco = $(this).attr("id");
			    moneyType = $(this).attr("money_type");
				var bankName = $(this).text();  //当前选中银行的值
				$(_pageId+" .bank_no").text(bankName);	  //选中值赋给选择框
				if (moneyType=="0"){
				$(_pageId+" .money_type ").text("人民币");
		    	}
			    else if (moneyType=="1"){
			    	$(_pageId+" .money_type ").text("美元");
		     	}else if(moneyType=="2"){
		     		$(_pageId+" .money_type ").text("港币");
			}
				$(_pageId+" #banktype").hide();
				queryPwd(bankAcco);
			});
			
			/*选中值赋给选择框*/
			appUtils.bindEvent($(_pageId+" #moneytype ul li span"),function(){
				var bankName = $(this).text();  //当前选中银行的值
				$(_pageId+" .money_type").text(bankName);	  //选中值赋给选择框
				$(_pageId+" #banktype").hide();
				$(_pageId+" #moneytype").hide();
				if ("0"==$(this).attr("id")){
				}
				else{
					layerUtils.iMsg(-1,"对不起，银行账户不存在此种货币！");
					$(_pageId+" .money_type").text("");
					return false;
				}
			});
			
			}
			else
			{
				layerUtils.iAlert(error_info);
			}
		});


	}

	function queryPwd(bankAcco){
		var param = {
			"trans_type" : trans_type,
			"bank_no" :  bankAcco,
		};	
		/*调用 银行转账接口*/
		service.queryPwd(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result = data.results;
			if(error_no == "0" )
			{
				if(result.length == 0){
					layerUtils.iMsg(-1,"暂无返回数据!");
					return false;
				}
				 is_bank_pwd=result[0].is_bank_pwd;
				 is_fund_pwd=result[0].is_fund_pwd;
				 is_trade_pwd=result[0].is_trade_pwd;
				if(is_bank_pwd=="1"){
					$(_pageId+" .bankPassword").show();
				}else{
					$(_pageId+" .bankPassword").hide();
				}
				if(is_fund_pwd=="1"){
					$(_pageId+" .fundPassword").show();
				}else{
					$(_pageId+" .fundPassword").hide();
				}
				if(is_trade_pwd=="1"){
					$(_pageId+" .tradePassword").show();
				}else{
					$(_pageId+" .tradePassword").hide();
				}
				
			}
			else
			{
				layerUtils.iAlert(error_info);
			}
		});
	}

	/* 银行转账*/
	function bankTrans(){

		//加密
		service.getRSAKey({},function(data){
			if(data.error_no=="0")
			{
				var modulus = data.results[0].modulus;
				var publicExponent =data.results[0].publicExponent;
				var endecryptUtils = require("endecryptUtils");
				if($.trim($(_pageId+" #trade_pwd").val())!=""){
					var trade_pwd=endecryptUtils.rsaEncrypt(modulus,publicExponent,$.trim($(_pageId+" #trade_pwd").val()));//机密后的密码
				}else{
					var trade_pwd=$(_pageId+" #trade_pwd").val();
				}
				if($.trim($(_pageId+" #bank_pwd").val())!=""){
					var bank_pwd=endecryptUtils.rsaEncrypt(modulus,publicExponent,$.trim($(_pageId+" #bank_pwd").val()));//机密后的密码
				}else{
					var bank_pwd=$(_pageId+" #bank_pwd").val();
				}
				if($.trim($(_pageId+" #fund_pwd").val())!=""){
					var fund_pwd=endecryptUtils.rsaEncrypt(modulus,publicExponent,$.trim($(_pageId+" #fund_pwd").val()));//机密后的密码
				}
				else{
					var fund_pwd=$(_pageId+" #fund_pwd").val();
				}
				var fund_account = appUtils.getSStorageInfo("fund_account");
//				var fund_money= $(_pageId+" .fund_amount").val();	//转账金额
/*				if(trade_pwd==null||trade_pwd=="")
				{
					layerUtils.iMsg(-1,"交易密码不能为空！");
					return false;
				}
				if(bank_pwd==null||bank_pwd=="")
				{
					layerUtils.iMsg(-1,"银行密码不能为空！");
					return false;
				}
*/				

				if(trans_type==1){
					var param = {
						"fund_account" : fund_account,
						"trans_type" : trans_type,
						"bank_no" :  bankAcco,
						"money_type" :  $(_pageId+" .money_type").val(),
						"fund_pwd" : fund_pwd,
						"trade_pwd": trade_pwd,
						"bank_pwd":bank_pwd,
						"fund_amount" : $(_pageId+" .fund_amount").val()
					};	
					/*调用 银行转账接口*/
					service.bankTrans(param,function(data){
						var error_no = data.error_no;
						var error_info = data.error_info;
						var result = data.results;
						if(error_no == "0"&& result.length != 0)
						{

							if(order_id!=null)
							{
								layerUtils.iMsg(-1,"银证转账成功,请到我的订单中支付");
								var product_id=appUtils.getPageParam().product_id;//产品编号
								var param={
										"product_id":product_id
								}
								if(appUtils.getSStorageInfo("_prePageCode")=="mall/finanOrder/orderPay"){
									appUtils.pageInit("account/bankTransfer","mall/finanOrder/orderPay",param);
								}
								if(appUtils.getSStorageInfo("_prePageCode")=="mall/fundOrder/orderPay"){
									appUtils.pageInit("account/bankTransfer","mall/fundOrder/orderPay",param);
								}
								if(appUtils.getSStorageInfo("_prePageCode")=="mall/infoOrder/orderPay"){
									appUtils.pageInit("account/bankTransfer","mall/infoOrder/orderPay",param);
								}
							}else if(prePage == "fz_marketCon"){

								if(gconfig.platform == "2"){
									toPage={"prefix":"www/m/index","suffix":"account/marketCon","prePage":"mall_bankTransfer"};
								}else{
									toPage = "/index/index.html#!/account/marketCon.html?prePage=mall_bankTransfer";
								}
								var param = {"funcNo":"50101","moduleName":"financial-mall","params":{"moduleName":"user-center","toPage":}};
								require("external").callMessage(param);

							}
							else
							{
								layerUtils.iMsg(-1,"银证转账成功!");
								appUtils.pageInit("account/bankTransfer","account/userCenter",{});
							}
							
						}
						else
						{
//							layerUtils.iAlert(error_info);
							$(_pageId+" .trade_box input").val("");
							$(_pageId+" .money_type").html("");
							$(_pageId+" #password em").html("");//切换时清除密码
							$(_pageId+" .bank_no").html("");  //切换时清除银行
							$(_pageId+" #bankPwd em").html("");
							$(_pageId+" #fundPwd em").html("");
						}
					});
				}
				else if(trans_type==2){
					var param = {
						"fund_account" : fund_account,
						"trans_type" : trans_type,
						"bank_no" :  bankAcco,
						"money_type" :  $(_pageId+" .money_type").val(),
						"fund_pwd" : fund_pwd,
						"trade_pwd": trade_pwd,
						"bank_pwd":bank_pwd,
						"fund_amount" :  $(_pageId+" .fund_amount").val()
					};	
					/*调用 银行转账接口*/
					service.bankTrans(param,function(data){
						var error_no = data.error_no;
						var error_info = data.error_info;
						var result = data.results;
						if(error_no == "0" && result.length != 0)
						{
							if(prePage == "fz_marketCon"){

								if(gconfig.platform == "2"){
									toPage={"prefix":"www/m/index","suffix":"account/marketCon","prePage":"sc"};
								}else{
									toPage = "/index/index.html#!/account/marketCon.html?prePage=sc";
								}
								var param = {"funcNo":"50101","moduleName":"financial-mall","params":{"moduleName":"user-center","toPage":toPage}};
								require("external").callMessage(param);

							}else{
								layerUtils.iMsg(-1,"银证转账成功!");
								appUtils.pageInit("account/bankTransfer","account/userCenter",{});
							}
						}
						else
						{
//							layerUtils.iAlert(error_info);
							$(_pageId+" .trade_box input").val("");
							$(_pageId+" .money_type").html("");
							$(_pageId+" #password em").html("");//切换时清除密码
							$(_pageId+" .bank_no").html("");  //切换时清除银行
							$(_pageId+" #bankPwd em").html("");
							$(_pageId+" #fundPwd em").html("");
						}
					});
				}
			}
		},{"isLastReq":false});	
	}


	/* 信息验证*/
	function verifyInfo(){
		var bank_no = $(_pageId+" .bank_no").text();
		var money_type = $(_pageId+" .money_type").text();
		var fund_pwd = $(_pageId+" #fund_pwd").val();
		var trade_pwd = $(_pageId+" #trade_pwd").val();
		var bank_pwd = $(_pageId+" #bank_pwd").val();
		var fund_amount = $(_pageId+" #zzje").val();
		if(bank_no == ""||bank_no==null)
		{
			layerUtils.iMsg(-1,"请选择银行！");
			return false;
		}

		if(money_type == ""||money_type==null)
		{
			layerUtils.iMsg(-1,"币种不能为空");
			return false;
		}
		if(is_bank_pwd==1){
			if(bank_pwd == ""||bank_pwd==null)
			{
				layerUtils.iMsg(-1,"银行密码不能为空");
				return false;
			}
		}
		
		if(is_fund_pwd==1){
			if(fund_pwd == ""||fund_pwd==null)
			{
				layerUtils.iMsg(-1,"资金密码不能为空");
				return false;
			}
		}
		
		if(is_trade_pwd==1){
			if(trade_pwd == ""||trade_pwd==null)
			{
				layerUtils.iMsg(-1,"交易密码不能为空");
				return false;
			}
		}
		

		if(fund_amount == ""||fund_amount==null)
		{
			layerUtils.iMsg(-1,"转账金额不能为空");
			return false;
		}
		//判断输入的值是否为数字
		if(isNaN(fund_amount))
		{
			layerUtils.iMsg(-1,"输入的金额必须为数字！");
			$(_pageId+" .fund_amount").val("");
			return false;
		}
		return true;
	}


	function destroy()
	{
		//清除数据
		$(_pageId+" .trade_box input").val("");
		$(_pageId+" .money_type").val("");
		$(_pageId+" #password em").html("");//切换时清除密码
		$(_pageId+" .bank_no").html("");  //切换时清除银行
		$(_pageId+" #bankPwd em").html("");
		$(_pageId+" #fundPwd em").html("");
		service.destroy();

	}

	var changeQuery = 
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = changeQuery;

});
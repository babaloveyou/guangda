/**
 * 人脸识别
 */
define( function(require, exports, module) {
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
		service = require("serviceImp").getInstance(), //业务层接口，请求数据
		global = require("gconfig").global,
		layerUtils = require("layerUtils"),
		validatorUtil = require("validatorUtil"),
		_pageId = "#account_backFaceVerify"
		/* 私有业务模块的全局变量 end */

	function init() {
		layerUtils.iLoading(false);
		window.verifyInfo = verifyInfo;
	}

	function bindPageEvent() {
		/* 绑定打开活体识别 */
		appUtils.bindEvent($(_pageId + " .fix_bot .ct_btn"), function() {
			liveVideo();
		});
	}

	function liveVideo() {
		//修改用户当前视频方式
		var param = {
			"user_id": appUtils.getSStorageInfo("user_id"),
			"witness_way": "1" //当前为单向视频
		};
		service.changeMethod(param, function(data) {
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result = data.results;
			if (error_no == "0" && result.length != 0) {
				// 活体识别 人脸识别
				var param = {
					"user_id": appUtils.getSStorageInfo("user_id"),
					"id_no": appUtils.getSStorageInfo("idCardNo"), //身份证号
					"url": global.serverPath + "?",
					"jsessionid": appUtils.getSStorageInfo("jsessionid"),
					"user_name": appUtils.getSStorageInfo("custname"),
					"org_id": appUtils.getSStorageInfo("branchno"),
					"jsessionid": appUtils.getSStorageInfo("jsessionid"),
					"user_type": "1",
					"netWorkStatus": "WIFI" //网络状态
				}
				require("shellPlugin").callShellMethod("liveVerifyPlugin", null, null, param);
			} else {
				layerUtils.iAlert(error_info, -1);
			}
		});
	}

	function verifyInfo(data, pass_flag) {
		if (data == "1" && pass_flag == "1") {
			nextBack();
		} else {
			appUtils.pageInit("account/backFaceVerify", "account/backVideoNotice", {});
		}
	}

	function nextBack() {
		//调用提交补全资料接口
		var notifyParam = {
			"userid": appUtils.getSStorageInfo("user_id"),
			"fieldname": "video_one" // 通知图片已补全
		};
		service.rejectStep(notifyParam, function(data) {
			if (data.error_no == 0) {
				appUtils.setSStorageInfo("isBack", "backInfo"); // 标志重新提交资料成功
				var accountParam = appUtils.getSStorageInfo("accountParam");
				var pwdParam = appUtils.getSStorageInfo("pwdParam");
				var thirdParam = appUtils.getSStorageInfo("thirdParam");
				accountParam = JSON.parse(accountParam);
				pwdParam = JSON.parse(pwdParam);
				thirdParam = JSON.parse(thirdParam);
				// 需要继续驳回到开股东卡
				if (accountParam.need_account == 1) {
					appUtils.pageInit("account/backUploadPhoto","account/backSignProtocol", accountParam);
				}
				// 需要驳回资金或交易密码
				else if (pwdParam.needBusinessPwd == 1 || pwdParam.needFundPwd == 1) {
					appUtils.pageInit("account/backUploadPhoto","account/backSetPwd", pwdParam); // 跳转设置密码页面
				}
				// 需要驳回到三方存管
				else if (thirdParam.needThirdDeposit == 1) {
					appUtils.pageInit("account/backUploadPhoto","account/backThirdDepository", thirdParam); //返回结果页
				} else {
					appUtils.pageInit("account/backUploadPhoto","account/accountResult", {});
				}
			}
		});
	}

	function destroy() {
		service.destroy();
	}

	var backFaceVerify = {
		"init": init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	//暴露接口
	module.exports = backFaceVerify;
});
/**
* 查看协议
*/
define(function(require,exports,module){
	var appUtils = require("appUtils"),
		global = require("gconfig").global,
		service = require("investService").getInstance(),  //业务层接口，请求数据
		_pageId = "#account_showProtocol";
	
	function init(){
		// 清除原有数据
		$(_pageId+" #contenttxt").text("");
		$(_pageId+" .top_title p:eq(0)").text("");
		//设置按钮显示提示文字
		if(appUtils.getSStorageInfo("openChannel") == "change")
		{
			if(appUtils.getSStorageInfo("finance") == "finance")
			{
				$(_pageId+" .fix_bot .ct_btn a").html("下一步");
			}
			else
			{
				$(_pageId+" .fix_bot .ct_btn a").html("下一步");
			}
		}
		else
		{
			$(_pageId+" .fix_bot .ct_btn a").html("下一步");
		}
		var protocol_id = appUtils.getPageParam("protocol_id");
		var param = {
			"econtract_no" : protocol_id,
			"econtract_version":""
		}
		//查询协议内容
		service.getProtocolInfo(param,function(data){
			if(error_no = data.error_no)
			{
				$(_pageId+" .top_title p:eq(0)").text(data.results[0].econtract_name);
				$(_pageId+" #contenttxt").append(data.results[0].econtract_content);
			}
			else
			{
				layerUtils.iMsg(-1, data.error_info);
			}
		});
	}
	function bindPageEvent(){
		
		// 绑定返回
		appUtils.bindEvent($(_pageId+" .header .icon_back"),function(){
//			appUtils.pageInit("account/showProtocol","account/thirdDepository");
			appUtils.pageBack();
		});
		
		// 绑定继续开户
		appUtils.bindEvent($(_pageId+" .ct_btn a"),function(){
//			appUtils.pageInit("account/showProtocol","account/thirdDepository");
			appUtils.pageBack();
		});
	}
	function destroy(){
		// 将协议内容置空
		$(_pageId+" #contenttxt").text("");
		$(_pageId+" .top_title p:eq(0)").text("");
		service.destroy();
	}
	
	var showProtocol = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	
	module.exports = showProtocol;
});
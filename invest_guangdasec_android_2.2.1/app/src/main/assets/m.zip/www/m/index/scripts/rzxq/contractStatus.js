/**
 * 合约状态
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils");
	var layerUtils = require("layerUtils");
	var validatorUtil = require("validatorUtil");
	var gconfig = require("gconfig");
	var putils = require("putils"); 
	var global = gconfig.global;
	var service = require("serviceImp");  // 业务层接口，请求数据
	var _pageId = "#rzxq_contractStatus ";
    var STATUS = true; // 是否看访问其他菜单
    var conStatus = ""; // 合同状态
    var userInfo = ""; // 用户信息
    var stock_code = ""; // 上市公司编码
    
    /**
     * 初始化
     */
	function init() {
		var fromPage = appUtils.getPageParam("fromPage");
		if(fromPage && fromPage=="userCenter"){
			appUtils.setSStorageInfo("fromPage",fromPage);
		}
		queryPremission(); // 查询权限
    }
	
	/**
	 * 事件绑定
	 */
	function bindPageEvent() {
		// 返回按钮
		appUtils.bindEvent($(_pageId + ".top_title .icon_back"), function(e){
			pageBack();
		});
		// 菜单栏跳转
		appUtils.bindEvent($(_pageId+'.top_nav:first ul li a'), function(e){
			var pageCode = _pageId.replace("#","").replaceAll("_","/").replace(" ","");
			if(STATUS){
				if($(this).attr("to-page")){
					var topage = $(this).attr("to-page");
					appUtils.pageInit(pageCode,topage,{});	
				}
			}else{
				layerUtils.iAlert("您的股权融资合同状态为"+conStatus+"状态",-1);
			}
			e.stopPropagation();
		 });
		// 股权激励资格确定
		appUtils.bindEvent($(_pageId + ".pop_footer #confirm_yes"), function(e){
	    	var stockCode =  $(_pageId + "#stockCode").val();
	    	if(validatorUtil.isEmpty(stockCode)){
	    		layerUtils.iAlert("股票代码不能为空");
	    	}else if(stockCode.length<6){
	    		layerUtils.iAlert("股票代码长度不能小于6");
	    	}else{
	    		$(_pageId + ".backdrop").hide();
	    		$(_pageId + ".pop_box").hide();
				queryEmpInfo(stockCode);
	    	}
			e.stopPropagation();
		});
		// 股权激励资格取消
		appUtils.bindEvent($(_pageId + ".pop_footer #confirm_no"), function(e){
    		$(_pageId + ".backdrop").hide();
    		$(_pageId + ".pop_box").hide();
			pageBack();
			e.stopPropagation();
		});
		// 我要签署按钮
		appUtils.bindEvent($(_pageId + ".mn_btn .btn"), function(e){
			if(STATUS){
				layerUtils.iAlert("您已签署合同");
			}else if(conStatus=="【未签署合同】"){
				appUtils.pageInit("rzxq/contractStatus","rzxq/contractApply",{"stockCode":stock_code});
			}else{
				layerUtils.iAlert("您没有股权激励计划,无法参加该业务",-1);
			}
		});
	}
    
	/**
	 * 股权融资资格查询-690
	 */
	function queryPremission(){
		var userInfo =  JSON.parse(appUtils.getSStorageInfo("userinfo"));
		var account = userInfo.client_no;
		var branch_no = userInfo.branch_no;
		var param = {
			"account":account,
			"branch_no":branch_no
		};	
		service.query690(param,function(data){
			if(data.error_no == "0"){  
				var result = data.results;
				if(result){
					var contract_status = result[0].contract_status2;
					var contract_number = result[0].contract_number2;
					appUtils.setSStorageInfo("contract_number",contract_number); // 保存合同编号
					if(validatorUtil.isEmpty(contract_status)){
						// 未签署合同
						STATUS = false;
						conStatus = "【未签署合同】";
						$(_pageId + ".backdrop").show();
						$(_pageId + ".pop_box").show();  // 提示签署
					}else if(contract_status == "1"){
						STATUS = true;
						conStatus = "【正常】";
					}else if(contract_status == "2"){
						STATUS = false;
						conStatus = "【冻结】";
					}else if(contract_status == "3"){
						STATUS = false;
						conStatus = "【终止】";
					}
					$(_pageId + ".pact_status span b").html(conStatus);
				}
			}else if(data.error_no == "-1"){ //用户不存在(未签署股权融资合同)
				STATUS = false;
				conStatus = "【未签署合同】";
				$(_pageId + ".backdrop").show();
				$(_pageId + ".pop_box").show();  // 提示签署
				$(_pageId + ".pact_status span b").html(conStatus);
			}else{
				layerUtils.iAlert(data.error_info,-1);
				STATUS = false;
				$(_pageId + ".pact_status span b").html("【"+data.error_info+"】");
			}
		});
	}

	/**
	 * 根据股票代码查询权限
	 */
	function queryEmpInfo(stockCode){
		var userInfo =  JSON.parse(appUtils.getSStorageInfo("userinfo"));
		var account = userInfo.client_no;
		var branch_no = userInfo.branch_no;
		var param = {
			"account":account,
			"branch_no":branch_no,
			"LCCode":stockCode
		};
		service.queryEmpInfo(param,function(data){
			if(data.error_no == "0"){  
				var result = data.results;
				if(result){
					if(result[0].sstatus3=='1'){//交易标志 0-禁止;1-许可
						conStatus = "【未签署合同】";
						stock_code = stockCode;
						STATUS = false;
						layerUtils.iAlert("您有股权激励计划，请点击我要签署在线签署合约 ",-1);
					}else{//没有行权权限
						conStatus = "【无股权激励计划】";
						STATUS = false;
						layerUtils.iAlert("【您没有股权激励计划,无法参加该业务】",-1);
					}
					$(_pageId + ".pact_status span b").html(conStatus);
				}
			}else{
				layerUtils.iAlert(data.error_info,-1);
			}
		});
	}
	
	function destroy(){
		$(_pageId + "#stockCode").val("");
	}
	
	/**
	 * 重写框架里面的pageBack方法
	 */
	function pageBack(){
		var fromPage = appUtils.getSStorageInfo("fromPage");
		if(fromPage && fromPage=="userCenter"){
			appUtils.clearSStorage("fromPage");
			appUtils.pageInit("rzxq/contractStatus","account/userCenter");
		}else{
			var param_index = {"funcNo":"50101","moduleName":"main"};
			require("external").callMessage(param_index);
		}
	}
	
	var base = {
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy,
		"pageBack": pageBack
	};
	module.exports = base;
});
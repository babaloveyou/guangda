/**
 * 风险揭示书
 */
define(function(require, exports, module) 
	{
	var appUtils = require("appUtils");
	var gconfig = require("gconfig");
	var service = require("mobileService");//业务层接口，请求数据
	var global = gconfig.global;
	var layerUtils = require("layerUtils");
	var _pageId ="#otc_riskDisclosure ";

	/*初始化*/
	function init()
	{
		var height_table = $(window).height() - $(_pageId+".header").height() - $(_pageId+".ce_btn").height() - $(_pageId+".inner h3").height()- $(_pageId+".rule_check").height() - 100;
	    $(_pageId+".risk_entry").css("overflow-y","auto");
	    $(_pageId+".risk_entry").css("overflow-x","hidden");
	    $(_pageId+".risk_entry").height(height_table); //给协议添加高度
		queryOTCAgreement();
	}

	function bindPageEvent() 
	{

		/* 绑定返回事件 */
		appUtils.bindEvent($(_pageId+" .top_title .icon_back"),function(){
			appUtils.pageInit("otc/riskDisclosure","account/userCenter",{});
		});
		
		/* 勾选协议 */
		appUtils.bindEvent($(_pageId+" #signProtocol"),function(){
			if($(this).hasClass("active"))
			{
				$(this).removeClass("active");
			}
			else
			{
				$(this).addClass("active");
			}
		});
		
		/* 提交申请 */
		appUtils.bindEvent($(_pageId+" #commitApply"),function(){
			if(!$(_pageId+" #signProtocol").hasClass("active"))
			{
				layerUtils.iAlert("请阅读并同意签署以下协议、合同！");
				return false;
			}
			signOTCAgreement();
		});
	}

	function queryOTCAgreement(){
		var cust_code=appUtils.getSStorageInfo("cust_code");
		var ticket=appUtils.getSStorageInfo("ticket");
		var param={"cust_code" : cust_code,"ticket" : ticket};

		/*调用查询资金接口*/
		service.queryOTCAgreement(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var results = data.results;
			if(error_no == "0" && results.length != 0){
				var agreementStr = "";
				for (var i  =0; i < results.length; i++){
					if(results[i].belongs == "otckh"){
						agreementStr +='<a href="javascript:void(0);" agreement_id='+results[i].agreement_id+' agreement_title='+results[i].agreement_title+'>《'+results[i].agreement_title+'》</a>';
					}
				}
				$(_pageId+" .inner h3").html(results[0].agreement_title);
				$(_pageId+" .inner .risk_entry").html(results[0].agreement_content);
				$(_pageId+" #agreement").html(agreementStr);
				
				//阅读协议
				appUtils.bindEvent($(_pageId+" #agreement a[agreement_id]"),function(){
					var agreement_id = $(this).attr("agreement_id");
					var agreement_title = $(this).attr("agreement_title");
					$(_pageId+" .inner h3").html(agreement_title);
					for (var i  =0; i < results.length; i++)
					{
						if(results[i].agreement_id==agreement_id)
						{
							$(_pageId+" .inner .risk_entry").html(results[i].agreement_content);//展示协议内容
						}
					} 
				},"touchstart"); 
			}else{
				layerUtils.iAlert(error_info);
			}
		});
	}
	
	function signOTCAgreement(){
		var cust_code=appUtils.getSStorageInfo("cust_code");
		var ticket=appUtils.getSStorageInfo("ticket");
		var param={
				"cust_code" : cust_code,
				"query_type": "otckh",
				"product_id": "",
				"ticket" : ticket
		};

		/*调用查询资金接口*/
		service.signNewAgreement(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			if(error_no == "0"){
				otcRiskResult();
			}else{
				layerUtils.iAlert(error_info);
				layerUtils.iLoading(false);
			}
		},{"isLastReq":false});
	}
	
	function otcRiskResult(){
		var cust_code=appUtils.getSStorageInfo("cust_code");
		var ticket=appUtils.getSStorageInfo("ticket");
		var cust_type=appUtils.getSStorageInfo("cust_type");
		var survey_sn = "";
		if(cust_type == "0"){
			survey_sn = "1001";
		}else if(cust_type == "1"){
			survey_sn = "1002";
		}else{
			survey_sn = "1001";
		}
		var param={
				"cust_code" : cust_code,
				"survey_sn": survey_sn,
				"ticket" : ticket
		};

		/*调用查询OTC风险测评结果*/
		service.newRiskResult(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result = data.results;
			if(error_no == "0"){
				if(result.length == 0){
					appUtils.pageInit("otc/riskDisclosure","otc/riskAssessment",{});
				}else{
					var is_overtime = result[0].is_overtime;
					if(is_overtime == "1"){
						appUtils.pageInit("otc/riskDisclosure","otc/riskAssessment",{});
					}else{
						appUtils.pageInit("otc/riskDisclosure","otc/riskResult",{});
					}
				}
			}else{
				layerUtils.iAlert(error_info);
			}
		});
	}


	function destroy()
	{
		service.destroy();
	}

	var riskDisclosure = 
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = riskDisclosure;

	});
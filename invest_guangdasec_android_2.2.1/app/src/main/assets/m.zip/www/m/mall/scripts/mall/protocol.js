/**
 * 理财--阅读协议
 */
define( function(require, exports, module)
	{	
	var service = require("mobileService"); //业务层接口，请求数据
	var appUtils = require('appUtils'),
	putils = require("putils"),
	layerUtils = require("layerUtils"),
	constants=require("constants");//常量类
	gconfig = require("gconfig"),
	global = gconfig.global;
	var _pageId ="#mall_protocol";

	//1、初始化
	function init() 
	{	
		var pageInParam=appUtils.getPageParam();
		var agreement_title=pageInParam.agreement_title;      //协议标题
		var agreement_id=pageInParam.agreement_id;      //协议标题

		var results=pageInParam.results;

		for (var i  =0; i < results.length; i++)
		{

			if(results[i].agreement_id==agreement_id)
			{
				$(_pageId+" .agreem_title").html(results[i].agreement_title); //展示协议标题
				$(_pageId+" .agreem_text").html(results[i].agreement_content);//展示协议内容
			}

		} 


	}
	//2、事件绑定
	function bindPageEvent()
	{	
		//点击 返回事件
		appUtils.bindEvent($(_pageId+" .icon_back"),function(){appUtils.pageBack();});
		
		//点击 返回顶部
		appUtils.bindEvent($(_pageId+" .back_btn"),function(){$('body,html').animate({scrollTop:0},1000);return false;});


		//点击 LOGO 
		appUtils.bindEvent($(_pageId+" .logo"),function(){appUtils.pageInit("mall/protocol","account/mainPage")});

		//点击 关闭
		appUtils.bindEvent($(_pageId+" .login_btn_ok"),function(){	appUtils.pageBack();});

		// 点击 个人中心 
		appUtils.bindEvent($(_pageId+"  .icon_info"),function(){
			appUtils.pageInit("mall/protocol","account/userCenter",{});
		});
	}



	//3、销毁
	function destroy()
	{
		 
	}

	var protocol =
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = protocol;

	});
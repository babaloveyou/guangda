/**
 * 资讯详情
 */
define(function(require, exports, module)
	{	
	var service = require("mobileService");//业务层接口，请求数据
	var appUtils = require('appUtils'),
	putils = require("putils"),
	layerUtils = require("layerUtils"),
	gconfig = require("gconfig"),
	global = gconfig.global;
	var _pageId="#mall_itemsInfoDetail";
	var save_value= null;
	var rules_id="";//购买类型id
	var rules_desc="";
	var service_typeparam="";//服务方式
	var service_desc="";
	var URL=global.url;
	//1、初始化
	function init() 
	{
		$(_pageId+" .produ_text").attr("style","height:90px;");
		var product_id=appUtils.getPageParam().product_id;
		//防止直接到该页面
		if(product_id==null)
		{
			layerUtils.iMsg(1, "数据加载错误！");
			appUtils.pageInit("mall/finanOrder/confirmOrder","account/mainPage",{})
			return false;
		}

		findInfoDeatil();
	}

	//查询咨询产品详情
	function findInfoDeatil()
	{	
		var product_id=appUtils.getPageParam().product_id;
		var param=
		{
			"product_id":product_id
		}
		service.findInfoDetail(param,function(data)
			{
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
			save_value=data.results[0];
			$(_pageId+" .cpmc").html(data.results[0].product_name+' ('+data.results[0].product_code+')');//展示产品名称和产品代码
			if(data.results[0].product_description=="")
			{	

				$(_pageId+" .cpxq").html(data.results[0].product_description?data.results[0].product_description:'暂无数据');// 产品详情(ok);
			}
			else
			{
				$(_pageId+" .cpxq").html(data.results[0].product_description?data.results[0].product_description:'无数据');// 产品详情(ok);

			}
			if(data.results[0].product_description.length>77)
			{
				$(_pageId+" .produ_text").removeAttr("style");
				var desc=data.results[0].product_description.substring(0,70);
				$(_pageId+" .cpxq").html(desc+'<a href="javascript:;" id="show"><font color="blue">····查看详情</font></a>');

				//点击详情
				$(_pageId+" #show").live("click",function(){
					$(_pageId+" .cpxq").html(data.results[0].product_description+'<a href="javascript:;" id="hide"><font color="blue"> 收起</font></a>');

					//点击回收
					$(_pageId+" #hide").live("click",function(){
						var desc=data.results[0].product_description.substring(0,70);
						$(_pageId+" .cpxq").html(desc+'<a href="javascript:;" id="show"><font color="blue">····查看详情</font></a>');
					})
				});
			}
			$(_pageId+" .produ_img").html("<img src="+URL+data.results[0].img_url_l+">");//图片
			$(_pageId+" .produ_cont").html(data.results[0].product_info);//展示产品介绍
			findPriceRule();

			})
	}

	//查询服务方式和价格规则
	function  findPriceRule(){
		var product_id=appUtils.getPageParam().product_id;

		var param=
		{
			"product_id":product_id
		}
		service.findPriceRule(param,function(data){
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
			//购买类型
			var buy_type =  data.DataSet;
			var bytHtmls="";
			for(var i=0,len=buy_type.length;i<len;i++)
			{	 
			bytHtmls += "<li rules_id="+buy_type[i].rules_id+" rules_pri="+buy_type[i].rules_price+">"+buy_type[i].rules_price+buy_type[i].rules_explanation;+"</li>";
			}
			$(_pageId+" #gmlx").html(bytHtmls);
			$(_pageId+" #gmlx li:eq(0)").addClass("on");
			rules_id = $(_pageId+" #gmlx li:eq(0)").attr("rules_id");//默认选中一个
			rules_desc = $(_pageId+" #gmlx li:eq(0)").html();//默认选中一个
			relrs_price = $(_pageId+" #gmlx li:eq(0)").attr("rules_pri");//默认选中一个
			//用于切换购买类型 
			appUtils.bindEvent($(_pageId+" #gmlx li"),function(){				
				rules_id=$(this).addClass("on").attr("rules_id");
				rules_desc=$(this).addClass("on").html();
				relrs_price=$(this).addClass("on").attr("rules_pri");
				$(this).addClass("on").siblings().removeClass("on");
			})

			//服务方式
			var service_type = data.DataSet1;
			var fwfsHtmls = "";
			for(var i=0,len=service_type.length;i<len;i++)
			{
				fwfsHtmls += "<li service_type="+service_type[i].service_type+">"+service_type[i].service_type_desc+"<li>";
			}
			$(_pageId+" #fwfs").html(fwfsHtmls);
			$(_pageId+" #fwfs li:odd").remove();
			$(_pageId+" #fwfs li:eq(0)").addClass("on");
			service_typeparam=$(_pageId+" #fwfs li:eq(0)").addClass("on").attr("service_type");//默认选中一个
			service_desc=$(_pageId+" #fwfs li:eq(0)").addClass("on").html();//默认选中一个
			//默认切换服务方式
			appUtils.bindEvent($(_pageId+" #fwfs li"),function(){
				service_typeparam=$(this).addClass("on").attr("service_type");
				service_desc=$(this).addClass("on").html();
				$(this).addClass("on").siblings().removeClass("on");
			})
		})
	}

	//添加关注
	function addattention()
	{	 
		var user_id = appUtils.getSStorageInfo("user_id");//从seesion获得用户编号
		var product_id= save_value.product_id; //获得产品编号
		var param ={
			"user_id":user_id,
			"product_id":product_id,
			"product_sub_type":"3"
		};
		service.addAttention(param,function(data)
		{
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
			    return false;
			}
			else
			{
				layerUtils.iMsg(-1,"关注成功！");
			}
		});
	}


	//咨询产品购买
	function infobuy()
	{	
		var product_name=save_value.product_name;   //产品名称
		var user_id=appUtils.getSStorageInfo("user_id"); //用户编号
		var product_id=appUtils.getPageParam().product_id; //产品编号

		//1、检查是否已经登录
//		if(appUtils.getSStorageInfo("_isLoginIn") != "true")
//		{
//			appUtils.setSStorageInfo("_loginInPageCode", "mall/itemsInfoDetail");
//			appUtils.setSStorageInfo("_loginInPageParam", JSON.stringify(appUtils.getPageParam()));
//			appUtils.pageInit("mall/itemsInfoDetail", "account/userLogin");
//			return false;
//		}
		var param=
		{
			"user_id":user_id,
			"product_id":product_id,
			"service_type":service_typeparam,
			"rules_id":rules_id,
			"order_quantity":"1",
			"service_desc":service_desc,
			"rules_desc":rules_desc,
			"relrs_price":relrs_price
		}	
		appUtils.setSStorageInfo("paramConfirmOrder",JSON.stringify(param));
		appUtils.pageInit("mall/itemsInfoDetail","mall/infoOrder/confirmOrder",param);
	}

	//2、事件绑定
	function bindPageEvent()
	{
		//点击 立即购买
		appUtils.bindEvent($(_pageId+" .n2"),function(){
			infobuy();
		});

		//点击 增加购买金额
		appUtils.bindEvent($(_pageId+" .icon_add"),function(){addAndMin("add");});

		// 点击 减少购买金额
		appUtils.bindEvent($(_pageId+" .icon_less"),function(){addAndMin("min");});

		// 点击 关注 
		appUtils.bindEvent($(_pageId+" .n1"),function(){addattention();});

		// 点击返回 
		appUtils.bindEvent($(_pageId+"  .icon_back"),function(){appUtils.pageBack();});

		//点击 返回顶部
		appUtils.bindEvent($(_pageId+" .back_top .back_btn"),function(){
			$(document.body).ScrollTo(0);
//			$('html,body').animate({scrollTop:0},700);
			return false;
		});
		
		$(window).scroll(function(){  //只要窗口滚动,就触发下面代码 
			var scrollt = document.documentElement.scrollTop + document.body.scrollTop; //获取滚动后的高度 
			if( scrollt >200 ){  //判断滚动后高度超过200px,就显示  
			       $(_pageId+" .back_top .back_btn").fadeIn(400); //淡出     
			}else{      
			       $(_pageId+" .back_top .back_btn").stop().fadeOut(400); //如果返回或者没有超过,就淡入.必须加上stop()停止之前动画,否则会出现闪动   
			}
			});
		
		//点击 LOGO 
		appUtils.bindEvent($(_pageId+" .logo"),function(){appUtils.pageInit("mall/itemsInfoDetail","account/mainPage")});

		//判断输入是否合法
		appUtils.bindEvent($(_pageId+" #buyValue"),function(){putils.numberLimit($(this));},"keyup");

		//控制输入不能为空
		appUtils.bindEvent($(_pageId+" #buyValue"),function(){
			if($(this).val()==null||$(this).val()==""){
				$(this).val(0);
			}
			$(this).val(putils.moneyFormat($(this).val()));

		},"blur");


		// 点击登录
		appUtils.bindEvent($(_pageId+" .icon_info"),function(){
			appUtils.pageInit("mall/itemsInfoDetail","account/userCenter",{});
		});
	}

	//3、销毁
	function destroy()
	{

	}

	var itemsInfoDetail =
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = itemsInfoDetail;

	});
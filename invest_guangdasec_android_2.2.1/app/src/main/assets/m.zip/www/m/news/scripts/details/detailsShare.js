/**
 * 
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils");
	var layerUtils = require("layerUtils");
	var gconfig = require("gconfig");
    var global = gconfig.global;
    var common = require("common");
    var service_news = require("service_news");
    var _pageId = "#details_detailsShare ";
    var _articleId = "";
    var _returnPage = "";
    var _catalogId = "";
    var _author = "";
    
    /**
     * 初始化
     */
	function init(){
		// $(_pageId + ".main").height($(window).height() - $(_pageId + ".header").height() - $(_pageId + "footer").height());
		$(_pageId + ".main").height($(window).height() - $(_pageId + ".header").height());
		$(_pageId + ".main").css("overflow-y","auto");
		
		//初始化顶部标题
		$(_pageId + ".title").text("内参 · " + appUtils.getSStorageInfo("catalogTit"));
		
		_returnPage = appUtils.getPageParam("returnPage");   //需要返回的页面
		_catalogId = appUtils.getPageParam("catalogId");   //返回页面携带的栏目编号
		_articleId = appUtils.getPageParam("articleId");   //传过来的文章编号
		_author = appUtils.getPageParam("author");
		if(!_articleId || _articleId == null || _articleId == "undefined"){
			layerUtils.iMsg(-1,"获取文章编号失败!");
			return;
		}
		
		queryArticleContent();   //查询文章内容
		
		//字体切换按钮初始化
		$(_pageId + ".header_inner .icon_font").addClass("on");
    }
	
	/**
	 * 事件绑定
	 */
	function bindPageEvent(){
		//返回按钮
		appUtils.bindEvent($(_pageId + ".header_inner .icon_back"), function(e){
			if(!_returnPage || _returnPage == null || _returnPage == "undefined"){
				_returnPage = "home/newsHome";
			}
//			appUtils.pageInit("details/detailsShare",_returnPage,{"catalogId":_catalogId,"flag":true});
			appUtils.setSStorageInfo("flag",true);
			appUtils.pageInit("details/detailsShare",_returnPage,{"catalogId":_catalogId,"articleId":_articleId});
			e.stopPropagation();
		});
		
		//字体大小切换
		appUtils.bindEvent($(_pageId + ".header_inner .icon_font"), function(e){
			$(this).toggleClass("on");
			if($(this).attr("class") == "icon_font"){
				$(_pageId + ".article_wrap .article_box").css("font-size","0.12rem");
				$(_pageId + ".article_wrap .article_box *").css("font-size","0.12rem");
			}else{
				$(_pageId + ".article_wrap .article_box").css("font-size","0.16rem");
				$(_pageId + ".article_wrap .article_box *").css("font-size","0.16rem");
			}
			e.stopPropagation();
		});
		
		//点赞
		appUtils.bindEvent($(_pageId + ".foot_flex1 a:first"), function(e){
			if($(this).find("span").attr("class") != "on"){
				//点赞+1
				AddLikeNum();
			}else{
				//取消点赞
				reduceLikeNum();
			}
			e.stopPropagation();
		});
		
	}
	
	/**
	 * 销毁
	 */
	function destroy(){
		$(_pageId + ".content").html("");
	    _articleId = "";
	    _returnPage = "";
	    _catalogId = "";
	    _author = "";
	    $(_pageId + ".foot_flex1 a:first").removeClass("on");
	}
	
	//增加点赞数
	function AddLikeNum(){
		var parme = {
				"article_id":_articleId
		};
		service_news.AddLikeNum(parme,AddLikeNumCallBack);
	}
	
	//点赞回调
	function AddLikeNumCallBack(data){
		if(data.error_no == 0){
			$(_pageId + ".foot_flex1 a:first span").toggleClass("on");
			//记录点赞状态
			common.addLikeStatus(_articleId);
		}
	}

	//取消点赞
	function reduceLikeNum(){
		var parme = {
				"article_id":_articleId
		};
		service_news.reduceLikeNum(parme,reduceLikeNumCallBack);
	}
	//取消点赞回调
	function reduceLikeNumCallBack(data){
		if(data.error_no == 0){
			$(_pageId + ".foot_flex1 a:first span").toggleClass("on");
			//删除点赞状态 
			common.removeLikeStatus(_articleId);
		}
	}
	
	//增加浏览数
	function AddPageViews(articleId){
		var parme = {
			"article_id":articleId
		};
		service_news.AddPageViews(parme,AddPageViewsCallBack,{"isLastReq":false,"isShowWait":false});
	}
	
	//增加浏览数回调
	function AddPageViewsCallBack(data){
		if(data.error_no == 0){
		}else{
		}
	}
	
	//查询文章内容
	function queryArticleContent(){
		var param = {
			"article_id":_articleId
		};
		service_news.queryArticleContent(param,queryArticleContentCallBack,{"isLastReq":true,"isShowWait":true});
	}
	//查询文章内容回调
	function queryArticleContentCallBack(data){
		if(data.error_no == 0){
			
			//增加浏览量
			AddPageViews(_articleId);
			var results = data.results;
			
			if(results.length>0){
				$(_pageId + ".content").html(createHTML(results[0]));
				
				//设置文章显示div高度
				// $(_pageId+".main .article_wrap").height($(_pageId + ".main").height()-12);  带空白条
				$(_pageId+".main .article_wrap").height($(_pageId + ".main").height());
				$(_pageId + ".main .article_wrap").css("overflow-y","auto");
				//设置文章字体默认大小,元素最大宽度，内边距,外边距
				$(_pageId + ".article_wrap .article_box *").css({"font-size":"0.16rem","padding":"0","max-width":$(_pageId+".article_wrap").width(),"margin":"0"});
//				$(_pageId + ".article_wrap .article_box span").css("display","inline-block");
				//设置文章中图片的宽度
				setImg();
			}else{
				var strHTML = "";
				strHTML += "<div class='no_data' style='margin:50% auto;'>";
				strHTML += "<span class='icon'></span>";
				strHTML += "<p style='text-align:center;'>暂无文章信息</p>";
				strHTML += "</div>";
				$(_pageId + ".content").html(strHTML);
				layerUtils.iAlert("未查询到相应的文章内容信息!");
			}
			//查询文章是否在列表时被点赞
			if(common.queryLikeStatus(_articleId) > -1){
				$(_pageId + ".foot_flex1 a:first span").addClass("on");
			}else{
				$(_pageId + ".foot_flex1 a:first span").removeClass("on");
			}
		}else{
			layerUtils.iAlert(data.error_info);
		}
	}
	//设置文章中图片的宽度
	function setImg(){
		var maxWidth = $(_pageId+".article_wrap").width();
		var style = "max-width:"+maxWidth+"px;height:auto;";
		style += "width:expression(this.width > "+maxWidth+" ? '"+maxWidth+"px' : this.width);";  //兼容IE
		$(_pageId+".article_wrap img").attr("style",style);
	}
	
	//生成文章内容HTML
	function createHTML(element){
		//替换文章内容中图片路径
		var strHTML = "";
		strHTML += "<div class='article_wrap'>";
		strHTML += "<div class='art_tit'>";
		strHTML += "<h6>"+element.title+"</h6>";
		strHTML += "<p><time>"+element.publish_date+"</time>&nbsp;&nbsp;<span>"+_author+"</span></p>";
		strHTML += "</div>";
		strHTML += "<div class='article_box' style='display:initial;font-size:0.16rem;'>";//display: initial
//		strHTML += "<p style='display: inherit;font-size:0.16rem;'>"+replaceSrc(element.content.replaceAll("style=\"","abc=\""))+"</p>";
		strHTML += "<div style='maxWidth:"+$(_pageId+".article_wrap").width()+"px;height:auto;'><p style='display: inherit;font-size:0.16rem;'>"+replaceSrc(element.content)+"</p></div>";
		strHTML += "</div>";
		strHTML += "</div>";
		return strHTML;
	}
	//替换文章内容图片的路径
	function replaceSrc(contentStr){
		var imgHead="<img src=\""+global.serviceUrl;
		contentStr=contentStr.replaceAll("<img src=\"",imgHead);
		return contentStr;
	}
	
	function pageBack(){
		if(!_returnPage || _returnPage == null || _returnPage == "undefined"){
			_returnPage = "home/newsHome";
		}
		appUtils.setSStorageInfo("flag",true);
		appUtils.pageInit("details/detailsShare",_returnPage,{"catalogId":_catalogId,"articleId":_articleId});
	}
	
	var base = {
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy,
		"pageBack": pageBack
	};
	module.exports = base;
});
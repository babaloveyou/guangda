/*
 * 设置预约取款金额
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	validatorUtil = require("validatorUtil"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	_pageId = "#xjb_setReservation ",
	yykqje = 0,//已预约金额
	maxYykqje = 0;//最大预约金额
	var prePage = "";
	
	/*
	 * 页面初始化
	 */
	function init(){
		if($(_pageId).width()<=336){
			$(_pageId+" .mn_tab ul li a").css({"font-size":"10px"});
		}
		var pageInParam  = appUtils.getPageParam();
		if(pageInParam){
			prePage = pageInParam.prePage;
		}
		var param = {
			"branch_no":appUtils.getSStorageInfo("branch_no"),
			"account":appUtils.getSStorageInfo("fund_account"),
			"market":"1"
		};
		service.queryYykqje(param,function(data){//查询已预约金额
			if(data.error_no == 0){
				yykqje = data.results[0].money;
				if(yykqje){
					$(_pageId+" .max_box p:eq(1)").html("<span>已预约金额 : </span>"+parseFloat(yykqje).toFixed(2));	
				}else{
				//	layerUtils.iAlert("查询预约金额失败");
				}
				
				var par = {
					"branch_no":appUtils.getSStorageInfo("branch_no"),
					"fund_account":appUtils.getSStorageInfo("fund_account"),
					"market":"1"
				};
				service.queryMaxYykqje(par,function(data){
					if(data.error_no == 0){
						maxYykqje = data.results[0].useable_money;
						$(_pageId+" .max_box p:eq(0)").html("<span>最大预约金额 :</span>"+parseFloat(maxYykqje).toFixed(2));
						$(_pageId+" .inputMoney").focus();
					}else{
						layerUtils.iLoading(false);
						layerUtils.iAlert(data.error_info);
					}
				});
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		});
	}
	
	/*
	 * 绑定页面事件
	 */
	function bindPageEvent(){
		
		//返回
		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(){
			if(prePage == "mall_myProduct"){
				var toPage = "";
    			if(gconfig.platform == "2"){
    				toPage={"prefix":"www/m/mall","suffix":"account/myProduct","prePage":"fz_xjb_setReservation"};
    			}else{
    				toPage = "/mall/index.html#!/account/myProduct.html?prePage=fz_xjb_setReservation";
    			}
    			var param = {"funcNo":"50101","moduleName":"financial-mall","params":{"moduleName":"user-center","toPage":toPage}};
    			require("external").callMessage(param);
			}else{
				appUtils.pageInit("xjb/setReservation","account/userCenter",{});
			}
		});
		
		//设置
		appUtils.bindEvent($(_pageId+" .ce_btn a"),function(){
			var money = $(_pageId+" .t1").val();
			if(validatorUtil.isEmpty(money)){
				layerUtils.iAlert("输入的金额不能为空");
				return false;
			}
			if(!validatorUtil.isMoney(money)){
				layerUtils.iAlert("输入的格式不正确");
				return false;
			}
			if(parseFloat(money) > parseFloat(maxYykqje)){
				layerUtils.iAlert("超过最大预约金额");
				return false;
			}
			var par = {
				"branch_no":appUtils.getSStorageInfo("branch_no"),
				"fund_account":appUtils.getSStorageInfo("fund_account"),
				"market":"1",
				"money":money
			};
			service.setYykqje(par,function(data){
				if(data.error_no == 0){
					$(_pageId+" .max_box p:eq(1)").html("<span>已预约金额 : </span>"+parseFloat($(_pageId+" .t1").val()).toFixed(2));
					layerUtils.iAlert("设置成功");
				}else{
					layerUtils.iLoading(false);
					var error = data.error_info;
					//后台返回的提示信息不友好
					if(error.indexOf("SQL")> -1){
						error = error.split("SQL")[0];
						error = error.substring(0,error.length-2);
					}
					layerUtils.iAlert(error);
				}
			});
		});
		
		//tab0
		appUtils.bindEvent($(_pageId+" .mn_tab .setReservationItem"),function(){
			
		});
		
		//tab1
		appUtils.bindEvent($(_pageId+" .mn_tab .fastCashItem"),function(){
			appUtils.pageInit("xjb/setReservation","xjb/fastCash",{});
		});
		
		//tab2
		appUtils.bindEvent($(_pageId+" .mn_tab .setReserveFundsItem"),function(){
			appUtils.pageInit("xjb/setReservation","xjb/setReserveFunds",{});
		});
		
		//tab3
		appUtils.bindEvent($(_pageId+" .mn_tab .setStateItem"),function(){
			appUtils.pageInit("xjb/setReservation","xjb/setState",{});
		});
		
		//tab4
		appUtils.bindEvent($(_pageId+" .mn_tab .queryQuotientItem"),function(){
			appUtils.pageInit("xjb/setReservation","xjb/queryQuotient",{});
		});
		
	}
	
	/*
	 * 销毁页面
	 */
	function destroy(){
		
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy
	};
	//暴露方法
	module.exports = base;
});
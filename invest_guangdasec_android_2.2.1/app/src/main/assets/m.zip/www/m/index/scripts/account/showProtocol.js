/**
 * 光大富尊
 */
define(function(require, exports, module){ 
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
		layerUtils = require("layerUtils"),
		gconfig = require("gconfig"),
		global = gconfig.global,
		service = require("serviceImp"),  //业务层接口，请求数据
		_pageId = "#account_showProtocol ";
	/* 私有业务模块的全局变量 end */

	var prePageCode;

	function init(param){
		prePageCode = appUtils.getSStorageInfo("_prePageCode");

		var econtract_no = appUtils.getPageParam("econtract_no");
		service.queryXyInfo({"econtract_no":econtract_no},function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			
			if(error_no ==0){
				$(_pageId + " .risk_entry").html((data.results)[0].econtract_content);
			}else{
				layerUtils.iAlert(error_info);
			}
		});
	}
	
	function bindPageEvent(){
		/* 返回  */
		appUtils.bindEvent($(_pageId+".icon_back span"),function(e){
			appUtils.pageInit("account/showProtocol",prePageCode);
		});
		
		//确定
		appUtils.bindEvent($(_pageId + " .ce_btn a"),function(){
			appUtils.pageInit("account/showProtocol",prePageCode);
		});
	}
	
	function destroy(){}
	
	var index = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	module.exports = index;
});
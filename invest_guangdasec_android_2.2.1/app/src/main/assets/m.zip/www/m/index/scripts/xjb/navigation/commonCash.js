/*
 * 普通取现
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	_pageId = "#xjb_navigation_commonCash ",
	yykqje = 0,//已预约金额
	maxYykqje = 0;//最大预约金额
	/*
	 * 页面初始化
	 */
	function init(){
		//设置页面高度
		$(_pageId + " .main").height($(window).height() - $(_pageId + " .header").height());
		$(_pageId + " .main").css("overflow-y","auto");
		$(_pageId+" input").val("");
		queryMoney();
	}
	function queryMoney(){
		var param = {
				"branch_no":appUtils.getSStorageInfo("branch_no"),
				"account":appUtils.getSStorageInfo("fund_account"),
				"market":"1"
		};
		service.queryYykqje(param,function(data){//查询已预约金额
			if(data.error_no == 0){
				yykqje = data.results[0].money;
				if(yykqje){
					$(_pageId+" .yuyue span").html(parseFloat(yykqje).toFixed(2)+"元");	
				}else{
					$(_pageId+" .yuyue span").html("----");
				//	layerUtils.iAlert("查询预约金额失败");
				}
				
				var par = {
					"branch_no":appUtils.getSStorageInfo("branch_no"),
					"fund_account":appUtils.getSStorageInfo("fund_account"),
					"market":"1"
				};
				service.queryMaxYykqje(par,function(data){
					if(data.error_no == 0){
						maxYykqje = data.results[0].useable_money;
						var show="";
						if(yykqje == null || yykqje ==undefined || yykqje == ""){
							show = parseFloat(maxYykqje).toFixed(2);
						}else{
							show = (parseFloat(yykqje)+parseFloat(maxYykqje)).toFixed(2);
						}
						$(_pageId+" input").attr("placeholder","最大可预约"+show);
					}else{
						layerUtils.iLoading(false);
						layerUtils.iAlert(data.error_info);
					}
				});
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		});
	}
	/*
	 * 绑定页面事件
	 */
	function bindPageEvent(){
		//监听input输入框
		appUtils.bindEvent($(_pageId+" input"),function(){
			var value = $(this).val();
			value=value.replace(/[^\d\.]/g,'');
			$(this).val(value);
			var ch = value.substr(value.length - 1,1); //当前输入的字符
			var pattern = /[0-9]+/;
			var reg = /\d+(\.\d{1,2})?/;
			var flag = false;   //当前字符是否合法
			if(value.length == 1){  //是否是第一个字符
				flag = pattern.test(ch);
			}else{
				if(value.substr(0,1) == 0 && value.length == 2){//检测第一个字符为0时,第二个是否是小数点
					flag = ch == ".";
				}else if(ch == "." && value.indexOf(".") ==  value.lastIndexOf(".")){//检测是否出现两个小数点
					flag = true;
				}else if(value.lastIndexOf(".") > 0 && value.lastIndexOf(".") < (value.length - 3)){//检测小数点后的位数
				}else{
					flag = reg.test(ch);
				}
			}
			if(!flag){//删除不合法字符
				value = value.substr(0, value.length - 1);
				$(this).val(value);
			}
			if(value != ""){
				$(_pageId + " .main .definbtn_01").css("background","#1199EE");
				$(_pageId + " .main .definbtn_01").addClass("isBlue");
			}else{
				$(_pageId + " .main .definbtn_01").css("background","#bebebe");
				$(_pageId + " .main .definbtn_01").removeClass("isBlue");
			}
		},"input");
		//返回
		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(e){
			pageBack();
			e.stopPropagation();
		});
		
		//清空输入
		appUtils.bindEvent($(_pageId+" .qkamout a"),function(e){
			$(_pageId + " .main .definbtn_01").css("background","#bebebe");
			$(_pageId + " .main .definbtn_01").removeClass("isBlue");
			$(_pageId+" input").val("");
		});
		
		//设置
		appUtils.bindEvent($(_pageId+" .definbtn_01"),function(e){
			$(_pageId+" .main input").blur();
			if($(this).hasClass("isBlue")){
				var value = $(_pageId+" input").val();
				if(value.substr(value.length - 1,1) == "."){//最后一个是小数点
					value += "00";
					$(_pageId+" input").val(value);
				}
				var money = $(_pageId+" input").val();
				if(money == ""){
					layerUtils.iAlert("输入的金额不能为空");
					return false;
				}
				if(parseFloat(money) > (parseFloat(yykqje)+parseFloat(maxYykqje))){
					layerUtils.iAlert("超过最大预约金额");
					//还原输入框
					$(_pageId + " .main .definbtn_01").css("background","#bebebe");
					$(_pageId + " .main .definbtn_01").removeClass("isBlue");
					$(_pageId+" input").val("");
					return false;
				}
				//20160920更改设置普通取现金额设置
				var user=appUtils.getSStorageInfo("userinfo");
				var userinfo=JSON.parse(user);
				var s="1002";
				if(userinfo.user_type=="0"){
					s="1001";
				}
				var par = {
						"branch_no":appUtils.getSStorageInfo("branch_no"),
						"fund_account":appUtils.getSStorageInfo("fund_account"),
						"money":money,
						"cust_code":userinfo.user_code,
						"ticket":"",
		  				"survey_sn":s
				};
				service.xjb_SetYyMoney_apro(par,function(data){
					if(data.error_no == 0){
						$(_pageId+" .yuyue span").html(parseFloat($(_pageId+" input").val()).toFixed(2));
						layerUtils.iAlert("设置成功");
						queryMoney();
					}else{
						layerUtils.iLoading(false);
						var error = data.error_info;
						//后台返回的提示信息不友好
						if(error.indexOf("SQL")> -1){
							error = error.split("SQL")[0];
							error = error.substring(0,error.length-2);
						}
						layerUtils.iAlert(error);
					}
					//还原输入框和设置按钮
					$(_pageId + " .main .definbtn_01").css("background","#bebebe");
					$(_pageId + " .main .definbtn_01").removeClass("isBlue");
					$(_pageId+" input").val("");
				});
				
				/*
				var par = {
						"branch_no":appUtils.getSStorageInfo("branch_no"),
						"fund_account":appUtils.getSStorageInfo("fund_account"),
						"market":"1",
						"money":money
				};
				service.setYykqje(par,function(data){
					if(data.error_no == 0){
						$(_pageId+" .yuyue span").html(parseFloat($(_pageId+" input").val()).toFixed(2));
						layerUtils.iAlert("设置成功");
						queryMoney();
					}else{
						layerUtils.iLoading(false);
						var error = data.error_info;
						//后台返回的提示信息不友好
						if(error.indexOf("SQL")> -1){
							error = error.split("SQL")[0];
							error = error.substring(0,error.length-2);
						}
						layerUtils.iAlert(error);
					}
					//还原输入框和设置按钮
					$(_pageId + " .main .definbtn_01").css("background","#bebebe");
					$(_pageId + " .main .definbtn_01").removeClass("isBlue");
					$(_pageId+" input").val("");
				});*/
			}
			e.stopPropagation();
		});
	}
	
	/*
	 * 销毁页面
	 */
	function destroy(){
		$(_pageId + " .main .definbtn_01").css("background","#bebebe");
		$(_pageId + " .main .definbtn_01").removeClass("isBlue");
		$(_pageId+" input").val("");
		$(_pageId+" .yuyue span").html("----");
	}
	
	function pageBack(){
		appUtils.pageInit("xjb/navigation/commonCash","xjb/navigation/index",{});
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy,
			"pageBack":pageBack
	};
	//暴露方法
	module.exports = base;
});
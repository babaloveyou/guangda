define(function (require, exports, module) {
require("../css/keyPanel.css"); //加载所需的css
require("../css/autocomplete.css"); //加载所需的css
var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
    allSelectWord = "",
    curKey = "",
    curTextInput = null,
    submitCallBack = "",
    _pageId = "",
    lastKeyPannel="keyPanel_num";

 var numbers=new Array(); 
// 生成随机数的方法 
function generateRandom(count){ 
	
     var rand = parseInt(Math.random()*count); 
     for(var i = 0 ; i < numbers.length; i++){ 
          if(numbers[i] == rand){ 
               return false; 
          }      
     }
     numbers.push(rand);
}
/**
 * 键盘初始化
 * allSelectWord 初始化值
 * _curTextInput键入的input组件
 * _submitCallBack键盘确定回调函数
 * type设置默认的键盘，num是数字键，abc是英文键盘，默认是数字键盘
 * tip提示设置
 */
function init_keyPanel(pageId,_allSelectWord,_curTextInput,_submitCallBack,type,tip)
{
	// 循环N次生成随机数 
	for(var i = 0 ; ; i++){
    	// 只生成10个随机数 
	    if(numbers.length<10){ 
	          generateRandom(10); 
	    }else{ 
	      break; 
	   	}
	} 

	var i = 0;
	$(".word_num_table tr td a").each(function(){
		if($(this).attr("class")!="btn"){
			$(this).text(numbers[i]);
			i++;
		}
	});
	numbers=[];
	if(_pageId!=pageId)
	{
	 _pageId = pageId;
	 if(type&&type=="abc")
		 {
			lastKeyPannel="keyPanel_abc";
		 }
	 else 
		 {
		 lastKeyPannel="keyPanel_num";
		 }
	}
	
	
	
		
	keyPanelChange(lastKeyPannel,tip);
	curKey = "";
	allSelectWord = _allSelectWord; 
	curTextInput =  _curTextInput;
	submitCallBack =  _submitCallBack;
	
}

 
 




/**
 * 键盘添加监听
 * */
function addKeyPanel(ui,tip)
{
	var tip=tip?tip:"股票代码或者拼音";
	appUtils.bindEvent($("#"+ui+" a"),function(e){
		//增加样式
		var ele = e.srcElement?e.srcElement:e.target;
		curKey = ele.className;
		var blank = "&nbsp;";
		var cur = ele.innerHTML;
		
		if(cur == "清空")
		{
			allSelectWord = "";
			cur = "";
		}else if(cur == "关闭")
		{
			closeKeyPanel();
			return false;
		}
		else if(cur == "确定")
		{
			closeKeyPanel();
			return false;
		}else if(cur == "删除")
		{
			allSelectWord=allSelectWord.substring(0, allSelectWord.length-1);
			curTextInput.html(allSelectWord);
			submitCallBack(allSelectWord);
			return false;
		}else if(cur == "搜索")
		{
			if(allSelectWord == "" || allSelectWord.length<=0)
			{
				layerUtils.iMsg(-1,"请键入"+tip);
				return false;
			}
			submitCallBack(allSelectWord);
			return false;
		}else if(cur == blank)//回退或者回退
		{
			cur = "";
			if(curKey == "space")//空格
			{
				layerUtils.iMsg(-1,"该控件只允许输入数字,请切换到数字键盘");
			}else if(curKey == "caps")//大小写转换
			{
				ele.className = "caps current";
				$(".col10 a").each(function(e){
					var eles = $(this);
					if(eles != null && eles[0].innerHTML != "&nbsp;")
					{
						eles[0].innerHTML = eles[0].innerHTML.toUpperCase();
					}
				});
			}else if(curKey == "caps current")//大小写转换
			{
				ele.className = "caps";
				$(".col10 a").each(function(e){
					var eles = $(this);
					if(eles != null && eles[0].innerHTML != "&nbsp;")
					{
						eles[0].innerHTML = eles[0].innerHTML.toLowerCase();
					}
				});
			}	
			
			
		}else if(cur == "ABC")
		{
			$("#keyPanel_abc").css("display","block");
			$("#keyPanel_num").css("display","none");
			lastKeyPannel="keyPanel_abc";
			return false;
		}else if(cur == "123")
		{
			$("#keyPanel_num").css("display","block");
			$("#keyPanel_abc").css("display","none");
			lastKeyPannel="keyPanel_num";
			return false;
		}
		allSelectWord+=cur;
		
		curTextInput.html(allSelectWord);
		submitCallBack(allSelectWord);
	});
}
/**
 * 关闭输入法
 * 
 * */
function closeKeyPanel()
{
	if($(" #keyPanel_num").length > 0)
	{
		$("#keyPanel_num").slideUp("fast");
		$("#keyPanel_num a").unbind("click");
	}
	if($("#keyPanel_abc").length > 0)
	{
		$("#keyPanel_abc").slideUp("fast");
		$("#keyPanel_abc a").unbind("click");
	}
	 $(".trade_body").css("margin-top","0px");
	 $(" header").show();
}

/**
 * 切换输入法
 * */
function keyPanelChange(tabPanel,tip)
{
	 if(tabPanel == "" || tabPanel == null || tabPanel == undefined)
	 {
		
		 tabPanel = "keyPanel_num";
	 }
	 addKeyPanel("keyPanel_abc",tip);
	 addKeyPanel("keyPanel_num",tip);
	 
	 $(".word_table").slideDown("fast");
	 $("#"+tabPanel).css("display","block").siblings(".word_table").css("display","none");
}

var clearSelectWord = function clearSelectWord()
{
	allSelectWord = "";
	curKey = "";
};
	
var keyPanels = {
		"init_keyPanel" : init_keyPanel,
		"clearSelectWord" : clearSelectWord,
		"closeKeyPanel" : closeKeyPanel,
		"allSelectWord":allSelectWord
	};
	//暴露对外的接口
	module.exports = keyPanels;	
});
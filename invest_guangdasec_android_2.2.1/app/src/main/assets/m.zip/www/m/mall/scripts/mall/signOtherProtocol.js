/**
 * 非金融产品--签署协议
 */
define(function(require, exports, module)
	{	
	var service = require("mobileService");//业务层接口，请求数据
	var appUtils = require('appUtils'),
	putils = require("putils"),
	layerUtils = require("layerUtils"),
	constants=require("constants");//常量类
	gconfig = require("gconfig"),
	global = gconfig.global;
	var _pageId ="#mall_signOtherProtocol";

	//1、初始化
	function init() 
	{	
		var pageInParam=appUtils.getPageParam();
		var _agreement_title=pageInParam._agreement_title; //协议标题
		var _agreement_id=pageInParam._agreement_id;       //协议编号
		var results=pageInParam.results;				   //协议结果集

		for (var i  =0; i < results.length; i++)
		{
			if(results[i].agreement_id==_agreement_id)
			{
				$(_pageId+" .agreem_title").html(results[i].agreement_title); //展示协议标题
				$(_pageId+" .agreem_text").html(results[i].agreement_content);//展示协议内容
			}
		} 
	}
	//签署协议
	function showContract()
	{
		var pageInParam  = appUtils.getPageParam();
		var user_id = appUtils.getSStorageInfo("user_id");
		var product_id=pageInParam.product_id;
		var results = pageInParam.results[0];
		console.info(results)
		var product_sub_type=pageInParam.product_sub_type;

		var param=
		{
			"user_id":user_id,
			"product_id":product_id,
			"product_sub_type":product_sub_type
		}
		service.signOtherAgreement (param,function(data){

			if(data.error_no!= "0") 
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
			if(data.error_info!="调用成功")
			{
				return false;
			}
			if(product_sub_type=='2')
			{
				$("#mall_servOrder_confirmOrder #tjdd").show();
				layerUtils.iMsg(0,"签署成功！");
				//签署成功，跳转
 				$("#mall_servOrder_confirmOrder #signProtocol").attr("checked", "checked") ;
			}
			else
			{
				$("#mall_infoOrder_confirmOrder #tjdd").show();
				layerUtils.iMsg(0,"签署成功！");
				//签署成功，跳转
				$("#mall_infoOrder_confirmOrder li a[agreement_id]").append("（<span style='color:green'>已签署</span>）");
				$("#mall_infoOrder_confirmOrder #signProtocol").attr("checked", "checked") ;
			}

			//签署完成，返回到上一个页面
			appUtils.pageBack();
		})
	}
	//2、事件绑定
	function bindPageEvent()
	{	
		//点击签署协议
		appUtils.bindEvent($(_pageId+" .login_btn_ok"),function(){

			//签署协议
			showContract();

		});

		//点击 返回顶部
		appUtils.bindEvent($(_pageId+" .back_btn"),function(){$('body,html').animate({scrollTop:0},1000);return false;});
	}

	//3、销毁
	function destroy()
	{
	}

	var signProtocol =
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = signProtocol;

	});
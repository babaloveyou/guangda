/*
 * E账号激活（完成）
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	_pageId = "#account_activateFinish ";
	
	/*
	 * 页面初始化
	 */
	function init(){
		var cust_code = appUtils.getPageParam("cust_code");
		var loginName = appUtils.getPageParam("loginName");
		
		// 显示分配的 E账号
		$(_pageId+" #cust_code").html(cust_code);
		$(_pageId+" #loginName").html(loginName);
	}
	
	/*
	 * 绑定页面事件
	 */
	function bindPageEvent(){
		//返回
		appUtils.bindEvent($(_pageId+" .radius"),function(){
			appUtils.pageInit("account/activateFinish","account/userCenter",{"cust_act_flag":"1"});
		});
	}
	
	/*
	 * 销毁页面
	 */
	function destroy(){
		
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy
	};
	//暴露方法
	module.exports = base;
});
/**
* 结果页
*/
define(function(require, exports, module){
	var appUtils = require("appUtils"),
	    gconfig = require("gconfig"),
	    global = gconfig.global,
		service = require("investService").getInstance(),  //业务层接口，请求数据
		_pageId = "#account_result";
	
	function init(){
		//电话号码
		var ggtopen_flag = appUtils.getSStorageInfo("ggtopen_flag"),  //港股通开通标志
			failReason = appUtils.getSStorageInfo("ggtopen_remark");   //失败原因
		var h1css = {color:'red'};
		//记录当前步骤，以便当用户重新进入时进行判定。
		appUtils.setSStorageInfo("current_step","account/result");
		if (ggtopen_flag == "2") {
			$(_pageId+" .icon").addClass("icon3");
			$(_pageId+" .succes_main h1").css(h1css);
			$(_pageId+" .succes_main h1").html("开通失败");
			$(_pageId+" .notice span:eq(0)").html("失败原因:"+failReason);
		} else if (ggtopen_flag == "0"){
			$(_pageId+" .succes_main h1").html("正在受理中");
			$(_pageId+" .notice span:eq(0)").html("尊敬的客户您好,港股通业务正在受理中");
		}
	}
	
	function bindPageEvent(){
		appUtils.bindEvent($(_pageId+" .tel"),function(){
			appUtils.pageInit("account/result","account/editNum",{});
		});
		appUtils.bindEvent($(_pageId+" .icon_back"),function(e){
			/* 绑定返回我的富尊主页 */
			var toPage = "";
			if(gconfig.platform == "2"){
				toPage={"prefix":"www/m/index","suffix":"account/userCenter"};
			}else{
				toPage = "/index/index.html#!/account/userCenter.html";
			}
            var param_index = {"funcNo":"50101","moduleName":"user-center","params":{"moduleName":"ggt","toPage":toPage}};
            require("external").callMessage(param_index);
            e.stopPropagation();
		});
		
		appUtils.bindEvent($(_pageId+" #returnToUserCenter"),function(e){
			/* 绑定返回我的富尊主页 */
			var toPage = "";
			if(gconfig.platform == "2"){
				toPage={"prefix":"www/m/index","suffix":"account/userCenter"};
			}else{
				toPage = "/index/index.html#!/account/userCenter.html";
			}
            var param_index = {"funcNo":"50101","moduleName":"user-center","params":{"moduleName":"ggt","toPage":toPage}};
            require("external").callMessage(param_index);
            e.stopPropagation();
		});
	}
	
	function destroy(){
		service.destroy();
	}
	
	var result = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	
	module.exports = result;
});
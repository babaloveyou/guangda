/*
 * 风险等级不适当
 * */
define(function(require, exports, module) {
	var service = require("mobileService");// 业务层接口，请求数据
	var appUtils = require('appUtils'), putils = require("putils"), gconfig = require("gconfig"), platform = gconfig.platform, global = gconfig.global;
	constants = require("constants");// 常量类
	layerUtils = require("layerUtils"), gconfig = require("gconfig"),
			global = gconfig.global;
	var _pageId = "#mall_otcOrder_riskFailure";
	var is_buysuperrisk = "";

	// 1、初始化
	function init() {
		var pageParam = appUtils.getPageParam();
		$(_pageId + " #presonRiskLevel").html(pageParam.risk_name);

		var notMatchTips = "";
		var notMatchTips1 = ";";
		var notMatchTips2 = ";";
		if (pageParam.risk_not) {
			notMatchTips += "其产品风险等级与本人/本机构的<span>风险承受能力不匹配。</span>；";
		}
		if (pageParam.invest_variety) {
			notMatchTips1 += "其产品投资期限与本人/本机构<span>拟投资的期限不匹配</span>；";
		}
		if (pageParam.invest_deadline) {
			notMatchTips2 += "其产品投资品种与本人/本机构<span>拟投资的品种不匹配</span>；";
		}

		/*
		 * if (notMatchTips.length < 4) { notMatchTips += "其产品风险等级与本人/本机构的<span>风险承受能力不匹配。</span>；"; }
		 */
		$(_pageId + " #notMatchTips").html(notMatchTips);
		$(_pageId + " #notMatchTips1").html(notMatchTips1);
		$(_pageId + " #notMatchTips2").html(notMatchTips2);

		OTCinfo();

		// otcRiskResult();
	}

	function otcRiskResult() {
		var cust_code = appUtils.getSStorageInfo("cust_code");
		var ticket = appUtils.getSStorageInfo("ticket");
		var user_type = appUtils.getSStorageInfo("user_type");
		var survey_sn = "";
		if (user_type == "0") {
			survey_sn = "1001";
		} else if (user_type == "1") {
			survey_sn = "1002";
		} else {
			survey_sn = "1001";
		}
		var param = {
			"cust_code" : cust_code,
			"survey_sn" : survey_sn,
			"ticket" : ticket
		};
		service.newRiskResult(param, function(data) {
			var error_no = data.error_no;
			var error_info = data.error_info;
			if (error_no == 0) {
				var risk_name = data.results[0].risk_name;
				$(_pageId + " #presonRiskLevel").html(risk_name);
			} else {
				layerUtils.iAlert(error_info);
				layerUtils.iLoading(false);
				return false;
			}
		}, {});
	}

	function OTCinfo() {
		var risk_not = appUtils.getPageParam("risk_not");
		var product_id = appUtils.getPageParam("product_id");// 页面跳转传过来的id
		if (product_id == null) {
			layerUtils.iMsg(1, "数据加载错误！");
			appUtils.pageInit("mall/otcOrder/riskFailure", "account/mainPage",
					{});
			return false;
		}
		var param = {
			"product_id" : product_id
		};
		service.OTCInfo(param, function(data) {
			if (data.error_no == "0") {
				var result = data.results[0];
				var risk_lvl = result.risk_lvl;// 风险等级
				var pro_deadline = result.pro_deadline;// 投资期限
				var belongs_invtype = result.belongs_invtype;// 投资类型
				is_buysuperrisk = result.is_buysuperrisk;// 超风险购买
				if (risk_not) {
					if (is_buysuperrisk == "0") {
						$(" #two_quedingbtn").hide();// 不匹配且不允许超风险购买时隐藏购买按钮
						$(" #quedingbtn").show();
					} else {
						$(" #two_quedingbtn").show();// 不匹配且允许超风险购买时显示购买按钮
						$(" #quedingbtn").show();
					}
				} else {
					$(" #two_quedingbtn").show();// 风测匹配时显示购买按钮
					$(" #quedingbtn").hide();
				}
				var risk_level_name = "";
				switch (risk_lvl) {
				case "1":
					risk_level_name = "低风险；";
					break;
				case "2":
					risk_level_name = "中低风险；";
					break;
				case "3":
					risk_level_name = "中风险；";
					break;
				case "4":
					risk_level_name = "中高风险；";
					break;
				case "5":
					risk_level_name = "高风险；";
					break;
				}
				if (pro_deadline == "") {
					pro_deadline = appUtils.getPageParam("invest_variety")
							|| "---";
				}
				if (belongs_invtype == "") {
					belongs_invtype = appUtils.getPageParam("invest_deadline")
							|| "--";
				}
				$(_pageId + " #risk_level").html(risk_level_name);
				$(_pageId + " #deadline").html(pro_deadline);
				$(_pageId + " #belongs_invtype").html(belongs_invtype);
			} else {
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
		});
	}

	// 2、事件 绑定
	function bindPageEvent() {
		/*
		 * //再做风险测评 appUtils.bindEvent($(_pageId+" #feng_xian"),function(){ var
		 * pageInParam = appUtils.getPageParam();
		 * appUtils.pageInit("mall/otcOrder/riskFailure","otc/riskAssessment",pageInParam);
		 * });
		 */
		// 再做风险测评
		appUtils.bindEvent($(_pageId + " #re_feng_xian"), function() {
			var pageInParam = appUtils.getPageParam();
			appUtils.pageInit("mall/otcOrder/riskFailure",
					"otc/riskAssessment", pageInParam);
		});

		// 点击返回
		appUtils.bindEvent($(_pageId + "  .close"), function() {

			appUtils.pageBack();
		});

		// 确定购买
		appUtils.bindEvent($(_pageId + " #goumai"), function() {
//			if (is_buysuperrisk == "0") {
//				layerUtils.iAlert("请先重新测评再来购买！！");
//				return false;
//			}
			otcBuy();
			// signOTCAgreement();
		});
	}

	// 签署协议（500100）
	function signOTCAgreement() {
		var cust_code = appUtils.getSStorageInfo("cust_code");
		var ticket = appUtils.getSStorageInfo("ticket");
		var pageInParam = appUtils.getPageParam();
		var product_id = pageInParam.product_id;
		var param = {
			"cust_code" : cust_code,
			"query_type" : "otclc",
			"product_id" : product_id,
			"ticket" : ticket
		};
		service.signNewAgreement(param, function(data) {
			var error_no = data.error_no;
			var error_info = data.error_info;
			if (error_no < 0) {
				layerUtils.iAlert(error_info);
				layerUtils.iLoading(false);
				return false;
			} else {
				otcBuy();
			}
		}, {
			"isLastReq" : false
		});
	}

	/**
	 * 2000004：购买OTC理财产品（下订单）
	 */
	function otcBuy() {
		var cust_code = appUtils.getSStorageInfo("cust_code");
		var cuacct_code = appUtils.getPageParam("cuacct_code");
		var pageInParam = appUtils.getPageParam();
		var product_id = pageInParam.product_id;
		var trd_amt = pageInParam.trd_amt;
		var product_name = pageInParam.product_name;
		var ticket = appUtils.getSStorageInfo("ticket");
		var param = {
			"cust_code" : cust_code,
			"cuacct_code" : cuacct_code,
			"product_id" : product_id,
			"trd_amt" : trd_amt,
			"ticket" : ticket,
			"risk_reveal_method" : "1",
			"order_channel" : "7"
		};
		service.otcBuy(param, function(data) {
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result = data.results[0];
			if (error_no == 0) {
				var order_id = result.order_id;// 订单编号
				var pageParam = appUtils.getPageParam();
				pageParam.order_id = order_id;
				appUtils.pageInit("mall/otcOrder/riskFailure",
						"mall/otcOrder/orderPay", pageParam);
			} else {
				layerUtils.iAlert(error_info);
				layerUtils.iLoading(false);
				return false;
			}
		}, {});
	}

	// 3、销毁
	function destroy() {

	}

	var riskFailure = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};

	module.exports = riskFailure;

});

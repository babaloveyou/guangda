/*
 * 现金宝参与状态设置
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	_pageId = "#xjb_navigation_fastCashNo ";
	var external = require("external");
	/*
	 * 页面初始化
	 */
	function init(){
		//设置页面高度
		$(_pageId + " .main").height($(window).height() - $(_pageId + " .header").height());
		$(_pageId + " .main").css("overflow-y","auto");
		$(_pageId + ".main .definbtn_01").css("background","#aaaaaa");
		$(_pageId + ".main .row_02").removeClass("check");
		
		//查询协议属性
		var ProtocolArray = [appUtils.getSStorageInfo("pro_code_t0_fwxy"),appUtils.getSStorageInfo("pro_code_t0_fxjs")]
		for(var i = 0;i<ProtocolArray.length;i++){
			queryProtocolAttr(ProtocolArray[i],i);
		}
		if($(_pageId + ".main .row_02").hasClass("active")){
			$(_pageId + ".main .row_02").addClass("check");
			$(_pageId + " .main .definbtn_01").css("background","#1199EE");
			$(_pageId + " .main .definbtn_01").addClass("isBlue");
		}
	}
	
	function queryProtocolAttr(protocols,index){
		service.queryProtocolAttr({"pro_code":protocols},function(data){
			if(data.error_no == 0){
				var pro_content = data.results[0].pro_content,
					pro_code = data.results[0].pro_code,
					file_name = data.results[0].file_name;
				$(_pageId+" .openment dd").eq(index).find("a").html("《"+data.results[0].pro_title+"》").attr("pro_content",pro_content).attr("pro_code",pro_code).attr("file_name",file_name);
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		});
	}
	
	/*
	 * 绑定页面事件
	 */
	function bindPageEvent(){
		
		//返回
		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(e){
			pageBack();
			e.stopPropagation();
		});
		
		//勾选
		appUtils.bindEvent($(_pageId + ".main .row_02"),function(e){
			$(this).toggleClass("check");
			if($(_pageId + ".main .row_02").hasClass("check")){
				$(_pageId + ".main .definbtn_01").css("background","#1199EE");
				$(_pageId + ".main .definbtn_01").addClass("isBlue");
			}else{
				$(_pageId + ".main .definbtn_01").css("background","#bebebe");
				$(_pageId + ".main .definbtn_01").removeClass("isBlue");
			}
			e.stopPropagation();
		});
		
		//立即签署
		appUtils.bindEvent($(_pageId+" .main .definbtn_01"),function(e){
			if($(_pageId + ".main .definbtn_01").hasClass("isBlue")){
//				openPower();
				suresqxieyi();
			}
			e.stopPropagation();
		});
		
		//查看协议
		appUtils.bindEvent($(_pageId+" .openment dd a"),function(e){
			var param = {
				pro_content:$(this).attr("pro_content"),
				pro_code:$(this).attr("pro_code"),
				file_name:$(this).attr("file_name")
			}
			showProtocol(param);
			// if($(this).index() == 0){//《光大阳光现金宝集合资产管理计划T+0快速取现业务客户服务协议》
				// showProtocol(appUtils.getSStorageInfo("pro_code_t0_fwxy"));
			// }
			// if($(this).index() == 1){//《光大阳光现金宝集合资产管理计划T+0快速取现业务风险揭示书》
				// showProtocol(appUtils.getSStorageInfo("pro_code_t0_fxjs"));
			// }
			e.stopPropagation();
		});

		//可签约银行列表
		appUtils.bindEvent($(_pageId+" .main .bankList"),function(e){
			var results = external.callMessage({"funcNo":"50109","url":global.backList});
			console.log(JSON.stringify(results));
			// appUtils.pageInit("xjb/navigation/fastCashNo","xjb/navigation/bankList",{});
			e.stopPropagation();
		});
	}
	
			/**
		 * T+0协议展示
		*/
	function showProtocol(param){
		// service.queryProtocolAttr({"pro_code":protocols},function(data){
			// if(data.error_no == 0){
				// var param = {
					// "pro_content":data.results[0].pro_content,
					// "pro_code":data.results[0].pro_code,
					// "file_name":data.results[0].file_name
				// };
				service.getProtocolContent(param,function(data){
					if(data.error_no == 0){
						var pdfUrl = global.pdfUrl + "/" + data.results[0].pdf_url;
						var results = external.callMessage({"funcNo":"50240","url":pdfUrl});
						console.log(JSON.stringify(results));
					}else{
						layerUtils.iLoading(false);
						layerUtils.iAlert(data.error_info);
					}
				});
			// }else{
				// layerUtils.iLoading(false);
				// layerUtils.iAlert(data.error_info);
			// }
		// });
   	}
	
	function suresqxieyi(){
		//签署协议前先判断银行卡是否支持快速取现
		var param = {
				"branch_no":appUtils.getSStorageInfo("branch_no"),
				"pro_code":appUtils.getSStorageInfo("pro_code"),
				"fund_account":appUtils.getSStorageInfo("fund_account"),
				"account_type":appUtils.getSStorageInfo("whichAccount"),
				"entrust_way":"SJWT"
			};
			service.getCardInfo(param,function(data){//查询银行卡信息作为入参2002022
				if(data.error_no == 0){
					var data=data.results;
					if(data.length>0){
						if('false'==data[0].flag){//不支持的三方存管银行
							layerUtils.iAlert("您的三方存管银行不支持T+0快速取现。");
							return;
						}else{//提交签署协议的请求
//							var ip = require("external").callMessage({"funcNo": "50023"});
							//获取手机号
							var mobilePhone = require("external").callMessage({"funcNo":"50043","key":"mobilePhone"}).results[0].value;
							var user=appUtils.getSStorageInfo("userinfo");
							var userinfo=JSON.parse(user);
							var signParam = {
									"branch_no":appUtils.getSStorageInfo("branch_no"),
									"account":appUtils.getSStorageInfo("fund_account"),
									"ezt_name":userinfo.user_code,
									"entrust_way":"SJWT",
									//20160923送手机号
									"mobile_channel":require("gconfig").platform,
									"mobile":mobilePhone
								};
							service.signFastCashProtocol(signParam,function(data){
									if(data.error_no == 0){
										var data=data.results;
										if(data!=null||data!=""){
											var flag=data[0].retval;
											if(flag=='该用户已签署过本产品'||flag=='电子合同签订成功'){
												openPower();//开通权限
											}else{
												layerUtils.iAlert(flag.trim());
												//测试专用,下一行
												// openPower();
											}
										}
									}else{
										layerUtils.iAlert(data.error_info);
									}
							});
						}
					}else{
						layerUtils.iAlert("还未绑定银行卡,请先绑定银行卡");
					}
				}
				else{
					layerUtils.iAlert(data.error_info);
//					layerUtils.iAlert("您的三方存管银行不支持T+0快速取现。"+data.error_info);
					
				}
			});
//			openPower();////开通T+0权限
	}
	
	
	//开通T+0权限
	function openPower(){
	    var callBack = function(data){//T+0快速取现权限开通功能号
			if(data.error_no == 0){
				if(data.results!=null){
					var result=data.results[0];
					if(result.err_state=='Y'){//开通权限成功
//						checkT0Power();
						layerUtils.iAlert("T+0快速取现开通成功",0,function(){
							appUtils.pageInit("xjb/navigation/fastcashNo","xjb/navigation/fastCash");
						});
					}else{
						layerUtils.iAlert("签署失败");
					}
				}else{
					layerUtils.iAlert(data.error_info);
				}
			}else{//开通失败
				layerUtils.iLoading(false);
   				var error = data.error_info;
   				//后台返回的提示信息不友好
   				if(error.indexOf("SQL")> -1){
   					error = error.split("SQL")[0];
   					var len = error.length;
   					error = error.substring(0,len-2);
   				}
   				layerUtils.iAlert(error);
			}
		};
		var param = {
				"branch_no":appUtils.getSStorageInfo("branch_no"),
				"account":appUtils.getSStorageInfo("fund_account"),
				"entrust_way":"SJWT",
				"is_open":1
			};
		service.openPower(param,callBack);//2002017
	}	
	
	/*
	 * 销毁页面
	 */
	function destroy(){
		$(_pageId + ".main .row_02").removeClass("check");
		$(_pageId + ".main .definbtn_01").css("background","#bebebe");
		$(_pageId + ".main .definbtn_01").removeClass("isBlue");
		$(_pageId+ " .main .definbtn_01").html("立刻签署");
		$(_pageId + ".main .row_02").removeClass("active");
	}
	
	function pageBack(){
		appUtils.pageInit("xjb/navigation/fastCashNo","xjb/navigation/index",{});
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy,
			"pageBack":pageBack
	};
	//暴露方法
	module.exports = base;
});
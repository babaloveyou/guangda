/*
 * E账号激活（协议）
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	_pageId = "#account_activateAgre ";
	
	/*
	 * 页面初始化
	 */
	function init(){
		
		var cust_code = appUtils.getPageParam("cust_code");
		if(cust_code){
			// 显示分配的 E账号
//			var EAccount = cust_code.replace(/(\d{4})\d{4}(\d{4})/, '$1XXXX$2');
			$(_pageId+" .active_info strong").html(cust_code);
		}
	}
	
	/*
	 * 绑定页面事件
	 */
	function bindPageEvent(){
		
		//返回
		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(){
			appUtils.pageBack();
		});
		
		//立即了解
		appUtils.bindEvent($(_pageId+" .knew"),function(){
			appUtils.pageInit("account/activateAgre","account/knew");
		});
		
		//同意
		appUtils.bindEvent($(_pageId+" .ce_btn>a"),function(){
			var EAccount = $(_pageId+" .active_info strong").html();
			if(EAccount){
				appUtils.pageInit("account/activateAgre","account/activateSet",{"cust_code":EAccount});
			}
		});
	}
	
	/*
	 * 销毁页面
	 */
	function destroy(){
		
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy
	};
	//暴露方法
	module.exports = base;
});
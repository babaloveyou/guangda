/*
 * 风险测评
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	_pageId = "#xjb_fxcp ";

	/*
	 * 页面初始化
	 */
	function init(){
		var user=appUtils.getSStorageInfo("userinfo");
		var userinfo=JSON.parse(user);
		var s="1002";
		if(userinfo.user_type=="0"){
			s="1001";
		}
		var param = {
			"cust_code":appUtils.getSStorageInfo("cust_code"),
			"survey_sn":s,
			"ticket":""
			//"risk_type_id":0
		};
		service.queryTestQuestion(param,function(data){
			var html = "";
			var results = data.results;
			var answers = "";
		//	alert(JSON.stringify(data));
			if(data.error_no == 0){
				for(var i = 0;i < results.length; i++){
					//因为数据库返回的answers不是json格式，自己解析
					answers = results[i].answers.substring(2,results[i].answers.length-2);
					answers = answers.split("{");
					console.log(answers);
					for(var k=0;k<answers.length;k++){
					    var answer = answers[k];
					    var questionInfo = {};
						if(k == 0){
							answer = answer.substring(0,answer.length-3);
							questionInfo = getJsonData(answer);
							html += "<dl class='part'><dt question_no="+questionInfo.question_no+">"+(i+1)+"、"+results[i].question_title+"</dt>" + "<dd><span class='icon_radio active' option_no='"+questionInfo.option_no+"' >"+questionInfo.description+"</span></dd>";;
						}else if(k == answers.length-1 ){
                            questionInfo = getJsonData(answer);
                            html +=  "<dd><span class='icon_radio' option_no='"+questionInfo.option_no+"'>"+questionInfo.description+"</span></dd></dl>";
						}else{
							answer = answer.substring(0,answer.length-3);
                            questionInfo = getJsonData(answer);
                            html +=  "<dd><span class='icon_radio' option_no='"+questionInfo.option_no+"'>"+questionInfo.description+"</span></dd>";
						}
					}
				}
				$(_pageId + " .test_main").prepend(html);	
				
				//默认选择第一项
				$(_pageId+" .test_main .part span").removeClass("active");
				$(_pageId+" .test_main .part").each(function(){
					$(this).find("dd").eq(0).find("span").addClass("active");
				});
				
				//绑定选择点击事件
				appUtils.bindEvent($(_pageId+" .test_main dd"),function(){
					$(this).siblings().find("span").removeClass("active");
					$(this).find("span").addClass("active");
				});
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		});
	}
	
	/*
	 * 绑定页面事件
	 */
	function bindPageEvent(){
		
		//返回
		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(){
			appUtils.pageBack();
		});
		
		//提交风险测评
		appUtils.bindEvent($(_pageId+" .ce_btn a"),function(){
			var content = "";
			var parts = $(_pageId+" .test_main .part");
			for(var i = 0;i<$(parts).size();i++){
					content += $(parts).eq(i).find("dt").attr("question_no")+"_";
					content += $(parts).eq(i).find("dd span[class*='active']").attr("option_no");
					if( i != $(parts).size()-1){
						content += "|";
					}
			}
			var user=appUtils.getSStorageInfo("userinfo");
			var userinfo=JSON.parse(user);
			var s="1002";
			if(userinfo.user_type=="0"){
				s="1001";
			}
			var param = {
				"cust_code":appUtils.getSStorageInfo("cust_code"),
				"survey_sn":s,
				"content" : content,
				"ticket":""
				//"risk_type_id":0
			};
			service.submitQuestionAnswer(param,function(data){
				if(data.error_no == 0){
					var result = data.results[0];
					var par = {
						"branch_no":appUtils.getSStorageInfo("branch_no"),
						"account":appUtils.getSStorageInfo("fund_account"),
						"evaluating_score":result.risk_fraction,
						"evaluating_result_grade":result.risk_level,
						"ezt_name":userinfo.user_code,
						"ticket":"",
						"survey_sn":s
					};
					service.xjb_fxcp(par,function(data){
						if(data.error_no == 0){
							appUtils.pageInit("xjb/fxcp","xjb/riskResult",{"risk_name":result.risk_name,"risk_fraction":result.risk_fraction});
						}else{
							layerUtils.iLoading(false);
							layerUtils.iAlert(data.error_info);
						}
					});
				}else{
					layerUtils.iLoading(false);
					layerUtils.iAlert(data.error_info);
				}
			});
		});
	}

	//将数组JSON化
	function getJsonData(answer){
		var questionInfo = {};
		$.each(answer.split(","),function(){
			var items = this.split("=");
			questionInfo[$.trim(items[0])] = $.trim(items[1]);
		});
		return questionInfo;
	}

	/*
	 * 销毁页面
	 */
	function destroy(){
		$(_pageId + " .part").remove();
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy
	};
	//暴露方法
	module.exports = base;
});
/*
 * 风险等级适当
 * */
define(function(require, exports, module)
	{
	var service = require("mobileService");//业务层接口，请求数据
	var appUtils = require('appUtils'),
	putils = require("putils"),
	constants=require("constants");//常量类
	layerUtils = require("layerUtils"),
	gconfig = require("gconfig"),
	global = gconfig.global;
	var _pageId ="#mall_finanOrder_riskSuccess";
	var  user_id="";
	 var  product_id="";
	 var  tot_price="";

	//1、初始化
	function init()
	{	
	     user_id = appUtils.getPageParam("user_id"); 
	     product_id = appUtils.getPageParam("product_id"); 
	     tot_price = appUtils.getPageParam("tot_price"); 
	  
	
	
		var  risk_name = appUtils.getPageParam("risk_name"); 
		$(_pageId+" #tian_kong0").html(risk_name);
		var  risk_level = appUtils.getPageParam("risk_level"); 
		var risk_level_name="";
		switch (risk_level){
		 case "1":
			 risk_level_name="低风险；";
		    break;
		  case "2":
			  risk_level_name="中低风险；";
		    break;
		  case "3":
			  risk_level_name="中风险；";
		    break;
		  case "4":
			  risk_level_name="中高风险；";
		    break;
		  case "5":
			  risk_level_name="高风险；";
		    break;
		}
		$(_pageId+" #tian_kong1").html(risk_level_name);
		var  tzqx_code = appUtils.getPageParam("tzqx_code");
		var tzqx_code_name="";
		switch (tzqx_code){
		 case "1":
			 tzqx_code_name="0到1年；";
		    break;
		  case "2":
			  tzqx_code_name="1到5年；";
		    break;
		  case "3":
			  tzqx_code_name="5年以上；";
		    break;
		  case "0":
			  tzqx_code_name="无固定期限；";
		    break;
		  
		}
		$(_pageId+" #tian_kong2").html(tzqx_code_name);
		
		var  tzpz_code = appUtils.getPageParam("tzpz_code");
		var tzpz_code_name="";
		switch (tzqx_code){
		 case "1":
			 tzpz_code_name="股票、混合型基金、偏股票基金、股票型基金、信托等权益类投资品种；";
		    break;
		  case "2":
			  tzpz_code_name="债券、货币市场基金、债券基金、信托等固定收益投资品种；";
		    break;
		  case "3":
			  tzpz_code_name="期货、融资融券；";
		    break;
		  case "4":
			  tzpz_code_name="复杂金融产品；";
		    break;
		  case "0":
			  tzpz_code_name="其他产品；";
		    break;
		  
		}
		$(_pageId+" #tian_kong3").html(tzpz_code_name);
		
		layerUtils.iLoading(false);

	}


	//2、事件 绑定
	function bindPageEvent()
	   {

		// 点击返回
		appUtils.bindEvent($(_pageId+"  .close"),function(){
			
				appUtils.pageBack();
		});

		

		//确定购买
		appUtils.bindEvent($(_pageId+" #goumai"),function(){
			
			if(platform=="1"){
				var order_channel=2;
			}else if(platform=="2"){
				var order_channel=1;
			}else{
				var order_channel=0;
			}
			
			var  rating_lvl = appUtils.getPageParam("rating_lvl");
			var param=
			{
				"user_id":user_id,
				"product_id":product_id,
				"tot_price":tot_price,
				"risk_level":rating_lvl,
				"order_channel":order_channel
			};
			service.finanPuy(param,function(data){

				if(data.error_no!="0")
				{
					
					layerUtils.iAlert(data.error_info);
					layerUtils.iLoading(false);
					return false;
				};
				var perData=data.results;
				order_id=perData[0].order_id;//订单编号
				var param=
				{
					"product_id":product_id,
					"tot_price":tot_price,
					"order_id":order_id
				};

				appUtils.pageInit("mall/finanOrder/riskSuccess","mall/finanOrder/orderPay",param);
			});

		});
			
		
	   }



	//3、销毁
	function destroy()
	{
	

	}

	var riskSuccess =
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = riskSuccess;

	});
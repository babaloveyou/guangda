/**
 * 基金--确认订单
 */
define(function(require, exports, module)
	{	
	var service = require("mobileService"); // 业务层接口，请求数据
	var appUtils = require('appUtils'),
	putils = require("putils"),
	layerUtils = require("layerUtils"),
	constants=require("constants");// 常量类
	var gconfig = require("gconfig");
	var global = gconfig.global;
	platform=gconfig.platform;
	var save_value= null;
	var product_price=null;
	var _pageId ="#mall_fundOrder_confirmOrder";
	var risk_level=null;// 保存产品 等级
	var finan_result=null; 
	var buy_limit = 0 ;  // 限购起点
	var URL=global.url;
	var paramConfirmOrder = null;
	var product_id="";
	var tot_price ="";
	var product_name ="";
	var product_code ="";
	
	// 1、初始化
	function init() 
	{
		document.execCommand('Refresh')
		// 检测登录
		// checkLogin();
		var pageInParam  = appUtils.getPageParam();
		
		paramConfirmOrder = JSON.parse(appUtils.getSStorageInfo("paramConfirmOrder"));
		appUtils.clearSStorage("paramConfirmOrder");
		var pageInParam  = appUtils.getPageParam();
		 tot_price = appUtils.getSStorageInfo("tot_price");
		 product_name = appUtils.getSStorageInfo("product_name");
		
		
		if(pageInParam != null && pageInParam != ""){
	    	if(pageInParam.param&&pageInParam.param!=""){
	    	  	var param = JSON.parse(pageInParam.param);
					product_id=param.product_id;
					product_code=param.product_code;
			}else {
            			product_id=pageInParam.product_id;
            			product_code=pageInParam.product_code;
			}
		}else if(paramConfirmOrder != null && paramConfirmOrder != ""){
				product_id=paramConfirmOrder.product_id;
				product_code=paramConfirmOrder.product_code;
		}else{
			layerUtils.iAlert("未获取到相应的产品信息!");
			return;
		}
		
		
		// 防止直接到该页面
		if(product_id==null)
		{
			layerUtils.iMsg(1, "数据加载错误！");
			appUtils.pageInit("mall/fundOrder/confirmOrder","account/mainPage",{})
			return false;
		}
// var product_name= pageInParam.product_name;
// var product_status=pageInParam.product_status;
// var product_id=pageInParam.product_id;
		$(_pageId+" #buyValue").val(tot_price);// 总金额
		$(_pageId+" #zj" ).html($(_pageId+" #buyValue").val());  


		// 查询基金单个信息
		findByid();
		isFirstBuy();
	}


	// 查询单个基金信息
	function findByid()
	{
		var pageInParam  = appUtils.getPageParam();
// product_id=appUtils.getSStorageInfo("product_id");
		
//		var product_name = "";
//		
//		if(pageInParam != null && pageInParam != ""){
//			product_name=pageInParam.product_name;
//		}else if(paramConfirmOrder != null && paramConfirmOrder != ""){
//			product_name=paramConfirmOrder.product_name;
//		}
		// 防止直接到该页面
		if(product_id==null)
		{
			layerUtils.iMsg(1, "数据加载错误！");
			appUtils.pageInit("mall/fundOrder/confirmOrder","account/mainPage",{})
			return false;
		}
		$(_pageId+" .cart_part h5" ).html(product_name);

		var param  =
		{
			"product_id":product_id,
			"product_sub_type":"1"
		}
		service.fundInfo(param,function(data)
			{
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
			var perData=data.results;
			save_value=perData[0];
			risk_level=perData[0].risk_level;// 产品风险等级
			var user_risk_level=appUtils.getSStorageInfo("risk_level");// 用户风险等级
			var current_price=perData[0].current_price;// 产品净值
			var per_buy_limit=perData[0].per_buy_limit;// 首次购买 金额
			var person_pace=perData[0].person_pace;// 追加购买金额
			var buy_pace=perData[0].buy_add_pace;// 购买步长
		/*
		 * if(person_pace==0||person_pace==null) { $(_pageId+"
		 * #add_pace").html(1); } else { $(_pageId+"
		 * #add_pace").html(person_pace); }
		 */
			if(person_pace==0||person_pace==null)
			{
				$(_pageId+" #buy_pace").html(1); 
			}
			else
			{
				$(_pageId+" #buy_pace").html(person_pace); 
			}
			$(_pageId+" .pro_thumb").html("<img src="+URL+perData[0].logo_url+">");// 图片
			$(_pageId+" #yqsy" ).html(current_price); 
			$(_pageId+" #frist").text(per_buy_limit); 	
			$(_pageId+" #append").text(person_pace); 
 			});
	}

	// 提交订单
	function commitOrder()
	{
		var pageInParam  = appUtils.getPageParam();
		if(pageInParam == null || pageInParam == ""){
			var pageInParam = paramConfirmOrder;
		}
		var user_id=appUtils.getSStorageInfo("user_id");
		var order_id=null;
		var param =
		{
			"user_id":user_id,
			"product_id":product_id

		};
		service.checkOrderSubmit(param,function(data)// 检测是否可以提交改订单
			{
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
			var perData=data.results;
			// 风险等级 =1时
			if(perData[0].is_risk==constants.is_risk.YES)
			{
				if(platform=="1"){
					var order_channel=2;
				}else if(platform=="2"){
					var order_channel=1;
				}else{
					var order_channel=0;
				}
				var param=
				{
					"user_id":user_id,
					"product_id":product_id,
					"tot_price":parseFloat($(_pageId+" #zj").html()),
					"order_channel":order_channel
				}
				service.fundPuy(param,function(data){// 提交订单
					if(data.error_no!="0")
					{
						layerUtils.iAlert(data.error_info);
						layerUtils.iLoading(false);
						return false;
					}
					var perData=data.results;
					order_id=perData[0].order_id;// 订单编号
					var param=
					{
						"product_id":product_id,
						"tot_price":parseFloat($(_pageId+" #zj").html()),
						"order_id":order_id
					}
					appUtils.pageInit("mall/fundOrder/confirmOrder","mall/fundOrder/orderPay",param);

				})

			}
			// 风险等级 =2时
			else if (perData[0].is_risk==constants.is_risk.LOW)
			{
				var risk_name=perData[0].risk_name;
				putils.layerTwoButton("您的风险等级为："+risk_name+"<br/>该基金产品的风险已超过您的可承受能力范围。若基金产品出现亏损，您承担的投资损失可能会超过您的可承受风险。","继续购买","重新测评",function()
						{
					if(platform=="1"){
						var order_channel=2;
					}else if(platform=="2"){
						var order_channel=1;
					}else{
						var order_channel=0;
					}
						var param=
						{
							"user_id":user_id,
							"product_id":product_id,
							"tot_price":parseFloat($(_pageId+" #zj").html()),
							"order_channel":order_channel
						}
						service.fundPuy(param,function(data){

							if(data.error_no!="0")
							{
								layerUtils.iAlert(data.error_info);
								layerUtils.iLoading(false);
								return false;
							}
							var perData=data.results;
							order_id=perData[0].order_id;// 订单编号
							var param=
							{
								"product_id":product_id,
								"tot_price":parseFloat($(_pageId+" #zj").html()),
								"order_id":order_id
							}

							appUtils.pageInit("mall/fundOrder/confirmOrder","mall/fundOrder/orderPay",param);
						})

						},function(){
							var pageInParam  = appUtils.getPageParam();
							if(pageInParam == null || pageInParam == ""){
								var pageInParam = paramConfirmOrder;
							}
							var product_name= pageInParam.product_name;
							var tot_price=pageInParam.tot_price;
						
							var param =
							{
								"product_name":product_name,
								"product_id":product_id,
								"tot_price":tot_price
							};
							appUtils.pageInit("mall/fundOrder/confirmOrder","account/fundRiskAssessment",param);
						});
				}

			// 风险等级 =3时
			else if(perData[0].is_risk==constants.is_risk.Theree)
			{
				layerUtils.iConfirm("您的风险测评已过期，请重新测评!",function()
					{
					if(pageInParam == null || pageInParam == ""){
						var pageInParam = paramConfirmOrder;
					}
// var pageInParam = appUtils.getPageParam();
					var product_name= pageInParam.product_name;
					var tot_price=pageInParam.tot_price;
					var param={
							"product_name":product_name,
							"product_id":product_id,
							"tot_price":tot_price
					}
					appUtils.pageInit("mall/fundOrder/confirmOrder","account/fundRiskAssessment",param);
					},function(){
						layerUtils.iLoading(false);
					});
			}
			// 风险等级 =其它时
			else
			{
				layerUtils.iConfirm("您还未做风险测评,请先测评!",function(){
					if(pageInParam == null || pageInParam == ""){
						var pageInParam = paramConfirmOrder;
					}
// var pageInParam = appUtils.getPageParam();
					var product_name= pageInParam.product_name;
					var tot_price=pageInParam.tot_price;
					var param={
							"product_name":product_name,
							"product_id":product_id,
							"tot_price":tot_price,
							"product_code":product_code
					}
					appUtils.pageInit("mall/fundOrder/confirmOrder","account/fundRiskAssessment",param);
				},function(){
					layerUtils.iLoading(false);
				});

			}

			});
	}
	

	// 判断是否是首次购买
	function isFirstBuy(){
		var pageInParam  = appUtils.getPageParam();
		if(pageInParam == null || pageInParam == ""){
			var pageInParam = paramConfirmOrder;
		}
		var fund_account=appUtils.getSStorageInfo("fund_account");
		var param=
		{
			"product_id":product_id,
			"fund_account":fund_account
		}
		service.isFirstBuyFund(param,function(data){
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
			var perData=data.results;
			var fristBuy= $(_pageId+" #frist").text();       // 首次
// var appendBuy=$(_pageId+" #append").text(); //追加
			var buy_pace= $(_pageId+" #buy_pace").text();    // 步长
			result=perData[0].result;
			finan_result=perData[0].result;// 保存结果

			if(constants.first_buy.YES==perData[0].result)// 追加购买
			{
				$(_pageId+" #frisrt").addClass("ared");
				buy_limit=fristBuy;

			}
			else // 首次购买
			{
				$(_pageId+" #frisrt").addClass("ared");
				buy_limit=fristBuy;
			}
		});
	}

	// 购买金额的加减
	function  addAndMin (par)
	{
		var person_pace=1;// 步长
		if(person_pace==""||person_pace=="0"){
			person_pace=1;
		}

		// 追加购买
		if(finan_result==constants.first_buy.YES)
		{
			var append= $(_pageId+" #buyValue").val();
			var limi=  $(_pageId+" #frist").html();

			// 点击+
			if(par=="add")
			{
				var sum= parseFloat(append)+parseFloat(person_pace);
				$(_pageId+" #buyValue").val((sum.toFixed(2)));
				$(_pageId+" #zj").html($(_pageId+" #buyValue").val());
			}

			// 点击-
			else if(par=="min")
			{

				if(parseFloat(append)<=parseFloat(limi))
				{
					layerUtils.iMsg(-1,"购买的金额不能低于"+limi);
					return false;
				}

				var minc= parseFloat(append)-parseFloat(person_pace);

				$(_pageId+" #buyValue").val(minc.toFixed(2));
				$(_pageId+" #zj").html($(_pageId+" #buyValue").val());

			}

		}


		// 首次购买
		else
		{
			var frist= $(_pageId+" #buyValue").val();
			var limi=  $(_pageId+" #frist").html();

			// 点击+
			if(par=="add")
			{
				var sum= parseFloat(frist)+parseFloat(person_pace);
				$(_pageId+" #buyValue").val((sum.toFixed(2)));
				$(_pageId+" #zj").html($(_pageId+" #buyValue").val());

			}

			// 点击-
			else if(par=="min")
			{

				if(parseFloat(frist)<=parseFloat(limi))
				{
					layerUtils.iMsg(-1,"购买的金额不能低于"+limi);
					$(_pageId+" #buyValue").val(parseFloat($(_pageId+" #frist").html()).toFixed(2));
					$(_pageId+" #zj").html(parseFloat($(_pageId+" #frist").html()).toFixed(2));
					return false;
				}
				var minc= parseFloat(frist)-parseFloat(person_pace);
				$ (_pageId+" #buyValue").val(minc.toFixed(2));
				$(_pageId+" #zj").html($(_pageId+" #buyValue").val());

			}
		}
	}

	// 判断是否是交易日
	function dealTimeSyn()
	{
		var param=
		{
			"date":""
		}
		service.dealTimeSyn(param,function(data){
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			} 
			else if(data.results[0].is_trade=='0')
			{
				layerUtils.iAlert("当前是非交易时间，理财和基金产品暂停交易。");
				return false;
			}
			else{
				// 提交订单
				commitOrder();
			}

		})
	}

	// 2、事件绑定
	function bindPageEvent()
	{

		// 立即提交
		appUtils.bindEvent($(_pageId+" .n2"),function()
			{
			var buyValue= $(_pageId+"  #buyValue").val();  // 购买金额
			var buy_pace=$(_pageId+" #buy_pace").html();   // 步长
			var buy_limit=  $(_pageId+" #frist").html();

			if(buy_pace==""||buy_pace=="0")
			{
				buy_pace="1"

			}
			if(parseFloat($(_pageId+" #buyValue").val())<parseFloat(buy_limit))
			{
				layerUtils.iMsg(-1,"购买的金额不能低于"+buy_limit);
				return false;
			}
			/*
			 * if((buyValue-buy_limit)%buy_pace!=0) {
			 * layerUtils.iMsg(-1,"输入金额必须是"+buy_pace+"的整数倍！"); return false; }
			 */
			dealTimeSyn();// 判断是否是交易日

			});

		// 点击 增加购买金额
		appUtils.bindEvent($(_pageId+" .icon_add"),function(){addAndMin("add");});

		// 点击 减少购买金额
		appUtils.bindEvent($(_pageId+" .icon_less"),function()	{addAndMin("min");});

		// 点击 理财
		appUtils.bindEvent($(_pageId+" #finan"),function(){appUtils.pageInit("mall/fundOrder/confirmOrder","mall/itemsFinan",{});});

		// 点击 基金
		appUtils.bindEvent($(_pageId+" #fund"),function(){	appUtils.pageInit("mall/fundOrder/confirmOrder","mall/itemsFund",{});});

		// 点击 LOGO
		appUtils.bindEvent($(_pageId+" .logo"),function(){appUtils.pageInit("mall/fundOrder/confirmOrder","account/mainPage")})

		// 点击 返回
		appUtils.bindEvent($(_pageId+" .icon_back"),function()	{appUtils.pageBack();});

		// 点击 返回顶部
		appUtils.bindEvent($(_pageId+" .back_btn"),function(){$('body,html').animate({scrollTop:0},1000);return false;});

		// 点击 继续选购
		appUtils.bindEvent($(_pageId+" .n1"),function(){appUtils.pageInit("mall/fundOrder/confirmOrder","account/mainPage")});		

		// 判断输入是否合法
		appUtils.bindEvent($(_pageId+" #buyValue"),function(){putils.numberLimit($(this));},"keyup");

		// 控制输入不能为空
		appUtils.bindEvent($(_pageId+" #buyValue"),function(){if($(this).val()==null||$(this).val()==""){	$(this).val(0);	$(this).val(putils.moneyFormat($(this).val()))}	$(_pageId+" #zj").html($(_pageId+" #buyValue").val());},"blur");

		// 点击个人中心
		appUtils.bindEvent($(_pageId+" .icon_info"),function(){
			appUtils.pageInit("mall/fundOrder/confirmOrder","account/userCenter",{});
		});
	}

	// 3、销毁
	function destroy()
	{

	}

	var confirmOrder =
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = confirmOrder;

	});
/**
 * 用户中心
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils");
	var gconfig = require("gconfig");
	var layerUtils = require("layerUtils");
	var service = require("mobileService");// 业务层接口，请求数据
	var global = gconfig.global;
	var _pageId = "#account_userCenter";
	/* 初始化 */
	function init() {
		newRiskResult();//风测
	}
	function bindPageEvent() {
		/* 绑定lOGO事件 */
		appUtils.bindEvent($(_pageId + " .header .back_app"), function() {
			appUtils.pageInit("account/userCenter", "account/mainPage", {});
		});

		/* 绑定返回首页事件 */
		appUtils.bindEvent($(_pageId + " .icon_mall"), function() {
			appUtils.pageInit("account/userCenter", "account/mainPage", {});
		});

		/* 点击 跳到到顶部 */
		appUtils.bindEvent($(_pageId + "  .back_btn"), function() {
			$('body,html').animate({
				scrollTop : 0
			}, 1000);
			return false;
		});

		// /* 绑定我的关注事件 */
		// appUtils.bindEvent($(_pageId+" .user_center_link ul
		// li:eq(2)"),function(){
		// appUtils.pageInit("account/userCenter","account/myAttention",{});
		// });

		/* 点击我的订单事件 */
		appUtils.bindEvent($(_pageId + " .user_center_link ul li:eq(1)"),
				function() {
					appUtils.pageInit("account/userCenter", "account/myOrder",
							{});
				});

		/* 绑定我的产品事件 */
		appUtils.bindEvent($(_pageId + " .user_center_link ul li:eq(0)"),
				function() {
					appUtils.pageInit("account/userCenter",
							"account/myProduct", {});
				});

		/* 点击总资产事件 */
		appUtils.bindEvent($(_pageId + " .user_center_link ul li:eq(2)"),
				function() {
					appUtils.pageInit("account/userCenter",
							"account/totalAssets", {});
				});

		/* 点击转账查询事件 */
		appUtils.bindEvent($(_pageId + " .user_center_link ul li:eq(4)"),
				function() {
					appUtils.pageInit("account/userCenter",
							"account/changeResults", {});
				});

		/* 点击银行转账事件 */
		appUtils.bindEvent($(_pageId + " .user_center_link ul li:eq(3)"),
				function() {
					appUtils.pageInit("account/userCenter",
							"account/bankTransfer", {});
				});

		/* 点击风险测评事件 */
		appUtils.bindEvent($(_pageId + " .user_center_link ul li:eq(5)"),
				function() {
					appUtils.pageInit("account/userCenter",
							"account/riskAssessment", {});
				});

		/* 点击资料修改事件 */
		appUtils.bindEvent($(_pageId + " .user_center_link ul li:eq(6)"),
				function() {
					appUtils.pageInit("account/userCenter",
							"account/infoModify", {});
				});

		/* 点击我的富尊 */
		appUtils.bindEvent($(_pageId + " .user_center_link ul li:eq(8)"),
				function(e) {
					/* 绑定返回我的富尊主页 */
					var param_index = {
						"funcNo" : "50101",
						"moduleName" : "user-center",
						"params" : {
							"moduleName" : "financial-mall"
						}
					};
					require("external").callMessage(param_index);
					e.stopPropagation();
				});

		/* 点击退出事件 */
		appUtils.bindEvent($(_pageId + " .user_center_link ul li:eq(7)"),
				function() {
					layerUtils.iConfirm("确定要退出吗？", function() {
						/* 调用退出登入接口 */
						// service.loginOut({},function(data){
						// var error_no = data.error_no;
						// var error_info = data.error_info;
						// var result = data.results;
						// if(error_no == "0")
						// {
						// appUtils.clearSStorage("_loginInPageCode");
						// appUtils.clearSStorage("_loginInPageParam");
						// appUtils.clearSStorage("_isLoginIn");
						// appUtils.clearSStorage();
						// $(" #account_userLogin #trade_pwd").val("");//清除密码
						// $(" #account_userLogin #password em").html("");//清除密码
						// appUtils.pageInit("account/userCenter","account/mainPage",{});
						// }
						// else
						// {
						// layerUtils.iAlert(error_info);
						// }
						// });
						var param = {
							"funcNo" : "70004"
						};
						require("external").callMessage(param);
					});
				});
	}

	function personCenter(risk_level_txt) {

		
		// 获取个人信息枚举
		var allPersonInfoStr = "";
		var user_name = appUtils.getSStorageInfo("user_name");
		// var account_name=appUtils.getSStorageInfo("account_name");
		var fund_account = appUtils.getSStorageInfo("fund_account");

		// var risk_level_txt=appUtils.getSStorageInfo("risk_level_txt");
		allPersonInfoStr += '<p ><span>用户：</span>' + user_name + '</p>'
				+ '<p ><span>已开通账户：</span>' + "资金账户" + "(" + fund_account + ")"
				+ '</p>' + '<p ><span>风险承受能力：</span>' + risk_level_txt + '</p>';
		$(_pageId + " .user_info").html(allPersonInfoStr); // 填充个人信息
	}

	// 客户风险查询(500003)
	function newRiskResult() {
		var cust_code = appUtils.getSStorageInfo("cust_code");
		var ticket = appUtils.getSStorageInfo("ticket");
		var user_type = appUtils.getSStorageInfo("user_type");
		// survey_sn个人是10001机构是10002
		var survey_sn = user_type == "1" ? "1002" : "1001";
		var param = {
			"cust_code" : cust_code,
			"survey_sn" : survey_sn,
			"ticket" : ticket
		};
		service.newRiskResult(param, function(data) {
			if (data.error_no == "0") {
				var perData = data.results;
				 var risk_level_txt = perData[0].risk_name;

			} else {
				risk_level_txt = "积极投资型";
			}
			personCenter(risk_level_txt);//个人信息填充
		});
	}

	function destroy() {
		service.destroy();
	}

	var userCenter = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};

	module.exports = userCenter;

});
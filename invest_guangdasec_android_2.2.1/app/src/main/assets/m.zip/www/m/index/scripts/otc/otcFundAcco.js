/**
 * 风险测评结果
 */
define(function(require, exports, module) 
	{
	var appUtils = require("appUtils");
	var gconfig = require("gconfig");
	var service = require("serviceImp");//业务层接口，请求数据
	var global = gconfig.global;
	var layerUtils = require("layerUtils");
	var _pageId ="#otc_otcFundAcco ";
	var fund_account = "";
	var branch_no = "";

	/*初始化*/
	function init()
	{
		fundlist();
	}

	function bindPageEvent() 
	{

		/* 绑定返回事件 */
		appUtils.bindEvent($(_pageId+" .top_title .icon_back"),function(){
			appUtils.pageBack();
		});
		
		/*请选择OTC支付资金账户 */
		appUtils.bindEvent($(_pageId+" #otcList"),function(e){
			$(_pageId+" #fundlist").show();
			e.stopPropagation();
		});
		
		appUtils.bindEvent($(_pageId),function(e){
			$(_pageId+" #fundlist").hide();
			e.stopPropagation();
		});
		
		/*下一步 */
		appUtils.bindEvent($(_pageId+" #next_step"),function(){
			otcOpenAcco();
		});
	}

	function otcOpenAcco(){
		var cust_code=appUtils.getSStorageInfo("cust_code");
		var ticket=appUtils.getSStorageInfo("ticket");
		var param={
				"cust_code" : cust_code,
				"int_org" : branch_no,
				"cuacct_code" : fund_account, 
				"ticket" : ticket
		};

		/*调用查询资金接口*/
		service.otcOpenAcco(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			if(error_no >= "0"){
				appUtils.pageInit("otc/otcFundAcco","otc/otcSuccess",{});
			}else{
				layerUtils.iAlert(error_info);
			}
		});
	}
	
	function fundlist(){
		var fundlist=appUtils.getSStorageInfo("fundlist");
		fundlist = eval(fundlist);
		//fundlist = JSON.parse(fundlist);
		var fundlistStr = "";
		for(var i = 0; i< fundlist.length; i++){
			if(fundlist[i].ext_syscode == "1"){
				fundlistStr +='<li><a href="javascript:void(0);" data-fundAccount='+fundlist[i].fund_account+' data-branchNo='+fundlist[i].branch_no+'>'+fundlist[i].fund_account+'</a></li>';
			}
		}
		$(_pageId+" #fundlist").html(fundlistStr);
		
		/*选中值赋给选择框*/
		appUtils.bindEvent($(_pageId+" #fundlist li a"),function(){
			fund_account = $(this).attr("data-fundAccount");
			branch_no = $(this).attr("data-branchNo");
			$(_pageId+" #otcList").html(fund_account);	  //选中值赋给选择框
			$(_pageId+" #fundlist").hide();
		});
	}

	function destroy()
	{
		$(_pageId+" #fundlist").hide();
		service.destroy();
	}

	var otcFundAcco = 
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = otcFundAcco;

	});
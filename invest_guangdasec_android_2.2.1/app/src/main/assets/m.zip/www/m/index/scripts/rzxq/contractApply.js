/**
 * 合同签署
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils");
	var layerUtils = require("layerUtils");
	var validatorUtil = require("validatorUtil");
	var gconfig = require("gconfig");
	var putils = require("putils"); 
	var global = gconfig.global;
	var service = require("serviceImp");
	var _pageId = "#rzxq_contractApply ";
	var userInfo = null;
	var stockCode = ""; // 上市公司股票代码
    
    /**
     * 初始化
     */
	function init() {
		userInfo =  JSON.parse(appUtils.getSStorageInfo("userinfo"));
		stockCode = appUtils.getPageParam("stockCode");
    }
	
	/**
	 * 事件绑定
	 */
	function bindPageEvent() {
		// 返回按钮
		appUtils.bindEvent($(_pageId + ".top_title .icon_back"), function(e){
			pageBack();
		});
		// 同意
		appUtils.bindEvent($(_pageId + ".mn_btn .btn_yes"), function(e){
			xqzySignAgree();
		});
		// 不同意
		appUtils.bindEvent($(_pageId + ".mn_btn .btn_no"), function(e){
			pageBack();
		});

	}
    
	/**
	 * 合同签署
	 */
	function xqzySignAgree(){
		var mac="--";
		if(gconfig.platform != "0"){ 
			mac = external.callMessage({"funcNo": "50024"}).results[0].mac; //设备IP地址
		}
		var account = userInfo.fund_account;
		var branch_no = userInfo.branch_no;
		var sdate0 = "";
		var param = {
			"scust_no":account,
			"sbranch_code0":branch_no,
			"sdate0":sdate0,
			"mac":mac
		};
		service.xqzySignAgree(param,function(data){
			if(data.error_no == "0"){  
				var result = data.results;
				if(result[0].return_code == "0000"){
					layerUtils.iAlert("【您的行权质押合同签署成功】",-1,queryXQZYHT);
				}else{
					layerUtils.iAlert(result[0].vsmess,-1,pageBack);
				}
			}else{
				layerUtils.iAlert(data.error_info,-1);
			}
		});
	}
	
	function queryXQZYHT(){
		var mac="--";
		if(gconfig.platform != "0"){ 
			mac = external.callMessage({"funcNo": "50024"}).results[0].mac; //设备IP地址
		}
		var account = userInfo.fund_account;
		var branch_no = userInfo.branch_no;
		var param = {
			"scust_no":account,
			"sbranch_code0":branch_no,
			"mac":mac
		};
		service.queryXQZYHT(param,function(data){
			if(data.error_no == "0"){  
				var result = data.results;
				if(result[0].return_code == "0000"){
					var scust_auth = data[0].sname; // 股票质押合同编号
					var sdate0 = data[0].sdate0; // 客户协议签署日期(起始日期)
					var scust_no = userInfo.fund_account; // 客户账户
					var sbranch_code0 = userInfo.branch_no;
				    var sstock_code2 = stockCode;
					var param = {
							"scust_auth":scust_auth,
							"sdate0":sdate0,
							"scust_no":scust_no,
							"sbranch_code0":sbranch_code0,
							"sstock_code2":sstock_code2
					};
					service.gqrzSignAgree(param,function(data){
						if(data.error_no == "0"){  
							var result = data.results;
							if(result[0].return_code == "0000"){
								layerUtils.iAlert("您的股权融资合同签署成功",-1,applySuccess);
							}else{
								layerUtils.iAlert("您的股权融资合同签署失败",-1);
							}
						}else{
							layerUtils.iAlert(data.error_info,-1);
						}
					});
				}
			}else{
				layerUtils.iAlert(data.error_info,-1);
			}
		});
	}
	function destroy(){
	}
	
	function applySuccess(){
		appUtils.pageInit("rzxq/contractApply","rzxq/contractSuccess");
	}
	/**
	 * 重写框架里面的pageBack方法
	 */
	function pageBack(){
		appUtils.pageInit("rzxq/contractApply","rzxq/contractStatus");
	}
	
	var base = {
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy,
		"pageBack": pageBack
	};
	module.exports = base;
});
﻿﻿/**
 * 港股通开户
 */
define(function(require, exports, module){
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
		service = require("investService").getInstance(),  //业务层接口，请求数据
		layerUtils = require("layerUtils"),
		gconfig = require("gconfig"),
		global = gconfig.global,
		_pageId = "#business_index";
	/* 私有业务模块的全局变量 end */
	
	function init()
	{
		var checkLoginPath = global.checkLoginPath;
		// 检测是否登录，保存返回值
		appUtils.invokeServer(checkLoginPath,{}, function(data){
			var result = data.data;
			if(result != undefined){
				saveData(result);  // 将数据保存到 session 中
			}
			else{
				layerUtils.iMsg(-1,data.err_info);
				layerUtils.iLoading(false);
			}
		});
	}
	
	function bindPageEvent(){
		
		/* 绑定新开账户  */
		appUtils.bindEvent($(_pageId+" .home_btn .next"),function(){  
			var cust_type = appUtils.getSStorageInfo("cust_type"); // 判断普通用户还是机构用户
			var current_step = appUtils.getSStorageInfo("current_step"); // 当前步骤
			if(current_step == "ktha/Success"){
				appUtils.pageInit("business/index","account/result",{});
			}
			else{
				if(current_step == "account/result"){
					appUtils.pageInit("business/index","account/result",{});
				}
				else{
				    //如果是机构户直接跳转到协议页面
				    if(cust_type=="2"){
				    	appUtils.pageInit("business/index","account/signProtocol",{"_prePagecode":"business/index"}); 
				    }
				    else{
					 	appUtils.pageInit("business/index","account/mainPage",{});      
				    }
				}
			}
		});
		
		/* 返回我的富尊  */
		appUtils.bindEvent($(_pageId+" .home_btn .wdfz"),function(e){ 
			/* 绑定返回我的富尊主页 */
			var toPage = "";
			if(gconfig.platform == "2"){
				toPage={"prefix":"www/m/index","suffix":"account/userCenter"};
			}else{
				toPage = "/index/index.html#!/account/userCenter.html";
			}
            var param_index = {"funcNo":"50101","moduleName":"user-center","params":{"moduleName":"ggt","toPage":toPage}};
            require("external").callMessage(param_index);
            e.stopPropagation();
		});
	}
	
	/**
	 * 港股通模拟登陆成功后保存数据（session）
	 * */
	function saveData(result)
	{
		// 黑名单标志
		appUtils.setSStorageInfo("in_blacklist",result.in_blacklist);
		//沪A账户是否指定交易
		appUtils.setSStorageInfo("is_regTrade",result.is_regTrade);
		//是否需要跑批
		appUtils.setSStorageInfo("is_autoTask",result.is_autoTask);
		//开通港股通备注
		appUtils.setSStorageInfo("ggtopen_remark",result.ggtopen_remark);
		//当前步骤
		appUtils.setSStorageInfo("current_step",result.current_step);
		//证件类型
		appUtils.setSStorageInfo("idtype",result.idtype);
		//证件有效截止日期
		appUtils.setSStorageInfo("idenddate",result.idenddate);
		//证件有效开始日期
		appUtils.setSStorageInfo("idbegindate",result.idbegindate);
		//沪A账号是否加挂
		appUtils.setSStorageInfo("isadd",result.isadd);
		//港股通开立标志
		appUtils.setSStorageInfo("ggtopen_flag",result.ggtopen_flag);
		//风险测评分数
		appUtils.setSStorageInfo("survey_score",result.survey_score);
		//风险测评是否有效
		appUtils.setSStorageInfo("risk_survey_valid",result.risk_survey_valid);
		//风险测评等级
		appUtils.setSStorageInfo("rating_lvl",result.rating_lvl);
		//知识测评分数
		appUtils.setSStorageInfo("knowledge_score",result.knowledge_score);
		//营业部编号
		appUtils.setSStorageInfo("branchno",result.branchno);
		//用户编号
		appUtils.setSStorageInfo("user_id",result.user_id);
		//风险测评等级名称
		appUtils.setSStorageInfo("rating_lvl_name",result.rating_lvl_name);
		//客户姓名
		appUtils.setSStorageInfo("custname",result.custname);
		//沪A账号
		appUtils.setSStorageInfo("shaaccount",result.shaaccount);
		//证券账户资产总值
		appUtils.setSStorageInfo("marketvalue",result.marketvalue);
		//电话号码
		appUtils.setSStorageInfo("mobileno",result.mobileno);
		//客户类型
		appUtils.setSStorageInfo("cust_type",result.cust_type);
		//信用证券账户总资产
		appUtils.setSStorageInfo("net_asset",result.net_asset);
		//联系地址
		appUtils.setSStorageInfo("address",result.address);
		//身份证是否在有效期内
		appUtils.setSStorageInfo("idenddate_valid",result.idenddate_valid);
		//身份证号
		appUtils.setSStorageInfo("idno",result.idno);
	}
	
	function destroy(){}
	
	var index = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	
	module.exports = index;
});

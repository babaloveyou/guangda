/*
 * T+0取现
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	_pageId = "#xjb_fastCashProtocol",
	external = require("external");
	/*
	 * 页面初始化
	 */
	function init(){
//		service.queryProtocolContentByName({"econtract_name":"现金宝T+0服务协议"},function(data){
//			if(data.error_no == 0){
//				$(_pageId+" .risk_entry").html("");
//				var result = data.results[0];
//				var content = result.econtract_content;
//				$(_pageId+" .risk_entry").append(content);
//				service.queryProtocolContentByName({"econtract_name":"现金宝T+0风险揭示书"},function(data){
//					if(data.error_no == 0){
//						var result = data.results[0];
//						var content = result.econtract_content;
//						$(_pageId+" .risk_entry").append(content);
//					}else{
//						layerUtils.iLoading(false);
//						layerUtils.iAlert(data.error_info);
//					}
//				});
//			}else{
//				layerUtils.iLoading(false);
//				layerUtils.iAlert(data.error_info);
//			}
//		});
		var t0_fwxy = appUtils.getSStorageInfo("pro_code_t0_fwxy");
        var t0_fxjs = appUtils.getSStorageInfo("pro_code_t0_fxjs");
		$(_pageId+" .risk_entry").html("");
		var $ulobj =$("<ul>").appendTo($(_pageId+" .risk_entry"));
		$ulobj.html("");
		service.queryProtocolAttr({"pro_code":t0_fwxy},function(data1){
			if(data1.error_no == 0){
				var $fwxyliobj = $("<li>").css("color","red");
				$ulobj.append($fwxyliobj.text(data1.results[0].pro_title));
				appUtils.bindEvent($fwxyliobj,function(){
					var param = {
						"pro_content":data1.results[0].pro_content,
						"pro_code":data1.results[0].pro_code,
						"file_name":data1.results[0].file_name
					};
					service.getProtocolContent(param,function(data2){
						if(data2.error_no == 0){
							var pdfUrl = global.pdfUrl + "/" + data2.results[0].pdf_url;
							//var pdfUrl = "http://192.168.5.251:2227/452345324.pdf";
							console.log(pdfUrl);
							var results = external.callMessage({"funcNo":"50240","url":pdfUrl});
						}else{
							layerUtils.iLoading(false);
							layerUtils.iAlert(data2.error_info);
						}
					});
				});
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data1.error_info);
			}
		});
		service.queryProtocolAttr({"pro_code":t0_fxjs},function(data3){
			if(data3.error_no == 0){
				var $fxjsliobj = $("<li>").css("color","red");
				$ulobj.append($fxjsliobj.text(data3.results[0].pro_title));
				appUtils.bindEvent($fxjsliobj,function(){
					var param = {
						"pro_content":data3.results[0].pro_content,
						"pro_code":data3.results[0].pro_code,
						"file_name":data3.results[0].file_name
					};
					service.getProtocolContent(param,function(data4){
						if(data4.error_no == 0){
							var pdfUrl = global.pdfUrl + "/" + data4.results[0].pdf_url;
							//var pdfUrl = "http://192.168.5.251:2227/452345324.pdf";
							console.log(pdfUrl);
							var results = external.callMessage({"funcNo":"50240","url":pdfUrl});
						}else{
							layerUtils.iLoading(false);
							layerUtils.iAlert(data4.error_info);
						}
					});
				});
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data3.error_info);
			}
		});
	}
	
	/*
	 * 绑定页面事件
	 */
	function bindPageEvent(){
		
		//返回
		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(){
			appUtils.pageInit("xjb/fastCashProtocol","xjb/fastCash");
		});
		
		//同意
		appUtils.bindEvent($(_pageId+" .two_btn a:eq(0)"),function(){
			signProtocol();
		});
		
		//不同意
		appUtils.bindEvent($(_pageId+" .two_btn a:eq(1)"),function(){
			layerUtils.iMsg(-1,"不同该协议将无法进入下一步",1);
		});
	}
	
	//签署合同
	function signProtocol(){
		var param = {
			"branch_no":appUtils.getSStorageInfo("branch_no"),
			"account":appUtils.getSStorageInfo("fund_account"),
			"entrust_way":"SJWT"
		};
		service.signFastCashProtocol(param,function(data){
			if(data.error_no == 0){
				openPower();
			}else{
				layerUtils.iLoading(false);
				var error = data.error_info;
				//后台返回的提示信息不友好
				if(error.indexOf("SQL")> -1){
					error = error.split("SQL")[0];
					var len = error.length;
					error = error.substring(0,len-2);
				}
				layerUtils.iAlert(error);
			}
		});
	}
	
	//开通T+0快速取现权限
	function openPower(){
		var param = {
			"branch_no":appUtils.getSStorageInfo("branch_no"),
			"account":appUtils.getSStorageInfo("fund_account"),
			"entrust_way":"SJWT",
			"is_open":1
		};
		service.openPower(param,function(data){
			if(data.error_no == 0){
				appUtils.pageInit("xjb/riskHint","xjb/fastCash");
			}else{
				layerUtils.iLoading(false);
				var error = data.error_info;
				//后台返回的提示信息不友好
				if(error.indexOf("SQL")> -1){
					error = error.split("SQL")[0];
					var len = error.length;
					error = error.substring(0,len-2);
				}
				layerUtils.iAlert(error);
			}
		});
	}
	
	/*
	 * 销毁页面
	 */
	function destroy(){
		
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy
	};
	//暴露方法
	module.exports = base;
});
/**
 * 我的订单
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils");
	var gconfig = require("gconfig");
	var service = require("mobileService");//业务层接口，请求数据
	var global = gconfig.global;
	var dateUtils= require("dateUtils");
	var layerUtils = require("layerUtils");
	var keyPanel = require("keyPanel");//软键盘
	var putils = require("putils");
	var _pageId="#account_myOrder ";
	VIscroll = require("vIscroll");
	var customVIscroll = {"scroll":null, "_init":false}; // 上下滑动
	var pagingObjArr = [{"total_pages":0,"curr_page":0}]; //消息分页对象数组，这个页面只有一个分页，简单分页
	var product_type=1;
	var prePage = "";
	var curPage=1;
	/*初始化*/
	function init()
	{
		$(_pageId+" .product_cont_list").empty();
		product_type= $(_pageId+" .tab_nav li:eq(0)").val();
		var pageInParam  = appUtils.getPageParam();
    	prePage = pageInParam.prePage;
//		$(_pageId+" .tab_nav ul li:eq(1)").removeClass(" active");
//		$(_pageId+" .tab_nav ul li:eq(2)").removeClass(" active");
//		$(_pageId+" .tab_nav ul li:eq(3)").removeClass(" active");
//		$(_pageId+" .tab_nav ul li:eq(0)").addClass(" active");
    	if(prePage == "fz_userCenter"){
    		$(_pageId+" .tab_nav ul li:eq(3)").addClass(" active").siblings("li").removeClass(" active");
    		product_type= $(_pageId+" .tab_nav li:eq(3)").val();
    		queryOtcOrder(curPage);
		}else{
			$(_pageId+" .tab_nav ul li:eq(0)").addClass(" active").siblings("li").removeClass(" active");
			queryMyOrder();
		}
	}

	function bindPageEvent() 
	{
		/* 绑定返回事件 */
		appUtils.bindEvent($(_pageId+" .top_title .icon_back"),function(){
			if(prePage == "fz_userCenter"){
				if(gconfig.platform == "2"){
					toPage={"prefix":"www/m/index","suffix":"account/userCenter","prePage":"mall_myOrder"};
				}else{
					toPage = "/index/index.html#!/account/userCenter.html?prePage=mall_myOrder";
				}
				var param = {"funcNo":"50101","moduleName":"user-center","params":{"moduleName":"financial-mall","toPage":toPage}};
				require("external").callMessage(param);
			}else{
				appUtils.pageInit("account/myOrder","account/userCenter",{});
			}
		});

		/* 绑定LOGO事件 */
		appUtils.bindEvent($(_pageId+" .header .logo"),function(){
			appUtils.pageInit("account/myOrder","account/mainPage",{});
		});

		/* 绑定购物图标事件 */
		appUtils.bindEvent($(_pageId+" .icon_mall1"),function(){
			appUtils.pageInit("account/myOrder","account/mainPage",{});
		});
		
		/* 绑定购物图标事件 */
		appUtils.bindEvent($(_pageId+" .buy"),function(){
			appUtils.pageInit("account/myOrder","account/mainPage",{});
		});

		/* 返回个人中心事件 */
		appUtils.bindEvent($(_pageId+" .icon_info"),function(){
			appUtils.pageInit("account/myOrder","account/userCenter",{});
		});

		/*点击 跳到到顶部*/
		appUtils.bindEvent($(_pageId+"  .back_btn"),function()
			{
			$('body,html').animate({
				scrollTop:0
			},
			1000);
			return false;
			});

		// 点击理财
		appUtils.bindEvent($(_pageId+" #lc"),function(){ 
			product_type= $(_pageId+" .tab_nav li:eq(0)").val();
			$(_pageId+" .tab_nav ul li:eq(1)").removeClass(" active");
			$(_pageId+" .tab_nav ul li:eq(2)").removeClass(" active");
			$(_pageId+" .tab_nav ul li:eq(3)").removeClass(" active");
			$(_pageId+" .tab_nav ul li:eq(0)").addClass(" active");
			queryMyOrder();
		});

		// 点击基金 
		appUtils.bindEvent($(_pageId+"   #jj"),function(){
			product_type= $(_pageId+" .tab_nav li:eq(1)").val();
			$(_pageId+" .tab_nav ul li:eq(0)").removeClass(" active");
			$(_pageId+" .tab_nav ul li:eq(2)").removeClass(" active");
			$(_pageId+" .tab_nav ul li:eq(3)").removeClass(" active");
			$(_pageId+" .tab_nav ul li:eq(1)").addClass(" active");
			queryMyOrder();
		}); 

		// 点击资讯 
		appUtils.bindEvent($(_pageId+"   #zx"),function(){
			product_type= $(_pageId+" .tab_nav li:eq(2)").val();
			$(_pageId+" .tab_nav ul li:eq(0)").removeClass(" active");
			$(_pageId+" .tab_nav ul li:eq(1)").removeClass(" active");
			$(_pageId+" .tab_nav ul li:eq(3)").removeClass(" active");
			$(_pageId+" .tab_nav ul li:eq(2)").addClass(" active");
			queryUserOrder();
		}); 

		// 点击OTC
		appUtils.bindEvent($(_pageId+"   #otc"),function(){
			var fund_list=appUtils.getSStorageInfo("fund_list");
			if(fund_list ==""|| fund_list == null || fund_list==undefined){
				layerUtils.iMsg(-1,"请用E帐号登录！！！");
				return false;
			}else{
				otcAccoInfo();
			}
		}); 

		//上一页、下一页
		appUtils.bindEvent($(_pageId+" span[name='aPrePage']"),function()
			{  
			if(product_type=="9"){
				if(pagingObjArr[0].curr_page==1){
					queryOtcOrder(parseInt(pagingObjArr[0].curr_page));
				}
				else{
					queryOtcOrder(parseInt(pagingObjArr[0].curr_page)-1);
				}
			}else{
				if(pagingObjArr[0].curr_page==1){
					handlePreNextPage(-1);
				}
				else{
					handlePreNextPage(-1);
				}
			}
			});
		appUtils.bindEvent($(_pageId+" span[name='aNextPage']"),function()
			{
			if(product_type=="9"){
				if(pagingObjArr[0].total_pages==pagingObjArr[0].curr_page){
					queryOtcOrder(parseInt(pagingObjArr[0].curr_page));
				}
				else{
					queryOtcOrder(parseInt(pagingObjArr[0].curr_page)+1);
				}
			}else{
				if(pagingObjArr[0].total_pages==pagingObjArr[0].curr_page){
					handlePreNextPage(1);
				}
				else{
					handlePreNextPage(1);
				}
			}
			});

	}
	/*
	 * 查询是否有交易账户
	 */
	function otcAccoInfo(){
		var cust_code=appUtils.getSStorageInfo("cust_code");
		var fund_list=appUtils.getSStorageInfo("fund_list");
		var ticket=appUtils.getSStorageInfo("ticket");
		var param={
				"cust_code" : cust_code,
				"cuacct_code" : fund_list,
				"ticket" : ticket
		};

		/*查询是否有交易账户*/
		service.otcAccoInfo(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var results = data.results;
			if(error_no == "0" && results.length != 0){
				var otcflag = results[0].otcflag;
				var cuacct_code = results[0].cuacct_code;
				$(_pageId+" #cuacct_code").html(cuacct_code);
				if(otcflag == "1"){
					product_type= $(_pageId+" .tab_nav li:eq(3)").val();
					$(_pageId+" .tab_nav ul li:eq(0)").removeClass(" active");
					$(_pageId+" .tab_nav ul li:eq(2)").removeClass(" active");
					$(_pageId+" .tab_nav ul li:eq(1)").removeClass(" active");
					$(_pageId+" .tab_nav ul li:eq(3)").addClass(" active");
					queryOtcOrder(curPage);
				}else{
					layerUtils.iMsg(-1,"请开通OTC账户！！！");
					return false;
				}
			}else{
				layerUtils.iAlert(error_info);
			}
		});
	}
	
	/* OTC撤销订单*/
	function otcUndoOrder(order_id, index,curr_page){
		var trade_pwd =$.trim($("#iLayer_myProd  #trade_pwd").val());
		var fund_account=appUtils.getSStorageInfo("fund_account");
		var ticket=appUtils.getSStorageInfo("ticket");
		if(trade_pwd==""){
			layerUtils.iMsg(-1,"交易密码不能为空！！！");
			return false;
		}
		//加密
		service.getRSAKey({},function(data){
			if(data.error_no=="0")
			{
				var modulus = data.results[0].modulus;
				var publicExponent =data.results[0].publicExponent;
				var endecryptUtils = require("endecryptUtils");
				var _trade_pwd=endecryptUtils.rsaEncrypt(modulus,publicExponent,$.trim(trade_pwd));
				var param =
				{
					"order_id" :order_id,
					"trade_pwd":_trade_pwd,
					"fund_account":fund_account,
					"ticket" : ticket
				};
				service.otcUndoOrder(param,function(data){
					var error_no = data.error_no;
					var error_info = data.error_info;
					if(error_no =="0")
					{
						layerUtils.iCustomClose(); 
						queryOtcOrder(curr_page);
					}
					else
					{
						layerUtils.iMsg(-1,error_info);
					}
				});
			}
		});
	}
	/* OTC取消订单*/
	function otcCancelOrder(order_id, index,curr_page){
		var ticket=appUtils.getSStorageInfo("ticket");
		var param =
		{
			"order_id":order_id,
			"ticket" : ticket
		};
		service.otcCancelOrder(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			if(error_no=="0")
			{
				queryOtcOrder(curr_page);
			}else{
				layerUtils.iMsg(-1,error_info);
				layerUtils.iLoading(false);
				return false;
			}
		});
	}
	
	/* OTC订单支付*/
	function payOTCOrder(product_id,order_id,tot_price,inst_sname,index){
		var user_id=appUtils.getSStorageInfo("user_id");
		var productType =product_type;
		var param1 =
		{
			"order_id":order_id,
			"user_id":user_id,
			"product_id":product_id,
			"tot_price":tot_price,
			"inst_sname":inst_sname
		};
		var param =
		{
			"product_id":product_id
		};
		service.OTCInfo(param,function(data)
			{
			var product_shelf=data.results[0].PRODUCT_SHELF;
			if(data.error_no=="0" && product_shelf=="1")
			{
				appUtils.pageInit("account/myOrder","mall/otcOrder/orderPay",param1);
			}else{
				layerUtils.iAlert("很抱歉，该产品已下架！！！");
				layerUtils.iLoading(false);
				return false;
			}
		});
	
	}
	/*获取订单产品(OTC) */
	function queryOtcOrder(curPage){
		var user_code =appUtils.getSStorageInfo("cust_code");
		var ticket=appUtils.getSStorageInfo("ticket");
		var param =
		{
			"user_code" : user_code,
			"page" :curPage,
			"numPerPage" :"4",
			"ticket" : ticket
		};

		service.otcOrderInfo(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			if(error_no =="0")
			{
				var result=data.results[0].data;
				if(result.length=="0"){
					layerUtils.iMsg(-1,"没有相关产品订单!");
					$(_pageId+" .product_bd_title").html('OTC产品订单总数 : 0');
					$(_pageId+" .product_cont_list").empty();
					var total_pages = data.results[0].totalPages;
					var curr_page = data.results[0].currentPage;
					var total_rows = data.results[0].totalRows;
					total_pages = total_pages ? total_pages:0;
					curr_page = curr_page ? curr_page:0;
					total_rows=total_rows?total_rows:0;
					pagingObjArr[0].total_pages=total_pages;
					$(_pageId+" em[name='totalPage']").html(total_pages);
					pagingObjArr[0].curr_page=curr_page;
					$(_pageId+" em[name='curPage']").html(0);
					//显示多少条数据
					$(_pageId+" em[name='total_rows']").html(total_rows);
					$(_pageId + "  span[name='aNextPage']").removeClass("blue");
				}
				else{
					var total_pages = data.results[0].totalPages;
					var curr_page = data.results[0].currentPage;
					var total_rows = data.results[0].totalRows;
					total_pages = total_pages ? total_pages:0;
					curr_page = curr_page ? curr_page:0;
					total_rows=total_rows?total_rows:0;
					pagingObjArr[0].total_pages=total_pages;
					$(_pageId+" em[name='totalPage']").html(total_pages);
					pagingObjArr[0].curr_page=curr_page;
					$(_pageId+" em[name='curPage']").html(curr_page);
					//显示多少条数据
					$(_pageId+" em[name='total_rows']").html(total_rows);
					var allRecommendStr =  "";
					var list =  data.results[0].data;
					var len = list.length;
					for( var idx = 0; idx<len ; idx++)
					{
						var order_state=list[idx].order_state;
						var operating_type=list[idx].operating_type;
						var order_stateLabel  = "";
						order_stateLabel = putils.order_state(order_state);
						var trd_id=list[idx].trd_id;
						var trd_amt = list[idx].trd_amt;
						if(trd_amt=="" || trd_amt==null){
							trd_amt="0";
						}
						var business_typeLabel="";
						var order_quantity=list[idx].trd_qty;
						if(order_quantity=="" || order_quantity==null){
							order_quantity="0";
						}
						if(trd_id == "110"){
							business_typeLabel = "认购";
						}else if(trd_id =="111"){
							business_typeLabel = "申购";
						}else if(trd_id =="112"){
							business_typeLabel = "赎回";
						}else if(trd_id =="20B"){
							business_typeLabel = "买入";
						}else if(trd_id =="20S"){
							business_typeLabel = "卖出";
						}else if(trd_id =="113"){
							business_typeLabel = "快速赎回";
						}else if(trd_id =="125"){
							business_typeLabel = "撤单确认";
						}else{
							business_typeLabel = "--";
						}
						
						if(operating_type =="4"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].inst_sname+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(trd_amt).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
							'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
							'<a  style="float:right"  href="javascript:;"  class="cancer"  product_id='+list[idx].product_id+' data-idx='+idx+'>--</a>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
						}
						if(operating_type =="0"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].inst_sname+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(trd_amt).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
							'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
							'<a  style="float:right"  href="javascript:;"  class="cancer"  product_id='+list[idx].product_id+' data-idx='+idx+'>--</a>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
						}
						if(operating_type =="1"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].inst_sname+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(trd_amt).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
							'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
							'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOTCOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+'>取消订单</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
						}
						if(operating_type =="2"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].inst_sname+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(trd_amt).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
							'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
							'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="payOTCOrder" data-product_id='+list[idx].product_id+' data-tot_price='+list[idx].tot_price+' data-inst_sname='+list[idx].inst_sname+' data-idx='+idx+'  style="color:blue">支付订单</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
						}
						if(operating_type =="3"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].inst_sname+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(trd_amt).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
							'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
							'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="undoOTCOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+'>撤销订单</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
						}
						if(operating_type =="5"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].inst_sname+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(trd_amt).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
							'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
							'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已执行撤单操作</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
						}
						if(operating_type =="12"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].inst_sname+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(trd_amt).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
							'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
							'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOTCOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+' >取&nbsp&nbsp&nbsp消</a><a href="javascript:void(0);" class="payOTCOrder" data-product_id='+list[idx].product_id+' data-order_id='+list[idx].order_id+' data-tot_price='+list[idx].trd_amt+' data-inst_sname='+list[idx].inst_sname+' data-idx='+idx+'  style="color:blue;font-size:15px">支&nbsp&nbsp&nbsp付</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
						}
					}
					$(_pageId+" .product_bd_title").html('OTC产品订单总数 : '+data.results[0].totalRows+'');
					$(_pageId+" .product_cont_list").html(allRecommendStr);

					//鼠标移入改变颜色
					appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
						$(this).css("color","red");
					},"mouseenter");

					//鼠标移出改变颜色
					appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
						$(this).css("color","black");
					},"mouseleave");

					/*点击名称进入详情*/
					appUtils.bindEvent($(_pageId+" a[product-id]"),function(){
						var param=
						{
							"product_id":$(this).attr("product-id")
						};
						appUtils.pageInit("account/myOrder","mall/itemsOTCInfo",param);
					});

					/* 绑定撤销订单事件 */
					appUtils.bindEvent($(_pageId+" .undoOTCOrder"),function(){
						var order_id = $(this).attr("data-order_id");
						var index = $(this).attr("data-idx");
						var param=
						{
							"date":""
						}
						service.dealTimeSyn(param,function(data){
							if(data.error_no!="0")
							{
								layerUtils.iAlert(data.error_info);
								layerUtils.iLoading(false);
								return false;
							} 
							else if(data.results[0].is_trade=='0')
							{
								layerUtils.iAlert("当前是非交易时间，理财和基金产品暂停交易。");
								return false;
							}
							else{
								layerUtils.layerCustom('<div class="popbox pop_rebuy" id="iLayer_myProd">	<div class="ptitle"><h2>订单撤销</h2></div>	<div class="pmain"><p class="input_text"></p><div class="input_text">	<label>交易密码</label><div id="password"  class="t1 trade_pwd input_custom" style="color:#A9A9A9;"><em>交易密码</em></div><input style="display:none" type="password"  class="t1"  id="trade_pwd" ></div><p class="input_text"><a href="javascript:void(0);" class="btn"  id="iLayer_redeemBtn">撤单</a><a href="javascript:void(0);" class="btn2" id="iLayer_closeBtn">关闭</a></p></div></div>');
								var fund_account=appUtils.getSStorageInfo("fund_account");
								var allRecommendStr =  "";
								allRecommendStr += "<label>资金账号</label>"+fund_account;
								$(" .pop_rebuy .input_text:eq(0)").append(allRecommendStr);
								appUtils.bindEvent($x("iLayer_myProd", "iLayer_redeemBtn"), function() {
									otcUndoOrder(order_id, index,curr_page); 
								});
								appUtils.bindEvent($x("iLayer_myProd", "iLayer_closeBtn"), function() {
									keyPanel.closeKeyPanel();
									layerUtils.iCustomClose(); 
								});
								
								appUtils.bindEvent($(" #code"),function(e){
									$(" .input_custom").removeClass(" active");
								});

								/*初始化键盘*/
								appUtils.bindEvent($(" #password") ,function(e){
									var input_pwd = $(this);
									input_pwd.find("em").html("");  // 清空密码
									input_pwd.attr("data-password","");  // 清空密码值
									$(" .input_custom").addClass("active");
									keyPanel.init_keyPanel(function(value){
										var curEchoText = input_pwd.find("em").html();  // 密码回显文本
										var input_pass_curPwd = input_pwd.attr("data-password") || "";  // 密码值
										var valInput=$(" #iLayer_myProd #trade_pwd");
										if(value == "del")
										{
											input_pwd.find("em").html(curEchoText.slice(0, -1));
											input_pwd.attr("data-password", input_pass_curPwd.slice(0, -1));
											valInput.val(input_pwd.attr("data-password"));
										}
										else
										{
											if(input_pass_curPwd.length < 6)
											{
												input_pwd.attr("data-password", input_pass_curPwd + value);  // 设置密码值
												input_pwd.find("em").html(curEchoText + "*");
												valInput.val(input_pass_curPwd + value);
											}
											else
											{
												layerUtils.iMsg(-1, "交易密码最多 6位!");
											}
										}
									}, input_pwd);
									e.stopPropagation();
								});

								//点击页面关闭软键盘
								appUtils.bindEvent($(" #iLayer_myProd"),function(){
									keyPanel.closeKeyPanel();
								});
							}

						})
					
					});

					/* 绑定取消订单事件 */
					appUtils.bindEvent($(_pageId+" .cancelOTCOrder"),function(){
						var order_id = $(this).attr("data-order_id");
						var index = $(this).attr("data-idx");
						layerUtils.iConfirm("确定是否取消订单",function () {
							otcCancelOrder(order_id, index,curr_page);
						});
													
					});

					/* 绑定确认订单支付事件 */
					appUtils.bindEvent($(_pageId+" .payOTCOrder"),function(){
						var product_id = $(this).attr("data-product_id");
						var order_id = $(this).attr("data-order_id");
						var tot_price = $(this).attr("data-tot_price");
						var inst_sname = $(this).attr("data-inst_sname");
						var index = $(this).attr("data-idx");
						var param=
						{
							"date":""
						}
						service.dealTimeSyn(param,function(data){
							if(data.error_no!="0")
							{
								layerUtils.iAlert(data.error_info);
								layerUtils.iLoading(false);
								return false;
							} 
							else if(data.results[0].is_trade=='0')
							{
								layerUtils.iAlert("当前是非交易时间，理财和基金产品暂停交易。");
								return false;
							}
							else{
								payOTCOrder(product_id,order_id,tot_price,inst_sname,index);
							}

						})
					
					});

					//上一页、下一页disabled效果
					if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
						$(_pageId + " span[name='aNextPage']").removeClass("blue");
						$(_pageId + " span[name='aPrePage']").addClass("blue");
					}
					else if (pagingObjArr[0].curr_page == 1) {
						$(_pageId + " span[name='aPrePage']").removeClass("blue");
						$(_pageId + " span[name='aNextPage']").addClass("blue");
					}
					else {
						$(_pageId + " span[name='aPrePage']").addClass("blue");
						$(_pageId + " span[name='aNextPage']").addClass("blue");
					}

					if (pagingObjArr[0].total_pages<2) {
						$(_pageId + " span[name='aPrePage']").removeClass("blue");
						$(_pageId + "  span[name='aNextPage']").removeClass("blue");
					}

					if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
						$(_pageId+" #isNull").html("暂无数据");
						$(_pageId + " span[name='aPrePage']").removeClass("blue");
						$(_pageId + " span[name='aNextPage']").removeClass("blue");
					}
				}

			}
			else{
				layerUtils.iMsg(-1,error_info);
			}
		});

	}
	
	/*获取订单产品(金融类) */
	function queryMyOrder(){

		var user_id =appUtils.getSStorageInfo("user_id");
		var productType =product_type;
		var param =
		{
			"user_id" : user_id,
			"product_sub_type" : productType,
			"page" :"",
			"numPerPage" :"4",
		};

		service.queryMyOrder(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result=data.results[0].data;
			if(error_no =="0" && productType=="1")
			{
				if(result.length=="0"){
					layerUtils.iMsg(-1,"没有相关产品订单!");
					$(_pageId+" .product_bd_title").html('理财产品订单总数 : 0');
					$(_pageId+" .product_cont_list").empty();
					var total_pages = data.results[0].totalPages;
					var curr_page = data.results[0].currentPage;
					var total_rows = data.results[0].totalRows;
					total_pages = total_pages ? total_pages:0;
					curr_page = curr_page ? curr_page:0;
					total_rows=total_rows?total_rows:0;
					pagingObjArr[0].total_pages=total_pages;
					$(_pageId+" em[name='totalPage']").html(total_pages);
					pagingObjArr[0].curr_page=curr_page;
					$(_pageId+" em[name='curPage']").html(0);
					//显示多少条数据
					$(_pageId+" em[name='total_rows']").html(total_rows);
					$(_pageId + "  span[name='aNextPage']").removeClass("blue");
				}
				else{
					var total_pages = data.results[0].totalPages;
					var curr_page = data.results[0].currentPage;
					var total_rows = data.results[0].totalRows;
					total_pages = total_pages ? total_pages:0;
					curr_page = curr_page ? curr_page:0;
					total_rows=total_rows?total_rows:0;
					pagingObjArr[0].total_pages=total_pages;
					$(_pageId+" em[name='totalPage']").html(total_pages);
					pagingObjArr[0].curr_page=curr_page;
					$(_pageId+" em[name='curPage']").html(curr_page);
					//显示多少条数据
					$(_pageId+" em[name='total_rows']").html(total_rows);
					var allRecommendStr =  "";
					var list =  data.results[0].data;
					var len = list.length;
					for( var idx = 0; idx<len ; idx++)
					{
						var order_state=list[idx].order_state;
						var operating_type=list[idx].operating_type;
						var order_stateLabel  = "";
						var business_type=list[idx].business_type;
						var business_typeLabel="";
						var order_quantity=list[idx].order_quantity;
						var tot_price=list[idx].tot_price;
						if(tot_price=="" || tot_price==null){
							tot_price="0";
						}
						if(order_quantity=="" || order_quantity==null){
							order_quantity="0";
						}
						if(business_type == "0"){
							business_typeLabel = "认购";
						}else if(business_type =="1"){
							business_typeLabel = "申购";
						}else if(business_type =="2"){
							business_typeLabel = "赎回";
						}
						
						if(order_state == "1")
						{
							order_stateLabel ="待提交";
						}
						else if(order_state == "0"){
							order_stateLabel ="新订单";
						}else if(order_state == "2"){
							order_stateLabel ="提交成功";
						}
						else if(order_state == "3"){
							order_stateLabel ="提交失败";
						}
						else if(order_state == "4"){
							order_stateLabel ="成交";
						}
						else if(order_state == "5"){
							order_stateLabel ="已取消";
						}
						else  if(order_state == "6"){
							order_stateLabel ="已撤单";
						}
						else  if(order_state == "7"){
							order_stateLabel ="退款";
						}
						if(operating_type =="0"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
							'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
							'<a  style="float:right"  href="javascript:;"  class="cancer"  product_id='+list[idx].product_id+' data-idx='+idx+'>--</a>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
						}
						if(operating_type =="1"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
							'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
							'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+'>取消订单</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
						}
						if(operating_type =="2"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
							'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
							'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="payOrder" data-product_id='+list[idx].product_id+' data-tot_price='+list[idx].tot_price+' data-idx='+idx+'  style="color:blue">支付订单</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
						}
						if(operating_type =="3"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
							'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
							'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="undoOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+'>撤销订单</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
						}
						if(operating_type =="4"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
							'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
							'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已执行撤单操作</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
						}
						if(operating_type =="12"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
							'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
							'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+' >取&nbsp&nbsp&nbsp消</a><a href="javascript:void(0);" class="payOrder" data-product_id='+list[idx].product_id+' data-order_id='+list[idx].order_id+' data-tot_price='+list[idx].tot_price+' data-idx='+idx+'  style="color:blue;font-size:15px">支&nbsp&nbsp&nbsp付</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
						}
					}
					$(_pageId+" .product_bd_title").html('理财产品订单总数 : '+data.results[0].totalRows+'');
					$(_pageId+" .product_cont_list").html(allRecommendStr);

					//鼠标移入改变颜色
					appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
						$(this).css("color","red");
					},"mouseenter");

					//鼠标移出改变颜色
					appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
						$(this).css("color","black");
					},"mouseleave");

					/*点击名称进入详情*/
					appUtils.bindEvent($(_pageId+" a[product-id]"),function(){
						var param=
						{
							"product_id":$(this).attr("product-id")
						};
						appUtils.pageInit("account/myOrder","mall/itemsFinanInfo",param);
					});

					/* 绑定撤销订单事件 */
					appUtils.bindEvent($(_pageId+" .undoOrder"),function(){
						var order_id = $(this).attr("data-order_id");
						var index = $(this).attr("data-idx");
						var param=
						{
							"date":""
						}
						service.dealTimeSyn(param,function(data){
							if(data.error_no!="0")
							{
								layerUtils.iAlert(data.error_info);
								layerUtils.iLoading(false);
								return false;
							} 
							else if(data.results[0].is_trade=='0')
							{
								layerUtils.iAlert("当前是非交易时间，理财和基金产品暂停交易。");
								return false;
							}
							else{
								layerUtils.layerCustom('<div class="popbox pop_rebuy" id="iLayer_myProd">	<div class="ptitle"><h2>订单撤销</h2></div>	<div class="pmain"><p class="input_text"></p><div class="input_text">	<label>交易密码</label><div id="password"  class="t1 trade_pwd input_custom" style="color:#A9A9A9;"><em>交易密码</em></div><input style="display:none" type="password"  class="t1"  id="trade_pwd" ></div><p class="input_text"><a href="javascript:void(0);" class="btn"  id="iLayer_redeemBtn">撤单</a><a href="javascript:void(0);" class="btn2" id="iLayer_closeBtn">关闭</a></p></div></div>');
							/*	var url=global.validateimg +"?v="+Math.random();						
								$(' .code_pic').click( 
									function(){ 
										$(' .code_pic').attr('src',url); 
									}); 
								$(' .code_pic').attr('src',url);//验证码错误，刷新获得验证码

								重新获取验证码
								appUtils.bindEvent($(" .code_pic") ,function(){
									var url=global.validateimg +"?v="+Math.random();
									$(' .code_pic').click( 
										function(){ 
											$(' .code_pic').attr('src',url); 
										}); 
									$(' .code_pic').attr('src',url);//验证码错误，刷新获得验证码
								});*/
								var fund_account=appUtils.getSStorageInfo("fund_account");
								var allRecommendStr =  "";
								allRecommendStr += "<label>资金账号</label>"+fund_account;
								$(" .pop_rebuy .input_text:eq(0)").append(allRecommendStr);
								appUtils.bindEvent($x("iLayer_myProd", "iLayer_redeemBtn"), function() {
									undoOrder(order_id, index,curr_page); 
									//								layerUtils.iCustomClose();
								});
								appUtils.bindEvent($x("iLayer_myProd", "iLayer_closeBtn"), function() {
									keyPanel.closeKeyPanel();
									layerUtils.iCustomClose(); 
								});
								
								appUtils.bindEvent($(" #code"),function(e){
									$(" .input_custom").removeClass(" active");
								});

								/*初始化键盘*/
								appUtils.bindEvent($(" #password") ,function(e){
									var input_pwd = $(this);
									input_pwd.find("em").html("");  // 清空密码
									input_pwd.attr("data-password","");  // 清空密码值
									$(" .input_custom").addClass("active");
									keyPanel.init_keyPanel(function(value){
										var curEchoText = input_pwd.find("em").html();  // 密码回显文本
										var input_pass_curPwd = input_pwd.attr("data-password") || "";  // 密码值
										var valInput=$(" #iLayer_myProd #trade_pwd");
										if(value == "del")
										{
											input_pwd.find("em").html(curEchoText.slice(0, -1));
											input_pwd.attr("data-password", input_pass_curPwd.slice(0, -1));
											valInput.val(input_pwd.attr("data-password"));
										}
										else
										{
											if(input_pass_curPwd.length < 6)
											{
												input_pwd.attr("data-password", input_pass_curPwd + value);  // 设置密码值
												input_pwd.find("em").html(curEchoText + "*");
												valInput.val(input_pass_curPwd + value);
											}
											else
											{
												layerUtils.iMsg(-1, "交易密码最多 6位!");
											}
										}
									}, input_pwd);
									e.stopPropagation();
//									$(" .input_custom").addClass(" active");
//									$(" #password em").html("");
//									$(" #trade_pwd").val("");
//									var passwordInput=$(" #password em");
//									var valInput=$(" #iLayer_myProd #trade_pwd");
//									keyPanel.init_keyPanel(" #iLayer_myProd",valInput.val(),valInput,function(pw)
//										{
//										var ch="";
//										for(var i=0;i<pw.length;i++){
//											ch+="*";
//										}
//										passwordInput.html(ch);
//										valInput.val(pw);
//										valInput.text("");
//										},"num","密码");
//									e.stopPropagation();	
								});

								//点击页面关闭软键盘
								appUtils.bindEvent($(" #iLayer_myProd"),function(){
									keyPanel.closeKeyPanel();
								});
							}

						})
					
					});

					/* 绑定取消订单事件 */
					appUtils.bindEvent($(_pageId+" .cancelOrder"),function(){
						var order_id = $(this).attr("data-order_id");
						var index = $(this).attr("data-idx");
						layerUtils.iConfirm("确定是否取消订单",function () {
							cancelOrder(order_id, index,curr_page);
						});
													
					});

					/* 绑定确认订单支付事件 */
					appUtils.bindEvent($(_pageId+" .payOrder"),function(){
						var product_id = $(this).attr("data-product_id");
						var order_id = $(this).attr("data-order_id");
						var tot_price = $(this).attr("data-tot_price");
						var index = $(this).attr("data-idx");
						var param=
						{
							"date":""
						}
						service.dealTimeSyn(param,function(data){
							if(data.error_no!="0")
							{
								layerUtils.iAlert(data.error_info);
								layerUtils.iLoading(false);
								return false;
							} 
							else if(data.results[0].is_trade=='0')
							{
								layerUtils.iAlert("当前是非交易时间，理财和基金产品暂停交易。");
								return false;
							}
							else{
								payOrder(product_id,order_id,tot_price,index);
							}

						})
					
					});

					//上一页、下一页disabled效果
					if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
						$(_pageId + " span[name='aNextPage']").removeClass("blue");
						$(_pageId + " span[name='aPrePage']").addClass("blue");
					}
					else if (pagingObjArr[0].curr_page == 1) {
						$(_pageId + " span[name='aPrePage']").removeClass("blue");
						$(_pageId + " span[name='aNextPage']").addClass("blue");
					}
					else {
						$(_pageId + " span[name='aPrePage']").addClass("blue");
						$(_pageId + " span[name='aNextPage']").addClass("blue");
					}

					if (pagingObjArr[0].total_pages<2) {
						$(_pageId + " span[name='aPrePage']").removeClass("blue");
						$(_pageId + "  span[name='aNextPage']").removeClass("blue");
					}

					if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
						$(_pageId+" #isNull").html("暂无数据");
						$(_pageId + " span[name='aPrePage']").removeClass("blue");
						$(_pageId + " span[name='aNextPage']").removeClass("blue");
					}
				}

			}
			else if(error_no =="0" && productType=="0"){
				if(result.length=="0"){
					layerUtils.iMsg(-1,"没有相关产品订单!");
					$(_pageId+" .product_bd_title").html('基金产品订单总数 : 0');
					$(_pageId+" .product_cont_list").empty();
					var total_pages = data.results[0].totalPages;
					var curr_page = data.results[0].currentPage;
					var total_rows = data.results[0].totalRows;
					total_pages = total_pages ? total_pages:0;
					curr_page = curr_page ? curr_page:0;
					total_rows=total_rows?total_rows:0;
					pagingObjArr[0].total_pages=total_pages;
					$(_pageId+" em[name='totalPage']").html(total_pages);
					pagingObjArr[0].curr_page=curr_page;
					$(_pageId+" em[name='curPage']").html(0);
					//显示多少条数据
					$(_pageId+" em[name='total_rows']").html(total_rows);
					$(_pageId + "  span[name='aNextPage']").removeClass("blue");
				}
				else{
					var total_pages = data.results[0].totalPages;
					var curr_page = data.results[0].currentPage;
					var total_rows = data.results[0].totalRows;
					total_pages = total_pages ? total_pages:0;
					curr_page = curr_page ? curr_page:0;
					total_rows=total_rows?total_rows:0;
					pagingObjArr[0].total_pages=total_pages;
					$(_pageId+" em[name='totalPage']").html(total_pages);
					pagingObjArr[0].curr_page=curr_page;
					$(_pageId+" em[name='curPage']").html(curr_page);
					//显示多少条数据
					$(_pageId+" em[name='total_rows']").html(total_rows);
					var allRecommendStr =  "";
					var list =  data.results[0].data;
					var len = list.length;
					for( var idx = 0; idx<len ; idx++)
					{
						var order_state=list[idx].order_state;
						var operating_type=list[idx].operating_type;
						var order_stateLabel  = "";
						var business_type=list[idx].business_type;
						var business_typeLabel="";
						var order_quantity=list[idx].order_quantity;
						var tot_price=list[idx].tot_price;
						if(tot_price=="" || tot_price==null){
							tot_price="0";
						}
						if(order_quantity=="" || order_quantity==null){
							order_quantity="0";
						}
						if(business_type == "0"){
							business_typeLabel = "认购";
						}else if(business_type =="1"){
							business_typeLabel = "申购";
						}else if(business_type =="2"){
							business_typeLabel = "赎回";
						}
						
						if(order_state == "1")
						{
							order_stateLabel ="待提交";
						}
						else if(order_state == "0"){
							order_stateLabel ="新订单";
						}else if(order_state == "2"){
							order_stateLabel ="提交成功";
						}
						else if(order_state == "3"){
							order_stateLabel ="提交失败";
						}
						else if(order_state == "4"){
							order_stateLabel ="成交";
						}
						else if(order_state == "5"){
							order_stateLabel ="已取消";
						}
						else  if(order_state == "6"){
							order_stateLabel ="已撤单";
						}
						else  if(order_state == "7"){
							order_stateLabel ="退款";
						}
						if(operating_type =="0"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
							'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
							'<a  style="float:right"  href="javascript:;"  class="cancer"  product_id='+list[idx].product_id+' data-idx='+idx+'>--</a>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
						}
						if(operating_type =="1"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
							'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
							'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+'>取消订单</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
						}
						if(operating_type =="2"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
							'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
							'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="payOrder" data-product_id='+list[idx].product_id+' data-tot_price='+list[idx].tot_price+' data-idx='+idx+'  style="color:blue">支付订单</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
						}
						if(operating_type =="3"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
							'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
							'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="undoOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+'>撤销订单</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
						}
						if(operating_type =="4"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
							'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
							'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已执行撤单操作</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
						}
						if(operating_type =="12"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
							'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
							'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+' >取&nbsp&nbsp&nbsp消</a><a href="javascript:void(0);" class="payOrder" data-product_id='+list[idx].product_id+' data-order_id='+list[idx].order_id+' data-tot_price='+list[idx].tot_price+' data-idx='+idx+'  style="color:blue;font-size:15px">支&nbsp&nbsp&nbsp付</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
						}
					}
					$(_pageId+" .product_bd_title").html('基金产品订单总数 : '+data.results[0].totalRows+'');
					$(_pageId+" .product_cont_list").html(allRecommendStr);

					//鼠标移入改变颜色
					appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
						$(this).css("color","red");
					},"mouseenter");

					//鼠标移出改变颜色
					appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
						$(this).css("color","black");
					},"mouseleave");

					/*点击名称进入详情*/
					appUtils.bindEvent($(_pageId+" a[product-id]"),function(){
						var param=
						{
							"product_id":$(this).attr("product-id")
						};
						appUtils.pageInit("account/myOrder","mall/itemsFundInfo",param);

					});

					/* 绑定撤销订单事件 */
					appUtils.bindEvent($(_pageId+" .undoOrder"),function(){
						var order_id = $(this).attr("data-order_id");
						var index = $(this).attr("data-idx");
						var param=
						{
							"date":""
						}
						service.dealTimeSyn(param,function(data){
							if(data.error_no!="0")
							{
								layerUtils.iAlert(data.error_info);
								layerUtils.iLoading(false);
								return false;
							} 
							else if(data.results[0].is_trade=='0')
							{
								layerUtils.iAlert("当前是非交易时间，理财和基金产品暂停交易。");
								return false;
							}
							else{
								layerUtils.layerCustom('<div class="popbox pop_rebuy" id="iLayer_myProd">	<div class="ptitle"><h2>订单撤销</h2></div>	<div class="pmain"><p class="input_text"></p><div class="input_text">	<label>交易密码</label><div id="password"  class="t1 trade_pwd input_custom" style="color:#A9A9A9;"><em>交易密码</em></div><input style="display:none" type="password"  class="t1"  id="trade_pwd" ></div><p class="input_text"><a href="javascript:void(0);" class="btn"  id="iLayer_redeemBtn">撤单</a><a href="javascript:void(0);" class="btn2" id="iLayer_closeBtn">关闭</a></p></div></div>');
								/*	var url=global.validateimg +"?v="+Math.random();						
									$(' .code_pic').click( 
										function(){ 
											$(' .code_pic').attr('src',url); 
										}); 
									$(' .code_pic').attr('src',url);//验证码错误，刷新获得验证码

									重新获取验证码
									appUtils.bindEvent($(" .code_pic") ,function(){
										var url=global.validateimg +"?v="+Math.random();
										$(' .code_pic').click( 
											function(){ 
												$(' .code_pic').attr('src',url); 
											}); 
										$(' .code_pic').attr('src',url);//验证码错误，刷新获得验证码
									});*/
									var fund_account=appUtils.getSStorageInfo("fund_account");
									var allRecommendStr =  "";
									allRecommendStr += "<label>资金账号</label>"+fund_account;
									$(" .pop_rebuy .input_text:eq(0)").append(allRecommendStr);
									appUtils.bindEvent($x("iLayer_myProd", "iLayer_redeemBtn"), function() {
										undoOrder(order_id, index,curr_page); 
										//								layerUtils.iCustomClose();
									});
									appUtils.bindEvent($x("iLayer_myProd", "iLayer_closeBtn"), function() {
										keyPanel.closeKeyPanel();
										layerUtils.iCustomClose(); 
									});
									
									appUtils.bindEvent($(" #code"),function(e){
										$(" .input_custom").removeClass(" active");
									});

									/*初始化键盘*/
									appUtils.bindEvent($(" #password") ,function(e){
										var input_pwd = $(this);
										input_pwd.find("em").html("");  // 清空密码
										input_pwd.attr("data-password","");  // 清空密码值
										$(" .input_custom").addClass("active");
										keyPanel.init_keyPanel(function(value){
											var curEchoText = input_pwd.find("em").html();  // 密码回显文本
											var input_pass_curPwd = input_pwd.attr("data-password") || "";  // 密码值
											var valInput=$(" #iLayer_myProd #trade_pwd");
											if(value == "del")
											{
												input_pwd.find("em").html(curEchoText.slice(0, -1));
												input_pwd.attr("data-password", input_pass_curPwd.slice(0, -1));
												valInput.val(input_pwd.attr("data-password"));
											}
											else
											{
												if(input_pass_curPwd.length < 6)
												{
													input_pwd.attr("data-password", input_pass_curPwd + value);  // 设置密码值
													input_pwd.find("em").html(curEchoText + "*");
													valInput.val(input_pass_curPwd + value);
												}
												else
												{
													layerUtils.iMsg(-1, "交易密码最多 6位!");
												}
											}
										}, input_pwd);
										e.stopPropagation();
//										$(" .input_custom").addClass(" active");
//										$(" #password em").html("");
//										$(" #trade_pwd").val("");
//										var passwordInput=$(" #password em");
//										var valInput=$(" #iLayer_myProd #trade_pwd");
//										keyPanel.init_keyPanel(" #iLayer_myProd",valInput.val(),valInput,function(pw)
//											{
//											var ch="";
//											for(var i=0;i<pw.length;i++){
//												ch+="*";
//											}
//											passwordInput.html(ch);
//											valInput.val(pw);
//											valInput.text("");
//											},"num","密码");
//										e.stopPropagation();	
									});

									//点击页面关闭软键盘
									appUtils.bindEvent($(" #iLayer_myProd"),function(){
										keyPanel.closeKeyPanel();
									});
								}

						})
					
					});

					/* 绑定取消订单事件 */
					appUtils.bindEvent($(_pageId+" .cancelOrder"),function(){
						var order_id = $(this).attr("data-order_id");
						var index = $(this).attr("data-idx");
						layerUtils.iConfirm("确定是否取消订单",function () {
							cancelOrder(order_id, index,curr_page);
						});
													
					});

					/* 绑定确认订单支付事件 */
					appUtils.bindEvent($(_pageId+" .payOrder"),function(){
						var product_id = $(this).attr("data-product_id");
						var order_id = $(this).attr("data-order_id");
						var tot_price = $(this).attr("data-tot_price");
						var index = $(this).attr("data-idx");
						var param=
						{
							"date":""
						}
						service.dealTimeSyn(param,function(data){
							if(data.error_no!="0")
							{
								layerUtils.iAlert(data.error_info);
								layerUtils.iLoading(false);
								return false;
							} 
							else if(data.results[0].is_trade=='0')
							{
								layerUtils.iAlert("当前是非交易时间，理财和基金产品暂停交易。");
								return false;
							}
							else{
								payOrder(product_id,order_id,tot_price,index);
							}

						})
					
					});

					//上一页、下一页disabled效果
					if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
						$(_pageId + " span[name='aNextPage']").removeClass("blue");
						$(_pageId + " span[name='aPrePage']").addClass("blue");
					}
					else if (pagingObjArr[0].curr_page == 1) {
						$(_pageId + " span[name='aPrePage']").removeClass("blue");
						$(_pageId + " span[name='aNextPage']").addClass("blue");
					}
					else {
						$(_pageId + " span[name='aPrePage']").addClass("blue");
						$(_pageId + " span[name='aNextPage']").addClass("blue");
					}

					if (pagingObjArr[0].total_pages<2) {
						$(_pageId + " span[name='aPrePage']").removeClass("blue");
						$(_pageId + "  span[name='aNextPage']").removeClass("blue");
					}

					if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
						$(_pageId+" #isNull").html("暂无数据");
						$(_pageId + " span[name='aPrePage']").removeClass("blue");
						$(_pageId + " span[name='aNextPage']").removeClass("blue");
					}
				}
			
			}else{
				layerUtils.iMsg(-1,error_info);
			}
		});

	}
	//非金融订单查询
	function queryUserOrder(){

		var user_id =appUtils.getSStorageInfo("user_id");
		var productType =product_type;
		var param =
		{
			"user_id" : user_id,
			"product_sub_type" : productType,
			"page" :"",
			"numPerPage" :"4",
		};

		service.queryUserOrder(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result=data.results[0].data;
		    if(error_no =="0" && productType=="3"){
				if(result.length=="0"){
					layerUtils.iMsg(-1,"没有相关产品订单!");
					$(_pageId+" .product_bd_title").html('资讯产品订单总数 : 0');
					$(_pageId+" .product_cont_list").empty();
					var total_pages = data.results[0].totalPages;
					var curr_page = data.results[0].currentPage;
					var total_rows = data.results[0].totalRows;
					total_pages = total_pages ? total_pages:0;
					curr_page = curr_page ? curr_page:0;
					total_rows=total_rows?total_rows:0;
					pagingObjArr[0].total_pages=total_pages;
					$(_pageId+" em[name='totalPage']").html(total_pages);
					pagingObjArr[0].curr_page=curr_page;
					$(_pageId+" em[name='curPage']").html(0);
					//显示多少条数据
					$(_pageId+" em[name='total_rows']").html(total_rows);
					$(_pageId + "  span[name='aNextPage']").removeClass("blue");
				}
				else{
					var total_pages = data.results[0].totalPages;
					var curr_page = data.results[0].currentPage;
					var total_rows = data.results[0].totalRows;
					total_pages = total_pages ? total_pages:0;
					curr_page = curr_page ? curr_page:0;
					total_rows=total_rows?total_rows:0;
					pagingObjArr[0].total_pages=total_pages;
					$(_pageId+" em[name='totalPage']").html(total_pages);
					pagingObjArr[0].curr_page=curr_page;
					$(_pageId+" em[name='curPage']").html(curr_page);
					//显示多少条数据
					$(_pageId+" em[name='total_rows']").html(total_rows);
					var allRecommendStr =  "";
					var list =  data.results[0].data;
					var len = list.length;
					for( var idx = 0; idx<len ; idx++)
					{
						var order_state=list[idx].order_state;
						var order_tot_price=list[idx].order_tot_price;
						if(order_tot_price=="" || order_tot_price==null){
							order_tot_price="0";
						}
						var order_stateLabel  = "";
						if(order_state == "1")
						{
							order_stateLabel ="待提交";
						}
						else if(order_state == "0"){
							order_stateLabel ="新订单";
						}else if(order_state == "2"){
							order_stateLabel ="提交成功";
						}
						else if(order_state == "3"){
							order_stateLabel ="提交失败";
						}
						else if(order_state == "4"){
							order_stateLabel ="成交";
						}
						else if(order_state == "5"){
							order_stateLabel ="已取消";
						}
						else  if(order_state == "6"){
							order_stateLabel ="已撤单";
						}
						else  if(order_state == "7"){
							order_stateLabel ="退款";
						}
						if(order_state =="0"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+' >取&nbsp&nbsp&nbsp消</a><a href="javascript:void(0);" class="payOrder" data-product_id='+list[idx].product_id+' data-order_id='+list[idx].order_id+' data-tot_price='+list[idx].tot_price+' data-idx='+idx+'  style="color:blue;font-size:15px">支&nbsp&nbsp&nbsp付</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
						}
						if(order_state =="1"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >待提交</a></p>'+
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
						}
						if(order_state =="2"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >提交成功</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
						}
						if(order_state =="3"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >提交失败</a></p>'+
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
						}
						if(order_state =="4"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >成交</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
						}
						if(order_state =="5"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已取消</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
						}
						if(order_state =="6"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已撤单</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
						}
						if(order_state =="7"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							' <p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >退款</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
						}
					}
					$(_pageId+" .product_bd_title").html('资讯产品订单总数 : '+data.results[0].totalRows+'');
					$(_pageId+" .product_cont_list").html(allRecommendStr);

					//鼠标移入改变颜色
					appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
						$(this).css("color","red");
					},"mouseenter");

					//鼠标移出改变颜色
					appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
						$(this).css("color","black");
					},"mouseleave");

					/*点击名称进入详情*/
					appUtils.bindEvent($(_pageId+" a[product-id]"),function(){
						var param=
						{
							"product_id":$(this).attr("product-id")
						};
							appUtils.pageInit("account/myOrder","mall/itemsInfoDetail",param);

					});

					/* 绑定撤销订单事件 */
					/*appUtils.bindEvent($(_pageId+" .undoOrder"),function(){
						var order_id = $(this).attr("data-order_id");
						var index = $(this).attr("data-idx");
						layerUtils.iConfirm("确定是否撤销订单",function () {
							undoOrder(order_id, index,curr_page);
						});
					});*/

					/* 绑定取消订单事件 */
					appUtils.bindEvent($(_pageId+" .cancelOrder"),function(){
						var order_id = $(this).attr("data-order_id");
						var index = $(this).attr("data-idx");
						layerUtils.iConfirm("确定是否取消订单",function () {
							cancelOrder(order_id, index,curr_page);
						})
						
					});

					/* 绑定确认订单支付事件 */
					appUtils.bindEvent($(_pageId+" .payOrder"),function(){
						var product_id = $(this).attr("data-product_id");
						var order_id = $(this).attr("data-order_id");
						var tot_price = $(this).attr("data-tot_price");
						var index = $(this).attr("data-idx");
						payOrder(product_id,order_id,tot_price,index);
					
					});

					//上一页、下一页disabled效果
					if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
						$(_pageId + " span[name='aNextPage']").removeClass("blue");
						$(_pageId + " span[name='aPrePage']").addClass("blue");
					}
					else if (pagingObjArr[0].curr_page == 1) {
						$(_pageId + " span[name='aPrePage']").removeClass("blue");
						$(_pageId + " span[name='aNextPage']").addClass("blue");
					}
					else {
						$(_pageId + " span[name='aPrePage']").addClass("blue");
						$(_pageId + " span[name='aNextPage']").addClass("blue");
					}

					if (pagingObjArr[0].total_pages<2) {
						$(_pageId + " span[name='aPrePage']").removeClass("blue");
						$(_pageId + "  span[name='aNextPage']").removeClass("blue");
					}

					if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
						$(_pageId+" #isNull").html("暂无数据");
						$(_pageId + " span[name='aPrePage']").removeClass("blue");
						$(_pageId + " span[name='aNextPage']").removeClass("blue");
					}
				}
			}
			else if(error_no =="0" && productType=="2"){
				if(result.length=="0"){
					layerUtils.iMsg(-1,"没有相关产品订单!");
					$(_pageId+" .product_bd_title").html('服务产品总数 : 0');
					$(_pageId+" .product_cont_list").empty();
					var total_pages = data.results[0].totalPages;
					var curr_page = data.results[0].currentPage;
					var total_rows = data.results[0].totalRows;
					total_pages = total_pages ? total_pages:0;
					curr_page = curr_page ? curr_page:0;
					total_rows=total_rows?total_rows:0;
					pagingObjArr[0].total_pages=total_pages;
					$(_pageId+" em[name='totalPage']").html(total_pages);
					pagingObjArr[0].curr_page=curr_page;
					$(_pageId+" em[name='curPage']").html(0);
					//显示多少条数据
					$(_pageId+" em[name='total_rows']").html(total_rows);
					$(_pageId + "  span[name='aNextPage']").removeClass("blue");
				}
				else{
					var total_pages = data.results[0].totalPages;
					var curr_page = data.results[0].currentPage;
					var total_rows = data.results[0].totalRows;
					total_pages = total_pages ? total_pages:0;
					curr_page = curr_page ? curr_page:0;
					total_rows=total_rows?total_rows:0;
					pagingObjArr[0].total_pages=total_pages;
					$(_pageId+" em[name='totalPage']").html(total_pages);
					pagingObjArr[0].curr_page=curr_page;
					$(_pageId+" em[name='curPage']").html(curr_page);
					//显示多少条数据
					$(_pageId+" em[name='total_rows']").html(total_rows);
					var allRecommendStr =  "";
					var list =  data.results[0].data;
					var len = list.length;
					for( var idx = 0; idx<len ; idx++)
					{
						var order_state=list[idx].order_state;
						var order_tot_price=list[idx].order_tot_price;
						if(order_tot_price=="" || order_tot_price==null){
							order_tot_price="0";
						}
						var order_stateLabel  = "";
						if(order_state == "1")
						{
							order_stateLabel ="待提交";
						}
						else if(order_state == "0"){
							order_stateLabel ="新订单";
						}else if(order_state == "2"){
							order_stateLabel ="提交成功";
						}
						else if(order_state == "3"){
							order_stateLabel ="提交失败";
						}
						else if(order_state == "4"){
							order_stateLabel ="成交";
						}
						else if(order_state == "5"){
							order_stateLabel ="已取消";
						}
						else  if(order_state == "6"){
							order_stateLabel ="已撤单";
						}
						else  if(order_state == "7"){
							order_stateLabel ="退款";
						}
						if(order_state =="0"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+' >取&nbsp&nbsp&nbsp消</a><a href="javascript:void(0);" class="payOrder" data-product_id='+list[idx].product_id+' data-order_id='+list[idx].order_id+' data-tot_price='+list[idx].tot_price+' data-idx='+idx+'  style="color:blue;font-size:15px">支&nbsp&nbsp&nbsp付</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
						}
						if(order_state =="1"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >待提交</a></p>'+
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
						}
						if(order_state =="2"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >提交成功</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
						}
						if(order_state =="3"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >提交失败</a></p>'+
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
						}
						if(order_state =="4"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >成交</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
						}
						if(order_state =="5"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已取消</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
						}
						if(order_state =="6"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已撤单</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
						}
						if(order_state =="7"){
							allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
							'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
							'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
							'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
							' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
							' <p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >退款</a></p>' +
							'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
						}
					}
					$(_pageId+" .product_bd_title").html('资讯产品订单总数 : '+data.results[0].totalRows+'');
					$(_pageId+" .product_cont_list").html(allRecommendStr);

					//鼠标移入改变颜色
					appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
						$(this).css("color","red");
					},"mouseenter");

					//鼠标移出改变颜色
					appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
						$(this).css("color","black");
					},"mouseleave");

					/*点击名称进入详情*/
					appUtils.bindEvent($(_pageId+" a[product-id]"),function(){
						var param=
						{
							"product_id":$(this).attr("product-id")
						};
							appUtils.pageInit("account/myOrder","mall/itemsInfoDetail",param);

					});

					/* 绑定撤销订单事件 */
					/*appUtils.bindEvent($(_pageId+" .undoOrder"),function(){
						var order_id = $(this).attr("data-order_id");
						var index = $(this).attr("data-idx");
						layerUtils.iConfirm("确定是否撤销订单",function () {
							undoOrder(order_id, index,curr_page);
						});
					});*/

					/* 绑定取消订单事件 */
					appUtils.bindEvent($(_pageId+" .cancelOrder"),function(){
						var order_id = $(this).attr("data-order_id");
						var index = $(this).attr("data-idx");
						layerUtils.iConfirm("确定是否取消订单",function () {
							cancelOrder(order_id, index,curr_page);
						});
						
					});

					/* 绑定确认订单支付事件 */
					appUtils.bindEvent($(_pageId+" .payOrder"),function(){
						var product_id = $(this).attr("data-product_id");
						var order_id = $(this).attr("data-order_id");
						var tot_price = $(this).attr("data-tot_price");
						var index = $(this).attr("data-idx");
						payOrder(product_id,order_id,tot_price,index);
										
					});

					//上一页、下一页disabled效果
					if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
						$(_pageId + " span[name='aNextPage']").removeClass("blue");
						$(_pageId + " span[name='aPrePage']").addClass("blue");
					}
					else if (pagingObjArr[0].curr_page == 1) {
						$(_pageId + " span[name='aPrePage']").removeClass("blue");
						$(_pageId + " span[name='aNextPage']").addClass("blue");
					}
					else {
						$(_pageId + " span[name='aPrePage']").addClass("blue");
						$(_pageId + " span[name='aNextPage']").addClass("blue");
					}

					if (pagingObjArr[0].total_pages<2) {
						$(_pageId + " span[name='aPrePage']").removeClass("blue");
						$(_pageId + "  span[name='aNextPage']").removeClass("blue");
					}

					if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
						$(_pageId+" #isNull").html("暂无数据");
						$(_pageId + " span[name='aPrePage']").removeClass("blue");
						$(_pageId + " span[name='aNextPage']").removeClass("blue");
					}
				}
			}else{
				layerUtils.iMsg(-1,error_info);
			}
		});

	}
	/* 订单支付*/
	function payOrder(product_id,order_id,tot_price,index){
		var user_id=appUtils.getSStorageInfo("user_id");
		var productType =product_type;
		var param1 =
		{
			"order_id":order_id,
			"user_id":user_id,
			"product_id":product_id,
			"tot_price":tot_price
		};
		if(productType=="0"){
			var param =
			{
				"product_id":product_id
			};
			service.fundInfo(param,function(data)
				{
				var product_shelf=data.results[0].product_shelf;
				if(data.error_no=="0" && product_shelf=="1")
				{
					appUtils.pageInit("account/myOrder","mall/fundOrder/orderPay",param1);
				}else{
					layerUtils.iAlert("很抱歉，该产品已下架！！！");
					layerUtils.iLoading(false);
					return false;
				}
			});
		}
		else if(productType=="1")
		{
			var param =
			{
				"product_id":product_id
			};
			service.finanInfo(param,function(data)
				{
				var product_shelf=data.results[0].product_shelf;
				if(data.error_no=="0" && product_shelf=="1")
				{
					appUtils.pageInit("account/myOrder","mall/finanOrder/orderPay",param1);
				}else{
					layerUtils.iAlert("很抱歉，该产品已下架！！！");
					layerUtils.iLoading(false);
					return false;
				}
			});
		
		}
		else if(productType=="2")
		{
			var param =
			{
				"product_id":product_id
			};
			service.findServInfo(param,function(data)
				{
				var product_shelf=data.results[0].product_shelf;
				if(data.error_no=="0" && product_shelf=="1")
				{
					appUtils.pageInit("account/myOrder","mall/servOrder/orderPay",param1);
				}else{
					layerUtils.iAlert("很抱歉，该产品已下架！！！");
					layerUtils.iLoading(false);
					return false;
				}
			});
		}
		else if(productType=="3")
		{
			var param =
			{
				"product_id":product_id
			};
			service.findInfoDetail(param,function(data)
				{
				var product_shelf=data.results[0].product_shelf;
				if(data.error_no=="0" && product_shelf=="1")
				{
					appUtils.pageInit("account/myOrder","mall/infoOrder/orderPay",param1);
				}else{
					layerUtils.iAlert("很抱歉，该产品已下架！！！");
					layerUtils.iLoading(false);
					return false;
				}
			});
		}
	}

	/* 撤销订单 */
	function undoOrder(order_id, index,curr_page){
//		var code =$.trim($("#iLayer_myProd .code1").val());
		var trade_pwd =$.trim($("#iLayer_myProd  #trade_pwd").val());
		if(trade_pwd==""){
			layerUtils.iMsg(-1,"交易密码不能为空！！！");
			return false;
		}
		/*if(code==""){
			layerUtils.iMsg(-1,"验证码不能为空！！！");
			return false;
		}*/
		//加密
		service.getRSAKey({},function(data){
			if(data.error_no=="0")
			{
				var modulus = data.results[0].modulus;
				var publicExponent =data.results[0].publicExponent;
				var endecryptUtils = require("endecryptUtils");
				var _trade_pwd=endecryptUtils.rsaEncrypt(modulus,publicExponent,$.trim(trade_pwd));
				var param =
				{
					"old_order_id" :order_id,
//					"vf_code":code,
					"trade_pwd":_trade_pwd
				};
				service.undoOrder(param,function(data){
					var error_no = data.error_no;
					var error_info = data.error_info;
					if(error_no =="0")
					{
						layerUtils.iCustomClose();
						//				$(_pageId+" .undoOrder[data-idx="+index+"]").html("已执行撤单操作");
						var user_id =appUtils.getSStorageInfo("user_id");
						var productType =product_type;

						if(productType=="0"||productType=="1"){
							var param =
							{
								"user_id":user_id,
								"page":curr_page,
								"numPerPage":"4",
								"product_sub_type":productType,
							};
							service.queryMyOrder(param,function(data)
								{
								var error_no = data.error_no;
								var error_info = data.error_info;
								if(error_no =="0" && productType=="1")
								{
									var total_pages = data.results[0].totalPages;
									var curr_page = data.results[0].currentPage;
									var total_rows = data.results[0].totalRows;
									total_pages = total_pages ? total_pages:0;
									curr_page = curr_page ? curr_page:0;
									total_rows=total_rows?total_rows:0;
									pagingObjArr[0].total_pages=total_pages;
									$(_pageId+" em[name='totalPage']").html(total_pages);
									pagingObjArr[0].curr_page=curr_page;
									$(_pageId+" em[name='curPage']").html(curr_page);
									//显示多少条数据
									$(_pageId+" em[name='total_rows']").html(total_rows);

									var allRecommendStr =  "";
									var list =  data.results[0].data;
									var len = list.length;
									for( var idx = 0; idx<len ; idx++)
									{
										var order_state=list[idx].order_state;
										var operating_type=list[idx].operating_type;
										var order_stateLabel  = "";
										var business_type=list[idx].business_type;
										var business_typeLabel="";
										var order_quantity=list[idx].order_quantity;
										var tot_price=list[idx].tot_price;
										if(tot_price=="" || tot_price==null){
											tot_price="0";
										}
										if(order_quantity=="" || order_quantity==null){
											order_quantity="0";
										}
										if(business_type == "0"){
											business_typeLabel = "认购";
										}else if(business_type =="1"){
											business_typeLabel = "申购";
										}else if(business_type =="2"){
											business_typeLabel = "赎回";
										}
										
										if(order_state == "1")
										{
											order_stateLabel ="待提交";
										}
										else if(order_state == "0"){
											order_stateLabel ="新订单";
										}else if(order_state == "2"){
											order_stateLabel ="提交成功";
										}
										else if(order_state == "3"){
											order_stateLabel ="提交失败";
										}
										else if(order_state == "4"){
											order_stateLabel ="成交";
										}
										else if(order_state == "5"){
											order_stateLabel ="已取消";
										}
										else  if(order_state == "6"){
											order_stateLabel ="已撤单";
										}
										else  if(order_state == "7"){
											order_stateLabel ="退款";
										}
										if(operating_type =="0"){
											allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
											'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
											'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
											'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
											' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
											'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
											'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
											'<a  style="float:right"  href="javascript:;"  class="cancer"  product_id='+list[idx].product_id+' data-idx='+idx+'>--</a>' +
											'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
										}
										if(operating_type =="1"){
											allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
											'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
											'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
											'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
											' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
											'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
											'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
											'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+'>取消订单</a></p>' +
											'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
										}
										if(operating_type =="2"){
											allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
											'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
											'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
											'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
											' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
											'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
											'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
											'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="payOrder" data-product_id='+list[idx].product_id+' data-tot_price='+list[idx].tot_price+' data-idx='+idx+'  style="color:blue">支付订单</a></p>' +
											'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
										}
										if(operating_type =="3"){
											allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
											'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
											'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
											'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
											' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
											'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
											'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
											'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="undoOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+'>撤销订单</a></p>' +
											'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
										}
										if(operating_type =="4"){
											allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
											'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
											'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
											'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
											' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
											'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
											'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
											'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已执行撤单操作</a></p>' +
											'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
										}
										if(operating_type =="12"){
											allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
											'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
											'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
											'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
											' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
											'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
											'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
											'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+' >取&nbsp&nbsp&nbsp消</a><a href="javascript:void(0);" class="payOrder" data-product_id='+list[idx].product_id+' data-order_id='+list[idx].order_id+' data-tot_price='+list[idx].tot_price+' data-idx='+idx+'  style="color:blue;font-size:15px">支&nbsp&nbsp&nbsp付</a></p>' +
											'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
										}
									}
									$(_pageId+" .product_cont_list").html(allRecommendStr);

									//鼠标移入改变颜色
									appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
										$(this).css("color","red");
									},"mouseenter");

									//鼠标移出改变颜色
									appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
										$(this).css("color","black");
									},"mouseleave");

									/*点击名称进入详情*/
									appUtils.bindEvent($(_pageId+" a[product-id]"),function(){
										var param=
										{
											"product_id":$(this).attr("product-id")
										};
										appUtils.pageInit("account/myOrder","mall/itemsFinanInfo",param);
									});


									/* 绑定撤销订单事件 */
									appUtils.bindEvent($(_pageId+" .undoOrder"),function(){
										var order_id = $(this).attr("data-order_id");
										var index = $(this).attr("data-idx");
										var param=
										{
											"date":""
										}
										service.dealTimeSyn(param,function(data){
											if(data.error_no!="0")
											{
												layerUtils.iAlert(data.error_info);
												layerUtils.iLoading(false);
												return false;
											} 
											else if(data.results[0].is_trade=='0')
											{
												layerUtils.iAlert("当前是非交易时间，理财和基金产品暂停交易。");
												return false;
											}
											else{
												layerUtils.layerCustom('<div class="popbox pop_rebuy" id="iLayer_myProd">	<div class="ptitle"><h2>订单撤销</h2></div>	<div class="pmain"><p class="input_text"></p><div class="input_text">	<label>交易密码</label><div id="password"  class="t1 trade_pwd input_custom" style="color:#A9A9A9;"><em>交易密码</em></div><input style="display:none" type="password"  class="t1"  id="trade_pwd" ></div><p class="input_text"><a href="javascript:void(0);" class="btn"  id="iLayer_redeemBtn">撤单</a><a href="javascript:void(0);" class="btn2" id="iLayer_closeBtn">关闭</a></p></div></div>');
												/*	var url=global.validateimg +"?v="+Math.random();						
													$(' .code_pic').click( 
														function(){ 
															$(' .code_pic').attr('src',url); 
														}); 
													$(' .code_pic').attr('src',url);//验证码错误，刷新获得验证码

													重新获取验证码
													appUtils.bindEvent($(" .code_pic") ,function(){
														var url=global.validateimg +"?v="+Math.random();
														$(' .code_pic').click( 
															function(){ 
																$(' .code_pic').attr('src',url); 
															}); 
														$(' .code_pic').attr('src',url);//验证码错误，刷新获得验证码
													});*/
													var fund_account=appUtils.getSStorageInfo("fund_account");
													var allRecommendStr =  "";
													allRecommendStr += "<label>资金账号</label>"+fund_account;
													$(" .pop_rebuy .input_text:eq(0)").append(allRecommendStr);
													appUtils.bindEvent($x("iLayer_myProd", "iLayer_redeemBtn"), function() {
														undoOrder(order_id, index,curr_page); 
														//								layerUtils.iCustomClose();
													});
													appUtils.bindEvent($x("iLayer_myProd", "iLayer_closeBtn"), function() {
														keyPanel.closeKeyPanel();
														layerUtils.iCustomClose(); 
													});
													
													appUtils.bindEvent($(" #code"),function(e){
														$(" .input_custom").removeClass(" active");
													});

													/*初始化键盘*/
													appUtils.bindEvent($(" #password") ,function(e){
														var input_pwd = $(this);
														input_pwd.find("em").html("");  // 清空密码
														input_pwd.attr("data-password","");  // 清空密码值
														$(" .input_custom").addClass("active");
														keyPanel.init_keyPanel(function(value){
															var curEchoText = input_pwd.find("em").html();  // 密码回显文本
															var input_pass_curPwd = input_pwd.attr("data-password") || "";  // 密码值
															var valInput=$(" #iLayer_myProd #trade_pwd");
															if(value == "del")
															{
																input_pwd.find("em").html(curEchoText.slice(0, -1));
																input_pwd.attr("data-password", input_pass_curPwd.slice(0, -1));
																valInput.val(input_pwd.attr("data-password"));
															}
															else
															{
																if(input_pass_curPwd.length < 6)
																{
																	input_pwd.attr("data-password", input_pass_curPwd + value);  // 设置密码值
																	input_pwd.find("em").html(curEchoText + "*");
																	valInput.val(input_pass_curPwd + value);
																}
																else
																{
																	layerUtils.iMsg(-1, "交易密码最多 6位!");
																}
															}
														}, input_pwd);
														e.stopPropagation();
//														$(" .input_custom").addClass(" active");
//														$(" #password em").html("");
//														$(" #trade_pwd").val("");
//														var passwordInput=$(" #password em");
//														var valInput=$(" #iLayer_myProd #trade_pwd");
//														keyPanel.init_keyPanel(" #iLayer_myProd",valInput.val(),valInput,function(pw)
//															{
//															var ch="";
//															for(var i=0;i<pw.length;i++){
//																ch+="*";
//															}
//															passwordInput.html(ch);
//															valInput.val(pw);
//															valInput.text("");
//															},"num","密码");
//														e.stopPropagation();	
													});

													//点击页面关闭软键盘
													appUtils.bindEvent($(" #iLayer_myProd"),function(){
														keyPanel.closeKeyPanel();
													});
												}

										})
									
									});

									/* 绑定取消订单事件 */
									appUtils.bindEvent($(_pageId+" .cancelOrder"),function(){
										var order_id = $(this).attr("data-order_id");
										var index = $(this).attr("data-idx");
										layerUtils.iConfirm("确定是否取消订单",function () {
											cancelOrder(order_id, index,curr_page);
										});
																	
									});

									/* 绑定确认订单支付事件 */
									appUtils.bindEvent($(_pageId+" .payOrder"),function(){
										var product_id = $(this).attr("data-product_id");
										var order_id = $(this).attr("data-order_id");
										var tot_price = $(this).attr("data-tot_price");
										var index = $(this).attr("data-idx");
										var param=
										{
											"date":""
										};
										service.dealTimeSyn(param,function(data){
											if(data.error_no!="0")
											{
												layerUtils.iAlert(data.error_info);
												layerUtils.iLoading(false);
												return false;
											} 
											else if(data.results[0].is_trade=='0')
											{
												layerUtils.iAlert("当前是非交易时间，理财和基金产品暂停交易。");
												return false;
											}
											else{
												payOrder(product_id,order_id,tot_price,index);
											}

										})
									
									});

									//上一页、下一页disabled效果
									if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
										$(_pageId + " span[name='aNextPage']").removeClass("blue");
										$(_pageId + " span[name='aPrePage']").addClass("blue");
									}
									else if (pagingObjArr[0].curr_page == 1) {
										$(_pageId + " span[name='aPrePage']").removeClass("blue");
										$(_pageId + " span[name='aNextPage']").addClass("blue");
									}
									else {
										$(_pageId + " span[name='aPrePage']").addClass("blue");
										$(_pageId + " span[name='aNextPage']").addClass("blue");
									}

									if (pagingObjArr[0].total_pages<2) {
										$(_pageId + " span[name='aPrePage']").removeClass("blue");
										$(_pageId + "  span[name='aNextPage']").removeClass("blue");
									}

									if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
										$(_pageId+" #isNull").html("暂无数据");
										$(_pageId + " span[name='aPrePage']").removeClass("blue");
										$(_pageId + " span[name='aNextPage']").removeClass("blue");
									}

								}
								else if(error_no =="0" && productType=="0"){
									var total_pages = data.results[0].totalPages;
									var curr_page = data.results[0].currentPage;
									var total_rows = data.results[0].totalRows;
									total_pages = total_pages ? total_pages:0;
									curr_page = curr_page ? curr_page:0;
									total_rows=total_rows?total_rows:0;
									pagingObjArr[0].total_pages=total_pages;
									$(_pageId+" em[name='totalPage']").html(total_pages);
									pagingObjArr[0].curr_page=curr_page;
									$(_pageId+" em[name='curPage']").html(curr_page);
									//显示多少条数据
									$(_pageId+" em[name='total_rows']").html(total_rows);

									var allRecommendStr =  "";
									var list =  data.results[0].data;
									var len = list.length;
									for( var idx = 0; idx<len ; idx++)
									{
										var order_state=list[idx].order_state;
										var operating_type=list[idx].operating_type;
										var order_stateLabel  = "";
										var business_type=list[idx].business_type;
										var business_typeLabel="";
										var order_quantity=list[idx].order_quantity;
										var tot_price=list[idx].tot_price;
										if(tot_price=="" || tot_price==null){
											tot_price="0";
										}
										if(order_quantity=="" || order_quantity==null){
											order_quantity="0";
										}
										if(business_type == "0"){
											business_typeLabel = "认购";
										}else if(business_type =="1"){
											business_typeLabel = "申购";
										}else if(business_type =="2"){
											business_typeLabel = "赎回";
										}
										
										if(order_state == "1")
										{
											order_stateLabel ="待提交";
										}
										else if(order_state == "0"){
											order_stateLabel ="新订单";
										}else if(order_state == "2"){
											order_stateLabel ="提交成功";
										}
										else if(order_state == "3"){
											order_stateLabel ="提交失败";
										}
										else if(order_state == "4"){
											order_stateLabel ="成交";
										}
										else if(order_state == "5"){
											order_stateLabel ="已取消";
										}
										else  if(order_state == "6"){
											order_stateLabel ="已撤单";
										}
										else  if(order_state == "7"){
											order_stateLabel ="退款";
										}
										if(operating_type =="0"){
											allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
											'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
											'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
											'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
											' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
											'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
											'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
											'<a  style="float:right"  href="javascript:;"  class="cancer"  product_id='+list[idx].product_id+' data-idx='+idx+'>--</a>' +
											'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
										}
										if(operating_type =="1"){
											allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
											'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
											'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
											'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
											' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
											'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
											'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
											'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+'>取消订单</a></p>' +
											'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
										}
										if(operating_type =="2"){
											allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
											'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
											'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
											'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
											' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
											'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
											'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
											'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="payOrder" data-product_id='+list[idx].product_id+' data-tot_price='+list[idx].tot_price+' data-idx='+idx+'  style="color:blue">支付订单</a></p>' +
											'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
										}
										if(operating_type =="3"){
											allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
											'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
											'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
											'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
											' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
											'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
											'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
											'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="undoOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+'>撤销订单</a></p>' +
											'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
										}
										if(operating_type =="4"){
											allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
											'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
											'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
											'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
											' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
											'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
											'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
											'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已执行撤单操作</a></p>' +
											'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
										}
										if(operating_type =="12"){
											allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
											'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
											'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
											'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
											' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
											'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
											'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
											'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+' >取&nbsp&nbsp&nbsp消</a><a href="javascript:void(0);" class="payOrder" data-product_id='+list[idx].product_id+' data-order_id='+list[idx].order_id+' data-tot_price='+list[idx].tot_price+' data-idx='+idx+'  style="color:blue;font-size:15px">支&nbsp&nbsp&nbsp付</a></p>' +
											'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
										}
									}
									$(_pageId+" .product_cont_list").html(allRecommendStr);

									//鼠标移入改变颜色
									appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
										$(this).css("color","red");
									},"mouseenter");

									//鼠标移出改变颜色
									appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
										$(this).css("color","black");
									},"mouseleave");

									/*点击名称进入详情*/
									appUtils.bindEvent($(_pageId+" a[product-id]"),function(){
										var param=
										{
											"product_id":$(this).attr("product-id")
										};
										appUtils.pageInit("account/myOrder","mall/itemsFundInfo",param);
									});


									/* 绑定撤销订单事件 */
									appUtils.bindEvent($(_pageId+" .undoOrder"),function(){
										var order_id = $(this).attr("data-order_id");
										var index = $(this).attr("data-idx");
										var param=
										{
											"date":""
										}
										service.dealTimeSyn(param,function(data){
											if(data.error_no!="0")
											{
												layerUtils.iAlert(data.error_info);
												layerUtils.iLoading(false);
												return false;
											} 
											else if(data.results[0].is_trade=='0')
											{
												layerUtils.iAlert("当前是非交易时间，理财和基金产品暂停交易。");
												return false;
											}
											else{
												layerUtils.layerCustom('<div class="popbox pop_rebuy" id="iLayer_myProd">	<div class="ptitle"><h2>订单撤销</h2></div>	<div class="pmain"><p class="input_text"></p><div class="input_text">	<label>交易密码</label><div id="password"  class="t1 trade_pwd input_custom" style="color:#A9A9A9;"><em>交易密码</em></div><input style="display:none" type="password"  class="t1"  id="trade_pwd" ></div><p class="input_text"><a href="javascript:void(0);" class="btn"  id="iLayer_redeemBtn">撤单</a><a href="javascript:void(0);" class="btn2" id="iLayer_closeBtn">关闭</a></p></div></div>');
												/*	var url=global.validateimg +"?v="+Math.random();						
													$(' .code_pic').click( 
														function(){ 
															$(' .code_pic').attr('src',url); 
														}); 
													$(' .code_pic').attr('src',url);//验证码错误，刷新获得验证码

													重新获取验证码
													appUtils.bindEvent($(" .code_pic") ,function(){
														var url=global.validateimg +"?v="+Math.random();
														$(' .code_pic').click( 
															function(){ 
																$(' .code_pic').attr('src',url); 
															}); 
														$(' .code_pic').attr('src',url);//验证码错误，刷新获得验证码
													});*/
													var fund_account=appUtils.getSStorageInfo("fund_account");
													var allRecommendStr =  "";
													allRecommendStr += "<label>资金账号</label>"+fund_account;
													$(" .pop_rebuy .input_text:eq(0)").append(allRecommendStr);
													appUtils.bindEvent($x("iLayer_myProd", "iLayer_redeemBtn"), function() {
														undoOrder(order_id, index,curr_page); 
														//								layerUtils.iCustomClose();
													});
													appUtils.bindEvent($x("iLayer_myProd", "iLayer_closeBtn"), function() {
														keyPanel.closeKeyPanel();
														layerUtils.iCustomClose(); 
													});
													
													appUtils.bindEvent($(" #code"),function(e){
														$(" .input_custom").removeClass(" active");
													});

													/*初始化键盘*/
													appUtils.bindEvent($(" #password") ,function(e){
														var input_pwd = $(this);
														input_pwd.find("em").html("");  // 清空密码
														input_pwd.attr("data-password","");  // 清空密码值
														$(" .input_custom").addClass("active");
														keyPanel.init_keyPanel(function(value){
															var curEchoText = input_pwd.find("em").html();  // 密码回显文本
															var input_pass_curPwd = input_pwd.attr("data-password") || "";  // 密码值
															var valInput=$(" #iLayer_myProd #trade_pwd");
															if(value == "del")
															{
																input_pwd.find("em").html(curEchoText.slice(0, -1));
																input_pwd.attr("data-password", input_pass_curPwd.slice(0, -1));
																valInput.val(input_pwd.attr("data-password"));
															}
															else
															{
																if(input_pass_curPwd.length < 6)
																{
																	input_pwd.attr("data-password", input_pass_curPwd + value);  // 设置密码值
																	input_pwd.find("em").html(curEchoText + "*");
																	valInput.val(input_pass_curPwd + value);
																}
																else
																{
																	layerUtils.iMsg(-1, "交易密码最多 6位!");
																}
															}
														}, input_pwd);
														e.stopPropagation();
//														$(" .input_custom").addClass(" active");
//														$(" #password em").html("");
//														$(" #trade_pwd").val("");
//														var passwordInput=$(" #password em");
//														var valInput=$(" #iLayer_myProd #trade_pwd");
//														keyPanel.init_keyPanel(" #iLayer_myProd",valInput.val(),valInput,function(pw)
//															{
//															var ch="";
//															for(var i=0;i<pw.length;i++){
//																ch+="*";
//															}
//															passwordInput.html(ch);
//															valInput.val(pw);
//															valInput.text("");
//															},"num","密码");
//														e.stopPropagation();	
													});

													//点击页面关闭软键盘
													appUtils.bindEvent($(" #iLayer_myProd"),function(){
														keyPanel.closeKeyPanel();
													});
												}

										})
									
									});

									/* 绑定取消订单事件 */
									appUtils.bindEvent($(_pageId+" .cancelOrder"),function(){
										var order_id = $(this).attr("data-order_id");
										var index = $(this).attr("data-idx");
										layerUtils.iConfirm("确定是否取消订单",function () {
											cancelOrder(order_id, index,curr_page);
										});
																	
									});

									/* 绑定确认订单支付事件 */
									appUtils.bindEvent($(_pageId+" .payOrder"),function(){
										var product_id = $(this).attr("data-product_id");
										var order_id = $(this).attr("data-order_id");
										var tot_price = $(this).attr("data-tot_price");
										var index = $(this).attr("data-idx");
										var param=
										{
											"date":""
										}
										service.dealTimeSyn(param,function(data){
											if(data.error_no!="0")
											{
												layerUtils.iAlert(data.error_info);
												layerUtils.iLoading(false);
												return false;
											} 
											else if(data.results[0].is_trade=='0')
											{
												layerUtils.iAlert("当前是非交易时间，理财和基金产品暂停交易。");
												return false;
											}
											else{
												payOrder(product_id,order_id,tot_price,index);
											}

										})
									
									});

									//上一页、下一页disabled效果
									if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
										$(_pageId + " span[name='aNextPage']").removeClass("blue");
										$(_pageId + " span[name='aPrePage']").addClass("blue");
									}
									else if (pagingObjArr[0].curr_page == 1) {
										$(_pageId + " span[name='aPrePage']").removeClass("blue");
										$(_pageId + " span[name='aNextPage']").addClass("blue");
									}
									else {
										$(_pageId + " span[name='aPrePage']").addClass("blue");
										$(_pageId + " span[name='aNextPage']").addClass("blue");
									}

									if (pagingObjArr[0].total_pages<2) {
										$(_pageId + " span[name='aPrePage']").removeClass("blue");
										$(_pageId + "  span[name='aNextPage']").removeClass("blue");
									}

									if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
										$(_pageId+" #isNull").html("暂无数据");
										$(_pageId + " span[name='aPrePage']").removeClass("blue");
										$(_pageId + " span[name='aNextPage']").removeClass("blue");
									}
								}else{
									layerUtils.iMsg(-1,error_info);
								}
						    });
						}else if(productType=="3"||productType=="2"){
							var param =
							{
								"user_id" : user_id,
								"product_sub_type" : productType,
								"page" :curr_page,
								"numPerPage" :"4",
							};

							service.queryUserOrder(param,function(data){
								var error_no = data.error_no;
								var error_info = data.error_info;
								var result=data.results[0].data;
							    if(error_no =="0" && productType=="3"){
									if(result.length=="0"){
										layerUtils.iMsg(-1,"没有相关产品订单!");
										$(_pageId+" .product_bd_title").html('资讯产品订单总数 : 0');
										$(_pageId+" .product_cont_list").empty();
									}
									else{
										var total_pages = data.results[0].totalPages;
										var curr_page = data.results[0].currentPage;
										var total_rows = data.results[0].totalRows;
										total_pages = total_pages ? total_pages:0;
										curr_page = curr_page ? curr_page:0;
										total_rows=total_rows?total_rows:0;
										pagingObjArr[0].total_pages=total_pages;
										$(_pageId+" em[name='totalPage']").html(total_pages);
										pagingObjArr[0].curr_page=curr_page;
										$(_pageId+" em[name='curPage']").html(curr_page);
										//显示多少条数据
										$(_pageId+" em[name='total_rows']").html(total_rows);
										var allRecommendStr =  "";
										var list =  data.results[0].data;
										var len = list.length;
										for( var idx = 0; idx<len ; idx++)
										{
											var order_state=list[idx].order_state;
											var order_tot_price=list[idx].order_tot_price;
											if(order_tot_price=="" || order_tot_price==null){
												order_tot_price="0";
											}
											var order_stateLabel  = "";
											if(order_state == "1")
											{
												order_stateLabel ="待提交";
											}
											else if(order_state == "0"){
												order_stateLabel ="新订单";
											}else if(order_state == "2"){
												order_stateLabel ="提交成功";
											}
											else if(order_state == "3"){
												order_stateLabel ="提交失败";
											}
											else if(order_state == "4"){
												order_stateLabel ="成交";
											}
											else if(order_state == "5"){
												order_stateLabel ="已取消";
											}
											else  if(order_state == "6"){
												order_stateLabel ="已撤单";
											}
											else  if(order_state == "7"){
												order_stateLabel ="退款";
											}
											if(order_state =="0"){
												allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
												'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
												'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
												'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
												' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
												'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+' >取&nbsp&nbsp&nbsp消</a><a href="javascript:void(0);" class="payOrder" data-product_id='+list[idx].product_id+' data-order_id='+list[idx].order_id+' data-tot_price='+list[idx].tot_price+' data-idx='+idx+'  style="color:blue;font-size:15px">支&nbsp&nbsp&nbsp付</a></p>' +
												'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
											}
											if(order_state =="1"){
												allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
												'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
												'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
												'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
												' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
												'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >待提交</a></p>'+
												'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
											}
											if(order_state =="2"){
												allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
												'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
												'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
												'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
												' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
												'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >提交成功</a></p>' +
												'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
											}
											if(order_state =="3"){
												allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
												'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
												'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
												'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
												' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
												'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >提交失败</a></p>'+
												'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
											}
											if(order_state =="4"){
												allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
												'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
												'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
												'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
												' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
												'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >成交</a></p>' +
												'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
											}
											if(order_state =="5"){
												allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
												'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
												'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
												'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
												' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
												'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已取消</a></p>' +
												'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
											}
											if(order_state =="6"){
												allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
												'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
												'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
												'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
												' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
												'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已撤单</a></p>' +
												'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
											}
											if(order_state =="7"){
												allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
												'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
												'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
												'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
												' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
												' <p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >退款</a></p>' +
												'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
											}
										}
										$(_pageId+" .product_bd_title").html('资讯产品订单总数 : '+data.results[0].totalRows+'');
										$(_pageId+" .product_cont_list").html(allRecommendStr);

										//鼠标移入改变颜色
										appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
											$(this).css("color","red");
										},"mouseenter");

										//鼠标移出改变颜色
										appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
											$(this).css("color","black");
										},"mouseleave");

										/*点击名称进入详情*/
										appUtils.bindEvent($(_pageId+" a[product-id]"),function(){
											var param=
											{
												"product_id":$(this).attr("product-id")
											};
												appUtils.pageInit("account/myOrder","mall/itemsInfoDetail",param);

										});

										/* 绑定撤销订单事件 */
										/*appUtils.bindEvent($(_pageId+" .undoOrder"),function(){
											var order_id = $(this).attr("data-order_id");
											var index = $(this).attr("data-idx");
											layerUtils.iConfirm("确定是否撤销订单",function () {
												undoOrder(order_id, index,curr_page);
											});
										});*/

										/* 绑定取消订单事件 */
										appUtils.bindEvent($(_pageId+" .cancelOrder"),function(){
											var order_id = $(this).attr("data-order_id");
											var index = $(this).attr("data-idx");
											layerUtils.iConfirm("确定是否取消订单",function () {
												cancelOrder(order_id, index,curr_page);
											});
											
										});

										/* 绑定确认订单支付事件 */
										appUtils.bindEvent($(_pageId+" .payOrder"),function(){
											var product_id = $(this).attr("data-product_id");
											var order_id = $(this).attr("data-order_id");
											var tot_price = $(this).attr("data-tot_price");
											var index = $(this).attr("data-idx");
											payOrder(product_id,order_id,tot_price,index);
																				
										});

										//上一页、下一页disabled效果
										if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
											$(_pageId + " span[name='aNextPage']").removeClass("blue");
											$(_pageId + " span[name='aPrePage']").addClass("blue");
										}
										else if (pagingObjArr[0].curr_page == 1) {
											$(_pageId + " span[name='aPrePage']").removeClass("blue");
											$(_pageId + " span[name='aNextPage']").addClass("blue");
										}
										else {
											$(_pageId + " span[name='aPrePage']").addClass("blue");
											$(_pageId + " span[name='aNextPage']").addClass("blue");
										}

										if (pagingObjArr[0].total_pages<2) {
											$(_pageId + " span[name='aPrePage']").removeClass("blue");
											$(_pageId + "  span[name='aNextPage']").removeClass("blue");
										}

										if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
											$(_pageId+" #isNull").html("暂无数据");
											$(_pageId + " span[name='aPrePage']").removeClass("blue");
											$(_pageId + " span[name='aNextPage']").removeClass("blue");
										}
									}
								}else if(error_no =="0" && productType=="2"){

									if(result.length=="0"){
										layerUtils.iMsg(-1,"没有相关产品订单!");
										$(_pageId+" .product_bd_title").html('服务产品总数 : 0');
										$(_pageId+" .product_cont_list").empty();
									}
									else{
										var total_pages = data.results[0].totalPages;
										var curr_page = data.results[0].currentPage;
										var total_rows = data.results[0].totalRows;
										total_pages = total_pages ? total_pages:0;
										curr_page = curr_page ? curr_page:0;
										total_rows=total_rows?total_rows:0;
										pagingObjArr[0].total_pages=total_pages;
										$(_pageId+" em[name='totalPage']").html(total_pages);
										pagingObjArr[0].curr_page=curr_page;
										$(_pageId+" em[name='curPage']").html(curr_page);
										//显示多少条数据
										$(_pageId+" em[name='total_rows']").html(total_rows);
										var allRecommendStr =  "";
										var list =  data.results[0].data;
										var len = list.length;
										for( var idx = 0; idx<len ; idx++)
										{
											var order_state=list[idx].order_state;
											var order_tot_price=list[idx].order_tot_price;
											if(order_tot_price=="" || order_tot_price==null){
												order_tot_price="0";
											}
											var order_stateLabel  = "";
											if(order_state == "1")
											{
												order_stateLabel ="待提交";
											}
											else if(order_state == "0"){
												order_stateLabel ="新订单";
											}else if(order_state == "2"){
												order_stateLabel ="提交成功";
											}
											else if(order_state == "3"){
												order_stateLabel ="提交失败";
											}
											else if(order_state == "4"){
												order_stateLabel ="成交";
											}
											else if(order_state == "5"){
												order_stateLabel ="已取消";
											}
											else  if(order_state == "6"){
												order_stateLabel ="已撤单";
											}
											else  if(order_state == "7"){
												order_stateLabel ="退款";
											}
											if(order_state =="0"){
												allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
												'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
												'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
												'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
												' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
												'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+' >取&nbsp&nbsp&nbsp消</a><a href="javascript:void(0);" class="payOrder" data-product_id='+list[idx].product_id+' data-order_id='+list[idx].order_id+' data-tot_price='+list[idx].tot_price+' data-idx='+idx+'  style="color:blue;font-size:15px">支&nbsp&nbsp&nbsp付</a></p>' +
												'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
											}
											if(order_state =="1"){
												allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
												'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
												'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
												'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
												' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
												'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >待提交</a></p>'+
												'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
											}
											if(order_state =="2"){
												allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
												'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
												'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
												'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
												' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
												'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >提交成功</a></p>' +
												'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
											}
											if(order_state =="3"){
												allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
												'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
												'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
												'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
												' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
												'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >提交失败</a></p>'+
												'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
											}
											if(order_state =="4"){
												allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
												'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
												'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
												'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
												' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
												'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >成交</a></p>' +
												'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
											}
											if(order_state =="5"){
												allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
												'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
												'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
												'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
												' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
												'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已取消</a></p>' +
												'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
											}
											if(order_state =="6"){
												allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
												'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
												'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
												'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
												' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
												'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已撤单</a></p>' +
												'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
											}
											if(order_state =="7"){
												allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
												'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
												'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
												'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
												' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
												' <p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >退款</a></p>' +
												'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
											}
										}
										$(_pageId+" .product_bd_title").html('服务产品总数 : '+data.results[0].totalRows+'');
										$(_pageId+" .product_cont_list").html(allRecommendStr);

										//鼠标移入改变颜色
										appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
											$(this).css("color","red");
										},"mouseenter");

										//鼠标移出改变颜色
										appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
											$(this).css("color","black");
										},"mouseleave");

										/*点击名称进入详情*/
										appUtils.bindEvent($(_pageId+" a[product-id]"),function(){
											var param=
											{
												"product_id":$(this).attr("product-id")
											};
												appUtils.pageInit("account/myOrder","mall/itemsServInfo",param);

										});

										/* 绑定撤销订单事件 */
										/*appUtils.bindEvent($(_pageId+" .undoOrder"),function(){
											var order_id = $(this).attr("data-order_id");
											var index = $(this).attr("data-idx");
											layerUtils.iConfirm("确定是否撤销订单",function () {
												undoOrder(order_id, index,curr_page);
											});
										});*/

										/* 绑定取消订单事件 */
										appUtils.bindEvent($(_pageId+" .cancelOrder"),function(){
											var order_id = $(this).attr("data-order_id");
											var index = $(this).attr("data-idx");
											layerUtils.iConfirm("确定是否取消订单",function () {
												cancelOrder(order_id, index,curr_page);
											});
																					
										});

										/* 绑定确认订单支付事件 */
										appUtils.bindEvent($(_pageId+" .payOrder"),function(){
											var product_id = $(this).attr("data-product_id");
											var order_id = $(this).attr("data-order_id");
											var tot_price = $(this).attr("data-tot_price");
											var index = $(this).attr("data-idx");
											payOrder(product_id,order_id,tot_price,index);
																				
										});

										//上一页、下一页disabled效果
										if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
											$(_pageId + " span[name='aNextPage']").removeClass("blue");
											$(_pageId + " span[name='aPrePage']").addClass("blue");
										}
										else if (pagingObjArr[0].curr_page == 1) {
											$(_pageId + " span[name='aPrePage']").removeClass("blue");
											$(_pageId + " span[name='aNextPage']").addClass("blue");
										}
										else {
											$(_pageId + " span[name='aPrePage']").addClass("blue");
											$(_pageId + " span[name='aNextPage']").addClass("blue");
										}

										if (pagingObjArr[0].total_pages<2) {
											$(_pageId + " span[name='aPrePage']").removeClass("blue");
											$(_pageId + "  span[name='aNextPage']").removeClass("blue");
										}

										if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
											$(_pageId+" #isNull").html("暂无数据");
											$(_pageId + " span[name='aPrePage']").removeClass("blue");
											$(_pageId + " span[name='aNextPage']").removeClass("blue");
										}
									}
								}
								else{
									layerUtils.iMsg(-1,error_info);
								}
							});
						}
					}
					else
					{
						layerUtils.iAlert(error_info);
					}
				});
			}
		});

	}

	/* 取消订单 */
	function cancelOrder(order_id, index,curr_page){
		var productType =product_type;
		var user_id =appUtils.getSStorageInfo("user_id");
		if(productType=="0"||productType=="1"){
		var param =
		{
			"user_id" :user_id,
			"old_order_id" :order_id,
		};
		service.cancelOrder(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			if(error_no =="0")
			{
				$(_pageId+" .product_cont_list li[data-idx="+index+"]").remove();
				var user_id =appUtils.getSStorageInfo("user_id");
				var productType =product_type;

					var param =
					{
						"user_id":user_id,
						"page":curr_page,
						"numPerPage":"4",
						"product_sub_type":productType,
					};
					service.queryMyOrder(param,function(data)
						{
						var error_no = data.error_no;
						var error_info = data.error_info;
						if(error_no =="0" && productType=="1")
						{
							var total_pages = data.results[0].totalPages;
							var curr_page = data.results[0].currentPage;
							var total_rows = data.results[0].totalRows;
							total_pages = total_pages ? total_pages:0;
							curr_page = curr_page ? curr_page:0;
							total_rows=total_rows?total_rows:0;
							pagingObjArr[0].total_pages=total_pages;
							$(_pageId+" em[name='totalPage']").html(total_pages);
							pagingObjArr[0].curr_page=curr_page;
							$(_pageId+" em[name='curPage']").html(curr_page);
							//显示多少条数据
							$(_pageId+" em[name='total_rows']").html(total_rows);

							var allRecommendStr =  "";
							var list =  data.results[0].data;
							var len = list.length;
							for( var idx = 0; idx<len ; idx++)
							{
								var order_state=list[idx].order_state;
								var operating_type=list[idx].operating_type;
								var order_stateLabel  = "";
								var business_type=list[idx].business_type;
								var business_typeLabel="";
								var order_quantity=list[idx].order_quantity;
								var tot_price=list[idx].tot_price;
								if(tot_price=="" || tot_price==null){
									tot_price="0";
								}
								if(order_quantity=="" || order_quantity==null){
									order_quantity="0";
								}
								if(business_type == "0"){
									business_typeLabel = "认购";
								}else if(business_type =="1"){
									business_typeLabel = "申购";
								}else if(business_type =="2"){
									business_typeLabel = "赎回";
								}
								
								if(order_state == "1")
								{
									order_stateLabel ="待提交";
								}
								else if(order_state == "0"){
									order_stateLabel ="新订单";
								}else if(order_state == "2"){
									order_stateLabel ="提交成功";
								}
								else if(order_state == "3"){
									order_stateLabel ="提交失败";
								}
								else if(order_state == "4"){
									order_stateLabel ="成交";
								}
								else if(order_state == "5"){
									order_stateLabel ="已取消";
								}
								else  if(order_state == "6"){
									order_stateLabel ="已撤单";
								}
								else  if(order_state == "7"){
									order_stateLabel ="退款";
								}
								if(operating_type =="0"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
									'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
									'<a  style="float:right"  href="javascript:;"  class="cancer"  product_id='+list[idx].product_id+' data-idx='+idx+'>--</a>' +
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
								}
								if(operating_type =="1"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
									'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
									'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+'>取消订单</a></p>' +
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
								}
								if(operating_type =="2"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
									'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
									'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="payOrder" data-product_id='+list[idx].product_id+' data-tot_price='+list[idx].tot_price+' data-idx='+idx+'  style="color:blue">支付订单</a></p>' +
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
								}
								if(operating_type =="3"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
									'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
									'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="undoOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+'>撤销订单</a></p>' +
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
								}
								if(operating_type =="4"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
									'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
									'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已执行撤单操作</a></p>' +
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
								}
								if(operating_type =="12"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
									'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
									'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+' >取&nbsp&nbsp&nbsp消</a><a href="javascript:void(0);" class="payOrder" data-product_id='+list[idx].product_id+' data-order_id='+list[idx].order_id+' data-tot_price='+list[idx].tot_price+' data-idx='+idx+'  style="color:blue;font-size:15px">支&nbsp&nbsp&nbsp付</a></p>' +
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
								}
							}
							$(_pageId+" .product_cont_list").html(allRecommendStr);

							//鼠标移入改变颜色
							appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
								$(this).css("color","red");
							},"mouseenter");

							//鼠标移出改变颜色
							appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
								$(this).css("color","black");
							},"mouseleave");

							/*点击名称进入详情*/
							appUtils.bindEvent($(_pageId+" a[product-id]"),function(){
								var param=
								{
									"product_id":$(this).attr("product-id")
								};
								appUtils.pageInit("account/myOrder","mall/itemsFinanInfo",param);
							});


							/* 绑定撤销订单事件 */
							appUtils.bindEvent($(_pageId+" .undoOrder"),function(){
								var order_id = $(this).attr("data-order_id");
								var index = $(this).attr("data-idx");
								var param=
								{
									"date":""
								}
								service.dealTimeSyn(param,function(data){
									if(data.error_no!="0")
									{
										layerUtils.iAlert(data.error_info);
										layerUtils.iLoading(false);
										return false;
									} 
									else if(data.results[0].is_trade=='0')
									{
										layerUtils.iAlert("当前是非交易时间，理财和基金产品暂停交易。");
										return false;
									}
									else{
										layerUtils.layerCustom('<div class="popbox pop_rebuy" id="iLayer_myProd">	<div class="ptitle"><h2>订单撤销</h2></div>	<div class="pmain"><p class="input_text"></p><div class="input_text">	<label>交易密码</label><div id="password"  class="t1 trade_pwd input_custom" style="color:#A9A9A9;"><em>交易密码</em></div><input style="display:none" type="password"  class="t1"  id="trade_pwd" ></div><p class="input_text"><a href="javascript:void(0);" class="btn"  id="iLayer_redeemBtn">撤单</a><a href="javascript:void(0);" class="btn2" id="iLayer_closeBtn">关闭</a></p></div></div>');
										/*	var url=global.validateimg +"?v="+Math.random();						
											$(' .code_pic').click( 
												function(){ 
													$(' .code_pic').attr('src',url); 
												}); 
											$(' .code_pic').attr('src',url);//验证码错误，刷新获得验证码

											重新获取验证码
											appUtils.bindEvent($(" .code_pic") ,function(){
												var url=global.validateimg +"?v="+Math.random();
												$(' .code_pic').click( 
													function(){ 
														$(' .code_pic').attr('src',url); 
													}); 
												$(' .code_pic').attr('src',url);//验证码错误，刷新获得验证码
											});*/
											var fund_account=appUtils.getSStorageInfo("fund_account");
											var allRecommendStr =  "";
											allRecommendStr += "<label>资金账号</label>"+fund_account;
											$(" .pop_rebuy .input_text:eq(0)").append(allRecommendStr);
											appUtils.bindEvent($x("iLayer_myProd", "iLayer_redeemBtn"), function() {
												undoOrder(order_id, index,curr_page); 
												//								layerUtils.iCustomClose();
											});
											appUtils.bindEvent($x("iLayer_myProd", "iLayer_closeBtn"), function() {
												keyPanel.closeKeyPanel();
												layerUtils.iCustomClose(); 
											});
											
											appUtils.bindEvent($(" #code"),function(e){
												$(" .input_custom").removeClass(" active");
											});

											/*初始化键盘*/
											appUtils.bindEvent($(" #password") ,function(e){
												var input_pwd = $(this);
												input_pwd.find("em").html("");  // 清空密码
												input_pwd.attr("data-password","");  // 清空密码值
												$(" .input_custom").addClass("active");
												keyPanel.init_keyPanel(function(value){
													var curEchoText = input_pwd.find("em").html();  // 密码回显文本
													var input_pass_curPwd = input_pwd.attr("data-password") || "";  // 密码值
													var valInput=$(" #iLayer_myProd #trade_pwd");
													if(value == "del")
													{
														input_pwd.find("em").html(curEchoText.slice(0, -1));
														input_pwd.attr("data-password", input_pass_curPwd.slice(0, -1));
														valInput.val(input_pwd.attr("data-password"));
													}
													else
													{
														if(input_pass_curPwd.length < 6)
														{
															input_pwd.attr("data-password", input_pass_curPwd + value);  // 设置密码值
															input_pwd.find("em").html(curEchoText + "*");
															valInput.val(input_pass_curPwd + value);
														}
														else
														{
															layerUtils.iMsg(-1, "交易密码最多 6位!");
														}
													}
												}, input_pwd);
												e.stopPropagation();
//												$(" .input_custom").addClass(" active");
//												$(" #password em").html("");
//												$(" #trade_pwd").val("");
//												var passwordInput=$(" #password em");
//												var valInput=$(" #iLayer_myProd #trade_pwd");
//												keyPanel.init_keyPanel(" #iLayer_myProd",valInput.val(),valInput,function(pw)
//													{
//													var ch="";
//													for(var i=0;i<pw.length;i++){
//														ch+="*";
//													}
//													passwordInput.html(ch);
//													valInput.val(pw);
//													valInput.text("");
//													},"num","密码");
//												e.stopPropagation();	
											});

											//点击页面关闭软键盘
											appUtils.bindEvent($(" #iLayer_myProd"),function(){
												keyPanel.closeKeyPanel();
											});
										}

								})
							
							});

							/* 绑定取消订单事件 */
							appUtils.bindEvent($(_pageId+" .cancelOrder"),function(){
								var order_id = $(this).attr("data-order_id");
								var index = $(this).attr("data-idx");
								layerUtils.iConfirm("确定是否取消订单",function () {
									cancelOrder(order_id, index,curr_page);
								});
															
							});

							/* 绑定确认订单支付事件 */
							appUtils.bindEvent($(_pageId+" .payOrder"),function(){
								var product_id = $(this).attr("data-product_id");
								var order_id = $(this).attr("data-order_id");
								var tot_price = $(this).attr("data-tot_price");
								var index = $(this).attr("data-idx");
								var param=
								{
									"date":""
								}
								service.dealTimeSyn(param,function(data){
									if(data.error_no!="0")
									{
										layerUtils.iAlert(data.error_info);
										layerUtils.iLoading(false);
										return false;
									} 
									else if(data.results[0].is_trade=='0')
									{
										layerUtils.iAlert("当前是非交易时间，理财和基金产品暂停交易。");
										return false;
									}
									else{
										payOrder(product_id,order_id,tot_price,index);
									}

								})
							
							});

							//上一页、下一页disabled效果
							if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
								$(_pageId + " span[name='aNextPage']").removeClass("blue");
								$(_pageId + " span[name='aPrePage']").addClass("blue");
							}
							else if (pagingObjArr[0].curr_page == 1) {
								$(_pageId + " span[name='aPrePage']").removeClass("blue");
								$(_pageId + " span[name='aNextPage']").addClass("blue");
							}
							else {
								$(_pageId + " span[name='aPrePage']").addClass("blue");
								$(_pageId + " span[name='aNextPage']").addClass("blue");
							}

							if (pagingObjArr[0].total_pages<2) {
								$(_pageId + " span[name='aPrePage']").removeClass("blue");
								$(_pageId + "  span[name='aNextPage']").removeClass("blue");
							}

							if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
								$(_pageId+" #isNull").html("暂无数据");
								$(_pageId + " span[name='aPrePage']").removeClass("blue");
								$(_pageId + " span[name='aNextPage']").removeClass("blue");
							}

						}
						else if(error_no =="0" && productType=="0"){
							var total_pages = data.results[0].totalPages;
							var curr_page = data.results[0].currentPage;
							var total_rows = data.results[0].totalRows;
							total_pages = total_pages ? total_pages:0;
							curr_page = curr_page ? curr_page:0;
							total_rows=total_rows?total_rows:0;
							pagingObjArr[0].total_pages=total_pages;
							$(_pageId+" em[name='totalPage']").html(total_pages);
							pagingObjArr[0].curr_page=curr_page;
							$(_pageId+" em[name='curPage']").html(curr_page);
							//显示多少条数据
							$(_pageId+" em[name='total_rows']").html(total_rows);

							var allRecommendStr =  "";
							var list =  data.results[0].data;
							var len = list.length;
							for( var idx = 0; idx<len ; idx++)
							{
								var order_state=list[idx].order_state;
								var operating_type=list[idx].operating_type;
								var order_stateLabel  = "";
								var business_type=list[idx].business_type;
								var business_typeLabel="";
								var order_quantity=list[idx].order_quantity;
								var tot_price=list[idx].tot_price;
								if(tot_price=="" || tot_price==null){
									tot_price="0";
								}
								if(order_quantity=="" || order_quantity==null){
									order_quantity="0";
								}
								if(business_type == "0"){
									business_typeLabel = "认购";
								}else if(business_type =="1"){
									business_typeLabel = "申购";
								}else if(business_type =="2"){
									business_typeLabel = "赎回";
								}
								
								if(order_state == "1")
								{
									order_stateLabel ="待提交";
								}
								else if(order_state == "0"){
									order_stateLabel ="新订单";
								}else if(order_state == "2"){
									order_stateLabel ="提交成功";
								}
								else if(order_state == "3"){
									order_stateLabel ="提交失败";
								}
								else if(order_state == "4"){
									order_stateLabel ="成交";
								}
								else if(order_state == "5"){
									order_stateLabel ="已取消";
								}
								else  if(order_state == "6"){
									order_stateLabel ="已撤单";
								}
								else  if(order_state == "7"){
									order_stateLabel ="退款";
								}
								if(operating_type =="0"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
									'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
									'<a  style="float:right"  href="javascript:;"  class="cancer"  product_id='+list[idx].product_id+' data-idx='+idx+'>--</a>' +
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
								}
								if(operating_type =="1"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
									'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
									'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+'>取消订单</a></p>' +
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
								}
								if(operating_type =="2"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
									'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
									'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="payOrder" data-product_id='+list[idx].product_id+' data-tot_price='+list[idx].tot_price+' data-idx='+idx+'  style="color:blue">支付订单</a></p>' +
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
								}
								if(operating_type =="3"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
									'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
									'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="undoOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+'>撤销订单</a></p>' +
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
								}
								if(operating_type =="4"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
									'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
									'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已执行撤单操作</a></p>' +
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
								}
								if(operating_type =="12"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
									'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
									'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+' >取&nbsp&nbsp&nbsp消</a><a href="javascript:void(0);" class="payOrder" data-product_id='+list[idx].product_id+' data-order_id='+list[idx].order_id+' data-tot_price='+list[idx].tot_price+' data-idx='+idx+'  style="color:blue;font-size:15px">支&nbsp&nbsp&nbsp付</a></p>' +
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
								}
							}
							$(_pageId+" .product_cont_list").html(allRecommendStr);

							//鼠标移入改变颜色
							appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
								$(this).css("color","red");
							},"mouseenter");

							//鼠标移出改变颜色
							appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
								$(this).css("color","black");
							},"mouseleave");

							/*点击名称进入详情*/
							appUtils.bindEvent($(_pageId+" a[product-id]"),function(){
								var param=
								{
									"product_id":$(this).attr("product-id")
								};
								appUtils.pageInit("account/myOrder","mall/itemsFundInfo",param);
							});


							/* 绑定撤销订单事件 */
							appUtils.bindEvent($(_pageId+" .undoOrder"),function(){
								var order_id = $(this).attr("data-order_id");
								var index = $(this).attr("data-idx");
								var param=
								{
									"date":""
								}
								service.dealTimeSyn(param,function(data){
									if(data.error_no!="0")
									{
										layerUtils.iAlert(data.error_info);
										layerUtils.iLoading(false);
										return false;
									} 
									else if(data.results[0].is_trade=='0')
									{
										layerUtils.iAlert("当前是非交易时间，理财和基金产品暂停交易。");
										return false;
									}
									else{
										layerUtils.layerCustom('<div class="popbox pop_rebuy" id="iLayer_myProd">	<div class="ptitle"><h2>订单撤销</h2></div>	<div class="pmain"><p class="input_text"></p><div class="input_text">	<label>交易密码</label><div id="password"  class="t1 trade_pwd input_custom" style="color:#A9A9A9;"><em>交易密码</em></div><input style="display:none" type="password"  class="t1"  id="trade_pwd" ></div><p class="input_text"><a href="javascript:void(0);" class="btn"  id="iLayer_redeemBtn">撤单</a><a href="javascript:void(0);" class="btn2" id="iLayer_closeBtn">关闭</a></p></div></div>');
										/*	var url=global.validateimg +"?v="+Math.random();						
											$(' .code_pic').click( 
												function(){ 
													$(' .code_pic').attr('src',url); 
												}); 
											$(' .code_pic').attr('src',url);//验证码错误，刷新获得验证码

											重新获取验证码
											appUtils.bindEvent($(" .code_pic") ,function(){
												var url=global.validateimg +"?v="+Math.random();
												$(' .code_pic').click( 
													function(){ 
														$(' .code_pic').attr('src',url); 
													}); 
												$(' .code_pic').attr('src',url);//验证码错误，刷新获得验证码
											});*/
											var fund_account=appUtils.getSStorageInfo("fund_account");
											var allRecommendStr =  "";
											allRecommendStr += "<label>资金账号</label>"+fund_account;
											$(" .pop_rebuy .input_text:eq(0)").append(allRecommendStr);
											appUtils.bindEvent($x("iLayer_myProd", "iLayer_redeemBtn"), function() {
												undoOrder(order_id, index,curr_page); 
												//								layerUtils.iCustomClose();
											});
											appUtils.bindEvent($x("iLayer_myProd", "iLayer_closeBtn"), function() {
												keyPanel.closeKeyPanel();
												layerUtils.iCustomClose(); 
											});
											
											appUtils.bindEvent($(" #code"),function(e){
												$(" .input_custom").removeClass(" active");
											});

											/*初始化键盘*/
											appUtils.bindEvent($(" #password") ,function(e){
												var input_pwd = $(this);
												input_pwd.find("em").html("");  // 清空密码
												input_pwd.attr("data-password","");  // 清空密码值
												$(" .input_custom").addClass("active");
												keyPanel.init_keyPanel(function(value){
													var curEchoText = input_pwd.find("em").html();  // 密码回显文本
													var input_pass_curPwd = input_pwd.attr("data-password") || "";  // 密码值
													var valInput=$(" #iLayer_myProd #trade_pwd");
													if(value == "del")
													{
														input_pwd.find("em").html(curEchoText.slice(0, -1));
														input_pwd.attr("data-password", input_pass_curPwd.slice(0, -1));
														valInput.val(input_pwd.attr("data-password"));
													}
													else
													{
														if(input_pass_curPwd.length < 6)
														{
															input_pwd.attr("data-password", input_pass_curPwd + value);  // 设置密码值
															input_pwd.find("em").html(curEchoText + "*");
															valInput.val(input_pass_curPwd + value);
														}
														else
														{
															layerUtils.iMsg(-1, "交易密码最多 6位!");
														}
													}
												}, input_pwd);
												e.stopPropagation();
//												$(" .input_custom").addClass(" active");
//												$(" #password em").html("");
//												$(" #trade_pwd").val("");
//												var passwordInput=$(" #password em");
//												var valInput=$(" #iLayer_myProd #trade_pwd");
//												keyPanel.init_keyPanel(" #iLayer_myProd",valInput.val(),valInput,function(pw)
//													{
//													var ch="";
//													for(var i=0;i<pw.length;i++){
//														ch+="*";
//													}
//													passwordInput.html(ch);
//													valInput.val(pw);
//													valInput.text("");
//													},"num","密码");
//												e.stopPropagation();	
											});

											//点击页面关闭软键盘
											appUtils.bindEvent($(" #iLayer_myProd"),function(){
												keyPanel.closeKeyPanel();
											});
										}

								})
							
							});

							/* 绑定取消订单事件 */
							appUtils.bindEvent($(_pageId+" .cancelOrder"),function(){
								var order_id = $(this).attr("data-order_id");
								var index = $(this).attr("data-idx");
								layerUtils.iConfirm("确定是否取消订单",function () {
									cancelOrder(order_id, index,curr_page);
								});
															
							});

							/* 绑定确认订单支付事件 */
							appUtils.bindEvent($(_pageId+" .payOrder"),function(){
								var product_id = $(this).attr("data-product_id");
								var order_id = $(this).attr("data-order_id");
								var tot_price = $(this).attr("data-tot_price");
								var index = $(this).attr("data-idx");
								var param=
								{
									"date":""
								}
								service.dealTimeSyn(param,function(data){
									if(data.error_no!="0")
									{
										layerUtils.iAlert(data.error_info);
										layerUtils.iLoading(false);
										return false;
									} 
									else if(data.results[0].is_trade=='0')
									{
										layerUtils.iAlert("当前是非交易时间，理财和基金产品暂停交易。");
										return false;
									}
									else{
										payOrder(product_id,order_id,tot_price,index);
									}

								})
							
							});

							//上一页、下一页disabled效果
							if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
								$(_pageId + " span[name='aNextPage']").removeClass("blue");
								$(_pageId + " span[name='aPrePage']").addClass("blue");
							}
							else if (pagingObjArr[0].curr_page == 1) {
								$(_pageId + " span[name='aPrePage']").removeClass("blue");
								$(_pageId + " span[name='aNextPage']").addClass("blue");
							}
							else {
								$(_pageId + " span[name='aPrePage']").addClass("blue");
								$(_pageId + " span[name='aNextPage']").addClass("blue");
							}

							if (pagingObjArr[0].total_pages<2) {
								$(_pageId + " span[name='aPrePage']").removeClass("blue");
								$(_pageId + "  span[name='aNextPage']").removeClass("blue");
							}

							if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
								$(_pageId+" #isNull").html("暂无数据");
								$(_pageId + " span[name='aPrePage']").removeClass("blue");
								$(_pageId + " span[name='aNextPage']").removeClass("blue");
							}
						}else{
							layerUtils.iMsg(-1,error_info);
						}
						});
			}
			else
			{
				layerUtils.iAlert(error_info);
			}

		});
		}
		else if(productType=="3"||productType=="2"){
			var param =
			{
				"user_id" :user_id,
				"old_order_id" :order_id,
				"product_sub_type":productType,
			};
			service.cancelOrder(param,function(data){
				var error_no = data.error_no;
				var error_info = data.error_info;
				if(error_no =="0")
				{
					$(_pageId+" .product_cont_list li[data-idx="+index+"]").remove();
					var user_id =appUtils.getSStorageInfo("user_id");
					var param =
					{
						"user_id" : user_id,
						"product_sub_type" : productType,
						"page" :curr_page,
						"numPerPage" :"4",
					};
			  service.queryUserOrder(param,function(data){
				var error_no = data.error_no;
				var error_info = data.error_info;
				var result=data.results[0].data;
			    if(error_no =="0" && productType=="3"){
					if(result.length=="0"){
						layerUtils.iMsg(-1,"没有相关产品订单!");
						$(_pageId+" .product_bd_title").html('资讯产品订单总数 : 0');
						$(_pageId+" .product_cont_list").empty();
						var total_pages = data.results[0].totalPages;
						var curr_page = data.results[0].currentPage;
						var total_rows = data.results[0].totalRows;
						total_pages = total_pages ? total_pages:0;
						curr_page = curr_page ? curr_page:0;
						total_rows=total_rows?total_rows:0;
						pagingObjArr[0].total_pages=total_pages;
						$(_pageId+" em[name='totalPage']").html(total_pages);
						pagingObjArr[0].curr_page=curr_page;
						$(_pageId+" em[name='curPage']").html(0);
						//显示多少条数据
						$(_pageId+" em[name='total_rows']").html(total_rows);
						$(_pageId + "  span[name='aNextPage']").removeClass("blue");
					}
					else{
						var total_pages = data.results[0].totalPages;
						var curr_page = data.results[0].currentPage;
						var total_rows = data.results[0].totalRows;
						total_pages = total_pages ? total_pages:0;
						curr_page = curr_page ? curr_page:0;
						total_rows=total_rows?total_rows:0;
						pagingObjArr[0].total_pages=total_pages;
						$(_pageId+" em[name='totalPage']").html(total_pages);
						pagingObjArr[0].curr_page=curr_page;
						$(_pageId+" em[name='curPage']").html(curr_page);
						//显示多少条数据
						$(_pageId+" em[name='total_rows']").html(total_rows);
						var allRecommendStr =  "";
						var list =  data.results[0].data;
						var len = list.length;
						for( var idx = 0; idx<len ; idx++)
						{
							var order_state=list[idx].order_state;
							var order_tot_price=list[idx].order_tot_price;
							if(order_tot_price=="" || order_tot_price==null){
								order_tot_price="0";
							}
							var order_stateLabel  = "";
							if(order_state == "1")
							{
								order_stateLabel ="待提交";
							}
							else if(order_state == "0"){
								order_stateLabel ="新订单";
							}else if(order_state == "2"){
								order_stateLabel ="提交成功";
							}
							else if(order_state == "3"){
								order_stateLabel ="提交失败";
							}
							else if(order_state == "4"){
								order_stateLabel ="成交";
							}
							else if(order_state == "5"){
								order_stateLabel ="已取消";
							}
							else  if(order_state == "6"){
								order_stateLabel ="已撤单";
							}
							else  if(order_state == "7"){
								order_stateLabel ="退款";
							}
							if(order_state =="0"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+' >取&nbsp&nbsp&nbsp消</a><a href="javascript:void(0);" class="payOrder" data-product_id='+list[idx].product_id+' data-order_id='+list[idx].order_id+' data-tot_price='+list[idx].tot_price+' data-idx='+idx+'  style="color:blue;font-size:15px">支&nbsp&nbsp&nbsp付</a></p>' +
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
							}
							if(order_state =="1"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >待提交</a></p>'+
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
							}
							if(order_state =="2"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >提交成功</a></p>' +
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
							}
							if(order_state =="3"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >提交失败</a></p>'+
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
							}
							if(order_state =="4"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >成交</a></p>' +
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
							}
							if(order_state =="5"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已取消</a></p>' +
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
							}
							if(order_state =="6"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已撤单</a></p>' +
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
							}
							if(order_state =="7"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								' <p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >退款</a></p>' +
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
							}
						}
						$(_pageId+" .product_bd_title").html('资讯产品订单总数 : '+data.results[0].totalRows+'');
						$(_pageId+" .product_cont_list").html(allRecommendStr);

						//鼠标移入改变颜色
						appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
							$(this).css("color","red");
						},"mouseenter");

						//鼠标移出改变颜色
						appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
							$(this).css("color","black");
						},"mouseleave");

						/*点击名称进入详情*/
						appUtils.bindEvent($(_pageId+" a[product-id]"),function(){
							var param=
							{
								"product_id":$(this).attr("product-id")
							};
								appUtils.pageInit("account/myOrder","mall/itemsInfoDetail",param);

						});

						/* 绑定撤销订单事件 */
						/*appUtils.bindEvent($(_pageId+" .undoOrder"),function(){
							var order_id = $(this).attr("data-order_id");
							var index = $(this).attr("data-idx");
							layerUtils.iConfirm("确定是否撤销订单",function () {
								undoOrder(order_id, index,curr_page);
							});
						});*/

						/* 绑定取消订单事件 */
						appUtils.bindEvent($(_pageId+" .cancelOrder"),function(){
							var order_id = $(this).attr("data-order_id");
							var index = $(this).attr("data-idx");
							layerUtils.iConfirm("确定是否取消订单",function () {
								cancelOrder(order_id, index,curr_page);
							});
													
						});

						/* 绑定确认订单支付事件 */
						appUtils.bindEvent($(_pageId+" .payOrder"),function(){
							var product_id = $(this).attr("data-product_id");
							var order_id = $(this).attr("data-order_id");
							var tot_price = $(this).attr("data-tot_price");
							var index = $(this).attr("data-idx");
							payOrder(product_id,order_id,tot_price,index);
												
						});

						//上一页、下一页disabled效果
						if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
							$(_pageId + " span[name='aNextPage']").removeClass("blue");
							$(_pageId + " span[name='aPrePage']").addClass("blue");
						}
						else if (pagingObjArr[0].curr_page == 1) {
							$(_pageId + " span[name='aPrePage']").removeClass("blue");
							$(_pageId + " span[name='aNextPage']").addClass("blue");
						}
						else {
							$(_pageId + " span[name='aPrePage']").addClass("blue");
							$(_pageId + " span[name='aNextPage']").addClass("blue");
						}

						if (pagingObjArr[0].total_pages<2) {
							$(_pageId + " span[name='aPrePage']").removeClass("blue");
							$(_pageId + "  span[name='aNextPage']").removeClass("blue");
						}

						if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
							$(_pageId+" #isNull").html("暂无数据");
							$(_pageId + " span[name='aPrePage']").removeClass("blue");
							$(_pageId + " span[name='aNextPage']").removeClass("blue");
						}
					}
				}
				else if(error_no =="0" && productType=="2"){
					if(result.length=="0"){
						layerUtils.iMsg(-1,"没有相关产品订单!");
						$(_pageId+" .product_bd_title").html('服务产品总数 : 0');
						$(_pageId+" .product_cont_list").empty();
						var total_pages = data.results[0].totalPages;
						var curr_page = data.results[0].currentPage;
						var total_rows = data.results[0].totalRows;
						total_pages = total_pages ? total_pages:0;
						curr_page = curr_page ? curr_page:0;
						total_rows=total_rows?total_rows:0;
						pagingObjArr[0].total_pages=total_pages;
						$(_pageId+" em[name='totalPage']").html(total_pages);
						pagingObjArr[0].curr_page=curr_page;
						$(_pageId+" em[name='curPage']").html(0);
						//显示多少条数据
						$(_pageId+" em[name='total_rows']").html(total_rows);
						$(_pageId + "  span[name='aNextPage']").removeClass("blue");
					}
					else{
						var total_pages = data.results[0].totalPages;
						var curr_page = data.results[0].currentPage;
						var total_rows = data.results[0].totalRows;
						total_pages = total_pages ? total_pages:0;
						curr_page = curr_page ? curr_page:0;
						total_rows=total_rows?total_rows:0;
						pagingObjArr[0].total_pages=total_pages;
						$(_pageId+" em[name='totalPage']").html(total_pages);
						pagingObjArr[0].curr_page=curr_page;
						$(_pageId+" em[name='curPage']").html(curr_page);
						//显示多少条数据
						$(_pageId+" em[name='total_rows']").html(total_rows);
						var allRecommendStr =  "";
						var list =  data.results[0].data;
						var len = list.length;
						for( var idx = 0; idx<len ; idx++)
						{
							var order_state=list[idx].order_state;
							var order_tot_price=list[idx].order_tot_price;
							if(order_tot_price=="" || order_tot_price==null){
								order_tot_price="0";
							}
							var order_stateLabel  = "";
							if(order_state == "1")
							{
								order_stateLabel ="待提交";
							}
							else if(order_state == "0"){
								order_stateLabel ="新订单";
							}else if(order_state == "2"){
								order_stateLabel ="提交成功";
							}
							else if(order_state == "3"){
								order_stateLabel ="提交失败";
							}
							else if(order_state == "4"){
								order_stateLabel ="成交";
							}
							else if(order_state == "5"){
								order_stateLabel ="已取消";
							}
							else  if(order_state == "6"){
								order_stateLabel ="已撤单";
							}
							else  if(order_state == "7"){
								order_stateLabel ="退款";
							}
							if(order_state =="0"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+' >取&nbsp&nbsp&nbsp消</a><a href="javascript:void(0);" class="payOrder" data-product_id='+list[idx].product_id+' data-order_id='+list[idx].order_id+' data-tot_price='+list[idx].tot_price+' data-idx='+idx+'  style="color:blue;font-size:15px">支&nbsp&nbsp&nbsp付</a></p>' +
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
							}
							if(order_state =="1"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >待提交</a></p>'+
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
							}
							if(order_state =="2"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >提交成功</a></p>' +
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
							}
							if(order_state =="3"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >提交失败</a></p>'+
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
							}
							if(order_state =="4"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >成交</a></p>' +
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
							}
							if(order_state =="5"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已取消</a></p>' +
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
							}
							if(order_state =="6"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已撤单</a></p>' +
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
							}
							if(order_state =="7"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								' <p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >退款</a></p>' +
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
							}
						}
						$(_pageId+" .product_bd_title").html('资讯产品订单总数 : '+data.results[0].totalRows+'');
						$(_pageId+" .product_cont_list").html(allRecommendStr);

						//鼠标移入改变颜色
						appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
							$(this).css("color","red");
						},"mouseenter");

						//鼠标移出改变颜色
						appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
							$(this).css("color","black");
						},"mouseleave");

						/*点击名称进入详情*/
						appUtils.bindEvent($(_pageId+" a[product-id]"),function(){
							var param=
							{
								"product_id":$(this).attr("product-id")
							};
								appUtils.pageInit("account/myOrder","mall/itemsInfoDetail",param);

						});

						/* 绑定撤销订单事件 */
						/*appUtils.bindEvent($(_pageId+" .undoOrder"),function(){
							var order_id = $(this).attr("data-order_id");
							var index = $(this).attr("data-idx");
							layerUtils.iConfirm("确定是否撤销订单",function () {
								undoOrder(order_id, index,curr_page);
							});
						});*/

						/* 绑定取消订单事件 */
						appUtils.bindEvent($(_pageId+" .cancelOrder"),function(){
							var order_id = $(this).attr("data-order_id");
							var index = $(this).attr("data-idx");
							layerUtils.iConfirm("确定是否取消订单",function () {
								cancelOrder(order_id, index,curr_page);
							});
													
						});

						/* 绑定确认订单支付事件 */
						appUtils.bindEvent($(_pageId+" .payOrder"),function(){
							var product_id = $(this).attr("data-product_id");
							var order_id = $(this).attr("data-order_id");
							var tot_price = $(this).attr("data-tot_price");
							var index = $(this).attr("data-idx");
							payOrder(product_id,order_id,tot_price,index);
												
						});

						//上一页、下一页disabled效果
						if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
							$(_pageId + " span[name='aNextPage']").removeClass("blue");
							$(_pageId + " span[name='aPrePage']").addClass("blue");
						}
						else if (pagingObjArr[0].curr_page == 1) {
							$(_pageId + " span[name='aPrePage']").removeClass("blue");
							$(_pageId + " span[name='aNextPage']").addClass("blue");
						}
						else {
							$(_pageId + " span[name='aPrePage']").addClass("blue");
							$(_pageId + " span[name='aNextPage']").addClass("blue");
						}

						if (pagingObjArr[0].total_pages<2) {
							$(_pageId + " span[name='aPrePage']").removeClass("blue");
							$(_pageId + "  span[name='aNextPage']").removeClass("blue");
						}

						if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
							$(_pageId+" #isNull").html("暂无数据");
							$(_pageId + " span[name='aPrePage']").removeClass("blue");
							$(_pageId + " span[name='aNextPage']").removeClass("blue");
						}
					}
				}else{
					layerUtils.iMsg(-1,error_info);
				}
			});
			}
			else{
					layerUtils.iMsg(-1,error_info);
				}
			});
		}
	}

	//处理上一页，下一页
	function handlePreNextPage(direction)
	{	
		var total_pages = pagingObjArr[0].total_pages;
		var   curr_page = pagingObjArr[0].curr_page;
		var   curPageNo = parseInt(curr_page) + direction ;
		var user_id =appUtils.getSStorageInfo("user_id");
		var productType =product_type;
		if(curPageNo>0 && curPageNo <= total_pages && curPageNo != curr_page) //有效执行跳转页面条件
		{
			if(productType=="0"||productType=="1"){
				var param =
				{
					"user_id":user_id,
					"page":curPageNo,
					"numPerPage":"4",
					"product_sub_type":productType,
				};
				service.queryMyOrder(param,function(data)
					{
					var error_no = data.error_no;
					var error_info = data.error_info;
					if(error_no =="0" && productType=="1")
					{
						var total_pages = data.results[0].totalPages;
						var curr_page = data.results[0].currentPage;
						var total_rows = data.results[0].totalRows;
						total_pages = total_pages ? total_pages:0;
						curr_page = curr_page ? curr_page:0;
						total_rows=total_rows?total_rows:0;
						pagingObjArr[0].total_pages=total_pages;
						$(_pageId+" em[name='totalPage']").html(total_pages);
						pagingObjArr[0].curr_page=curr_page;
						$(_pageId+" em[name='curPage']").html(curr_page);
						//显示多少条数据
						$(_pageId+" em[name='total_rows']").html(total_rows);

						var allRecommendStr =  "";
						var list =  data.results[0].data;
						var len = list.length;
						for( var idx = 0; idx<len ; idx++)
						{
							var order_state=list[idx].order_state;
							var operating_type=list[idx].operating_type;
							var order_stateLabel  = "";
							var business_type=list[idx].business_type;
							var business_typeLabel="";
							var order_quantity=list[idx].order_quantity;
							var tot_price=list[idx].tot_price;
							if(tot_price=="" || tot_price==null){
								tot_price="0";
							}
							if(order_quantity=="" || order_quantity==null){
								order_quantity="0";
							}
							if(business_type == "0"){
								business_typeLabel = "认购";
							}else if(business_type =="1"){
								business_typeLabel = "申购";
							}else if(business_type =="2"){
								business_typeLabel = "赎回";
							}
							
							if(order_state == "1")
							{
								order_stateLabel ="待提交";
							}
							else if(order_state == "0"){
								order_stateLabel ="新订单";
							}else if(order_state == "2"){
								order_stateLabel ="提交成功";
							}
							else if(order_state == "3"){
								order_stateLabel ="提交失败";
							}
							else if(order_state == "4"){
								order_stateLabel ="成交";
							}
							else if(order_state == "5"){
								order_stateLabel ="已取消";
							}
							else  if(order_state == "6"){
								order_stateLabel ="已撤单";
							}
							else  if(order_state == "7"){
								order_stateLabel ="退款";
							}
							if(operating_type =="0"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
								'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
								'<a  style="float:right"  href="javascript:;"  class="cancer"  product_id='+list[idx].product_id+' data-idx='+idx+'>--</a>' +
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
							}
							if(operating_type =="1"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
								'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
								'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+'>取消订单</a></p>' +
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
							}
							if(operating_type =="2"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
								'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
								'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="payOrder" data-product_id='+list[idx].product_id+' data-tot_price='+list[idx].tot_price+' data-idx='+idx+'  style="color:blue">支付订单</a></p>' +
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
							}
							if(operating_type =="3"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
								'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
								'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="undoOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+'>撤销订单</a></p>' +
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
							}
							if(operating_type =="4"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
								'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
								'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已执行撤单操作</a></p>' +
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
							}
							if(operating_type =="12"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
								'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
								'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+' >取&nbsp&nbsp&nbsp消</a><a href="javascript:void(0);" class="payOrder" data-product_id='+list[idx].product_id+' data-order_id='+list[idx].order_id+' data-tot_price='+list[idx].tot_price+' data-idx='+idx+'  style="color:blue;font-size:15px">支&nbsp&nbsp&nbsp付</a></p>' +
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
							}
						}
						$(_pageId+" .product_cont_list").html(allRecommendStr);

						//鼠标移入改变颜色
						appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
							$(this).css("color","red");
						},"mouseenter");

						//鼠标移出改变颜色
						appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
							$(this).css("color","black");
						},"mouseleave");

						/*点击名称进入详情*/
						appUtils.bindEvent($(_pageId+" a[product-id]"),function(){
							var param=
							{
								"product_id":$(this).attr("product-id")
							};
							appUtils.pageInit("account/myOrder","mall/itemsFinanInfo",param);
						});


						/* 绑定撤销订单事件 */
						appUtils.bindEvent($(_pageId+" .undoOrder"),function(){
							var order_id = $(this).attr("data-order_id");
							var index = $(this).attr("data-idx");
							var param=
							{
								"date":""
							}
							service.dealTimeSyn(param,function(data){
								if(data.error_no!="0")
								{
									layerUtils.iAlert(data.error_info);
									layerUtils.iLoading(false);
									return false;
								} 
								else if(data.results[0].is_trade=='0')
								{
									layerUtils.iAlert("当前是非交易时间，理财和基金产品暂停交易。");
									return false;
								}
								else{
									layerUtils.layerCustom('<div class="popbox pop_rebuy" id="iLayer_myProd">	<div class="ptitle"><h2>订单撤销</h2></div>	<div class="pmain"><p class="input_text"></p><div class="input_text">	<label>交易密码</label><div id="password"  class="t1 trade_pwd input_custom" style="color:#A9A9A9;"><em>交易密码</em></div><input style="display:none" type="password"  class="t1"  id="trade_pwd" ></div><p class="input_text"><a href="javascript:void(0);" class="btn"  id="iLayer_redeemBtn">撤单</a><a href="javascript:void(0);" class="btn2" id="iLayer_closeBtn">关闭</a></p></div></div>');
									/*	var url=global.validateimg +"?v="+Math.random();						
										$(' .code_pic').click( 
											function(){ 
												$(' .code_pic').attr('src',url); 
											}); 
										$(' .code_pic').attr('src',url);//验证码错误，刷新获得验证码

										重新获取验证码
										appUtils.bindEvent($(" .code_pic") ,function(){
											var url=global.validateimg +"?v="+Math.random();
											$(' .code_pic').click( 
												function(){ 
													$(' .code_pic').attr('src',url); 
												}); 
											$(' .code_pic').attr('src',url);//验证码错误，刷新获得验证码
										});*/
										var fund_account=appUtils.getSStorageInfo("fund_account");
										var allRecommendStr =  "";
										allRecommendStr += "<label>资金账号</label>"+fund_account;
										$(" .pop_rebuy .input_text:eq(0)").append(allRecommendStr);
										appUtils.bindEvent($x("iLayer_myProd", "iLayer_redeemBtn"), function() {
											undoOrder(order_id, index,curr_page); 
											//								layerUtils.iCustomClose();
										});
										appUtils.bindEvent($x("iLayer_myProd", "iLayer_closeBtn"), function() {
											keyPanel.closeKeyPanel();
											layerUtils.iCustomClose(); 
										});
										
										appUtils.bindEvent($(" #code"),function(e){
											$(" .input_custom").removeClass(" active");
										});

										/*初始化键盘*/
										appUtils.bindEvent($(" #password") ,function(e){
											var input_pwd = $(this);
											input_pwd.find("em").html("");  // 清空密码
											input_pwd.attr("data-password","");  // 清空密码值
											$(" .input_custom").addClass("active");
											keyPanel.init_keyPanel(function(value){
												var curEchoText = input_pwd.find("em").html();  // 密码回显文本
												var input_pass_curPwd = input_pwd.attr("data-password") || "";  // 密码值
												var valInput=$(" #iLayer_myProd #trade_pwd");
												if(value == "del")
												{
													input_pwd.find("em").html(curEchoText.slice(0, -1));
													input_pwd.attr("data-password", input_pass_curPwd.slice(0, -1));
													valInput.val(input_pwd.attr("data-password"));
												}
												else
												{
													if(input_pass_curPwd.length < 6)
													{
														input_pwd.attr("data-password", input_pass_curPwd + value);  // 设置密码值
														input_pwd.find("em").html(curEchoText + "*");
														valInput.val(input_pass_curPwd + value);
													}
													else
													{
														layerUtils.iMsg(-1, "交易密码最多 6位!");
													}
												}
											}, input_pwd);
											e.stopPropagation();
//											$(" .input_custom").addClass(" active");
//											$(" #password em").html("");
//											$(" #trade_pwd").val("");
//											var passwordInput=$(" #password em");
//											var valInput=$(" #iLayer_myProd #trade_pwd");
//											keyPanel.init_keyPanel(" #iLayer_myProd",valInput.val(),valInput,function(pw)
//												{
//												var ch="";
//												for(var i=0;i<pw.length;i++){
//													ch+="*";
//												}
//												passwordInput.html(ch);
//												valInput.val(pw);
//												valInput.text("");
//												},"num","密码");
//											e.stopPropagation();	
										});

										//点击页面关闭软键盘
										appUtils.bindEvent($(" #iLayer_myProd"),function(){
											keyPanel.closeKeyPanel();
										});
									}

							})
						
						});

						/* 绑定取消订单事件 */
						appUtils.bindEvent($(_pageId+" .cancelOrder"),function(){
							var order_id = $(this).attr("data-order_id");
							var index = $(this).attr("data-idx");
							layerUtils.iConfirm("确定是否取消订单",function () {
								cancelOrder(order_id, index,curr_page);
							});
														
						});

						/* 绑定确认订单支付事件 */
						appUtils.bindEvent($(_pageId+" .payOrder"),function(){
							var product_id = $(this).attr("data-product_id");
							var order_id = $(this).attr("data-order_id");
							var tot_price = $(this).attr("data-tot_price");
							var index = $(this).attr("data-idx");
							var param=
							{
								"date":""
							}
							service.dealTimeSyn(param,function(data){
								if(data.error_no!="0")
								{
									layerUtils.iAlert(data.error_info);
									layerUtils.iLoading(false);
									return false;
								} 
								else if(data.results[0].is_trade=='0')
								{
									layerUtils.iAlert("当前是非交易时间，理财和基金产品暂停交易。");
									return false;
								}
								else{
									payOrder(product_id,order_id,tot_price,index);
								}

							})
						
						});

						//上一页、下一页disabled效果
						if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
							$(_pageId + " span[name='aNextPage']").removeClass("blue");
							$(_pageId + " span[name='aPrePage']").addClass("blue");
						}
						else if (pagingObjArr[0].curr_page == 1) {
							$(_pageId + " span[name='aPrePage']").removeClass("blue");
							$(_pageId + " span[name='aNextPage']").addClass("blue");
						}
						else {
							$(_pageId + " span[name='aPrePage']").addClass("blue");
							$(_pageId + " span[name='aNextPage']").addClass("blue");
						}

						if (pagingObjArr[0].total_pages<2) {
							$(_pageId + " span[name='aPrePage']").removeClass("blue");
							$(_pageId + "  span[name='aNextPage']").removeClass("blue");
						}

						if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
							$(_pageId+" #isNull").html("暂无数据");
							$(_pageId + " span[name='aPrePage']").removeClass("blue");
							$(_pageId + " span[name='aNextPage']").removeClass("blue");
						}

					}
					else if(error_no =="0" && productType=="0"){
						var total_pages = data.results[0].totalPages;
						var curr_page = data.results[0].currentPage;
						var total_rows = data.results[0].totalRows;
						total_pages = total_pages ? total_pages:0;
						curr_page = curr_page ? curr_page:0;
						total_rows=total_rows?total_rows:0;
						pagingObjArr[0].total_pages=total_pages;
						$(_pageId+" em[name='totalPage']").html(total_pages);
						pagingObjArr[0].curr_page=curr_page;
						$(_pageId+" em[name='curPage']").html(curr_page);
						//显示多少条数据
						$(_pageId+" em[name='total_rows']").html(total_rows);

						var allRecommendStr =  "";
						var list =  data.results[0].data;
						var len = list.length;
						for( var idx = 0; idx<len ; idx++)
						{
							var order_state=list[idx].order_state;
							var operating_type=list[idx].operating_type;
							var order_stateLabel  = "";
							var business_type=list[idx].business_type;
							var business_typeLabel="";
							var order_quantity=list[idx].order_quantity;
							var tot_price=list[idx].tot_price;
							if(tot_price=="" || tot_price==null){
								tot_price="0";
							}
							if(order_quantity=="" || order_quantity==null){
								order_quantity="0";
							}
							if(business_type == "0"){
								business_typeLabel = "认购";
							}else if(business_type =="1"){
								business_typeLabel = "申购";
							}else if(business_type =="2"){
								business_typeLabel = "赎回";
							}
							
							if(order_state == "1")
							{
								order_stateLabel ="待提交";
							}
							else if(order_state == "0"){
								order_stateLabel ="新订单";
							}else if(order_state == "2"){
								order_stateLabel ="提交成功";
							}
							else if(order_state == "3"){
								order_stateLabel ="提交失败";
							}
							else if(order_state == "4"){
								order_stateLabel ="成交";
							}
							else if(order_state == "5"){
								order_stateLabel ="已取消";
							}
							else  if(order_state == "6"){
								order_stateLabel ="已撤单";
							}
							else  if(order_state == "7"){
								order_stateLabel ="退款";
							}
							if(operating_type =="0"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
								'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
								'<a  style="float:right"  href="javascript:;"  class="cancer"  product_id='+list[idx].product_id+' data-idx='+idx+'>--</a>' +
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
							}
							if(operating_type =="1"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
								'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
								'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+'>取消订单</a></p>' +
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
							}
							if(operating_type =="2"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
								'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
								'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="payOrder" data-product_id='+list[idx].product_id+' data-tot_price='+list[idx].tot_price+' data-idx='+idx+'  style="color:blue">支付订单</a></p>' +
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
							}
							if(operating_type =="3"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
								'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
								'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="undoOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+'>撤销订单</a></p>' +
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
							}
							if(operating_type =="4"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
								'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
								'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已执行撤单操作</a></p>' +
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
							}
							if(operating_type =="12"){
								allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
								'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
								'<span><strong>购买金额：</strong>'+parseFloat(tot_price).toFixed(2)+' 元</span> ' +
								'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
								' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
								'<span><strong>订单份额：</strong>'+order_quantity+' 份</span>' +
								'<span><strong>业务类型：</strong>'+business_typeLabel+' </span>' +
								'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+' >取&nbsp&nbsp&nbsp消</a><a href="javascript:void(0);" class="payOrder" data-product_id='+list[idx].product_id+' data-order_id='+list[idx].order_id+' data-tot_price='+list[idx].tot_price+' data-idx='+idx+'  style="color:blue;font-size:15px">支&nbsp&nbsp&nbsp付</a></p>' +
								'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
							}
						}
						$(_pageId+" .product_cont_list").html(allRecommendStr);

						//鼠标移入改变颜色
						appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
							$(this).css("color","red");
						},"mouseenter");

						//鼠标移出改变颜色
						appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
							$(this).css("color","black");
						},"mouseleave");

						/*点击名称进入详情*/
						appUtils.bindEvent($(_pageId+" a[product-id]"),function(){
							var param=
							{
								"product_id":$(this).attr("product-id")
							};
							appUtils.pageInit("account/myOrder","mall/itemsFundInfo",param);
						});


						/* 绑定撤销订单事件 */
						appUtils.bindEvent($(_pageId+" .undoOrder"),function(){
							var order_id = $(this).attr("data-order_id");
							var index = $(this).attr("data-idx");
							var param=
							{
								"date":""
							}
							service.dealTimeSyn(param,function(data){
								if(data.error_no!="0")
								{
									layerUtils.iAlert(data.error_info);
									layerUtils.iLoading(false);
									return false;
								} 
								else if(data.results[0].is_trade=='0')
								{
									layerUtils.iAlert("当前是非交易时间，理财和基金产品暂停交易。");
									return false;
								}
								else{
									layerUtils.layerCustom('<div class="popbox pop_rebuy" id="iLayer_myProd">	<div class="ptitle"><h2>订单撤销</h2></div>	<div class="pmain"><p class="input_text"></p><div class="input_text">	<label>交易密码</label><div id="password"  class="t1 trade_pwd input_custom" style="color:#A9A9A9;"><em>交易密码</em></div><input style="display:none" type="password"  class="t1"  id="trade_pwd" ></div><p class="input_text"><a href="javascript:void(0);" class="btn"  id="iLayer_redeemBtn">撤单</a><a href="javascript:void(0);" class="btn2" id="iLayer_closeBtn">关闭</a></p></div></div>');
									/*	var url=global.validateimg +"?v="+Math.random();						
										$(' .code_pic').click( 
											function(){ 
												$(' .code_pic').attr('src',url); 
											}); 
										$(' .code_pic').attr('src',url);//验证码错误，刷新获得验证码

										重新获取验证码
										appUtils.bindEvent($(" .code_pic") ,function(){
											var url=global.validateimg +"?v="+Math.random();
											$(' .code_pic').click( 
												function(){ 
													$(' .code_pic').attr('src',url); 
												}); 
											$(' .code_pic').attr('src',url);//验证码错误，刷新获得验证码
										});*/
										var fund_account=appUtils.getSStorageInfo("fund_account");
										var allRecommendStr =  "";
										allRecommendStr += "<label>资金账号</label>"+fund_account;
										$(" .pop_rebuy .input_text:eq(0)").append(allRecommendStr);
										appUtils.bindEvent($x("iLayer_myProd", "iLayer_redeemBtn"), function() {
											undoOrder(order_id, index,curr_page); 
											//								layerUtils.iCustomClose();
										});
										appUtils.bindEvent($x("iLayer_myProd", "iLayer_closeBtn"), function() {
											keyPanel.closeKeyPanel();
											layerUtils.iCustomClose(); 
										});
										
										appUtils.bindEvent($(" #code"),function(e){
											$(" .input_custom").removeClass(" active");
										});

										/*初始化键盘*/
										appUtils.bindEvent($(" #password") ,function(e){
											var input_pwd = $(this);
											input_pwd.find("em").html("");  // 清空密码
											input_pwd.attr("data-password","");  // 清空密码值
											$(" .input_custom").addClass("active");
											keyPanel.init_keyPanel(function(value){
												var curEchoText = input_pwd.find("em").html();  // 密码回显文本
												var input_pass_curPwd = input_pwd.attr("data-password") || "";  // 密码值
												var valInput=$(" #iLayer_myProd #trade_pwd");
												if(value == "del")
												{
													input_pwd.find("em").html(curEchoText.slice(0, -1));
													input_pwd.attr("data-password", input_pass_curPwd.slice(0, -1));
													valInput.val(input_pwd.attr("data-password"));
												}
												else
												{
													if(input_pass_curPwd.length < 6)
													{
														input_pwd.attr("data-password", input_pass_curPwd + value);  // 设置密码值
														input_pwd.find("em").html(curEchoText + "*");
														valInput.val(input_pass_curPwd + value);
													}
													else
													{
														layerUtils.iMsg(-1, "交易密码最多 6位!");
													}
												}
											}, input_pwd);
											e.stopPropagation();
//											$(" .input_custom").addClass(" active");
//											$(" #password em").html("");
//											$(" #trade_pwd").val("");
//											var passwordInput=$(" #password em");
//											var valInput=$(" #iLayer_myProd #trade_pwd");
//											keyPanel.init_keyPanel(" #iLayer_myProd",valInput.val(),valInput,function(pw)
//												{
//												var ch="";
//												for(var i=0;i<pw.length;i++){
//													ch+="*";
//												}
//												passwordInput.html(ch);
//												valInput.val(pw);
//												valInput.text("");
//												},"num","密码");
//											e.stopPropagation();	
										});

										//点击页面关闭软键盘
										appUtils.bindEvent($(" #iLayer_myProd"),function(){
											keyPanel.closeKeyPanel();
										});
									}

							})
						
						});

						/* 绑定取消订单事件 */
						appUtils.bindEvent($(_pageId+" .cancelOrder"),function(){
							var order_id = $(this).attr("data-order_id");
							var index = $(this).attr("data-idx");
							layerUtils.iConfirm("确定是否取消订单",function () {
								cancelOrder(order_id, index,curr_page);
							});
														
						});

						/* 绑定确认订单支付事件 */
						appUtils.bindEvent($(_pageId+" .payOrder"),function(){
							var product_id = $(this).attr("data-product_id");
							var order_id = $(this).attr("data-order_id");
							var tot_price = $(this).attr("data-tot_price");
							var index = $(this).attr("data-idx");
							var param=
							{
								"date":""
							}
							service.dealTimeSyn(param,function(data){
								if(data.error_no!="0")
								{
									layerUtils.iAlert(data.error_info);
									layerUtils.iLoading(false);
									return false;
								} 
								else if(data.results[0].is_trade=='0')
								{
									layerUtils.iAlert("当前是非交易时间，理财和基金产品暂停交易。");
									return false;
								}
								else{
									payOrder(product_id,order_id,tot_price,index);
								}

							})
						
						});

						//上一页、下一页disabled效果
						if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
							$(_pageId + " span[name='aNextPage']").removeClass("blue");
							$(_pageId + " span[name='aPrePage']").addClass("blue");
						}
						else if (pagingObjArr[0].curr_page == 1) {
							$(_pageId + " span[name='aPrePage']").removeClass("blue");
							$(_pageId + " span[name='aNextPage']").addClass("blue");
						}
						else {
							$(_pageId + " span[name='aPrePage']").addClass("blue");
							$(_pageId + " span[name='aNextPage']").addClass("blue");
						}

						if (pagingObjArr[0].total_pages<2) {
							$(_pageId + " span[name='aPrePage']").removeClass("blue");
							$(_pageId + "  span[name='aNextPage']").removeClass("blue");
						}

						if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
							$(_pageId+" #isNull").html("暂无数据");
							$(_pageId + " span[name='aPrePage']").removeClass("blue");
							$(_pageId + " span[name='aNextPage']").removeClass("blue");
						}
					}else{
						layerUtils.iMsg(-1,error_info);
					}
					});
			}else if(productType=="3"||productType=="2"){
				var param =
				{
					"user_id" : user_id,
					"product_sub_type" : productType,
					"page" :curPageNo,
					"numPerPage" :"4",
				};

				service.queryUserOrder(param,function(data){
					var error_no = data.error_no;
					var error_info = data.error_info;
					var result=data.results[0].data;
				    if(error_no =="0" && productType=="3"){
				    	var total_pages = data.results[0].totalPages;
						var curr_page = data.results[0].currentPage;
						var total_rows = data.results[0].totalRows;
							total_pages = total_pages ? total_pages:0;
							curr_page = curr_page ? curr_page:0;
							total_rows=total_rows?total_rows:0;
							pagingObjArr[0].total_pages=total_pages;
							$(_pageId+" em[name='totalPage']").html(total_pages);
							pagingObjArr[0].curr_page=curr_page;
							$(_pageId+" em[name='curPage']").html(curr_page);
							//显示多少条数据
							$(_pageId+" em[name='total_rows']").html(total_rows);
							var allRecommendStr =  "";
							var list =  data.results[0].data;
							var len = list.length;
							for( var idx = 0; idx<len ; idx++)
							{
								var order_state=list[idx].order_state;
								var order_tot_price=list[idx].order_tot_price;
								if(order_tot_price=="" || order_tot_price==null){
									order_tot_price="0";
								}
								var order_stateLabel  = "";
								if(order_state == "1")
								{
									order_stateLabel ="待提交";
								}
								else if(order_state == "0"){
									order_stateLabel ="新订单";
								}else if(order_state == "2"){
									order_stateLabel ="提交成功";
								}
								else if(order_state == "3"){
									order_stateLabel ="提交失败";
								}
								else if(order_state == "4"){
									order_stateLabel ="成交";
								}
								else if(order_state == "5"){
									order_stateLabel ="已取消";
								}
								else  if(order_state == "6"){
									order_stateLabel ="已撤单";
								}
								else  if(order_state == "7"){
									order_stateLabel ="退款";
								}
								if(order_state =="0"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+' >取&nbsp&nbsp&nbsp消</a><a href="javascript:void(0);" class="payOrder" data-product_id='+list[idx].product_id+' data-order_id='+list[idx].order_id+' data-tot_price='+list[idx].tot_price+' data-idx='+idx+'  style="color:blue;font-size:15px">支&nbsp&nbsp&nbsp付</a></p>' +
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
								}
								if(order_state =="1"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >待提交</a></p>'+
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
								}
								if(order_state =="2"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >提交成功</a></p>' +
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
								}
								if(order_state =="3"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >提交失败</a></p>'+
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
								}
								if(order_state =="4"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >成交</a></p>' +
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
								}
								if(order_state =="5"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已取消</a></p>' +
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
								}
								if(order_state =="6"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已撤单</a></p>' +
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
								}
								if(order_state =="7"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									' <p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >退款</a></p>' +
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
								}
							}
							$(_pageId+" .product_bd_title").html('资讯产品订单总数 : '+data.results[0].totalRows+'');
							$(_pageId+" .product_cont_list").html(allRecommendStr);

							//鼠标移入改变颜色
							appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
								$(this).css("color","red");
							},"mouseenter");

							//鼠标移出改变颜色
							appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
								$(this).css("color","black");
							},"mouseleave");

							/*点击名称进入详情*/
							appUtils.bindEvent($(_pageId+" a[product-id]"),function(){
								var param=
								{
									"product_id":$(this).attr("product-id")
								};
									appUtils.pageInit("account/myOrder","mall/itemsInfoDetail",param);

							});

							/* 绑定撤销订单事件 */
							/*appUtils.bindEvent($(_pageId+" .undoOrder"),function(){
								var order_id = $(this).attr("data-order_id");
								var index = $(this).attr("data-idx");
								layerUtils.iConfirm("确定是否撤销订单",function () {
									undoOrder(order_id, index,curr_page);
								});
							});*/

							/* 绑定取消订单事件 */
							appUtils.bindEvent($(_pageId+" .cancelOrder"),function(){
								var order_id = $(this).attr("data-order_id");
								var index = $(this).attr("data-idx");
								layerUtils.iConfirm("确定是否取消订单",function () {
									cancelOrder(order_id, index,curr_page);
								});
															
							});

							/* 绑定确认订单支付事件 */
							appUtils.bindEvent($(_pageId+" .payOrder"),function(){
								var product_id = $(this).attr("data-product_id");
								var order_id = $(this).attr("data-order_id");
								var tot_price = $(this).attr("data-tot_price");
								var index = $(this).attr("data-idx");
								payOrder(product_id,order_id,tot_price,index);
														
							});

							//上一页、下一页disabled效果
							if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
								$(_pageId + " span[name='aNextPage']").removeClass("blue");
								$(_pageId + " span[name='aPrePage']").addClass("blue");
							}
							else if (pagingObjArr[0].curr_page == 1) {
								$(_pageId + " span[name='aPrePage']").removeClass("blue");
								$(_pageId + " span[name='aNextPage']").addClass("blue");
							}
							else {
								$(_pageId + " span[name='aPrePage']").addClass("blue");
								$(_pageId + " span[name='aNextPage']").addClass("blue");
							}

							if (pagingObjArr[0].total_pages<2) {
								$(_pageId + " span[name='aPrePage']").removeClass("blue");
								$(_pageId + "  span[name='aNextPage']").removeClass("blue");
							}

							if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
								$(_pageId+" #isNull").html("暂无数据");
								$(_pageId + " span[name='aPrePage']").removeClass("blue");
								$(_pageId + " span[name='aNextPage']").removeClass("blue");
							}
					}
					else if(error_no =="0" && productType=="2"){
						var total_pages = data.results[0].totalPages;
						var curr_page = data.results[0].currentPage;
						var total_rows = data.results[0].totalRows;
							total_pages = total_pages ? total_pages:0;
							curr_page = curr_page ? curr_page:0;
							total_rows=total_rows?total_rows:0;
							pagingObjArr[0].total_pages=total_pages;
							$(_pageId+" em[name='totalPage']").html(total_pages);
							pagingObjArr[0].curr_page=curr_page;
							$(_pageId+" em[name='curPage']").html(curr_page);
							//显示多少条数据
							$(_pageId+" em[name='total_rows']").html(total_rows);
							var allRecommendStr =  "";
							var list =  data.results[0].data;
							var len = list.length;
							for( var idx = 0; idx<len ; idx++)
							{
								var order_state=list[idx].order_state;
								var order_tot_price=list[idx].order_tot_price;
								if(order_tot_price=="" || order_tot_price==null){
									order_tot_price="0";
								}
								var order_stateLabel  = "";
								if(order_state == "1")
								{
									order_stateLabel ="待提交";
								}
								else if(order_state == "0"){
									order_stateLabel ="新订单";
								}else if(order_state == "2"){
									order_stateLabel ="提交成功";
								}
								else if(order_state == "3"){
									order_stateLabel ="提交失败";
								}
								else if(order_state == "4"){
									order_stateLabel ="成交";
								}
								else if(order_state == "5"){
									order_stateLabel ="已取消";
								}
								else  if(order_state == "6"){
									order_stateLabel ="已撤单";
								}
								else  if(order_state == "7"){
									order_stateLabel ="退款";
								}
								if(order_state =="0"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<p class=\"product_btn_box\"><a  style="color:blue; font-size:15px"  href="javascript:void(0);" class="cancelOrder" data-order_id='+list[idx].order_id+' data-idx='+idx+' >取&nbsp&nbsp&nbsp消</a><a href="javascript:void(0);" class="payOrder" data-product_id='+list[idx].product_id+' data-order_id='+list[idx].order_id+' data-tot_price='+list[idx].tot_price+' data-idx='+idx+'  style="color:blue;font-size:15px">支&nbsp&nbsp&nbsp付</a></p>' +
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
								}
								if(order_state =="1"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >待提交</a></p>'+
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
								}
								if(order_state =="2"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >提交成功</a></p>' +
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
								}
								if(order_state =="3"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >提交失败</a></p>'+
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
								}
								if(order_state =="4"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >成交</a></p>' +
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
								}
								if(order_state =="5"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已取消</a></p>' +
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
								}
								if(order_state =="6"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									'<p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >已撤单</a></p>' +
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ;
								}
								if(order_state =="7"){
									allRecommendStr+=' <li class=\"orderlist\" data-idx='+idx+'><span><strong>产品名称：</strong><a href="javascript:;"  product-id='+list[idx].product_id+'><font color="0000FF"><font color="0000FF">'+list[idx].product_name+'</font></font></a></span> ' +
									'<span><strong>订单编号：</strong>'+list[idx].order_id+' </span> ' +
									'<span><strong>购买金额：</strong>'+parseFloat(order_tot_price).toFixed(2)+' 元</span> ' +
									'<span><strong>订单状态：</strong>'+order_stateLabel+' </span>' +
									' <span style="width:300px"><strong>购买日期：</strong>'+list[idx].create_time+'</span> ' +
									' <p class=\"product_btn_box\"><a  style="font-size:15px; color:gray"  href="javascript:void(0);" >退款</a></p>' +
									'<p class="product_btn_box2" style="border-top:0px" style="height:120px"> </p> </li>'  ; 
								}
							}
							$(_pageId+" .product_bd_title").html('服务产品总数 : '+data.results[0].totalRows+'');
							$(_pageId+" .product_cont_list").html(allRecommendStr);

							//鼠标移入改变颜色
							appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
								$(this).css("color","red");
							},"mouseenter");

							//鼠标移出改变颜色
							appUtils.bindEvent($(_pageId+" a[product-id]"), function(){
								$(this).css("color","black");
							},"mouseleave");

							/*点击名称进入详情*/
							appUtils.bindEvent($(_pageId+" a[product-id]"),function(){
								var param=
								{
									"product_id":$(this).attr("product-id")
								};
								     appUtils.pageInit("account/myOrder","mall/itemsServInfo",param);

							});

							/* 绑定撤销订单事件 */
							/*appUtils.bindEvent($(_pageId+" .undoOrder"),function(){
								var order_id = $(this).attr("data-order_id");
								var index = $(this).attr("data-idx");
								layerUtils.iConfirm("确定是否撤销订单",function () {
									undoOrder(order_id, index,curr_page);
								});
							});*/

							/* 绑定取消订单事件 */
							appUtils.bindEvent($(_pageId+" .cancelOrder"),function(){
								var order_id = $(this).attr("data-order_id");
								var index = $(this).attr("data-idx");
								layerUtils.iConfirm("确定是否取消订单",function () {
									cancelOrder(order_id, index,curr_page);
								});
															
							});

							/* 绑定确认订单支付事件 */
							appUtils.bindEvent($(_pageId+" .payOrder"),function(){
								var product_id = $(this).attr("data-product_id");
								var order_id = $(this).attr("data-order_id");
								var tot_price = $(this).attr("data-tot_price");
								var index = $(this).attr("data-idx");
								payOrder(product_id,order_id,tot_price,index);							
							});

							//上一页、下一页disabled效果
							if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
								$(_pageId + " span[name='aNextPage']").removeClass("blue");
								$(_pageId + " span[name='aPrePage']").addClass("blue");
							}
							else if (pagingObjArr[0].curr_page == 1) {
								$(_pageId + " span[name='aPrePage']").removeClass("blue");
								$(_pageId + " span[name='aNextPage']").addClass("blue");
							}
							else {
								$(_pageId + " span[name='aPrePage']").addClass("blue");
								$(_pageId + " span[name='aNextPage']").addClass("blue");
							}

							if (pagingObjArr[0].total_pages<2) {
								$(_pageId + " span[name='aPrePage']").removeClass("blue");
								$(_pageId + "  span[name='aNextPage']").removeClass("blue");
							}

							if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
								$(_pageId+" #isNull").html("暂无数据");
								$(_pageId + " span[name='aPrePage']").removeClass("blue");
								$(_pageId + " span[name='aNextPage']").removeClass("blue");
							}
					}else{
						layerUtils.iMsg(-1,error_info);
					}
				});
			}
		}
	}

	//清理页面元素
	function clearPageElements(){
		$(_pageId+" .ce_table").html( '<table width="100%" border="1" cellspacing="0" cellpadding="0" class="ce_table">'+
			' <tr> <th scope="col">订单名称</th>   <th scope="col">购买金额</th> <th scope="col">购买日期</th>'+
		' <th scope="col">状态</th>    <th scope="col">操作</th>  </tr>  </table>  </div>');
	}


	function destroy()
	{
		keyPanel.closeKeyPanel();
		service.destroy();
	}

	var myOrder = 
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = myOrder;

});
/**
 * 理财--确认订单
 */
define(function(require, exports, module)
	{	
	var service = require("mobileService");//业务层接口，请求数据
	var appUtils = require('appUtils'),
	putils = require("putils"),
	layerUtils = require("layerUtils"),
	nativePluginService = require("nativePluginService"),
	constants=require("constants");//常量类
	var gconfig = require("gconfig");
    var global = gconfig.global;
    platform=gconfig.platform;
	var save_value= null;
	var save_Agreement=null;
	var _pageId ="#mall_finanOrder_confirmOrder ";
	var risk_level=null;//保存产品风险等级
	var product_code="";
	var fund_result=null; 
	var buy_limit = 0 ;  //限购起点
	var URL=global.url;
	var readProtocolArr = [];
	var contract_not = [];
	var readProtocolLen = 0;
	var tzpz_code="";
	var tzqx_code="";
	var tran_type = ""; // 交易类别
	var product_status = ""; // 产品状态
	var pro_code="";//协议编号
	var entrust_way="";//委托方式
	var com_sign="";//强制签署
	var risk_uncover="";//风险揭露
	var flagPersonOrOrgan=true;//判断本产品是否匹配购买类型,个人或机构
	var paramConfirmOrder = null;
	var pro_risk_level="";//产品风测等级
	var product_id="";//产品ID
	var product_name = "";
	var tot_price = "";
	var product_code = "";
	
	//1、初始化
	function init() 
	{	
		//检测登录
		//checkLogin();
		initGlobalParam();
		$(_pageId+" #signProtocol").removeAttr("checked");
		paramConfirmOrder = JSON.parse(appUtils.getSStorageInfo("paramConfirmOrder"));
		appUtils.clearSStorage("paramConfirmOrder");
		var pageInParam  = appUtils.getPageParam();
		pro_risk_level=pageInParam.pro_risk_level;
		if(pageInParam != null && pageInParam != ""){
	    	if(pageInParam.param&&pageInParam.param!=""){
	    	  	var param = JSON.parse(pageInParam.param);
	    	  		product_name= param.product_name;
	    	  		product_id=param.product_id;
	    	  		tot_price=param.tot_price;
	    	  		product_code=param.product_code;
			    	// 当为字符格式时候 添加参数为json格式
			    	pageInParam.product_name = product_name;
			    	pageInParam.product_id = product_id;
			    	pageInParam.tot_price = tot_price;
			    	pageInParam.product_code = product_code;
			    	pageInParam.tzqx_code = param.tzqx_code;
			    	pageInParam.tzpz_code = param.tzpz_code;
			    	pageInParam.risk_level = param.risk_level;
			    	pageInParam.pro_risk_level = param.pro_risk_level;

			}else{
						product_name= pageInParam.product_name;
            			product_id=pageInParam.product_id;
            			tot_price=pageInParam.tot_price;
            			product_code=pageInParam.product_code;
			}
		}else if(paramConfirmOrder != null && paramConfirmOrder != ""){
			product_name= paramConfirmOrder.product_name;
			product_id=paramConfirmOrder.product_id;
			tot_price=paramConfirmOrder.tot_price;
			product_code=paramConfirmOrder.product_code;
		}else{
			layerUtils.iAlert("未获取到相应的产品信息!");
			return;
		}
		
		configuration=gconfig.global;
		
		if(pageInParam != null && pageInParam != ""){
			risk_level = appUtils.getPageParam("risk_level");
			tzpz_code = appUtils.getPageParam("tzpz_code");
			tzqx_code = appUtils.getPageParam("tzqx_code");
		}else if(paramConfirmOrder != null && paramConfirmOrder != ""){
			risk_level= paramConfirmOrder.risk_level;
			tzpz_code=paramConfirmOrder.tzpz_code;
			tzqx_code=paramConfirmOrder.tzqx_code;
		}
		
		
		//防止直接到该页面
		if(product_id==null)
		{
			layerUtils.iMsg(1, "数据加载错误！");
			appUtils.pageInit("mall/finanOrder/confirmOrder","account/mainPage",{})
			return false;
		}
		$(_pageId+" .cart_part h5" ).html(product_name+"("+product_code+")");
		$(_pageId+" #buyValue").val(tot_price);
		$(_pageId+" #zj").html(tot_price);
		
		
		//查询理财单个信息
		findByid();
		isFirstBuy();

	}
	
	/**
	 * 初始化全局变量
	 */
	function initGlobalParam(){
		var len = readProtocolArr.length;
		for(var i=0; i<len; i++){
			readProtocolArr[i] = false;
		}
		readProtocolLen = 0;
		readProtocolArr = [];
		contract_not = [];
	}


	//查询理财单个信息
	function findByid()
	{
		
		// var pageInParam  = appUtils.getPageParam();
		// if(pageInParam != null && pageInParam != ""){
			// product_id=pageInParam.product_id;
		// }else if(paramConfirmOrder != null && paramConfirmOrder != ""){
			// product_id= paramConfirmOrder.product_id;
		// }

		var param  =
		{
			"product_id":product_id,
			"product_sub_type":"1"
		}
		service.finanInfo(param,function(data)
			{
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
			var perData=data.results;
			product_code =perData[0].product_code;//产品编号
			save_value=perData[0];
			risk_level=perData[0].risk_level;					//产品风险等级
			var user_risk_level=appUtils.getSStorageInfo("risk_level");//用户风险等级
			var current_price=perData[0].current_price;//预期收益
			product_status=perData[0].product_status;//产品状态
			var per_buy_limit=perData[0].per_buy_limit;//首次购买 金额
			var person_pace=perData[0].person_pace;    //追加购买金额
			var buy_pace=perData[0].buy_add_pace;      //追加金额
			if(person_pace==0||person_pace==null)
			{
				$(_pageId+" #buy_pace").html(1); 
			}
			else
			{
				$(_pageId+" #buy_pace").html(person_pace); 
			}
			$(_pageId+" .pro_thumb").html("<img src="+URL+perData[0].img_url_l+">");//图片
//			$(_pageId+" #add_pace").html(person_pace); 
			$(_pageId+" #yqsy" ).html(current_price); 
			$(_pageId+" #frist").html(per_buy_limit); 
			//判断协议
			findAgreement(product_code);//500011展示协议
		},{"isLastReq" : false});
	}

	//判断是否是首次购买
	function isFirstBuy(){
		// var product_id = "";
		// var pageInParam  = appUtils.getPageParam();
		// if(pageInParam != null && pageInParam != ""){
			// product_id=pageInParam.product_id;
		// }else if(paramConfirmOrder != null && paramConfirmOrder != ""){
			// product_id= paramConfirmOrder.product_id;
		// }
		
		
		var fund_account=appUtils.getSStorageInfo("fund_account");
		var param=
		{
			"product_id":product_id,
			"fund_account":fund_account
		}
		service.isFirstBuyFund(param,function(data){
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
			var perData=data.results;
			var fristBuy= $(_pageId+" #frist").text();       //首次
//			var appendBuy=$(_pageId+" #append").text(); 	 //追加
			var buy_pace= $(_pageId+" #buy_pace").text();    //步长
			result=perData[0].result;
			fund_result=perData[0].result;//保存结果

			if(constants.first_buy.YES==perData[0].result)//追加购买
			{
				$(_pageId+" #frisrt").addClass("ared");
				buy_limit=fristBuy;

			}
			else //首次购买
			{
				$(_pageId+" #frisrt").addClass("ared");
				buy_limit=fristBuy;
			}
		}, {"isLastReq" : false});
	}




	//购买金额的加减
	function  addAndMin (par)
	{
		var person_pace=1;//步长
		if(buy_pace==""||buy_pace=="0"){
			buy_pace=1;
		}

		//追加购买
		if(fund_result==constants.first_buy.YES)
		{
			var append= $(_pageId+" #buyValue").val();
			var limi=  $(_pageId+" #frist").html();

			//点击+
			if(par=="add")
			{
				var sum= parseFloat(append)+parseFloat(person_pace);
				$(_pageId+" #buyValue").val((sum.toFixed(2)));
				$(_pageId+" #zj").html($(_pageId+" #buyValue").val());
			}

			//点击-
			else if(par=="min")
			{

				if(parseFloat(append)<=parseFloat(limi))
				{
					layerUtils.iMsg(-1,"购买的金额不能低于"+limi);
					return false;
				}

				var minc= parseFloat(append)-parseFloat(person_pace);

				$(_pageId+" #buyValue").val(minc.toFixed(2));
				$(_pageId+" #zj").html($(_pageId+" #buyValue").val());

			}

		}


		//首次购买
		else
		{
			var frist= $(_pageId+" #buyValue").val();
			var limi=  $(_pageId+" #frist").html();

			//点击+
			if(par=="add")
			{
				var sum= parseFloat(frist)+parseFloat(person_pace);
				$(_pageId+" #buyValue").val((sum.toFixed(2)));
				$(_pageId+" #zj").html($(_pageId+" #buyValue").val());

			}

			//点击-
			else if(par=="min")
			{

				if(parseFloat(frist)<=parseFloat(limi))
				{
					layerUtils.iMsg(-1,"购买的金额不能低于"+limi);
					$(_pageId+" #buyValue").val(parseFloat($(_pageId+" #frist").html()).toFixed(2));
					$(_pageId+" #zj").html(parseFloat($(_pageId+" #frist").html()).toFixed(2));
					return false;
				}
				var minc= parseFloat(frist)-parseFloat(person_pace);
				$ (_pageId+" #buyValue").val(minc.toFixed(2));
				$(_pageId+" #zj").html($(_pageId+" #buyValue").val());

			}
		}
	}
	// 判断是否签署的电子签名约定书（500004）
	function querySingedAgreement(pro_code, agreementId, fileName, agreementName)
	{	
		var pageInParam  = appUtils.getPageParam();
		
		if(pageInParam == null || pageInParam == ""){
			pageInParam = paramConfirmOrder;
		}
		
		var user_id = appUtils.getSStorageInfo("user_id");
		// var product_id=pageInParam.product_id;
		var isOnlineSign = true ; // 是否支持网上开通电子签名协议
//		var flag = true ;		  // 签署协议标识，true 为已签署
		var showDataList =[];
		var _agreement_id ;
		var _agreement_title ;
		var results=null; //保存结果集
		var tran_type = ""; // 交易类别
		var cust_code = appUtils.getSStorageInfo("cust_code");
		var ticket = appUtils.getSStorageInfo("ticket");
		
		var param =
		{
			"cust_code":cust_code,
			"pro_type":"2", // 电子签名书
			"pro_code":pro_code,
			"ticket":ticket,
			"entrust_way":entrust_way
				
		};
		service.querySingedAgreement(param,function(data){
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
//			if(true){             //调试用之后去掉
				if(data!=null){
				var perData=data.results;
				if(perData.length > 0){
					var over_date=perData[0].over_date;
					// 判断是否过期
					if(over_date!="0"){ 
//					if(false){ 				//调试用
						layerUtils.iLoading(false);
						showElcBookWindow(pro_code, agreementId, fileName, agreementName);
					}else{
						 // 已签署且未过期
						$(_pageId + "#eclBookDiv").hide();
						newRiskResult(); // 500003风险测评	
					}
				}else{
					layerUtils.iLoading(false);
					// 未签，弹电子签名约定书
					showElcBookWindow(pro_code, agreementId, fileName, agreementName);
				}
				
			}else{
				layerUtils.iLoading(false);
				// 未签，弹电子签名约定书
				showElcBookWindow(pro_code, agreementId, fileName, agreementName);
				
			}
			
		},{"isLastReq" : false});
	
	}
	
	/**
	 * 弹出签署电子签名约定书提示窗口
	 */
	function showElcBookWindow(pro_code, agreementId, fileName, agreementName){
		$(_pageId + "#eclBookDiv").show().find("#elcBookName").html("《" + agreementName + "》");
		
		// 点击签署协议
		appUtils.bindEvent(_pageId + "#sureBtn", function(){
			$(_pageId + "#eclBookDiv").hide();
			signAgreement(pro_code);
		});
		
		// 取消返回上一个页面
		appUtils.bindEvent(_pageId + "#cancelBtn", function(){
			appUtils.pageBack();
		});
		
		// 点击查看协议内容
		appUtils.bindEvent($(_pageId + "#elcBookName"),function(){
			// 调用查询协议内容500009
			var reqParam = {
				"pro_content" : agreementId,
				"pro_code" : pro_code,
				"file_name" : fileName,
				"entrust_way" : entrust_way
			};
			service.agreementContent(reqParam,function(data){
				if(data.error_no!="0")
				{
					layerUtils.iAlert(data.error_info);
					layerUtils.iLoading(false);
					return false;
				}
				var perData=data.results;
				if(perData){
					var pdf_url = perData[0].pdf_url; // 协议地址
					url=pdf_url;//
					var param = {
						"url" : pdf_url
					}
					lookContract(param);
					return false;
				}
			});
		});
	}
	
	
	/**
	 * 查看协议(文本，pdf)
	 * 1、查看存在文件路径的协议时，调用原生接口，如pdf协议。
	 * 2、查看不存在文件路径且指定了目标页面的协议时，跳转到指定页面并把相关协议内容在参数中传递过去。
	 */
function lookContract(param, targetPage){
	var _curPageCode = appUtils.getSStorageInfo("_curPageCode"); //当前页 pageCode
	if(param.url == ""){
		var pageInParam = {
			"data" : param.result
		};
		if (targetPage) {
			appUtils.pageInit(_curPageCode, targetPage, pageInParam);
		}
	}else{
		var path = gconfig.global.url + "/" + param.url;
		var invokeParam = {
			"funcNo" : "50240",
			"url" : path
	    };
		var result = nativePluginService.function50240(invokeParam);
	}
}

	//产品所属协议查询展示(1有 0没有)(500011)
	function  findAgreement(product_code)
	{
		var pageInParam  = appUtils.getPageParam();
		if(pageInParam == null || pageInParam == ""){
			pageInParam = paramConfirmOrder;
		}
		var user_id = appUtils.getSStorageInfo("user_id");
		// var product_id=pageInParam.product_id;
		var isOnlineSign = true ; // 是否支持网上开通电子签名协议
		var flag = true ;		  // 签署协议标识，true 为已签署
		var showDataList =[];
		var _agreement_id;
		var _agreement_title;
		var results=null; //保存结果集
		
		
		if (product_status && product_status == '0' || product_status == '1' || product_status == '6') {
			if (product_status == '0' || product_status == '6') {
				tran_type = "111";
			}else{
				tran_type = "110";
			}
		}else{
			layerUtils.iMsg(-1,"产品状态不正常");
			layerUtils.iLoading(false);
			return false;
		}
		
		var param =
		{
			//"user_id":user_id,
			//"product_id":product_id
			"tran_type" : tran_type,
			"inst_id" : product_code,
			"cust_code" : appUtils.getSStorageInfo("cust_code"),
			"ticket" : appUtils.getSStorageInfo("ticket"),
			"entrust_way" : entrust_way
		};

		service.showSign(param,function(data) {
			if(data.error_no != "0") 
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}

			results= data.results,
			allProtocolStr = ""; // 所有协议字符串
			var flag = false;
			if (results.length > 0) {
				for (var i = 0; i < results.length; i++) {
					var item  = results[i];
					var pro_code = item.pro_code; // 协议编号
					if (item.pro_type != "2"){ // 电子签名约定书不展示
						readProtocolArr[readProtocolLen] = false;
						readProtocolLen++;
						allProtocolStr += '<li id="agreement_id"><a file_name="'+item.file_name+'" pro_code="'+pro_code+'" href="javascript:void(0);" agreement_id='+item.file_id+  ' pro_code='+item.pro_code+'>'+item.pro_title+'</a></li>';
						$(_pageId+" #agreement").html(allProtocolStr);
					}else if(item.pro_type == "2"){
						flag = true;
						querySingedAgreement(pro_code, item.file_id, item.file_name, item.pro_title);//2电子签名约定书，去500004判断是否签署
					}
				}
				$(_pageId+" #ifSignProt").html(allProtocolStr);
				//绑定协议事件
				appUtils.bindEvent($(_pageId + " #agreement_id a"),function(){
					var idx = $(_pageId + "#agreement_id a").index($(this));
					readProtocolArr[idx] = true;
					
				    var allReadFlag = true;
					var allReadFlag = false;
					for(var i=0, len = readProtocolArr.length; i<len; i++){
						var flag = readProtocolArr[i];
						if(flag == true){
							allReadFlag = true;
						} else {
							allReadFlag = false;
							break;
						}
					}
					if (allReadFlag) {
						$(_pageId + " #signProtocol").attr("checked", "checked");
					}
					
					var perData=data.results;
					var pro_content = $(this).attr("agreement_id"); // 协议ID
					pro_code = $(this).attr("pro_code"); // 协议编号					
					var pro_title= $(this).attr("file_name"); // 协议名称	
					// 调用查询协议内容500009
					var reqParam = {
						"pro_content" : pro_content,
						"pro_code" : pro_code,
						"file_name" : pro_title,
						"entrust_way" : entrust_way
					};
					service.agreementContent(reqParam,function(data){
						if(data.error_no!="0")
						{
							layerUtils.iAlert(data.error_info);
							layerUtils.iLoading(false);
							return false;
						}
						var perData=data.results;
						if(perData){
							var pdf_url = perData[0].pdf_url; // 协议地址
							url=pdf_url;//
							var param = {
								"url" : pdf_url
							}
							lookContract(param);
							return false;
						}
					});
				}, "click");
			}else{
				$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
				layerUtils.iMsg(-1,"该产品还未配置协议");
				$(_pageId+" #ifSignProt").html("");
				layerUtils.iLoading(false);
				return false;
			}
			if (!flag) {
				newRiskResult(); // 500003风险测评	
			}
		},{"isLastReq" : false});
	}

	/*
 	 * 开通柜台基金账户(500010)
	 */
	function fundAccount(){
		var fund_account= appUtils.getSStorageInfo("fund_account");
		
		var param = { 
			"fund_account":fund_account,
			"product_code":product_code,
			"entrust_way":entrust_way
		}
		service.fundAccount(param,function(data){
			if(data.error_no!="0") {
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}else{//开户成功
				signUndoneAgreement();//签署未签署协议500005
			}
			
		});	
	}
	//签署电子签名约定书(500005)
	function signAgreement(pro_code){
		var ticket=appUtils.getSStorageInfo("ticket"); 
		var cust_code=appUtils.getSStorageInfo("cust_code");
		var fund_account= appUtils.getSStorageInfo("fund_account");
		
		var mobilePhone = require("external").callMessage({
			"funcNo" : "50043",
			"key" : "mobilePhone"
		}).results[0].value;
		
			var param = {           			
				"cust_code":cust_code,
				"ticket":ticket,
				"fund_account" : fund_account,
				"pro_code":pro_code,
				"mobile" : mobilePhone,
				"com_sign":"0",
				"entrust_way":entrust_way,
				"mobile_channel":platform,
				"risk_uncover":"0"
			};
			
			var callBack = function(data){
				if(data.error_no!="0") {
					layerUtils.iAlert(data.error_info);
					layerUtils.iLoading(false);
					return false;
				};
				var is_flag=false;
				var perData = data.results;
				if(perData.length > 0){
						if(perData[0].sign_status=="9"){//9接口调用异常
							layerUtils.iAlert("接口调用异常");
							return false;	
						}else if(perData[0].sign_status=="1"){//1需要强制签署
							is_flag=ture;
						}else if(perData[0].sign_status == "2"){//2不能签署
							layerUtils.iMsg(-1,"不符合签署条件");
							return false;
						}
					if (is_flag) {
						layerUtils.iConfirm("您的风险等级与产品等级不匹配,是否强制签署协议?", function(){
							var reqParam = {
								"cust_code":cust_code,
								"ticket":ticket,
								"pro_code":pro_code,
								"fund_account" : fund_account,
								"mobile" : mobilePhone,
//								"sign_mode" : "1",
								"com_sign":"1",
								"risk_uncover":"1",
								"entrust_way":entrust_way
							}
							service.signAgreement(reqParam, callBack,{"isLastReq" : false});
						},function(){
							appUtils.pageBack();
							$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
						},"确定","取消");
					} else {
						newRiskResult(); // 500003风险测评	
					}
				} else {
					layerUtils.iLoading(false);
				}
			}
			service.signAgreement(param,callBack,{"isLastReq" : false});
	}

	/**
	 * 签署未签署的协议(500005)
	 */
	function signUndoneAgreement(){
		var ticket=appUtils.getSStorageInfo("ticket"); 
		var cust_code=appUtils.getSStorageInfo("cust_code");
		var fund_account= appUtils.getSStorageInfo("fund_account");
		
		var mobilePhone = require("external").callMessage({
			"funcNo" : "50043",
			"key" : "mobilePhone"
		}).results[0].value;
		
		if (contract_not.length > 0) {
			var param = {           			
				"cust_code":cust_code,
				"ticket":ticket,
				"fund_account": fund_account,
				"mobile" : mobilePhone,
				"pro_code":contract_not.join(","),
				"com_sign":"0",
				"entrust_way":entrust_way,
				"mobile_channel":platform,
				"risk_uncover":"0"
			};
			
			var callBack = function(data){
				if(data.error_no!="0") {
					layerUtils.iAlert(data.error_info);
					layerUtils.iLoading(false);
					return false;
				};
				var contract_force = [];//需强制签署的协议
				var perData = data.results;
				if(perData.length > 0){
					for (var i=0; i < perData.length; i++){
						if(perData[i].sign_status=="9"){//9接口调用异常
							layerUtils.iAlert("接口调用异常");
							return false;	
						}else if(perData[i].sign_status=="1"){//1需要强制签署
							contract_force.push(perData[i].pro_code);
						}else if(perData[i].sign_status == "2"){//2不能签署
							layerUtils.iMsg(-1,"不符合签署条件");
							return false;
						}
					}
					if (contract_force.length > 0) {
						layerUtils.iConfirm("您的风险等级与产品等级不匹配,是否强制签署协议?", function(){
							var reqParam = {
								"cust_code":cust_code,
								"ticket":ticket,
								"fund_account" : fund_account,
								"mobile" : mobilePhone,
								"pro_code":contract_force.join(","),
								"sign_mode" : 1,
								"risk_uncover":"1",
								"mobile_channel":platform,
								"com_sign":"1",
								"entrust_way":entrust_way
							}
							service.signAgreement(reqParam, callBack,{"isLastReq" : false});
						},function(){
							appUtils.pageBack();
							$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
						},"确定","取消");}
					else {
						appropriateMatch();//适当性第二次匹配
					}
				} else {
					layerUtils.iLoading(false);
				}
			}
			service.signAgreement(param,callBack,{"isLastReq" : false});
		}else{
			appropriateMatch();//适当性第二次匹配			
		}
	}
	
	/*
	 *第一次适当性匹配(500006)
	 */
	function checkOrderSubmit(){
		var cust_code = appUtils.getSStorageInfo("cust_code");
		var fund_account  = appUtils.getSStorageInfo("fund_account");
		var pageInParam  = appUtils.getPageParam();
		if(pageInParam == null || pageInParam == ""){
			pageInParam = paramConfirmOrder;
		}
		// var product_id=pageInParam.product_id;
		var order_id=null;
		var ticket = appUtils.getSStorageInfo("ticket");
		var param =
		{
			"cust_code":cust_code,
			"tran_type":tran_type,   
			"ticket":ticket,
			"inst_id":product_code,
			"fund_account":fund_account,
			"entrust_way":entrust_way
		};
		service.appropriateMatch(param,function(data){
			if(data.error_no!="0") {
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
			var perData = data.results;
			if(perData.length != 0){
				var match_rs = perData[0].match_rs; //匹配结果集
				match_rs = $.parseJSON(match_rs);
				var not_match_rs = perData[0].not_match_rs; // 不匹配结果集
				not_match_rs = $.parseJSON(not_match_rs);
				var leng = not_match_rs.length;	
				var flagPersonOrOrgan=true;//判断本产品是否匹配购买类型,个人或机构
				var flagRisk=false;//判断是否风测
				var flagProduct=false;//是否需要做产品问卷标识
				var product_survey = "";//产品问卷调查编码
				var flagAppend=false;//是否需要做附加题标识
				var _otherQuestion=[];//其他类型问卷调查的编码集
				if(perData[0].rs_code == '0'){//0不匹配,1匹配
					for (var l = 0; l < not_match_rs.length; l++) {
						//表明是客户类型参数,并且客户的类型和产品的购买类型不匹配,如果不匹配,则程序不需要再继续
						var item = not_match_rs[l];
						if(item.FLD_NAME == "CUST_TYPE" && item.FUND_NO == global.appro_cust){
							flagPersonOrOrgan=false;
							break;
						}
					}
					if(flagPersonOrOrgan){
						var user_type = appUtils.getSStorageInfo("user_type");
						for(var i=0;i<leng;i++){
	                        //判断有没有调查问卷
	                        if(not_match_rs[i].SURVEY_CODE && (not_match_rs[i].SURVEY_CODE).indexOf("205") > -1){//问卷调查
	                            if(not_match_rs[i].FUND_NO == global.appro_risk || not_match_rs[i].FUND_NO == global.appro_ques){//需要问卷调查
//	                            	 var product_id  = appUtils.getPageParam("product_id");
//	                            	var product_name  = appUtils.getPageParam("product_name");
//	                            	var tot_price  = appUtils.getPageParam("tot_price");
//	                            	var product_code=appUtils.getPageParam("product_code");
////	                            	
//	                            	if(product_id == null || product_id == "" || product_id =="undefined"){
//	                            	var	product_id = paramConfirmOrder.product_id;
//	                            	var	product_name = paramConfirmOrder.product_name;
//	                            	var tot_price=paramConfirmOrder.tot_price;
//	                            	var product_code=paramConfirmOrder.product_code;
//	                            	
//	                        		}
                    				var param = {
                						"product_id":product_id,
                						"product_name":product_name,
                						"tot_price":tot_price,
                						"product_code":product_code,
                						"survey_sn": "1001" // 个人是10001机构是10002
                    				};
	                            	if(user_type === '0' && not_match_rs[i].CUST_TYPE === '0'){//个人问卷调查
	                            		param.survey_sn = not_match_rs[i].FLD_NAME;
	                    				layerUtils.iConfirm("您未做调查问卷，请做调查问卷!",function() {
	                    					appUtils.pageInit("mall/finanOrder/confirmOrder","mall/finanOrder/knowledgeQuestionnaire",param);
	                    				},function(){
	                    					layerUtils.iLoading(false);
	                    					$(_pageId + " #tjdd").unbind(); // 解绑提交订单按钮
	                    					appUtils.pageInit("mall/finanOrder/confirmOrder","mall/itemsFinanInfo",param);
	                    				})
	                                	return false;
	                                }else if(user_type == '1' && not_match_rs[i].CUST_TYPE == '1'){//机构问卷调查
	                                	param.survey_sn = not_match_rs[i].FLD_NAME;
	                    				layerUtils.iConfirm("您未做调查问卷，请做调查问卷!",function() {
	                    					appUtils.pageInit("mall/finanOrder/confirmOrder","mall/finanOrder/knowledgeQuestionnaire",param);
	                    				},function(){
	                    					layerUtils.iLoading(false);
	                    					$(_pageId + " #tjdd").unbind(); // 解绑提交订单按钮
	                    					appUtils.pageInit("mall/finanOrder/confirmOrder","mall/itemsFinanInfo",param);
	                    				})
	                                	return false;
	                                }else if(not_match_rs[i].CUST_TYPE==""){//通用问卷调查,值为空
	                                	param.survey_sn = not_match_rs[i].FLD_NAME;
	                    				layerUtils.iConfirm("您未做调查问卷，请做调查问卷!",function() {
	                    					appUtils.pageInit("mall/finanOrder/confirmOrder","mall/finanOrder/knowledgeQuestionnaire",param);
	                    				},function(){
	                    					layerUtils.iLoading(false);
	                    					$(_pageId + " #tjdd").unbind(); // 解绑提交订单按钮
	                    					appUtils.pageInit("mall/finanOrder/confirmOrder","mall/itemsFinanInfo",param);
	                    				})
	                                	return false;
	                                }
	                            }
	                        
	                        }else if(not_match_rs[i].FUND_NO === global.contract_mark){
	                        	contract_not.push(not_match_rs[i].FLD_VAL);//还没有签署的协议
							}
	                    }
	                    if(flagAppend){
//	                    	 var product_id  = appUtils.getPageParam("product_id");
//	                    	var tot_price  = appUtils.getPageParam("tot_price");
//	                    	var product_name  = appUtils.getPageParam("product_name");
//	                    	var product_code  = appUtils.getPageParam("product_code");
//	                    	if(product_id == null || product_id == "" || product_id =="undefined"){
//	                    		var product_id=paramConfirmOrder.product_id;
//	                    		var product_name=paramConfirmOrder.product_name;
//	      					    var tot_price=paramConfirmOrder.tot_price;
//	      					    var product_code=paramConfirmOrder.product_code;
//                    		}
	                    	
            				var param = {
        						"product_id":product_id,
        						"product_name":product_name,
        						"tot_price":tot_price,
        						"product_code":product_code,
        						"survey_sn": "1001" // 个人是10001机构是10002
            				};
	                    	if(user_type === '0'){//个人附加问卷
	                    		param.survey_sn = global.append_single;
	                    		layerUtils.iConfirm("您未做调查问卷，请做调查问卷!",function() {
                					appUtils.pageInit("mall/finanOrder/confirmOrder","mall/finanOrder/knowledgeQuestionnaire",param);
                				},function(){
                					layerUtils.iLoading(false);
                					$(_pageId + " #tjdd").unbind(); // 解绑提交订单按钮
                					appUtils.pageInit("mall/finanOrder/confirmOrder","mall/itemsFinanInfo",param);
                				})
	                			return;
	                		}else if(user_type === '1'){
	                			param.survey_sn = global.append_org;
	                    		layerUtils.iConfirm("您未做调查问卷，请做调查问卷!",function() {
                					appUtils.pageInit("mall/finanOrder/confirmOrder","mall/finanOrder/knowledgeQuestionnaire",param);
                				},function(){
                					layerUtils.iLoading(false);
                					$(_pageId + " #tjdd").unbind(); // 解绑提交订单按钮
                					appUtils.pageInit("mall/finanOrder/confirmOrder","mall/itemsFinanInfo",param);
                				})
	                			return;
	                		}
	                    }
	                    //循环调用做其他问卷
	                    if(_otherQuestion.length>0){
//	                    	 var product_id  = appUtils.getPageParam("product_id");
//	                    	var product_name  = appUtils.getPageParam("product_name");
//	                    	var tot_price  = appUtils.getPageParam("tot_price");
//	                    	var product_code  = appUtils.getPageParam("product_code");
//	                    	if(product_id == null || product_id == "" || product_id =="undefined"){
//	                    		var	product_id = paramConfirmOrder.product_id;
//	                    		var product_name=paramConfirmOrder.product_name;
//	      					    var tot_price=paramConfirmOrder.tot_price;
//	      					    var product_code=paramConfirmOrder.product_code;
//                    		}
	                    	
	                    	if(pageInParam == null || pageInParam == ""){
                    			pageInParam = paramConfirmOrder;
                    		}
            				var param = {
        						"product_id":product_id,
        						"product_name":product_name,
        						"tot_price":tot_price,
        						"product_code":product_code,
        						"survey_sn": "1001" // 个人是10001机构是10002
            				};
		            		for(var h =0;h<_otherQuestion.length;h++){
		            			param.survey_sn = _otherQuestion[h];
		            			layerUtils.iConfirm("您未做调查问卷，请做调查问卷!",function() {
		            				
		            				appUtils.pageInit("mall/finan/confirmOrder","mall/finanOrder/knowledgeQuestionnaire",param);
		            			},function(){
                					layerUtils.iLoading(false);
                					$(_pageId + " #tjdd").unbind(); // 解绑提交订单按钮
                					appUtils.pageInit("mall/finanOrder/confirmOrder","mall/itemsFinanInfo",param);
                				})
		          				return false;
		            		}
	                    }
	            		
	            		$(_pageId+" #tjdd").text("提交订单"); 
	            		$(_pageId+" #tjdd").attr('style',"background-color:#19e;float: none; display: inline-block;");
						bindOrder();
					}else{
						if(user_type === '0'){
							layerUtils.iMsg(-1,"该产品允许购买的客户类型是机构");
						}else{
							layerUtils.iMsg(-1,"该产品允许购买的客户类型是个人");
						}
					}
	            }else{
	            	for(var k=0;k<leng;k++){
	            		if(not_match_rs[k].FUND_NO === global.contract_mark){
	                    	contract_not.push(not_match_rs[k].FLD_VAL);//还没有签署的协议
						}
	            	}
	            	$(_pageId+" #tjdd").text("提交订单"); 
	        		$(_pageId+" #tjdd").attr('style',"background-color:#19e;float: none; display: inline-block;");
	            	bindOrder();
	            }
			}else{
				$(_pageId + " #tjdd").css("background","#CFCFCF").unbind(); // 解绑提交订单按钮
				layerUtils.iMsg(-2,"该产品还未配置协议");
			}	
		});
	}
	//客户风险查询(500003)
	function newRiskResult(){
		var cust_code = appUtils.getSStorageInfo("cust_code");
		var ticket = appUtils.getSStorageInfo("ticket");
		var user_type=appUtils.getSStorageInfo("user_type");
		//survey_sn个人是10001机构是10002
		var survey_sn = user_type == "1" ? "1002" : "1001";
		var param = {
			"cust_code":cust_code,
			"survey_sn":survey_sn,
			"ticket":ticket
		};  		
		service.newRiskResult(param,function(data){
			if (data.error_no == "0") {
				var perData = data.results;
				if(perData.length>0){    
					var is_overtime = perData[0].is_overtime;
					if(is_overtime == "1"){//1过期
						layerUtils.iLoading(false);
//						var pageInParam  = appUtils.getPageParam();
//                    	if(pageInParam == null || pageInParam == ""){
//                			pageInParam = paramConfirmOrder;
//                		}
//				    	var product_name= pageInParam.product_name;
//					    var product_id=pageInParam.product_id;
//					    var tot_price=pageInParam.tot_price;
//					    var product_code=pageInParam.product_code;
						var param = {
							"product_name":product_name,
							"product_id":product_id,
							"tot_price":tot_price,
							"product_code":product_code
						};
						layerUtils.iConfirm("您的风险测评已过期，请重新测评!",function() {
							appUtils.setSStorageInfo("_prePageCode","mall/finanOrder/confirmOrder");
							appUtils.pageInit("mall/finanOrder/confirmOrder","account/riskAssessment",param);
							return false;
						},function(){
							layerUtils.iLoading(false);$(_pageId + " #tjdd").unbind(); // 解绑提交订单按钮
							appUtils.pageInit("mall/finanOrder/confirmOrder","mall/itemsFinanInfo",param);
						});
					} else {
						//适当性第一次匹配。先电子签名约定书，风测，问卷光行规定
						checkOrderSubmit();
					}
				} else {           //未作风测
					layerUtils.iLoading(false);
//					var pageInParam = appUtils.getPageParam();
//                	if(pageInParam == null || pageInParam == ""){
//            			pageInParam = paramConfirmOrder;
//            		}
//			    	var product_name = pageInParam.product_name;
//				     var product_id = pageInParam.product_id;
//				    var tot_price = pageInParam.tot_price;
//				    var product_code = pageInParam.product_code;
					var param = {
						"product_name":product_name,
						"product_id":product_id,
						"tot_price":tot_price,
						"product_code":product_code
					};
					layerUtils.iConfirm("您还没有风险测评，请测评!",function() {
						appUtils.pageInit("mall/finanOrder/confirmOrder","account/riskAssessment",param);
					},function(){
						layerUtils.iLoading(false);
					});	
				}	
			} else {
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
		},{"isLastReq" : false});		
	}
	
	function appropriateMatch()//适当性匹配(第二次匹配500006)
	{
		var user_id=appUtils.getSStorageInfo("user_id");
		var cust_code = appUtils.getSStorageInfo("cust_code");
		var fund_account  = appUtils.getSStorageInfo("fund_account");
		var pageInParam  = appUtils.getPageParam();
    	if(pageInParam == null || pageInParam == ""){
			pageInParam = paramConfirmOrder;
		}
		// var product_id=pageInParam.product_id;
		var order_id=null;
		var ticket = appUtils.getSStorageInfo("ticket");

		var param =
		{
			"cust_code":cust_code,
			"fund_account":fund_account,
			"tran_type":tran_type,
			"ticket":ticket,
			"inst_id" : product_code,
			"entrust_way" : entrust_way
		};
		service.appropriateMatch(param,function(data){
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			};
			var perData=data.results;
			var rs_code = perData[0].rs_code;
			var not_match_rs = $.parseJSON(perData[0].not_match_rs); // 不匹配结果集
			var leng = not_match_rs.length;
			for(var j=0; j<leng; j++){//大的部分匹配,检测不匹配中的其他值,若是有值则仍为不匹配,否则匹配
				if(not_match_rs[j].CUST_RS !== ""){//CUST_RS表示客户有实际值,但是不匹配
					rs_code="0";
					break;
				}
			}
			if(rs_code == "1"){ //适当性匹配
				queryRiskResult(function(data){
					var results = data.results;
					var rating_lvl = results[0].rating_lvl;
					if(results && results.length > 0){
						//跳到适当匹配书
						var pageInParamObj = appUtils.getPageParam();
                    	if(pageInParamObj == null || pageInParamObj == ""){
                    		pageInParamObj = paramConfirmOrder;
                		}
                    	pageInParam = pageInParamObj || {};
						pageInParam.pro_risk_level = pro_risk_level;
						pageInParam.user_id = user_id;
						pageInParam.tot_price = parseFloat($(_pageId+" #zj").html());
						pageInParam.risk_name = results[0].risk_name;
						pageInParam.rating_lvl = results[0].rating_lvl;
						appUtils.pageInit("mall/finanOrder/confirmOrder","mall/finanOrder/riskSuccess",pageInParam);
						return false;
					}
				});
			} else if(rs_code == '0'){//不匹配      弹不适当匹配书
				queryRiskResult(function(data){
					var results = data.results;
					var rating_lvl = results[0].rating_lvl;
					var risk_levels = results[0].risk_level;
					if(results && results.length > 0){
						var invest_variety = "";
						var invest_deadline = "";
						var risk_not = false;
						for(var i=0;i<leng;i++){
							if (not_match_rs[i].FUND_NO===global.appro_append) {
								if(not_match_rs[i].FLD_NAME==="INVE_VARI"){//客户投资品种
									invest_variety = dicInvestVaritey(not_match_rs[i].CUST_RS);
								}
								if(not_match_rs[i].FLD_NAME==="INVE_PERI"){//客户投资期限
									invest_deadline = dicInvestDeadline(not_match_rs[i].CUST_RS);
								}
							}
							var user_type = appUtils.getSStorageInfo("user_type");
							
							if(user_type == "0" && not_match_rs[i].FLD_NAME == "1001" && not_match_rs[i].FUND_NO =="S0014027"){
								risk_not = true;
							}else if(user_type == "1" && not_match_rs[i].FLD_NAME == "1002" && not_match_rs[i].FUND_NO =="S0014027"){
								risk_not = true;
							}
						}
						var pageInParamObj = appUtils.getPageParam();
                    	if(pageInParamObj == null || pageInParamObj == ""){
                    		pageInParamObj = paramConfirmOrder;
                		}
                    	pageInParam = pageInParamObj || {};
                    	pageInParam.pro_risk_level = pro_risk_level;
						pageInParam.user_id = user_id;
						pageInParam.tot_price = parseFloat($(_pageId+" #zj").html());
						pageInParam.risk_name = results[0].risk_name;
						pageInParam.risk_level = risk_level;
						pageInParam.rating_lvl = results[0].rating_lvl;
						//跳到不适当匹配书
						appUtils.pageInit("mall/finanOrder/confirmOrder","mall/finanOrder/riskFailure",pageInParam);
						return false;
					}
				});
			}
			return;
		});
	}
	
	
	//客户风险查询(500003)
	function queryRiskResult(callBack){
		var cust_code = appUtils.getSStorageInfo("cust_code");
		var ticket = appUtils.getSStorageInfo("ticket");
		var user_type=appUtils.getSStorageInfo("user_type");
		//survey_sn个人是10001机构是10002
		var survey_sn = user_type == "1" ? "1002" : "1001";
		var param = {
			"cust_code":cust_code,
			"survey_sn":survey_sn,
			"ticket":ticket
		};  		
		service.newRiskResult(param, function(data){
			if (data.error_no == "0") {
				callBack(data);
			} else {
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
			}
		});		
	}
	
	//投资期限字典
	function dicInvestDeadline(inve_peri){
		switch(inve_peri) {
			case "1":
				return "短期-0到1年";
			case "2":
				return "中期-1到5年";
			case "3":
				return "长期-5年以上";
			case "4":
				return "无固定期限";
			default: return "--";
		}
	}
	//投资品种字典
	function dicInvestVaritey(inve_vari){
		switch(inve_vari) {
			case "1":
				return "债券、货币市场基金、债券基金、信托等固定收益类投资品种";
			case "2":
				return "股票、混合型基金、偏股型基金、股票型基金、信托等权益类投资品种";
			case "3":
				return "期货、融资融券";
			case "4":
				return "复杂或高金融产品";
			case "5":
				return "其他产品";
			default: return "--";
		}
	}

	
	//判断是否是交易日
	function dealTimeSyn()
	{
		var param=
		{
			"date":""
		}
		service.dealTimeSyn(param,function(data){
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			} 
			else if(data.results[0].is_trade=='0')
			{
				layerUtils.iAlert("当前是非交易时间，理财和基金产品暂停交易。");
				layerUtils.iLoading(false);
				return false;
			}
			else{
				//开基金账户（500010）
				fundAccount();
			}

		},false)
	}

/*	function checkAllRead(){
		var allReadFlag = false;
		if(readProtocolArr.length==0){
			allReadFlag = true;
		}
		for(var i=0, len = readProtocolArr.length; i<len; i++){
			var flag = readProtocolArr[i];
			if(flag == true){
				allReadFlag = true;
			} else {
				allReadFlag = false;
				break;
			}
		}
		return allReadFlag;
	}
*/
	//2、事件绑定
	function bindPageEvent()
	{	

		//点击 增加购买金额
		appUtils.bindEvent($(_pageId+" .icon_add"),function(){addAndMin("add");});

		//点击 减少购买金额
		appUtils.bindEvent($(_pageId+" .icon_less"),function()	{addAndMin("min");	});
		//点击理财
		appUtils.bindEvent($(_pageId+" #finan"),function(){appUtils.pageInit("mall/finanorder/confirmOrder","mall/itemsFinan",{});});

		//点击基金
		appUtils.bindEvent($(_pageId+" #fund"),function(){appUtils.pageInit("mall/finanOrder/confirmOrder","mall/itemsFund",{});});

		//点击 返回
		appUtils.bindEvent($(_pageId+" .icon_back"),function(){appUtils.pageBack();});

		//点击 返回顶部
		appUtils.bindEvent($(_pageId+" .back_btn"),function(){$('body,html').animate({scrollTop:0},1000);return false;});

		//点击 LOGO 
		appUtils.bindEvent($(_pageId+" .logo"),function(){appUtils.pageInit("mall/finanOrder/confirmOrder","account/mainPage")})

		//点击 继续选购
		appUtils.bindEvent($(_pageId+" .n1"),function(){appUtils.pageInit("mall/finanOrder/confirmOrder","account/mainPage")});		

		//判断输入是否合法
		appUtils.bindEvent($(_pageId+" #buyValue"),function(){putils.numberLimit($(this));},"keyup");

		//控制输入不能为空
		appUtils.bindEvent($(_pageId+" #buyValue"),function(){

			if($(this).val()==null||$(this).val()==""){
				$(this).val(0);
			}
			$(this).val(putils.moneyFormat($(this).val()));
			$(_pageId+" #zj").html($(_pageId+" #buyValue").val());
		},"blur");

		//点击登录
		appUtils.bindEvent($(_pageId+" .icon_info"),function()
			{
			var user_id=appUtils.getSStorageInfo("user_id");
			if(user_id!=""&&user_id!=null)
			{
				appUtils.pageInit("mall/finanOrder/confirmOrder","account/userCenter",{});
			}
			else
			{
				appUtils.pageInit("mall/finanOrder/confirmOrder","account/userLogin",{});
			}

			});


	}

	//点击 个人中心 事件
	appUtils.bindEvent($(_pageId+"  .icon_info"),function()
		{
		var user_id=appUtils.getSStorageInfo("user_id");
		if(user_id!=null&&user_id!=="")
		{
			appUtils.pageInit("mall/finanOrder/confirmOrder","account/userCenter",{});
		}
		else
		{   layerUtils.iMsg(0,"您还没有登录，请登录");
		appUtils.pageInit("mall/finanOrder/confirmOrder","account/userLogin",{});
		}

	});

	
	/**
	 * 绑定订单提交事件
	 */
	function bindOrder(){
		//立即提交
		appUtils.bindEvent($(_pageId+" #tjdd"),function(){
//			if(readProtocolArr.length != 0){
//				if(checkAllRead() == false){
//					layerUtils.iMsg(-1, "请阅读完所有的协议");
//					return false;
//				}
//			}
			if(!$(_pageId+" #signProtocol").prop("checked"))
			{
				layerUtils.iAlert("请同意并签署此购买合同！");
				return false;
			}	
			
			var buyValue= $(_pageId+"  #buyValue").val();  //购买金额
			var buy_pace=$(_pageId+" #buy_pace").html();   //步长
			var frist =$(_pageId+" #frist").html();       //首次购买起点

			var name=$(_pageId+" .n2").attr("id");
			if(name==null||name=="")
			{
				return false;
			}
			if(buy_pace==""||buy_pace=="0")
			{
				buy_pace="1"

			}
			if(parseFloat($(_pageId+" #buyValue").val())<parseFloat(frist))
			{
				layerUtils.iMsg(-1,"购买的金额不能低于"+frist);
				return false;
			}
			/*if((buyValue-frist)%buy_pace!=0)
			{
				layerUtils.iMsg(0,"输入金额必须是"+buy_pace+"的整数倍！");
				return false;
			}*/

			dealTimeSyn();//判断是否是交易日
			$(_pageId + " #tjdd").html("提交中...").unbind(); // 解绑提交订单按钮
		});
	}
	
	

	//3、销毁
	function destroy()
	{
		for(var i=0, len = readProtocolArr.length; i<len; i++){
			readProtocolArr[i] = false;
		}
		readProtocolLen=0;
		readProtocolArr = [];
		$(_pageId + " #signProtocol").attr("checked", "unchecked");
		$(_pageId+" #signProtocol").attr("unchecked");
		$(_pageId+" #tjdd").text("提交订单"); 
		$(_pageId+" #tjdd").attr('style',"background-color:#19e;float: none; display: inline-block;");
		$(_pageId + "#eclBookDiv").hide();
	}

	var confirmOrder =
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = confirmOrder;

	});
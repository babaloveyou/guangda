﻿/*
 * xjb首页
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	_pageId = "#xjb_account_index ";
	var _fxcp = "";
	var _isTa = "";
	/*
	 * 页面初始化
	 */
	function init(){
		//设置页面高度
		$(_pageId + " .main").height($(window).height() - $(_pageId + " .header").height());
		$(_pageId + " .main").css("overflow-y","auto");
		
		//获取username
		var user=appUtils.getSStorageInfo("userinfo");
		var userinfo=JSON.parse(user);
		$(_pageId + " .main .respect .em_name").html(userinfo.user_name);
		
		//查询所有协议id
		service.getAllProtocolId("",function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			if(error_no == "0"){
				var result = data.results[0];
				appUtils.setSStorageInfo("pro_code_fxjss",result.pro_code_fxjss);
				appUtils.setSStorageInfo("pro_code_ht",result.pro_code_ht);
				appUtils.setSStorageInfo("pro_code_qys",result.pro_code_qys);
				appUtils.setSStorageInfo("pro_code_t0_fwxy",result.pro_code_t0_fwxy);
				appUtils.setSStorageInfo("pro_code_t0_fxjs",result.pro_code_t0_fxjs);
			}else{
				layerUtils.iAlert(error_info);
				return false;
			}
		});
		//是否开户与签署电子合同
		stepCheck();
		showMain();
	}
	
	function showMain(){
		$(_pageId + " .main li").hide();
		if(_fxcp && _isTa){//风险测评 中登检测都通过
			$(_pageId + " .main .li3").show();
			$(_pageId + " .main .li6").show();
			$(_pageId + " .main .li3  .col_02").html(_fxcp);
			$(_pageId + " .main .li6  .col_02").html(_isTa);
			$(_pageId + " .main .definbtn_01").css("background","#1199EE");
			$(_pageId + " .main .definbtn_01").addClass("isBlue");
		}else{
			if(_fxcp == "" && _isTa != ""){ //未风测
				$(_pageId + " .main .li2").show();
				$(_pageId + " .main .li6").show();
				$(_pageId + " .main .li6 .col_02").html(_isTa);
			}else if(_isTa == "" && _fxcp != ""){ //未开户
				$(_pageId + " .main .li3").show();
				$(_pageId + " .main .li5").show();
				$(_pageId + " .main .li3 .col_02").html(_fxcp);
			}else{
				$(_pageId + " .main .li2").show();
				$(_pageId + " .main .li5").show();
			}
		}
	}
	
	//查询风险测评
	function queryFxcp(){
		//20160920改为500003查询风测结果
		var callBackFunc=function(data){ // 2002006
			if(data.error_no == 0){
				var result = data.results;
				if(result.length > 0 && result[0].is_overtime == "0"){//风测是否过期,1过期,0未过期
					_fxcp = result[0].risk_name;
				}
			}else{
				layerUtils.iAlert(data.error_info);
			}
		};
		var user=appUtils.getSStorageInfo("userinfo");
		var userinfo=JSON.parse(user);
		var s="1002";
		if(userinfo.user_type=="0"){
			s="1001";
		}
		var param = {
			"cust_code":userinfo.user_code,
			"ticket":"",
			"survey_sn":s
		};
		service.newRiskResult(param,callBackFunc,{isAsync:false});
		/*
		var callBackFunc=function(data){ // 2002006
			if(data.error_no == 0){
				var result = data.results[0];
				if(result.sffxcp == 1){  //1表示已测评
					_fxcp = result.riskResult;
				}
			}else{
				layerUtils.iAlert(data.error_info);
			}
		};
		var param={
			"fund_account":appUtils.getSStorageInfo("fund_account"),
			"branch_no":appUtils.getSStorageInfo("branch_no")
		};
		service.cyb_queryFxcp(param,callBackFunc,{isAsync:false});
		*/
	}
	//检查是否开户
	function taIsOpen(){
		var callBackFunc06=function(data){ // 2002006
			if(data.error_no == 0){
				var result = data.results[0];
				if(result.contract_type==1){//1表示已开户
					_isTa = result.fund_account;
					if(_isTa == " "){
						_isTa = "已报中登";
					}
				}
			}else{
				layerUtils.iAlert(data.error_info);
			}
		};
		var param={
			"fund_account":appUtils.getSStorageInfo("fund_account")
		};
		service.taIsOpen(param,callBackFunc06,{isAsync:false});
	}
	
	/**
	 * 流程检测 --- 现金宝
	 */
	function stepCheck(){
		//记录进入现金宝的信息
		var par = {
			"fund_account":appUtils.getSStorageInfo("fund_account"),
			"branch_no":appUtils.getSStorageInfo("branch_no"),
			"entrust_way":"SJWT",
			"mac":appUtils.getSStorageInfo("mac"),
			"ip":appUtils.getSStorageInfo("ip"),
		};
		service.recordInfo(par,function(data){
			if(data.error_no == 0){
				//用E帐通登录时没有营业部编号
				if(appUtils.getSStorageInfo("branch_no")==null || appUtils.getSStorageInfo("branch_no") ==undefined){
					appUtils.setSStorageInfo("branch_no",data.results[0].branch_no);
				}
				var user=appUtils.getSStorageInfo("userinfo");
				var userinfo=JSON.parse(user);
				var s="1002";
				if(userinfo.user_type=="0"){
					s="1001";
				}
				var param = {
					"fund_account":appUtils.getSStorageInfo("fund_account"),
					"sign":4,
					"ezt_name":userinfo.user_code,
					"ticket":"",
					"survey_sn":s
				};
				service.isCompleteStep(param,function(data){
					if(data.error_no == 0){
						var result = data.results[0];
						if(result.sfkh == "1" && result.sfqsdzht == "1"){//已经开户、已签约合同  0否 1是
							appUtils.pageInit("xjb/account/index","xjb/navigation/index",{});
						// if(result.sfqsdzht == "1"){//已签约合同  0否 1是
							// taIsOpen();
							// if(_isTa){
								// appUtils.pageInit("xjb/account/index","xjb/navigation/index",{});
							// }else{
								// queryFxcp();
								// showMain();
							// }
						}else{//开户和电子合同不满足
							taIsOpen();
							queryFxcp();
							showMain();
						}
					}else{
						layerUtils.iLoading(false);
						var error = data.error_info;
						//后台返回的提示信息不友好
						if(error.indexOf("SQL")> -1){
							error = error.split("SQL")[0];
							var len = error.length;
							error = error.substring(0,len-2);
						}
						layerUtils.iAlert(error);
						// layerUtils.iLoading(false);
						// layerUtils.iAlert(data.error_info);
					}
				});
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		});
	}
	
	/*
	 * 绑定页面事件
	 */
	function bindPageEvent(){
		//返回
		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(e){
			pageBack();
			e.stopPropagation();
		});
		//下一步
		appUtils.bindEvent($(_pageId + " .main .definbtn_01"),function(e){
			if($(this).hasClass("isBlue")){
				appUtils.pageInit("xjb/account/index","xjb/account/contractSign",{"fxcp":_fxcp,"isTa":_isTa});
			}
			e.stopPropagation();
		});
		//风险测评
		appUtils.bindEvent($(_pageId + " .main .li2"),function(e){
			appUtils.pageInit("xjb/account/index","xjb/account/fxcp",{});
			e.stopPropagation();
		});
		//开户
		appUtils.bindEvent($(_pageId + " .main .li5"),function(e){
			appUtils.pageInit("xjb/account/index","xjb/account/openTa",{"category_englishname":"xjbxykh"});
			e.stopPropagation();
		});
	}
	
	/*
	 * 销毁页面
	 */
	function destroy(){
		$(_pageId + " .main .definbtn_01").css("background","#bebebe");
		$(_pageId + " .main li").hide();
		$(_pageId + " .main .li1").show();
		$(_pageId + " .main .li4").show();
		_fxcp = "";
		_isTa = "";
	}
	
	function pageBack(){
		var fromPage = appUtils.getSStorageInfo("xjb_fromPage");
		appUtils.setSStorageInfo("xjb_fromPage","");
		if(fromPage && fromPage=="userCenter"){
			appUtils.pageInit("xjb/account/index","account/userCenter",{});
		}else{
			var param_index = {"funcNo":"50101","moduleName":"main"};
			require("external").callMessage(param_index);
		}
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy,
			"pageBack":pageBack
	};
	//暴露方法
	module.exports = base;
});
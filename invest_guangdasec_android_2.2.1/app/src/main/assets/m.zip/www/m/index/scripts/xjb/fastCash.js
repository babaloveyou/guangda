/*
 * 快速取现
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	maxCash = 0,//最大取现金额
	isSupport = false,//三方是否支持快速取现
	bank_no = "",//
	bank_card_no = "",//银行卡号
	_pageId = "#xjb_fastCash ";
	
	/*
	 * 页面初始化
	 */
	function init(){
		maxCash = 0;
		isSupport = false;//三方是否支持快速取现
		bank_no = "";//
		bank_card_no = "";//银行卡号
		
		var param = {
			"branch_no":appUtils.getSStorageInfo("branch_no"),
			"pro_code":appUtils.getSStorageInfo("pro_code"),
			"fund_account":appUtils.getSStorageInfo("fund_account"),
			"account_type":appUtils.getSStorageInfo("whichAccount"),
			"entrust_way":"SJWT"
		};
		service.getCardInfo(param,function(data){//查银行卡信息 三方是否支持快速取现
			if(data.error_no == 0){
				isSupport = data.results[0].flag;
				bank_no = data.results[0].bank_no;
				bank_card_no = data.results[0].bank_card_no;
				
				var par = {
					"branch_no":appUtils.getSStorageInfo("branch_no"),
					"account":appUtils.getSStorageInfo("fund_account"),
					"account_type":appUtils.getSStorageInfo("whichAccount"),
					"entrust_way":"SJWT"
				};
				service.innovateBusinessIsExist(par,function(data){//是否已开通快速取现
					if(data.error_no == 0){
						if(data.results[0].competence_flag == "1"){
							card_info = data.results[0];
							queryMaxCash();
						}else{
							$(_pageId+" .noSign").show();
						}
					}else{
						layerUtils.iLoading(false);
						layerUtils.iAlert(data.error_info);
					}
				});
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		});
	}
	
	/*
	 * 绑定页面事件
	 */
	function bindPageEvent(){
		
		//返回
		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(){
			appUtils.pageInit("xjb/fashCash","account/userCenter",{});
		});
		
		//签署协议
		appUtils.bindEvent($(_pageId+" .signProtocolBtn"),function(){
			if(isSupport == "true" || isSupport == true){
				//签署协议
				appUtils.pageInit("xjb/fastCash","xjb/fastCashProtocol");
			}else{
				layerUtils.iAlert("您的三方存管银行不支持T+0快速取现！");
			}
		});
		
		//取现
		appUtils.bindEvent($(_pageId+" .getCash"),function(){
			if(validateInput()){
				var param = {
					"branch_no":appUtils.getSStorageInfo("branch_no"),
					"account":appUtils.getSStorageInfo("fund_account"),
					"cash_amount":$(_pageId+" .inputCash").val(),
					"entrust_way":"SJWT"
				};
				service.getCash(param,function(data){//转账到证券账户
					if(data.error_no == 0){
						maxCash = maxCash - parseFloat($(_pageId+" .inputCash").val());
						$(_pageId+" .maxCash").html(maxCash);
						//取现到银行卡时，先取现到证券账户，再调用银证转账
						if($(_pageId+" .sel_list").attr("data-type") == "bank"){
							var par = {
								"fund_pwd":$(_pageId+" .inputPwd").val(),
								"fund_amount":$(_pageId+" .inputCash").val(),
								"fund_account":appUtils.getSStorageInfo("fund_account"),
								"bank_no":bank_no,
								"trans_type":"2",
								"bank_card_no":bank_card_no,
								"entrust_way":"SJWT"
							};
							service.saveCash(par,function(data){//转账到银行
								if(data.error_no == 0){
									layerUtils.iMsg(0,"您的申请已提交，编号为:"+data.results[0].apply_no+".");
								}else{
									layerUtils.iLoading(false);
									layerUtils.iAlert("快速取现成功但转账到银行卡失败，请重新进行银证转账："+data.error_info);
								}
							});
						}else{
							layerUtils.iMsg(0,"取现成功!");
						}
					}else{
						layerUtils.iLoading(false);
						layerUtils.iAlert(data.error_info);
					}
					$(_pageId+" .inputCash").val("");
					$(_pageId+" .inputPwd").val("");
				});
			}
		});
		
		//选择
		appUtils.bindEvent($(_pageId+" .sel_list,.bankCard,.stockAccount"),function(){
			$(_pageId+" .sel").slideToggle();
		});
		//选择子项
		appUtils.bindEvent($(_pageId+" .bankCard,.stockAccount"),function(){
			$(_pageId+" .sel").slideToggle();
			$(_pageId+" .sel_list").attr("data-type",$(this).attr("data-type"));
			$(_pageId+" .sel_list strong").html($(this).text());
			if($(this).hasClass("bankCard")){
				$(_pageId+" .pwd").slideDown();
			}else{
				$(_pageId+" .pwd").slideUp();
			}
		});
		
		//tab0
		appUtils.bindEvent($(_pageId+" .mn_tab .setReservationItem"),function(){
			appUtils.pageInit("xjb/fastCash","xjb/setReservation",{});
		});
		
		//tab1
		appUtils.bindEvent($(_pageId+" .mn_tab .fastCashItem"),function(){
		
		});
		
		//tab2
		appUtils.bindEvent($(_pageId+" .mn_tab .setReserveFundsItem"),function(){
			appUtils.pageInit("xjb/fastCash","xjb/setReserveFunds",{});
		});
		
		//tab3
		appUtils.bindEvent($(_pageId+" .mn_tab .setStateItem"),function(){
			appUtils.pageInit("xjb/fastCash","xjb/setState",{});
		});
		
		//tab4
		appUtils.bindEvent($(_pageId+" .mn_tab .queryQuotientItem"),function(){
			appUtils.pageInit("xjb/fastCash","xjb/queryQuotient",{});
		});
		
	}
	
	function queryMaxCash(){
		var param = {
			"branch_no":appUtils.getSStorageInfo("branch_no"),
			"pro_code":appUtils.getSStorageInfo("pro_code"),
			"account":appUtils.getSStorageInfo("fund_account"),
			"account_type":appUtils.getSStorageInfo("whichAccount"),
			"entrust_way":"SJWT"
		};
		service.queryMaxCash(param,function(data){//是否开通
			if(data.error_no == 0){
				maxCash = data.results[0].maximum_amount;
				$(_pageId+" .maxCash").html(maxCash);
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		});
		$(_pageId+" .signed").show();
	}
	
	function validateInput(){
		var inputCash = $(_pageId+" .inputCash").val();
		var password = $(_pageId+" .inputPwd").val();
		var selType = $(_pageId+" .sel_list").attr("data-type");
		if(!selType){
			layerUtils.iAlert("您还没有选择取现到哪里！");
			return false;
		}
		if(!inputCash){
			layerUtils.iAlert("取现金额不能为空！");
			return false;
		}
		if(parseFloat(inputCash) <= 0){
			layerUtils.iAlert("取现金额必须大于0元！");
			return false;
		}
		if(parseFloat(inputCash) > maxCash){
			layerUtils.iAlert("取现金额不能大于"+maxCash+"元！");
			return false;
		}
		if(!password && selType == "bankCard"){
			layerUtils.iAlert("资金密码不能为空！");
			return false;
		}
		if(password.length != 6  && selType == "bankCard"){
			layerUtils.iAlert("请输入6位资金密码！");
			return false;
		}
		return true;
	}
	/*
	 * 销毁页面
	 */
	function destroy(){
		$(_pageId+" .noSign").hide();
		$(_pageId+" .signed").hide();
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy
	};
	//暴露方法
	module.exports = base;
});
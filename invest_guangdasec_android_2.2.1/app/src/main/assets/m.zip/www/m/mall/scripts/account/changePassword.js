/**
 * 密码修改
 */
define(function(require, exports, module) 
	{
	var appUtils = require("appUtils");
	var gconfig = require("gconfig");
	var service = require("mobileService"); //业务层接口，请求数据
	var global = gconfig.global;
	var layerUtils = require("layerUtils");
	var _pageId ="#account_changePassword";

	/*初始化*/
	function init()
	{
		var user_name=appUtils.getSStorageInfo("user_name");
		$(_pageId+" .u_stat").html(user_name);
	}

	function bindPageEvent() 
	{

		/* 绑定返回事件 */
		appUtils.bindEvent($(_pageId+" .new_nav .icon_back"),function()
			{
			appUtils.pageBack();
			});

		/* 绑定返回首页事件 */
		appUtils.bindEvent($(_pageId+" .header .logo"),function(){
			appUtils.pageInit("account/totalAssets","account/mainPage",{});
		});

		/*点击 跳到到顶部*/
		appUtils.bindEvent($(_pageId+"  .back_btn"),function()
			{
			$('body,html').animate({
				scrollTop:0
			},
			1000);
			return false;
			});

		//点击登录
		appUtils.bindEvent($(_pageId+" .u_stat"),function(){
			appUtils.pageInit("account/changePassword","account/userCenter",{});
		});
	}

	function queryAsset(){
		var fund_account=appUtils.getSStorageInfo("fund_account");
		var param={"fund_account" : fund_account};

		/*调用查询资金接口*/
		service.queryAsset(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result = data.results;
			if(error_no == "0" && result.length != 0)
			{

			}
			else
			{
				layerUtils.iAlert(error_info);
			}
		});
	}


	function destroy()
	{
		service.destroy();
	}

	var changePassword = 
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = changePassword;

	});
/*
 * E账号激活（设置）
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	keyPanel = require("keyAbcPanel"),//软键盘
	_pageId = "#account_activateSet ";
	var cust_code = "";//分配的 E账号
	
	/*
	 * 页面初始化
	 */
	function init(){
		cust_code = appUtils.getPageParam("cust_code");
		if(cust_code){
			// 显示分配的 E账号
			$(_pageId+" .input_form strong").html(cust_code);
		}
	}
	
	/*
	 * 绑定页面事件
	 */
	function bindPageEvent(){
		
		//返回
		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(){
			appUtils.pageBack();
		});
		
		//确认激活
		appUtils.bindEvent($(_pageId+" .ce_btn>a"),function(){
			var loginName = $.trim($(_pageId+" #loginName").val());
			var setPassword = $.trim($(_pageId+" #setPassword").val());
			var checkPassword = $.trim($(_pageId+" #checkPassword").val());
			if(isInputLegal(loginName,setPassword,checkPassword)){
				service.getRSAKey({},function(data){
					if(data.error_no === "0"){
						var results = data.results[0];
						var modulus = results.modulus;
						var publicExponent = results.publicExponent;
						var endecryptUtils = require("endecryptUtils");
						var trade_pwd = endecryptUtils.rsaEncrypt(modulus,publicExponent,setPassword);
						//E账号激活
						activateEAccount(loginName,trade_pwd);
					}
				},{"isLastReq":false});
			}
		});
		
		//设置密码
		appUtils.bindEvent($(_pageId+" #setPassDiv"),function(e){
			var input_pwd = $(this);
			input_pwd.find("em").html("");  // 清空密码
			input_pwd.attr("data-password","");  // 清空密码值
			$(this).addClass("active");
			$(_pageId+" #checkPassDiv").removeClass("active");
			keyPanel.init_keyPanel(function(value){
				var curEchoText = input_pwd.find("em").html();  // 密码回显文本
				var input_pass_curPwd = input_pwd.attr("data-password") || "";  // 密码值
				var valInput=$(_pageId+" #setPassword");
				if(value == "del")
				{
					input_pwd.find("em").html(curEchoText.slice(0, -1));
					input_pwd.attr("data-password", input_pass_curPwd.slice(0, -1));
					valInput.val(input_pwd.attr("data-password"));
				}
				else
				{
					if(input_pass_curPwd.length < 12)
					{
						input_pwd.attr("data-password", input_pass_curPwd + value);  // 设置密码值
						input_pwd.find("em").html(curEchoText + "*");
						valInput.val(input_pass_curPwd + value);
					}
					else
					{
						layerUtils.iMsg(-1, "密码最多12位!");
					}
				}
			}, input_pwd);
			$("body>#keyPanel_num").css("position", "absolute");
			e.stopPropagation();
		});
		
		// 确认密码
		appUtils.bindEvent($(_pageId+" #checkPassDiv"),function(e){
			var input_pwd = $(this);
			input_pwd.find("em").html("");  // 清空密码
			input_pwd.attr("data-password","");  // 清空密码值
			$(this).addClass("active");
			$(_pageId+" #setPassDiv").removeClass("active");
			keyPanel.init_keyPanel(function(value){
				var curEchoText = input_pwd.find("em").html();  // 密码回显文本
				var input_pass_curPwd = input_pwd.attr("data-password") || "";  // 密码值
				var valInput=$(_pageId+" #checkPassword");
				if(value == "del")
				{
					input_pwd.find("em").html(curEchoText.slice(0, -1));
					input_pwd.attr("data-password", input_pass_curPwd.slice(0, -1));
					valInput.val(input_pwd.attr("data-password"));
				}
				else
				{
					if(input_pass_curPwd.length < 12)
					{
						input_pwd.attr("data-password", input_pass_curPwd + value);  // 设置密码值
						input_pwd.find("em").html(curEchoText + "*");
						valInput.val(input_pass_curPwd + value);
					}
					else
					{
						layerUtils.iMsg(-1, "密码最多12位!");
					}
				}
			}, input_pwd);
			$("body>#keyPanel_num").css("position", "absolute");
			e.stopPropagation();
		});
		
		//点击页面关闭软键盘
		appUtils.bindEvent($(_pageId),function(){
			keyPanel.closeKeyPanel();
			$(_pageId+" .input_custom").removeClass("active");
		});
	}
	
	/*
	 * 销毁页面
	 */
	function destroy(){
//		$(_pageId+" .error").html("");
		
	}
	
	/*
	 * 判断输入数据的合法性
	 */
	function isInputLegal(loginName,setPassword,checkPassword){
		var check = false;
		if(!loginName){
			layerUtils.iMsg(-1,"登录名不能为空！",1);
			check = false;
		}
		else if(loginName.length < 6 || loginName.length > 32){
			layerUtils.iMsg(-1,"登录名为6-32位字符和数字！",1);
			check = false;
		}else if(!setPassword){
			layerUtils.iMsg(-1,"设置密码不能为空！",1);
			check = false;
		}else if(!checkPassword){
			layerUtils.iMsg(-1,"重置密码不能为空！",1);
			check = false;
		}else if((setPassword.length < 6)||(setPassword.length > 12)){
			layerUtils.iMsg(-1,"重置密码的长度必须是6-12位英文或数字！",1);
			check = false;
		}else if(!(setPassword === checkPassword)){
			layerUtils.iMsg(-1,"两次输入的密码不符！",1);
			check = false;
		}else{
			check = true;
		}
		return check;
	}
	
	/*
	 * E账号激活
	 */
	function activateEAccount(loginName,trade_pwd){
		var result = JSON.parse(appUtils.getSStorageInfo("userinfo"));
		var param = {
				"cust_code":cust_code,
				"cust_pwd":trade_pwd,
				"cust_dname":loginName,
				"account":result.fund_account,
				"protocol_code":"1"
		};
		service.activateE_Account(param,function(data){
			var errorNo = data.error_no;
			var errorInfo = data.error_info;
			if(errorNo === "0"){
				var result = data.results;
				var item = result[0];
				var cust_code = item.cust_code;//客户阳光E账号
				// 改变激活状态值 cust_act_flag = 1，已经激活      
				var userInfo = JSON.parse(appUtils.getSStorageInfo("userinfo"));
				userInfo.cust_act_flag = "1";
				appUtils.setSStorageInfo("userinfo",JSON.stringify(userInfo)); // 重新保存用户信息
				appUtils.setSStorageInfo("cust_act_flag","1"); //保存E激活状态
				appUtils.pageInit("account/activateSet","account/activateFinish",{"cust_code":cust_code,"loginName":loginName});
			}else{
				layerUtils.iAlert(errorInfo);
			}
		});
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy
	};
	//暴露方法
	module.exports = base;
});
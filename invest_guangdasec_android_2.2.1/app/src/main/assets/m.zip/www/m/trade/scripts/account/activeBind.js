define(function(require,exports,module){
	var layerUtils = require("layerUtils");
	var appUtils = require("appUtils");
	var service_common = require("service_common");
	var canvasActive = require("canvasActive");
	var _pageId = "#account_activeBind ";
	var phone = null;
	var isClick = false;
	var isFirst = true;
	var gconfig = require("gconfig");
	var global = gconfig.global;
	var common = require("common");
	
	function init(){
		var browserAddress = window.location.href;
		if(window.navigator.userAgent.indexOf("Android") > -1){
			var bap = appUtils.getLStorageInfo("hardwareInformation");
			if(!bap || bap == null || bap == "undefined"){
				if(browserAddress.indexOf("?") != -1){
					browserAddress = browserAddress.substring(browserAddress.indexOf("?")+1);
					browserAddress = browserAddress.replace("?", "&");
					var browserAddressParameter = '{"' + browserAddress.replaceAll("&", '","').replaceAll("=", '":"') + '"}';
					appUtils.setLStorageInfo("hardwareInformation",browserAddressParameter);
				}
			}
		}else if(window.navigator.userAgent.indexOf("iPhone") > -1 || window.navigator.userAgent.indexOf("iPad") > -1){
			if(browserAddress.indexOf("logo") != -1){
				appUtils.setLStorageInfo("logo","iosJump");
			}
		}
		
		if(!appUtils.getLStorageInfo("acitve_phone")){
			appUtils.pageInit("account/activeBind", "account/activePhone", {phone:appUtils.getPageParam("phone"),"isFromWeiXin":appUtils.getPageParam("isFromWeiXin")});
		}else{
			phone = appUtils.getLStorageInfo("acitve_phone");
			$(_pageId+"#phone").html("您的手机号："+phone.substring(0,phone.length - 2)).show();
		}
		
		if(window.navigator.userAgent.indexOf("Android") > -1){
			var bap = appUtils.getLStorageInfo("hardwareInformation");
			if(bap && bap != null && bap != "undefined"){
				var bapObj = JSON.parse(bap);
				acitvePhone(phone,bapObj);
			}
		}else if(window.navigator.userAgent.indexOf("iPhone") > -1 || window.navigator.userAgent.indexOf("iPad") > -1){
			//判断是否已认证
			var logos = appUtils.getLStorageInfo("logo");
			if(logos && logos != null && logos != "undefined"){
				getDeviceInfo();
			}
		}

		//判断浏览器型号
		checkBrowser();

		var cHeight = $(_pageId+"#canvasMain").height();
		var cWidth = $(_pageId+"#canvasMain").width();
		$(_pageId+"#activeCanvas").css({"height":cHeight,"width":cWidth});
		var opts = {
				"fcolor1":"#5E5",
				"fcolor2":"red",
				"fcolor3":"#ccc",
				"lcolor1":"#5E5",
				"lcolor2":"red",
				"acolor1":"#5E5",
				"acolor2":"red",
				"acolor3":"white",
				"abcolor1":"#ccc",
				"abcolor2":"#ccc",
				"abcolor3":"#ccc"
		};
		canvasActive.init(opts);
	}
	
	function bindPageEvent(){
		//返回按钮
		appUtils.bindEvent($(_pageId + " .icon_back"), function(e){
			appUtils.pageInit("account/activeBind", "account/activePhone", {phone:appUtils.getPageParam("phone"),"isFromWeiXin":appUtils.getPageParam("isFromWeiXin")});
			e.stopPropagation();
		});
		
		//立即绑定
		appUtils.bindEvent($(_pageId+"#doAuth"),function(e){
			if(common.isWeiXin()){
				$("body>#jiantou").slideDown();
				$(_pageId+"#deviceInfo").html("请在系统浏览器中打开本页面<br>完成操作后请点击\"已完成操作\"");
				$(_pageId+"#doAuth").hide();
				$(_pageId+"#getDeviceInfo").show();
			}else if (common.browser.versions.ios || common.browser.versions.iPhone || common.browser.versions.iPad) { 
				appUtils.setLStorageInfo("hasClickAuth", true);//点击后，cookie中设置点击状态
				//window.location = global.iosPluginPath;
				window.location = global.iosPluginPath+"?uuid="+phone;
			}else if (common.browser.versions.android){ 
				appUtils.setLStorageInfo("hasClickAuth", true);//点击后，cookie中设置点击状态
				setTimeout(function(){
					window.location.href = global.androidPluginPath;
				},500);
				window.location.href = "thinkive://"+window.location.href+"?phone="+phone;
			}else{
				layerUtils.iAlert("请使用iOS或android设备的系统浏览器进行绑定操作");
			}
		},"click");
		
		appUtils.bindEvent($(_pageId+"#login"), function(e){
			appUtils.pageInit("account/activeBind", "account/login", {"isFromWeiXin":appUtils.getPageParam("isFromWeiXin")});
		},"click");

//		//判断是否已认证
//		if(!appUtils.getSStorageInfo("hasClickAuth")){
//			bindAuthEvent();
//		}
	}

//	function bindAuthEvent(){
//		//绑定事件
//		appUtils.bindEvent($(_pageId+"#doAuth"),function(e){
//			if(common.isWeiXin()){
//				$("body>#jiantou").slideDown();
//				$(_pageId+"#deviceInfo").html("请在系统浏览器中打开本页面<br>完成操作后请点击\"已完成操作\"");
//				$(_pageId+"#doAuth").hide();
//				$(_pageId+"#getDeviceInfo").show();
//			}
//			else if (common.browser.versions.ios || common.browser.versions.iPhone || common.browser.versions.iPad) 
//			{ 
//				appUtils.setLStorageInfo("hasClickAuth", true);//点击后，cookie中设置点击状态
//				//window.location = global.iosPluginPath;
//				window.location = global.iosPluginPath+"?uuid="+phone;
//			}
//			else if (common.browser.versions.android) 
//			{ 
//				appUtils.setLStorageInfo("hasClickAuth", true);//点击后，cookie中设置点击状态
//				setTimeout(function(){
//					window.location.href = global.androidPluginPath;
//				},500);
//				window.location.href = "thinkive://"+window.location.href+"?phone="+phone;
//			}
//			else
//			{
//				layerUtils.iAlert("请使用iOS或android设备的系统浏览器进行绑定操作");
//			}
//		},"click");
//		
//		appUtils.bindEvent($(_pageId+"#login"), function(e){
//			appUtils.pageInit("account/activeBind", "account/login", {"isFromWeiXin":appUtils.getPageParam("isFromWeiXin")});
//		},"click");
//		
//		appUtils.bindEvent($(_pageId+"#getDeviceInfo"), function(e){
//			getDeviceInfo();
//			$("body>#jiantou").slideUp();
//		},"click");
//	}
	
	function getDeviceInfo(){
		//从url参数中获取返回的设备信息
		var param;
		phone = appUtils.getLStorageInfo("acitve_phone");//缓存的已验证的手机号
		if(appUtils.getPageParam("isFromWeixin")){
			$(_pageId+"#deviceInfo").html("已完成本设备与手机"+phone.substring(0,phone.length - 2)+"的认证，请在微信中刷新页面");
		}else{
			$(_pageId+"#deviceInfo").html("正在验证绑定结果，请稍后……");
			//通过手机号查询硬件信息
			service_common.queryDeviceInfo({"uuid":phone}, function(data){
				if (data.error_no === "0"){
					var results = data.results;
					if (results.length > 0){
						var device = results[0];
						var mac = device.mac;
						var imei = device.imei;
						var os_version = device.os_version;
						var device_name = device.device_name;
						param = {
							"phone": phone,
							"imei": imei,
							"device_name": device_name,
							"os_version":os_version,
							"mac":mac
						};
						
						appUtils.setLStorageInfo("hardwareInformation",JSON.stringify(param));
						
						acitvePhone(phone,param);
//						$(_pageId+"#deviceInfo").html("设备信息获取成功，绑定手机成功!<br>"
//							+"PHONE:"+phone
//							+"<br>IMEI:"+imei);
//						$(_pageId+"#login").show();
//						$(_pageId+"#doAuth").hide();
//						$(_pageId+"#getDeviceInfo").hide();
					} else {
						$(_pageId+"#deviceInfo").html("未查询到设备信息，为保证安全性，设备信息只能查询一次，请您重新绑定");
						$(_pageId+"#doAuth").show();
						$(_pageId+"#getDeviceInfo").hide();
					}
				} else {
					layerUtils.iAlert(data.error_info);
					$(_pageId+"#deviceInfo").html("查询设备信息失败，请稍后重试");
					$(_pageId+"#doAuth").show();
					$(_pageId+"#getDeviceInfo").hide();
				}
			});
		}
	}

	/**
     * 激活客户的手机，并跳转页面
     */
//    function acitvePhone(param){
//		service_common.binDingPhone(param, function(data){
//			var errorNo = data.error_no,
//				errorInfo = data.error_info;
//			if (errorNo === "0"){
//				var results = data.results,
//					re_len = results.length;
//				if (re_len > 0){
//					var item = results[0],
//						cur = item.cur;
//					if (cur === "1"){
//						bindOk(param);
//					} else {
//						layerUtils.iAlert("绑定失败，请重试");
//					}
//				} else {
//					layerUtils.iAlert("绑定失败，请重试");
//				}
//			} else {
//				layerUtils.iAlert(errorInfo);
//			}
//    	});
//	}

	//绑定成功的后续操作
	function bindOk(param){
		//保存手机号码
		appUtils.setLStorageInfo("imei", param.imei);
		$(_pageId+"#login").show();
		$(_pageId+"#doAuth").hide();
		$(_pageId+"#getDeviceInfo").hide();
		$(_pageId+"#deviceInfo").html("恭喜您，绑定成功<br>手机号："+param.phone+"<br>IMEI："+param.imei+"<br>您可以进行交易了！").css("text-align","left");
	}
	
	function checkBrowser(){
		if(common.browser.versions.ios || common.browser.versions.android){
			if(common.isWeiXin()){
				$("body>#jiantou").slideDown();
				$(_pageId+"#deviceInfo").html("请在系统浏览器中打开本页面<br>完成操作后请点击\"已完成操作\"");
				$(_pageId+"#doAuth").hide();
				$(_pageId+"#getDeviceInfo").show();
				if(!common.getPageParam("isFromWeiXin"))
					window.location.href = window.location.href + "&isFromWeiXin=true";
			}
		}else{
			$(_pageId+"#deviceInfo").html("请在安卓或IOS设备上打开本页面<br><img src='/m1/trade/images/device-ewm.png' width='185px'>").css("text-align","center");;
		}
	}
	
	
	 function acitvePhone(iPhone,bapObj){
//    	var phoneNum = $.trim($(_pageId + " #phoneNum").val());
//		var hardsn = getRndNum(10) + " " + new Date().format("yyyy-MM-dd HH:mm:ss.S");
    	var phoneNum = iPhone;
    	var hardsn = bapObj.imei;
		var param = {
			"phone" : phoneNum,
			"hardsn": hardsn
		};
		service_common.binDingCustomerPhone(param,function(data){
			if(data.error_no == "0"){
				$(_pageId+"#deviceInfo").html("设备信息获取成功，绑定手机成功!<br>"
						+"PHONE:"+iPhone.substring(0,iPhone.length - 2)
						+"<br>IMEI:"+bapObj.imei);
				$(_pageId+"#login").show();
				$(_pageId+"#doAuth").hide();
				$(_pageId+"#getDeviceInfo").hide();
				
				global.trade_flag = phoneNum + "FZ"; //手机号码
			    appUtils.setLStorageInfo("hardsn", hardsn);
			}else{
				layerUtils.iMsg(data.error_info);
			}
			appUtils.setLStorageInfo("logo","");
		});
	 }
	
	
	function destroy(){
		$(_pageId + "#deviceInfo").html("为保证您的交易过程安全可靠，我们需要认证您正在使用的设备信息，系统将为您安装安全插件，如果您已知悉，请点击“立即绑定”，并按提示完成操作！");
		$(_pageId + "#doAuth").show();
		$(_pageId + "#login").hide();
		$(_pageId + "#getDeviceInfo").hide();
	}
	
	var base = {
		"init":init,
		"bindPageEvent":bindPageEvent,
		"destroy":destroy
	};
	module.exports = base;
	
});
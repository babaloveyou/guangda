/*
 * 风险测评结果
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	_pageId = "#xjb_riskResult ";
	
	/*
	 * 页面初始化
	 */
	function init(){
		$(_pageId+" #score").html(appUtils.getPageParam("risk_fraction")+"<span>分</span>");
		$(_pageId+" .tztype").html(appUtils.getPageParam("risk_name"));
	}
	
	/*
	 * 绑定页面事件
	 */
	function bindPageEvent(){
		
		//返回
		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(){
			appUtils.pageInit("xjb/riskResult","xjb/fxcp",{});
		});
		
		//下一步
		appUtils.bindEvent($(_pageId+" .ce_btn a"),function(){
			appUtils.pageInit("xjb/riskResult","xjb/electronicContract",{});//签署电子合同
		});

		//重新测评
		appUtils.bindEvent($(_pageId+" .test_link a"),function(){
			appUtils.pageInit("xjb/riskResult","xjb/fxcp",{});
		});
		
	}
	
	/*
	 * 销毁页面
	 */
	function destroy(){
		
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy
	};
	//暴露方法
	module.exports = base;
});
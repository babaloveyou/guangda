/**
 * 基金详情
 */
define(function(require, exports, module)
	{	
	var service = require("mobileService"); //业务层接口，请求数据
	var appUtils = require('appUtils'),
	putils = require("putils"),
	layerUtils = require("layerUtils"),
	gconfig = require("gconfig"),
	global = gconfig.global;
	var _pageId ="#mall_itemsFundInfo";
	var buy_limit = 0 ;  //限购起点
	var URL=global.url;
	//1、初始化
	function init() 
	{
		var  product_id=appUtils.getPageParam().product_id;
			if(!product_id){
				product_id=appUtils.getSStorageInfo("product_id");
				if(!product_id){//防止直接跳到详情页面
					layerUtils.iMsg(1, "数据加载错误！");
					appUtils.pageInit("mall/itemsFinanInfo","account/mainPage",{});
					return false;
				}
			}else{
				appUtils.setSStorageInfo("product_id",product_id);
			}
		var param =
		{
			"product_id":product_id

		};
		service.fundInfo(param,function(data)
			{
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}

			var perData=data.results;
			productInfo =perData[0];//保存产品信息
			var product_status=perData[0].product_status;
			if(product_status!="0" && product_status!="1" && product_status!="6")
			{
				$(_pageId+" .n2").css("background","gray");

			}
			else
			{
				$(_pageId+" .n2").css("background","#3697E7");
			}

			$(_pageId+" .cpmc").html(perData[0].product_name+'('+perData[0].product_code+')');  //产品名称(ok)+基金代码(ok)
			$(_pageId+" #product_id").val(perData[0].product_id);          //产品 id --隐藏在表单域中
			$(_pageId+" #product_status").val(perData[0].product_status);  //产品状态 --隐藏在表单域中
			$(_pageId+" #product_code").val(perData[0].product_code);      //基金代码--隐藏在表单域中
			$(_pageId+" #buy_add_pace").val(perData[0].buy_add_pace);      //步长--隐藏在表单域中
			appUtils.setSStorageInfo("product_code",product_code);
			appUtils.setSStorageInfo("product_name",perData[0].product_name);
			if(perData[0].product_description=="")
			{	

				$(_pageId+" .cpxq").html(perData[0].product_description?perData[0].product_description:'暂无数据');// 产品详情(ok);
			}
			else
			{

				$(_pageId+" .produ_text").removeAttr("style");//如果网速较慢，加载数据时样式会错位， 把style="height:90px">，然后加载完数据之前删除
				$(_pageId+" .cpxq").html(perData[0].product_description?perData[0].product_description:'无数据');// 产品详情(ok);

			}
			if(data.results[0].product_description.length>77)
			{
				var desc=data.results[0].product_description.substring(0,70);
				$(_pageId+" .cpxq").html(desc+'<a href="javascript:;" id="show"><font color="blue">····查看详情</font></a>');

				//点击详情
				$(_pageId+" #show").live("click",function(){
					$(_pageId+" .cpxq").html(data.results[0].product_description+'<a href="javascript:;" id="hide"><font color="blue"> 收起</font></a>');

					//点击回收
					$(_pageId+" #hide").live("click",function(){
						var desc=data.results[0].product_description.substring(0,70);
						$(_pageId+" .cpxq").html(desc+'<a href="javascript:;" id="show"><font color="blue">····查看详情</font></a>');
					})
				});
			}
			buy_limit=perData[0].per_buy_limit;
			$(_pageId+" .produ_img").html("<img src="+URL+perData[0].logo_url+">");//图片
			$(_pageId+" #buyValue").val(perData[0].per_buy_limit).attr("data-origin",perData[0].per_buy_limit);//产品价格(ok)
			$(_pageId+" .ljsy").html(perData[0].cumulative_net?perData[0].cumulative_net:"--") ;// 累积净值(ok)
			$(_pageId+" .tzlx").html(putils.tz_fund_type(perData[0].fund_type)?putils.tz_fund_type(perData[0].fund_type):"--") ;//投资类型(ok)
			$(_pageId+" #cpjj").html(perData[0].product_detail_4_phone?perData[0].product_detail_4_phone:"--");//产品简介(手机端)(ok)
			$(_pageId+" .drjz").html(perData[0].current_price?perData[0].current_price+",<font color='red' size='4'>"+perData[0].yieldrate1d+'%</font>':"---");//产品净值(ok)
			$(_pageId+" .kfzt").html(putils.prstor( $(_pageId+" #product_status").val())?putils.prstor( $(_pageId+" #product_status").val()):"---");//开放状态(ok)
			$(_pageId+" .fxdj").html(putils.risk_level(perData[0].risk_level))//风险等级(ok)
			$(_pageId+" .rgqd").html(perData[0].per_buy_limit?perData[0].per_buy_limit:"---"); // 认购起点(ok)
			$(_pageId+" .f1").html(perData[0].product_name?perData[0].product_name:"---");//产品名称(ok)
			$(_pageId+" .f2").html(perData[0].product_code?perData[0].product_code:"---");//基金代码(ok)
			$(_pageId+" .f3").html(perData[0].found_time?perData[0].found_time:"---");//上市时间(ok)
			$(_pageId+" .f4").html(perData[0].risk_feature?perData[0].risk_feature:"---");// 风险收益特征 
			$(_pageId+" .f5").html(perData[0].manager_name?perData[0].manager_name:"---");// 基金管理人(ok)
			$(_pageId+" .f6").html(perData[0].custodian?perData[0].custodian:"---");// 基金托管人 (ok)
			$(_pageId+" .f7").html(perData[0].invest_objective?perData[0].invest_objective:"---");//投资目标(ok)
			$(_pageId+" .f8").html(perData[0].invest_scope?perData[0].invest_scope:"---");//投资范围
			$(_pageId+" .f9").html(perData[0].invest_strategy?perData[0].invest_strategy:"---");//投资策略 (ok)
			$(_pageId+" .f10").html(perData[0].benchmark?perData[0].benchmark:"---");//业绩比较基准(ok)
			});
	}


	//基金产品购买
	function fundbuy()
	{
		//检查是否可购买
		var product_status=$(_pageId+" #product_status").val();
		var tot_price =$(_pageId+" #buyValue").val();   //购买金额
		var person_pace = $(_pageId+" .rgqd").html();   //认购起点

		if(tot_price>0&&tot_price!=null)
		{
			var buyValue= $(_pageId+"  #buyValue").val();  //购买金额
			var buy_pace=$(_pageId+" #buy_add_pace").val();   //步长


			if(buy_pace==""||buy_pace=="0")
			{
				buy_pace="1"

			}
		/*	if((buyValue-buy_limit)%buy_pace!=0)
			{
				layerUtils.iMsg(0,"输入金额必须是"+buy_pace+"的整数倍！");
				return false;
			}*/

			//1、判断购买是否金额大于认购起点
			if(parseFloat(tot_price) < parseFloat(person_pace)){
				layerUtils.iMsg(-1,"购买的金额不能低于"+person_pace);
				return false;
			}

			//2、检查是否已经登录
		/*	if(appUtils.getSStorageInfo("_isLoginIn") != "true")
			{
				appUtils.setSStorageInfo("_loginInPageCode", "mall/itemsFundInfo");
				appUtils.setSStorageInfo("_loginInPageParam", JSON.stringify(appUtils.getPageParam()));
				appUtils.pageInit("mall/itemsFundInfo", "account/userLogin");
				return false;
			}*/
			//3、判断是否是开放期
			if(product_status!="0" && product_status!="1" && product_status!="6")
			{
				layerUtils.iMsg(0, "不是开放期，不能购买");
				return false;
			}

			var param=
			{
				"user_id": appUtils.getSStorageInfo("user_id"),
				"product_name": $(_pageId+" .cpmc").html(),
				"product_id": productInfo.product_id,
				"tot_price": $(_pageId+" #buyValue").val()//购买产品的总价格
			};
			appUtils.setSStorageInfo("tot_price",tot_price);
//		
			appUtils.setSStorageInfo("paramConfirmOrder",JSON.stringify(param));
			appUtils.pageInit("mall/itemsFundInfo","mall/fundOrder/confirmOrder",param);
		}
		else
		{
			layerUtils.iMsg(0, "购买金额填写有误，请确认!");
		}

	}


	//添加关注
	function addattention()
	{
		var user_id = appUtils.getSStorageInfo("user_id");  //从seesion获得用户编号
		var product_id= productInfo.product_id;             //获得产品编号
		var product_sub_type = productInfo.product_sub_type;//获得产品类别
		var param ={
			"user_id":user_id,
			"product_id":product_id,
			"product_sub_type":product_sub_type
		};
		service.addAttention(param,function(data)
		{
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				return false;
			}
			else
			{
				layerUtils.iMsg(-1,"关注成功！");
			}
		});
	}
	//购买金额的加减
	function  addAndMin (par)
	{ 
		var buy_value =$(_pageId+" #buyValue").val();  //追加购买
		var buy_pace=$(_pageId+" #buy_add_pace").val();//购买步长

		//判断步长是否为0 ，如果为0，初始化1 
		if(buy_pace==""||buy_pace=="0")		
		{
			buy_pace="1";
		}
		console.info("购买步长"+buy_pace);

		if(buy_value!=null&&buy_value!="")
		{
			//点击+
			if(par=="add")
			{
				var sum= parseFloat(buy_value)+parseFloat(buy_pace);

				$(_pageId+" #buyValue").val((sum.toFixed(2)));
			}
			else if(par=="min")
			{
				if(parseFloat(buy_value)<=parseFloat($(_pageId+" .rgqd").html()))
				{
					layerUtils.iMsg(-1,"购买的金额不能低于"+parseFloat($(_pageId+" .rgqd").html()));
					$(_pageId+" #buyValue").val(parseFloat($(_pageId+" .rgqd").html()).toFixed(2));
					return false;
				}
				var minc= parseFloat(buy_value)-parseFloat(buy_pace);

				$(_pageId+" #buyValue").val((minc.toFixed(2)));
			}

		}
	}
	
	//判断是否是交易日
	function dealTimeSyn()
	{
		var param=
		{
			"date":""
		}
		service.dealTimeSyn(param,function(data){
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			} 
			else if(data.results[0].is_trade=='0')
			{
				layerUtils.iAlert("当前是非交易时间，理财和基金产品暂停交易。");
				return false;
			}
			else{
				fundbuy();//立即购买
			}

		})
	}

	//2、事件绑定
	function bindPageEvent()
	{

		//点击 立即购买
		appUtils.bindEvent($(_pageId+" .icon_buy"),function(){
			dealTimeSyn();
			});

		//点击 增加购买金额
		appUtils.bindEvent($(_pageId+" .icon_add"),function(){addAndMin("add");});

		// 点击 减少购买金额
		appUtils.bindEvent($(_pageId+" .icon_less"),function(){addAndMin("min");});

		// 点击 关注 
		appUtils.bindEvent($(_pageId+" .icon_fav"),function(){addattention();});

		// 点击返回 
		appUtils.bindEvent($(_pageId+"  .icon_back"),function(){
			var gobackmain=appUtils.getPageParam("gobackmain");
			if(gobackmain){
	            var param_index = {"funcNo":"50101","moduleName":"main"};
	            require("external").callMessage(param_index);
			}else{
				appUtils.pageBack();
			}
		
		});

		//点击 返回顶部
		appUtils.bindEvent($(_pageId+" .back_top .back_btn"),function(){
			$(document.body).ScrollTo(0);
//			$('html,body').animate({scrollTop:0},700);
			return false;
		});
		
		$(window).scroll(function(){  //只要窗口滚动,就触发下面代码 
			var scrollt = document.documentElement.scrollTop + document.body.scrollTop; //获取滚动后的高度 
			if( scrollt >200 ){  //判断滚动后高度超过200px,就显示  
			       $(_pageId+" .back_top .back_btn").fadeIn(400); //淡出     
			}else{      
			       $(_pageId+" .back_top .back_btn").stop().fadeOut(400); //如果返回或者没有超过,就淡入.必须加上stop()停止之前动画,否则会出现闪动   
			}
			});
		
		// 点击首页
		appUtils.bindEvent($(_pageId+" #mainPage"),function(){appUtils.pageInit("mall/itemsFundInfo","account/mainPage",{});});

		// 点击理财
		appUtils.bindEvent($(_pageId+" #finan"),function() { appUtils.pageInit("mall/itemsFundInfo","mall/itemsFinan",{});});

		// 点击基金
		appUtils.bindEvent($(_pageId+" #fund"),function(){appUtils.pageInit("mall/itemsFundInfo","mall/itemsFund",{});});

		//点击 LOGO 
		appUtils.bindEvent($(_pageId+" .logo"),function(){appUtils.pageInit("mall/itemsFundInfo","account/mainPage")});

		//判断输入是否合法
		appUtils.bindEvent($(_pageId+" #buyValue"),function(){putils.numberLimit($(this));},"keyup");

		//控制输入不能为空
		appUtils.bindEvent($(_pageId+" #buyValue"),function(){
			if($(this).val()==null||$(this).val()==""){
				$(this).val(0);
			}
			$(this).val(putils.moneyFormat($(this).val()));

		},"blur");

		// 点击 个人中心 
		appUtils.bindEvent($(_pageId+" .icon_info"),function(){
			appUtils.pageInit("mall/itemsFundInfo","account/userCenter",{});
		});
	}

	//3、销毁
	function destroy()
	{
		var product_id="";
	}
	var itemsFundInfo =
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = itemsFundInfo;

	});
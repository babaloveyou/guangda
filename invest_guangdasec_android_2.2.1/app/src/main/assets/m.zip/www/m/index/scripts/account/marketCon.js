/**
 * 退市整理
 */
define(function(require, exports, module){
	/*模块内部全局变量*/
	var appUtils = require("appUtils"),
		layerUtils = require("layerUtils"),
		gconfig = require("gconfig"),
		global = gconfig.global,
		service = require("serviceImp"),  //业务层接口，请求数据
		_pageId = "#account_marketCon";
	var carouselScroll = {"scroll":null,"_init":false};
	
	var fund_account;
	var branch_no;
	var xy_list;       //协议集合
	var isFlag = "";//首次交易日是否满足条件
	var risk_level_valid="";//风险测评是否过期，0表示已过期
	var cust_type = "";//客户类型
	var total_net_asset = 0;//总资产
	var account;          //股票代码
	var market;           //市场
	var user_id="";
	
	/*页面初始化方法*/
	function init()
	{
		fund_account = appUtils.getSStorageInfo("fund_account");
		branch_no = appUtils.getSStorageInfo("branch_no");
		total_net_asset = 0;
		isFlag = "";
		if(appUtils.getSStorageInfo("_prePageCode")=="account/queryRzrqMoney"){
			total_net_asset = appUtils.getPageParam("marketvalue")||"0";
		}

		//清理保存的选择账号
		if(appUtils.getSStorageInfo("_prePageCode")=="account/userCenter"){
			appUtils.clearSStorage("accountSelect");
		}
		initPage();
	}
	
	function initPage(){
		service.queryAccountInfo({"fund_account":fund_account,"branch_no":branch_no},function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			
			if(error_no==0){
				var result = data.results;
				risk_level_valid = result[0].risk_level_valid;
				cust_type=result[0].cust_type;
//				layerUtils.iAlert(total_net_asset+"|"+result[0].net_asset+"|"+user_id+"|"+appUtils.getSStorageInfo("_prePageCode"))
				total_net_asset = Number(result[0].net_asset)+Number(total_net_asset);
				user_id = result[0].user_id;

				$(_pageId + " .user_box strong").text(fund_account);
				$(_pageId + " .delist_info p:eq(1)").html("<span>风险测评状态</span>"+
														(result[0].risk_level == "--"&&"未做测评"||result[0].risk_level_name)+
														((result[0].risk_level_valid=="0"||result[0].risk_level=="--")&&
														"<a href='javascript:void(0)'>测评</a>"||""));
				$(_pageId + " .two").html("<span>资产</span><a href='javascript:void(0)'>转 入</a><a href='javascript:void(0)'>合并资产</a>"
													+ overAMillion(total_net_asset));
				
				//绑定合并资产按钮
				bindRzrq();

				if(result[0].risk_level_valid!="1"){
					bindRiskAssessment(_pageId + " .delist_info p:eq(1) a");//跳转风险测评
				}
													
				queryStockAcccount();
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(error_info);
			}
		},{"isLastReq":false});
	}

	//资产过万转化
	function overAMillion(num){
		num = Number(num);
		if(num >= 10000){
			num = (num/10000).toFixed(2) + "万";
		}
		return num;
	}

	//跳转风险测评
	function bindRiskAssessment(data){
		appUtils.bindEvent($(data),function(e){
        			var toPage = "";
        			if(gconfig.platform == "2"){
        				toPage={"prefix":"www/m/mall","suffix":"account/riskAssessment","prePage":"fz_marketCon"};
        			}else{
        				toPage = "/mall/index.html#!/account/riskAssessment.html?prePage=fz_marketCon";
        			}
        			var param = {"funcNo":"50101","moduleName":"user-center","params":{"moduleName":"financial-mall","toPage":toPage}};
        			require("external").callMessage(param);
        		});
	}

	//绑定合并资产按钮
	function bindRzrq(){
		appUtils.bindEvent($(_pageId + " .two a:last"),function(){
			appUtils.pageInit("account/marketCon","account/queryRzrqMoney",{"user_id":user_id});
		});

		appUtils.bindEvent($(_pageId + " .two a:first"),function(){
        			var toPage = "";
					if(gconfig.platform == "2"){
						toPage={"prefix":"www/m/mall","suffix":"account/bankTransfer","prePage":"fz_marketCon"};
					}else{
						toPage = "/mall/index.html#!/account/bankTransfer.html?prePage=fz_marketCon";
					}
					var param = {"funcNo":"50101","moduleName":"user-center","params":{"moduleName":"financial-mall","toPage":toPage}};
					require("external").callMessage(param);
        });

	}
				
	//查询股东信息
	function queryStockAcccount(){
		var param = {"fund_account":fund_account,
					"branch_no":branch_no,
					"user_id":user_id,
					"market":""};
		service.queryStockAcccount(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			
			if(error_no == 0){
				var result = data.results;
				$(_pageId + " .input_select").html("<label>申请开通账号</label><div class='sel_list'><strong type=''>请选择账户</strong></div>");

				var accountSelect = appUtils.getSStorageInfo("accountSelect");
				for(var i=0;i<result.length;i++){
					if(accountSelect == result[i].account){
						$(_pageId + " .sel_list:first strong").text(accountSelect);
                        $(_pageId + " .sel_list:first strong").attr("type",result[i].type);
                        queryFirstTime(accountSelect,result[i].type);
					}
					$(_pageId + " .input_select").append("<ul type='" + result[i].type +"' class='list' style='display:none;background-color:white;z-index: 1000;position: inherit'>" + result[i].account+ "</ul>");
				}
				//绑定点击事件
				bindSelsctStock();
				
				//查询协议
				queryXyName();
				
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(error_info);
			}
		},{"isLastReq":false});
	}
	
	//查询协议
	function queryXyName(){
		var param = {"category_englishname":"ts_protcl",
					"category_no":"",
					"econtract_no":""};
		service.queryXyname(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			
			if(error_no == 0){
				xy_list = data.results;
				var str = "";
				for(var i=0;i<xy_list.length;i++){
					str += "<p value='"+ i +"'><a href='javascript:void(0)'>《"+ xy_list[i].econtract_name +"》</a></p>";
				}
				$(_pageId + " .inner_rule").html(str);
				
				//绑定查看协议
				appUtils.bindEvent($(_pageId + " .inner_rule p"),function(){
					appUtils.pageInit("account/marketCon","account/showProtocol",{"econtract_no":xy_list[Number($(this).attr("value"))].econtract_no});
				});
			}else{
				layerUtils.iAlert(error_info);
			}
		});
	}
	
	//绑定点击选择账户事件
	function bindSelsctStock(){
		appUtils.bindEvent($(_pageId + " .sel_list:first"),function(e){
			$(_pageId + " .input_select ul").toggle();
			e.stopPropagation();
		});
		
		//选择账户
		appUtils.bindEvent($(_pageId + " .input_select ul"),function(e){
			account = $(this).text();
			market = $(this).attr("type");
			$(_pageId + " .sel_list:first strong").text(account);
			$(_pageId + " .sel_list:first strong").attr("type",market);
			$(_pageId + " .input_select ul").toggle();
			appUtils.setSStorageInfo("accountSelect",account);
			e.stopPropagation();
			isFlag = "";
			//查询首次交易日期
			queryFirstTime(account,market);
		});
		
		appUtils.bindEvent($(_pageId),function(){
			$(_pageId + " .input_select ul").hide();
		});
	}
	
	//查询首次交易日期
	function queryFirstTime(account,market){
		var param = {"stock_type":market,
					"stock_code":account,
					"user_id":user_id,
					"type":"3"};
		service.queryFirstTime(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			if(error_no==0){
				var result = data.results;
				if(result.length>0){
					$(_pageId + " .delist_info p:eq(3)").html("<span>首次交易日期</span>" + result[0].fristDate);
					isFlag = result[0].isFlag;
					if(isFlag!="0"){
//						layerUtils.iAlert("首次交易日期未查询到，或不满足交易经验超过两年的要求");
					}
				}else{
//					layerUtils.iAlert("首次交易日期未查询到，或不满足交易经验超过两年的要求");
				}
			}else{
//				layerUtils.iAlert(error_info);
			}
		},{"isShowWait":false});
	}
	/*绑定页面事件的方法*/
	function bindPageEvent()
	{
		/*返回*/
		appUtils.bindEvent($(_pageId+" .icon_back,"+_pageId+" .fix_bot>.ce_btn"), function(e){
			appUtils.pageInit("account/marketCon","account/userCenter");
			e.stopPropagation();
		});
		
		/* 进入光大富尊主页 */
		appUtils.bindEvent($(_pageId+" .b1"),function(e){
		    appUtils.setLStorageInfo("isGuided", true);
//			require("external").callFunction("55033", "");
		    var param_index = {"funcNo":"50101","moduleName":"launcher"};
//          require("external").callMessage(param_index);
            e.stopPropagation();
			appUtils.pageInit("account/guide","account/active");
		});
		
		//签署协议
		appUtils.bindEvent($(_pageId + " .rule_check span"),function(){
			$(this).toggleClass("active");
		});
		
		//申请开通事件
		appUtils.bindEvent($(_pageId + " .delist_btn a"),function(){
			if(checkInfo()){
				querySignInfo();//查询退市整理签约情况
			}
		});
	}
	
	//查询退市整理签约情况
	function querySignInfo(){
		var param = {"fund_account":fund_account,
					"branch_no":branch_no,
					"user_id":user_id,
					"market_code":market,
					"stock_code":account,
					"access_type":"T",
					"mode_operation":"3",
					"market_codes":market};
				
		service.querySignInfo(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			
			if(error_no==0){
				var result = data.results;
				if(result[0].access_type=="T"){
					layerUtils.iAlert("您已经签过约，不需要重复签约。");
				}else{
					SignCheck();//验签
				}
			}else{
				layerUtils.iAlert(error_info);
			}
		});
	}
	
	//验签
	function SignCheck(){
		var protocolArray = new Array();  // 存放协议签名值
		for(var k=0;k<xy_list.length;k++){
			// 添加值到数组中
			var protocol = {
				"protocol_id" : xy_list[k].econtract_no,
				"protocol_dcsign" : "",
				"summary":xy_list[k].econtract_md5
			}
			protocolArray.push(protocol);
		}
		
		var param = {"user_id":user_id,
					"jsondata":JSON.stringify(protocolArray),
					"checksign":"1"};
		service.signCheck(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			
			if(error_no==0){
				var param = {"fund_account":fund_account,
					"branch_no":branch_no,
					"user_id":user_id,
					"market_code":market,
					"stock_code":account,
					"access_type":"T",
					"mode_operation":"1",
					"market_codes":market};
				
				service.querySignInfo(param,function(data){
					var error_no = data.error_no;
					var error_info = data.error_info;
					
					if(error_no==0){
						layerUtils.iAlert("您的业务权限已开通成功，请注意投资风险。");
					}else{
						layerUtils.iAlert(error_info);
					}
				});
					
			}else{
				layerUtils.iAlert(error_info);
			}
		
		});
	}
	
	//检查申请条件
	function checkInfo(){
//		return 1;
		if (risk_level_valid == "1") {
			if (cust_type == "1") {
				if (Number(total_net_asset) >= 500000) {
					if (isFlag == "0") {
						if ($(_pageId + " .sel_list:first strong").attr("type") !="") {
							if ($(_pageId + " .rule_check span").hasClass("active")) {
								return true;
							} else {
								layerUtils.iAlert("请勾选同意签署");
								return false;
							}
						} else {
							layerUtils.iAlert("请选择您要签署的股东账户！");
							return false;
						}
					} else {
						layerUtils.iAlert("首次交易日期未查询到，或不满足交易经验超过两年的要求");
						return false;
					}
				} else {
					layerUtils.iAlert("账户资金不足50万元");
					return false;
				}
			} else if ($(_pageId + " .sel_list:first strong").attr("type") !="") {
				if ($(_pageId + " .rule_check span").hasClass("active")) {
					return true;
				} else {
					layerUtils.iAlert("请勾选同意签署");
					return false;
				}
			} else {
				layerUtils.iAlert("请选择您要签署的股东账户！");
				return false;
			}
		} else {
			layerUtils.iAlert("请进行风险测评");
			return false;
		}
	}
	
	/*页面销毁方法*/
	function destroy()
	{
		$(_pageId + " .user_box strong").text("");
		$(_pageId + " .delist_info p:eq(1)").html("<span>风险测评状态</span>" + "未做测评<a href='javascript:void(0)'>测评</a>");
		$(_pageId + " .two").html("<span>资产</span><a href='javascript:void(0)'>转 入</a><a href='javascript:void(0)'>合并资产</a>");
		$(_pageId + " .delist_info p:eq(3)").html("<span>首次交易日期</span>");
		$(_pageId + " .input_select").html("<label>申请开通账号</label><div class='sel_list'><strong type=''>请选择账户</strong></div>");
		service.destroy();
	}
	
	/*向外暴露的 JSON 对象*/
	var guide = {
			"init" : init,
			"bindPageEvent" : bindPageEvent,
			"destroy" : destroy
	};
	
	/*对外暴露 JSON 对象*/
	module.exports = guide;
});
/**
 * 基金列表
 */
define(function(require, exports, module) 
	{
	var service = require("mobileService"); //业务层接口，请求数据
	var appUtils = require('appUtils'),
	layerUtils = require("layerUtils"),
	putils = require("putils"),
	gconfig = require("gconfig"),
	global = gconfig.global,
	FIscroll = require("fIscroll"),
	VIscroll = require("vIscroll");
	var _pageId ="#mall_itemsFund";
	var constants=require("constants");//常量类
	var customVIscroll = {"scroll":null, "_init":false}; // 上下滑动
	var fixScrollArray = [{"scroll":null,"_init":false}];
	var pagingScrollArray = [{"scroll":null,"_init":false}];
	var pagingObjArr = [{"total_pages":0,"curr_page":0}]; //消息分页对象数组，这个页面只有一个分页，简单分页
	var globalFunc = require("globalFunc");
	var product_performance="1m";
//	var fundType="";
//	var risk_level="";
//	var is_nav="";
//	var performance_sort="";
	
//	var iFlag = true;

	//1、初始化
	function init() 
	{
		clearPageElements();  // 清理页面元素
		configFund();
		//globalFunc.backIndex($(_pageId+" .back_app")); // 返回App首页
		$(_pageId+" .tab_nav ul li:eq(2)").addClass(" active").siblings("li").removeClass(" active");

	}

	//初始化基金
	function configFund ()
	{
		/*左右滑动组件 end*/

		//1、查询基金列表，返回结果集
		var param =
		{
			"product_shelf":constants.product_shelf.SHELF_ON,
			"comp_ecommend_type":"",
			"recommend_type":"",
			"fund_type":"",
			"register_corp_code":"",
			"risk_level":"",
			"amount":"",
			"create_time":"",
			"is_nav":"",
			"product_performance":"1m",
			"performance_sort":"0",
			"page":"1",
			"numPerPage":10,
			"is_hot_sale":""

		}
		service.findFund(param,function(data)
			{
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}

			//2、拿到结果集，传入到fundItems中
			fundItems(data);
			if(!pagingScrollArray._init)
			{
				var pagingConfig = {
					isPagingType:true,
					container : $(_pageId+" #v_container_funds_jj"), //container元素
					wrapper: $(_pageId+" #v_wrapper_funds_jj"), //wrapper元素
					isHead : false,
					perRowHeight : 30 ,
					rowNum : 11,
					wrapperObj: null,
					downHandle : function() {
					handlePreNextPage(-1);
					pagingScrollArray[0].scroll.refresh();
				},
				upHandle : function(){
					handlePreNextPage(1);
					pagingScrollArray[0].scroll.refresh();
				}
				};
				pagingScrollArray[0].scroll = new VIscroll(pagingConfig); //初始化
				pagingScrollArray[0]._init = true; //尽量只初始化一次，保持性能
			}
			else
			{
				pagingScrollArray[0].scroll.refresh();
			}
			});


	}


	//3、处理结果集信息
	function fundItems(data) {
		var total_pages = data.results[0].totalPages;
		var curr_page = data.results[0].currentPage;
		var total_rows = data.results[0].totalRows;
		total_pages = total_pages ? total_pages : 0;
		curr_page = curr_page ? curr_page : 0;
		total_rows = total_rows ? total_rows : 0;//总条数
		pagingObjArr[0].total_pages = total_pages;
		$(_pageId + " em[name='totalPage']").html(total_pages);
		pagingObjArr[0].curr_page = curr_page;
		$(_pageId + " em[name='curPage']").html(curr_page);
		//显示多少条数据
		$(_pageId + " #totalNum").html(total_rows);


		//上一页、下一页disabled效果
		if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
			$(_pageId + " span[name='aNextPage']").removeClass("blue");
			$(_pageId + " span[name='aPrePage']").addClass("blue");
		}
		else if (pagingObjArr[0].curr_page == 1) {
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + " span[name='aNextPage']").addClass("blue");
		}
		else {
			$(_pageId + " span[name='aPrePage']").addClass("blue");
			$(_pageId + " span[name='aNextPage']").addClass("blue");
		}

		if (pagingObjArr[0].total_pages<2) {
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + "  span[name='aNextPage']").removeClass("blue");
		}


		var list =  data.results[0].data;
		var len = list.length;
		if(len<1)
		{

			$(_pageId+" #container_funds_jj .isc_item_fixed  .isc_item:not(:eq(0))").remove();
			$(_pageId+"  #container_funds_jj #scroller_funds_jj .isc_item:not(:eq(0))").remove();
		}
		else
		{
			for( var i = 0; i<len ; i++)
			{
				var perData = list[i];
				var itemsStrArr=handlePerItem(perData,i);

				$(_pageId+" #container_funds_jj .isc_item_fixed").append(itemsStrArr[0]);
				$(_pageId+"  #container_funds_jj #scroller_funds_jj").append(itemsStrArr[1]);
			}

			//点击 购买跳转到详情
			appUtils.bindEvent($(_pageId+" .isc_item span a[product-id]"),function(e){
//				if(iFlag)
//				{
//					iFlag = false;
//				}
				var pageInParam = {
						"product_id" :$(this).attr("product-id"),
						"product_status": $(this).attr("product_status"),
				};
				appUtils.pageInit("mall/itemsFund", "mall/itemsFundInfo",pageInParam);
				e.stopPropagation();
			},"click");

			//点击 名字跳转到详情
			appUtils.bindEvent($(_pageId+" .isc_item span[product-id]"),function(e){
				var pageInParam=
				{
					"product_id" : $(this).attr("product-id"),
					"product_status": $(this).attr("product_status")
				}
				appUtils.pageInit("mall/itemsFund", "mall/itemsFundInfo",pageInParam);
				e.stopPropagation();
			});
		}
		
		/*左右滑动组件 begin*/
		if(!fixScrollArray._init)
		{
			var config = {
				container: $(_pageId+" #container_funds_jj"), //container元素
				wrapper: $(_pageId+" #wrapper_funds_jj"), //wrapper元素
				wPerColumn: [90,110,80,80,90,80,100], //自定每列的宽度
				wrapperObj: null
			};
			fixScrollArray[0].scroll = new FIscroll(config); //初始化
			fixScrollArray[0]._init = true; //尽量只初始化一次，保持性能
		}
		else
		{
			fixScrollArray[0].scroll.setCssHW();
		}


	}



	//处理每一条数据，做展示
	function handlePerItem(perData,idx)
	{
		var allRecommendStr="";
		var allfoaxmentStr="";
		var product_id =  perData.product_id;      //基金ID
		var product_name= perData.product_name;    //基金名称
		var product_abbr= perData.product_abbr;    //基金简称
		var product_code = perData.product_code;   //基金代码
		var current_price=perData.current_price;   //单位净值
//		var cumulative_net=perData.cumulative_net  //累计净值
		var yieldrate1d= perData.yieldrate1d;    //日收益率
		var yieldrate1m= perData.yieldrate1m;    //近1个月收益率
		var yieldrate3m= perData.yieldrate3m;    //近3个月收益率
//		var yieldratety= perData.yieldratety;    //年收益率
		var product_status=perData.product_status; //申购状态(产品状态)
			
		allRecommendStr+= "<div class=\"isc_item\" data-idx=\""+idx+"\"  id=\"product_name"+idx+"\" style=\"cursor:pointer;\">" +
		"<span style='width:90px;padding:0 5px; white-space:nowrap; text-overflow:ellipsis; overflow:hidden;' id=\"productid\"  product-id='"+product_id+"' product_status='"+product_status+"' ><a class=\"ct_btn2\" href=\"javascript:;\" id=\"buyItemBtn"+idx+"\" product_status='"+product_status+"'  product-id='"+product_id+"' >购买</a></span></div>";
		allfoaxmentStr += '<div class="isc_item"><span  style="width:110px; white-space:nowrap; text-overflow:ellipsis; overflow:hidden;" product-id='+product_id+' product_status='+product_status+'>'+product_abbr+'</span><span>'+current_price+'</span> <span>'+putils.prstor(product_status)+'' +
		'</span><span style="width:90px; ">'+yieldrate1d+'</span> <span>'+yieldrate1m+'' +
		'</span><span>'+yieldrate3m+'</span></div>';
		return [allRecommendStr,allfoaxmentStr];

	}


	//处理 点击 上一页，下一页
	function handlePreNextPage(direction)
	{
		var total_pages = pagingObjArr[0].total_pages;
		var  curr_page = pagingObjArr[0].curr_page;
		var  curPageNo = parseInt(curr_page) + direction ;
//		var fundType =$(_pageId+"  #fundType").val();
		var risk_level=$(_pageId+" .riskLevel0 li[class='active']").attr("data-value");
		var fundType=$(_pageId+" .fundsType0 li[class='active']").attr("data-value");
		   if($(_pageId+" .sortOrder0 li[class='active']").attr("data-value")=="1m"){
				product_performance=$(_pageId+" .sortOrder0 li[class='active']").attr("data-value");
			}
			else{
				var is_nav=$(_pageId+" .sortOrder0 li[class='active']").attr("data-value");
			}
		if(curPageNo>0 && curPageNo <= total_pages && curPageNo != curr_page) //有效执行跳转页面条件
		{
			var param =
			{
				"product_shelf":constants.product_shelf.SHELF_ON,
				"comp_ecommend_type":"",
				"recommend_type":"",
				"register_corp_code":"",
				"amount":"",
				"create_time":"",
				"fund_type":fundType,
			    "risk_level":risk_level,
				"is_nav":is_nav,
				"product_performance":product_performance,
				"performance_sort":"0",
				"page":curPageNo,
				"numPerPage":"10",
				"is_hot_sale":""
			}
			service.findFund(param,function(data)
				{
				if(data.error_no!="0")
				{
					layerUtils.iAlert(data.error_info);
					layerUtils.iLoading(false);
					return false;
				}
				$(_pageId+" #container_funds_jj .isc_item_fixed  .isc_item:not(:eq(0))").remove();
				$(_pageId+"  #container_funds_jj #scroller_funds_jj .isc_item:not(:eq(0))").remove();
				fundItems(data);

				});

		}
	}



	//2、事件绑定
	function bindPageEvent()
	{
	    /* 绑定返回我的富尊主页 */
        appUtils.bindEvent($(_pageId+" .header .back_app"),function(e){
            var param_index = {"funcNo":"50101","moduleName":"main"};
            require("external").callMessage(param_index);
            e.stopPropagation();
        });
        //		基金分类
		appUtils.bindEvent($(_pageId+"  .select_link"),function(){
			$(_pageId+" .pop_filter").show();
		});

		//点击 上一页、下一页
		appUtils.bindEvent($(_pageId+" span[name='aPrePage']"),function(){handlePreNextPage(-1);});
		appUtils.bindEvent($(_pageId+" span[name='aNextPage']"),function(){ handlePreNextPage(1);});
		
		// 点击首页 
		appUtils.bindEvent($(_pageId+" #mainPage"),function(){appUtils.pageInit("mall/itemsFund","account/mainPage",{});});

		// 点击理财
		appUtils.bindEvent($(_pageId+" #finan"),function(){appUtils.pageInit("mall/itemsFund","mall/itemsFinan",{});});

		//点击资讯
		appUtils.bindEvent($(_pageId+" #info"),function()	{appUtils.pageInit("mall/itemsFund","mall/itemsInfo",{});});

		// 点击基金 
		appUtils.bindEvent($(_pageId+" #fund"),function(){appUtils.pageInit("mall/itemsFund","mall/itemsFund",{});});

		// 点击服务 
		appUtils.bindEvent($(_pageId+" #serv"),function(){appUtils.pageInit("mall/itemsFund","mall/itemsServ",{});});
		
		//点击OTC
		appUtils.bindEvent($(_pageId+" #otc"),function(){appUtils.pageInit("mall/itemsFund","mall/itemsOTC",{});});

		//点击 LOGO 
		appUtils.bindEvent($(_pageId+" .logo"),function(){appUtils.pageInit("mall/itemsFund","account/mainPage")});

		//点击 返回顶部
		appUtils.bindEvent($(_pageId+" .back_btn"),function(){$('body,html').animate({scrollTop:0},1000);return false;});


		//点击 个人中心 
		appUtils.bindEvent($(_pageId+"  .icon_info"),function()
			{
				appUtils.pageInit("mall/itemsFund","account/userCenter",{});
			});
		
		//点击搜索图标 
		appUtils.bindEvent($(_pageId+" .icon_search"),function(){appUtils.pageInit("mall/itemsFund","mall/fundSearch",{"product_sub_type":"0"})});
		
		//基金类型筛选
		appUtils.bindEvent($(_pageId+" .fundsType"),function(){
			$(_pageId+" .filt_tab ul li:eq(0)").addClass(" active").siblings("li").removeClass(" active");
			$(_pageId+" .fundsType0").show();
			$(_pageId+" .riskLevel0").hide();
			$(_pageId+" .sortOrder0").hide();
		});
		//风险等级筛选
		appUtils.bindEvent($(_pageId+" .riskLevel"),function(){
			$(_pageId+" .filt_tab ul li:eq(1)").addClass(" active").siblings("li").removeClass(" active");
			$(_pageId+" .fundsType0").hide();
			$(_pageId+" .riskLevel0").show();
			$(_pageId+" .sortOrder0").hide();
		});
		//排序方式筛选
		appUtils.bindEvent($(_pageId+" .sortOrder"),function(){
			$(_pageId+" .filt_tab ul li:eq(2)").addClass(" active").siblings("li").removeClass(" active");
			$(_pageId+" .fundsType0").hide();
			$(_pageId+" .riskLevel0").hide();
			$(_pageId+" .sortOrder0").show();
		});
		//基金类型
		appUtils.bindEvent($(_pageId+" .fundsType0 li"),function(){
			if($(this).hasClass("active")){
			    $(this).removeClass("active");
			}else{
				$(this).addClass(" active").siblings("li").removeClass(" active");
			}
		});
		//风险等级
		appUtils.bindEvent($(_pageId+" .riskLevel0 li"),function(){
			if($(this).hasClass("active")){
			    $(this).removeClass("active");
			}else{
				$(this).addClass(" active").siblings("li").removeClass(" active");
			}
		});
		//排序方式
		appUtils.bindEvent($(_pageId+" .sortOrder0 li"),function(){
			if($(this).hasClass("active")){
			    $(this).removeClass("active");
			}else{
				$(this).addClass(" active").siblings("li").removeClass(" active");
			}
		});
		//清空筛选
		appUtils.bindEvent($(_pageId+" .clear"),function(){
			$(_pageId+" .filt_list li").removeClass(" active");
		});
		//取消
		appUtils.bindEvent($(_pageId+" .tl"),function(){
			$(_pageId+" .filt_list li").removeClass(" active");
			$(_pageId+" .pop_filter").hide();
		});
		
		//确定
		appUtils.bindEvent($(_pageId+" .tr"),function(){
			$(_pageId+" .pop_filter").hide();
			var risk_level=$(_pageId+" .riskLevel0 li[class='active']").attr("data-value");
			var fundType=$(_pageId+" .fundsType0 li[class='active']").attr("data-value");
			   if($(_pageId+" .sortOrder0 li[class='active']").attr("data-value")=="1m"){
					var product_performance=$(_pageId+" .sortOrder0 li[class='active']").attr("data-value");
				}
				else{
					var is_nav=$(_pageId+" .sortOrder0 li[class='active']").attr("data-value");
				}
			var param =
			{
				"product_shelf":constants.product_shelf.SHELF_ON,
				"page":"1",
				"numPerPage":"10",
				"recommend_type":"",
				"fund_type":fundType,
			    "risk_level":risk_level,
				"is_nav":is_nav,
				"product_performance":product_performance,
				"performance_sort":"0",
				"is_hot_sale":""
			};

			service.findFund(param,function(data)
				{
				if(data.error_no!="0")
				{
					layerUtils.iAlert(data.error_info);
					layerUtils.iLoading(false);
					return false;
				}

				$(_pageId+" #container_funds_jj .isc_item_fixed  .isc_item:not(:eq(0))").remove();
				$(_pageId+"  #container_funds_jj #scroller_funds_jj .isc_item:not(:eq(0))").remove();
				fundItems(data);

				});
		});
	}

	//3、销毁
	function destroy()
	{
//		iFlag = true;
		appUtils.pageResetValue("mall_itemsFund");
	}

	/*清理页面元素*/
	function clearPageElements()
	{
		$(_pageId+" #container_funds_jj .isc_item_fixed").html('<div class="isc_item isc_item_title"><span>操作</span>div>');
		$(_pageId+"  #container_funds_jj #scroller_funds_jj").html('<div class="isc_item isc_item_title"><span>简称</span><span>单位净值</span><span>申购状态</span><span>日涨幅</span> <span>近一月涨幅</span><span>近三月涨幅</span></div>');
	}

	var itemsFund =
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = itemsFund;

	});
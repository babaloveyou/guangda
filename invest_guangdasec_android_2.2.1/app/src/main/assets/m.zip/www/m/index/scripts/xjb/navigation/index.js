/*
 * 现金宝导航栏
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	_pageId = "#xjb_navigation_index ",
	isCanOperation = -1;//是否可操作  0不可操作  1可操作
	
	/*
	 * 页面初始化
	 */
	function init(){
		//设置页面高度
		$(_pageId + " .main").height($(window).height() - $(_pageId + " .header").height());
		$(_pageId + " .main").css("overflow-y","auto");
		//查询所有协议id
		service.getAllProtocolId("",function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			if(error_no == "0"){
				var result = data.results[0];
				appUtils.setSStorageInfo("pro_code_fxjss",result.pro_code_fxjss);
				appUtils.setSStorageInfo("pro_code_ht",result.pro_code_ht);
				appUtils.setSStorageInfo("pro_code_qys",result.pro_code_qys);
				appUtils.setSStorageInfo("pro_code_t0_fwxy",result.pro_code_t0_fwxy);
				appUtils.setSStorageInfo("pro_code_t0_fxjs",result.pro_code_t0_fxjs);
			}else{
				layerUtils.iAlert(error_info);
				return false;
			}
		});
		valide();
	}
	
	/*
	 * 绑定页面事件
	 */
	function bindPageEvent(){
		
		//返回
		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(e){
			pageBack();
			e.stopPropagation();
		});
		
		//li事件绑定
		appUtils.bindEvent($(_pageId+" .speedwith li"),function(e){
			var flag = true;
			if($(this).index() == 3){//参与状态设置
				appUtils.pageInit("xjb/navigation/index","xjb/navigation/setState",{});
//				appUtils.pageInit("xjb/navigation/index","xjb/account/setState",{});
			}else{
				if(isCanOperation == 0){
					layerUtils.iMsg(-1,"您还没有参与现金宝");
					flag = false;
				}
				if($(this).index() == 0 && flag){ //快速取现
					checkT0Power();
				}
				if($(this).index() == 1 && flag){//普通取现
					appUtils.pageInit("xjb/navigation/index","xjb/navigation/commonCash",{});
				}
				if($(this).index() == 2 && flag){//预留金额设置
					appUtils.pageInit("xjb/navigation/index","xjb/navigation/amountSetModify",{});
				}
				if($(this).index() == 4 && flag){//份额查询
					appUtils.pageInit("xjb/navigation/index","xjb/navigation/queryQuotient",{});
				}
			}
			e.stopPropagation();
		});
		
	}
	
	//（快速取现）判断是否已签署T+0协议
	function checkT0Power(){
		var param={
			"branch_no":appUtils.getSStorageInfo("branch_no"),
			"account":appUtils.getSStorageInfo("fund_account"),
			"account_type":appUtils.getSStorageInfo("whichAccount"),
			"entrust_way":"SJWT"
		}
		  var callBack = function(data){//2002015
			if(data.error_no == 0){
				if(data!=null){
					var result=data.results[0];
					if(result.competence_flag=='1'){
						appUtils.pageInit("xjb/navigation/index","xjb/navigation/fastCash",{});
					}else{
						appUtils.pageInit("xjb/navigation/index","xjb/navigation/fastCashNo",{});
					}
				}
			}else{
				layerUtils.iAlert(data.error_info);
			}
		};
		service.innovateBusinessIsExist(param,callBack);//2002015
	}
	
	function valide(){
		var user=appUtils.getSStorageInfo("userinfo");
		var userinfo=JSON.parse(user);
		//20160921
		var par = {
			"branch_no":appUtils.getSStorageInfo("branch_no"),
			"account":appUtils.getSStorageInfo("fund_account"),
			"market":"1",
			"eztName":userinfo.user_code,
			"ticket":""
		};
		service.queryHtzt(par,function(data){//查询合同状态
			if(data.error_no == 0){
				var result = data.results[0];
				if(result.electronic_contract_status == "1"){//状态为参与，直接进入业务操作
					isCanOperation = 1;
				}else{
					isCanOperation = 0;
				}
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		});
		
		// var user=appUtils.getSStorageInfo("userinfo");
		// var userinfo=JSON.parse(user);
		// var s="1002";
		// if(userinfo.user_type=="0"){
			// s="1001";
		// }
		// var param = {
			// "fund_account":appUtils.getSStorageInfo("fund_account"),
			// "sign":4,
			// "ezt_name":userinfo.user_code,
			// "ticket":"",
			// "survey_sn":s
		// };
		// service.isCompleteStep(param,function(data){
			// if(data.error_no == 0){
				// var result = data.results[0];
				// if(result.sfkh == "1"){//已经开户
					// if(result.sfqsdzht == "1"){//合同已签署
						// var par = {
							// "branch_no":appUtils.getSStorageInfo("branch_no"),
							// "account":appUtils.getSStorageInfo("fund_account"),
							// "market":"1",
							// "eztName":userinfo.user_code,
							// "ticket":""
						// };
						// service.queryHtzt(par,function(data){//查询合同状态
							// if(data.error_no == 0){
								// var result = data.results[0];
								// if(result.electronic_contract_status == "1"){//状态为参与，直接进入业务操作
									// isCanOperation = 1;
								// }else{
									// isCanOperation = 0;
								// }
							// }else{
								// layerUtils.iLoading(false);
								// layerUtils.iAlert(data.error_info);
							// }
						// });
					// }else{
						// layerUtils.iMsg(-1,"您还没有签署合同");
					// }
				// }else{
					// layerUtils.iMsg(-1,"您还没有开TA户");
				// }
			// }else{
				// layerUtils.iLoading(false);
				// layerUtils.iAlert(data.error_info);
			// }
		// });
	}

	/*
	 * 销毁页面
	 */
	function destroy(){
	}
	
	function pageBack(){
		var fromPage = appUtils.getSStorageInfo("xjb_fromPage");
		appUtils.setSStorageInfo("xjb_fromPage","");
		if(fromPage && fromPage=="userCenter"){
			appUtils.pageInit("xjb/index","account/userCenter",{});
		}else{
			var param_index = {"funcNo":"50101","moduleName":"main"};
			require("external").callMessage(param_index);
		}
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy,
			"pageBack":pageBack
	};
	//暴露方法
	module.exports = base;
});
/**
 * 账户资金信息
 */
define(function(require, exports, module){ 
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
	    service = require("investService").getInstance(),  //业务层接口，请求数据
		global = require("gconfig").global,
		layerUtils = require("layerUtils"),
		marketvalue = "", //账户资金
		fundsFlag = "", //资金判断状态，1代表满足状态了 ,2代表资金状态不满足
		_pageId = "#account_fundsInfo";
	/* 私有业务模块的全局变量 end */
	
	function init()
	{
		//cleanPageElement();
		marketvalue = appUtils.getSStorageInfo("marketvalue");
		var marketvalue_str = parseFloat(marketvalue).toFixed(2);
		$(_pageId+" .value_box h5").html(marketvalue_str+"<small>/元</small>");
		if(marketvalue >= 500000){
			$(_pageId+" .ver_notice h5 span").html("已满足");
			$(_pageId+" .ver_notice h5").addClass("over");
			$(_pageId+" .ver_notice p").html("您的证券账户资产已满足≥50万要求，请继续满足其他条件。");
			$(_pageId+" .ce_btn").show();
			fundsFlag = "1";
		}else{
			fundsFlag = "2";
		}
	}
	
	function bindPageEvent()
	{
		appUtils.bindEvent($(_pageId+" #net"),function(){
			appUtils.pageInit("account/fundsInfo","account/netLogin",{});
		});
		
		//如果资产大于500000
		appUtils.bindEvent($(_pageId+" .ce_btn"),function(){
			appUtils.pageInit("account/fundsInfo","account/mainPage",{"fundsFlag":fundsFlag});
		});
		
		//绑定返回按钮
		appUtils.bindEvent($(_pageId+" .icon_back"),function(){
			appUtils.setSStorageInfo("value",marketvalue);
			appUtils.pageInit("account/fundsInfo","account/mainPage",{"fundsFlag":fundsFlag});
		});
	}
	
	function destroy()
	{
		service.destroy();
	}

	
	/* 清理界面元素*/
	function cleanPageElement()
	{
		$(_pageId+" .ver_notice h5 span").html("抱歉");
		$(_pageId+" .ver_notice h5").removeClass("over");
		$(_pageId+" .ver_notice p").html("您的证券账户资产未满足≥50万要求，暂时无法开通港股通业务，登陆<a href='javascript:void(0);' id='net' style='color:#00acee;'>信用账户</a>试试。");
		$(_pageId+" .ce_btn").hide();
	}
	
	var fundsInfo = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	
	module.exports = fundsInfo;
});
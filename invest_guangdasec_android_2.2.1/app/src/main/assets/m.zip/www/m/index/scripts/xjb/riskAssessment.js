/*
 * 风险测评
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	_pageId = "#xjb_riskAssessment ";
	
	/*
	 * 页面初始化
	 */
	function init(){
		

	}
	
	/*
	 * 绑定页面事件
	 */
	function bindPageEvent(){
		
		//返回
		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(){
			appUtils.pageBack();
		});
		
		//我要评测
		appUtils.bindEvent($(_pageId+" .step_num .ce_btn a"),function(){
			appUtils.pageInit("xjb/riskAssessment","xjb/fxcp");
		});

		//重新进入
		appUtils.bindEvent($(_pageId+" .retry_btn"),function(e){
			stepCheck();
		});
	}
	
	/*
	 * 销毁页面
	 */
	function destroy(){
		
	}

	/**
	 * 流程检测 --- 现金宝
	 */
	function stepCheck(){
		var user=appUtils.getSStorageInfo("userinfo");
		var userinfo=JSON.parse(user);
		var s="1002";
		if(userinfo.user_type=="0"){
			s="1001";
		}
		var param = {
			"fund_account":appUtils.getSStorageInfo("fund_account"),
			"sign":4,
			"ezt_name":userinfo.user_code,
			"ticket":"",
			"survey_sn":s
		};
		service.isCompleteStep(param,function(data){
			if(data.error_no == 0){
				var result = data.results[0];
				if(result.sfkh == "1"){//已经开户
					if(result.sfqsdzqmyds == "1"){//是否签署电子协议
						if(result.sffxcp == "1"){//是否风险测评
							if(result.sfqsdzht == "1"){//合同已签署
								var par = {
									"branch_no":appUtils.getSStorageInfo("branch_no"),
									"account":appUtils.getSStorageInfo("fund_account"),
									"market":"1",
									"eztName":userinfo.user_code,
									"ticket":""
								};
								service.queryHtzt(par,function(data){//查询合同状态
									if(data.error_no == 0){
										var result = data.results[0];
										if(result.electronic_contract_status == "1"){//状态为参与，直接进入业务操作
											appUtils.pageInit("account/userCenter","xjb/setReservation",{});
										}else{//修改状态
											appUtils.pageInit("account/userCenter","xjb/setState",{});
										}
									}else{
										layerUtils.iLoading(false);
										layerUtils.iAlert(data.error_info);
									}
								});
							}else{//没有签署合同
								appUtils.pageInit("account/userCenter","xjb/electronicContract",{});//签署电子合同
							}
						}else{//没有风险测评
							appUtils.pageInit("account/userCenter","xjb/riskAssessment",{});//风险测评
						}
					}else{//没有签署电子协议
						appUtils.pageInit("account/userCenter","xjb/electronicAgreement",{});//签署电子协议
					}
				}else{//没有开TA账户
					appUtils.pageInit("account/userCenter","xjb/index");//走开户
				}
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		});
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy
	};
	//暴露方法
	module.exports = base;
});
define(function(require, exports, module) {
	
	var appUtils = require("appUtils");
	var gconfig = require("gconfig");
	var layerUtils = require("layerUtils");
	
	/**
	 * 微信起始过渡页特殊的pageInit方法
	 * 这里没有prePageCode，而是负载元素pageCode
	 */
	function wxTransPageInit(parentPageCode, pageCode, param)
	{
		$("#stepLoadingDiv").hide();
		//增加过渡页面的标志位，兼容普通见面跳转过来
		if(!param){
			param = {};
		}
		param._isWxTransFlag = true;
		
		var pageUrl = gconfig.viewsPath + pageCode + ".html",
			pageId = pageCode.replaceAll("/", "_"),
			parentPageId = parentPageCode.replaceAll("/", "_"); //负载父元素ID
		
		try {
			if($("#"+pageId).length < 1) {
				require("ajax").loadHtml(pageUrl, function(htmlContent) {
					document.title = $(htmlContent).attr("data-pageTitle");
					$("#"+parentPageId).append(htmlContent); //保存这个page到parentPageCode
					$("#"+pageId+" img").each(function() { //设置图片scr地址，防止出错
						var src = $(this).attr("src");
						if(src && $(this).attr("data-serverImg")!="true") {
							$(this).attr("src", gconfig.imagesPath + src.substring(src.indexOf("images")+7));
						}
					});
					require.async(gconfig.scriptsPath+pageCode, function(page) {
						appUtils.setSStorageInfo("wxTransPage_pageParam", JSON.stringify(param));
						page.init(); //页面初始化
						page.bindPageEvent(); //事件绑定
					});
				}, true, false, false);
			} else {
				require.async(gconfig.scriptsPath+pageCode, function(page) {
					appUtils.setSStorageInfo("wxTransPage_pageParam", JSON.stringify(param));
					page.init(); //页面初始化
					page.bindPageEvent(); //事件绑定
				});
			}
		} catch(e) {
			console.printStackTrace(e);
		}
	}
	
	/**
	 * 微信起始过渡页特殊的getPageParam方法
	 */
	function wxGetPageParam(paramName) 
	{
		 //根据_isWxTransFlag判断，兼容普通见面跳转过来
		var jsonParam = appUtils.getSStorageInfo("wxTransPage_pageParam");
		jsonParam = JSON.parse(jsonParam);
		if(jsonParam && jsonParam._isWxTransFlag){
			if(paramName) {
				return jsonParam[paramName];
			} else {
				return jsonParam;
			}
		} else {
			return appUtils.getPageParam(paramName);
		}
	}
	
	function firstLoadFunc() {
		$("#loading").fadeOut();
		require("external");
		console.log("firstLoad...");
	}
	
	function filterLoginOut(data){
		var error_no = data.error_no;
		var error_info = data.error_info;
		if(error_no == "-999") {
			appUtils.clearSStorage("_isLoginIn");
			appUtils.clearSStorage("_loginInPageCode");
			appUtils.clearSStorage("_loginInPageParam");
			//其他清理工作...
			
			appUtils.pageInit(appUtils.getSStorageInfo("_curPageCode"), gconfig.loginPage.pageCode, gconfig.loginPage.jsonParam);
		}
	}
	
	/**
	 * 权限校验
	 * @param checkInParam 校验判断依据
	 * "checkInParam": {
	 * 		"prePageCode": prePageCode,
	 * 		"pageCode": pageCode,
	 * 		"param": param,
	 * 		"isLastReq": isLastReq,
	 * 		"isShowWait": isShowWait,
	 * 		"isShowOverLay": isShowOverLay
	 *	}
	 */
	function checkPermission(checkInParam) {
		return true;
	}

	var common = {
		"firstLoadFunc": firstLoadFunc,
		"checkPermission": checkPermission,
		"wxTransPageInit": wxTransPageInit,
		"wxGetPageParam": wxGetPageParam
	};
	//暴露对外的接口
	module.exports = common;
});

/**
 * 通用工具类，将项目中的公用方法抽出来
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils"),
		validatorUtil = require("validatorUtil"),
		service = require("investService").getInstance(), //业务层接口，请求数据
		layerUtils = require("layerUtils"),
		gconfig = require("gconfig"),
		global = gconfig.global;
	var external = require("external");
	var platform = require("gconfig").platform;

	  //选择离自己最近的营业部
        function getNearBranch(brancharray,callback){
            var r=6378.137;
            function rad(d){
                return d* Math.PI/180.0;
            }
            function getDistance(lng1,lat1,lng2,lat2){
                var radLat1=rad(lat1);
                var radLat2=rad(lat2);
                var a=radLat1-radLat2;
                var b=rad(lng1)-rad(lng2);
                var s=2*Math.asin(Math.sqrt(Math.pow(Math.sin(a/2),2) +   Math.cos(radLat1)*Math.cos(radLat2)*Math.pow(Math.sin(b/2),2)));
                s=s*r;
                s=s * 1000;
                return s.toFixed(6);
            };

            function sortS(a,b) {
                return a.s-b.s;
            };

            //console.log("lng:"+info.lng+"\tlat:"+info.lat);
            //console.log("===》globalpoint:"+JSON.stringify(globalPoint));

    //        layerUtils.iAlert(JSON.stringify(globalPoint));
    //        return;
            if(globalPoint){
                var s_array = new Array();
                for (var i=0; i<brancharray.length; i++) {
                    var item_address = brancharray[i];
                    item_address.s = getDistance(globalPoint.locationX,globalPoint.locationY, item_address.locationX, item_address.locationY);
                    s_array.push(item_address);
                }
                s_array.sort(sortS);
    //            console.log("=====>> s_array:"+JSON.stringify(s_array));
    //            alert(JSON.stringify(globalPoint)+"||"+JSON.stringify(brancharray));
                callback(s_array[0]);
    //            var s_array = new Array();
    //            for (var i=0; i<brancharray.length; i++) {
    //                brancharray[i].s = getDistance(globalPoint.x,globalPoint.y, brancharray[i].locationX, brancharray[i].locationY);
    //            }
    //            brancharray.sort(sortS);
    //            alert(JSON.stringify(globalPoint)+"||"+JSON.stringify(brancharray));
    //            return   callback(brancharray[0]);
            } else {
                callback(null);
            }

        }

	/**
	 * 下载证书
	 * @param callback 证书下载安装之后回调处理
	 */
	function installCertificate(callback) {
		// 下载证书，创建10位随机数
		console.log("下载证书");
		var createKeyRandom = "1";
		for (var i = 0; i < 9; i++) {
			createKeyRandom += parseInt(Math.random() * 10) + "";
		}
		// 证书申请串，数据来源于壳子
		var pkcs10 = "",
			createKeyParam = {
				"rodam": createKeyRandom,
				"userId": appUtils.getSStorageInfo("user_id"),
				"key": "stockDelegateTradeSys",
				"funcNo": "60003"
			};
		// 调用壳子的方法生成证书申请串
		//		require("shellPlugin").callShellMethod("createKeyPlugin",function(data){
		//			pkcs10 = data.pkcs10;
		//			var param = {
		//				"user_id" : appUtils.getSStorageInfo("user_id"),
		//				"pkcs10" : pkcs10
		//			};
		//			var cert_type ="";  //证书类型
		//			// 新开调用中登证书
		//			if(appUtils.getSStorageInfo("openChannel") == "new")
		//			{
		//				cert_type = "zd";
		//				service.queryCompyCart(param,function(data){callcert(data,cert_type,callback)},false,true,function(){handleTimeout(callback)});
		//			}
		//			else if(appUtils.getSStorageInfo("openChannel") == "change")
		//			{
		//				cert_type = "tw";
		//				service.queryMyselfCart(param,function(data){callcert(data,cert_type,callback)},false,true,function(){handleTimeout(callback)});
		//			}
		//		},function(){
		//			handleTimeout(callback);
		//		},createKeyParam);
		var result = external.callMessage(createKeyParam);
		//       	var error_no;
		//       	if(platform == "1") {
		//			var result = JSON.parse(result);
		//			error_no = result.error_no;
		//       	} else if (platform == "2") {
		//			error_no = result.error_no;
		//			var result = result.results[0];
		//       	}
//		if (platform == "1") {
//			var result = JSON.parse(result);
//		}
		var error_no = result.error_no;
		var error_info = result.error_info;
		var result = result.results[0];
		if (error_no == "0" || error_no == "1") {
			pkcs10 = result.pkcs10;
			// 中登证书
			var param = {
				"user_id": appUtils.getSStorageInfo("user_id"),
				"pkcs10": pkcs10
			};
			var cert_type = ""; //证书类型
			// 新开调用中登证书
			if (appUtils.getSStorageInfo("openChannel") == "new") {
				cert_type = "zd";
				service.queryCompyCart(param, function(data) {
					callcert(data, cert_type, callback)
				}, false, true, function() {
					handleTimeout(callback)
				});
			} else if (appUtils.getSStorageInfo("openChannel") == "change") {
				cert_type = "zd";
				service.queryCompyCart(param, function(data) {
					callcert(data, cert_type, callback)
				}, false, true, function() {
					handleTimeout(callback)
				});
			}
		} else {
			handleTimeout(callback);
		}
	}

	/* 处理请求超时 */
	function handleTimeout(callback) {
		layerUtils.iConfirm("请求超时，是否重新加载？", function() {
			installCertificate(callback) // 再次下载证书
		});
	}

	/**
	 * 安装证书回调方法
	 * @param callback 证书下载安装之后回调处理
	 */
	function callcert(data, cert_type, callback) {
		var error_no = data.error_no;
		var error_info = data.error_info;
		if (error_no == "0") {
			// 获取证书的内容
			console.log("获取证书内容");
			var certParam = {
				"content": data.results[0].p7cert,
				"userId": appUtils.getSStorageInfo("user_id"),
				"type": cert_type,
				"funcNo": "60004"
			};
			// 壳子读取证书，然后安装证书
			//			require("shellPlugin").callShellMethod("initZsPlugin",function(data){
			//				if(data == "OK")
			//				{
			//					callback();
			//				}
			//			},null,certParam);
			var result = external.callMessage(certParam);

			//            var error_no;
			//       //android
			//       if(platform == "1"){
			//       var result = JSON.parse(result);
			//       error_no = result.error_no;
			//       }
			//
			//       //ios
			//       if(platform == "2"){
			//       error_no = result.error_no;
			//       result = result.results[0];
			//       }
//			if (platform == "1") {
//				var result = JSON.parse(result);
//			}
			var error_no = result.error_no;
			var error_info = result.error_info;
			//            var result = result.results[0];

			if (error_no == "0" || error_no == "1") {
				callback();
			}
		} else {
			layerUtils.iLoading(false);
			layerUtils.iAlert(data.error_info, -1);
		}
	}

	/**
	 * 自定义确认框
	 * @param layerMsg 确认框的内容
	 * @param oneText 第一个按钮按钮的文本内容
	 * @param twoText 第二个按钮的文本内容
	 * @param funcOne 第一个按钮的回调函数
	 * @param funcTwo 第二个按钮的回调函数
	 */
	function layerTwoButton(layerMsg, oneText, twoText, funcOne, funcTwo) {
		var viewContent = '<div class="pop_tip notice" id="utils_confirm"><span class="icon"></span><p>' + layerMsg + '</p><div class="btn"><a href="javascript:void(0);" id="utils_confirm_one">' + oneText + '</a><a href="javascript:void(0);" id="utils_confirm_two">' + twoText + '</a></div></div>';
		var iConfirm = layerUtils.layerCustom(viewContent);
		appUtils.preBindEvent($("#utils_confirm"), " #utils_confirm_one", function() {
			if (funcOne) {
				funcOne();
			}
			layerUtils.iCustomClose();
		});
		appUtils.preBindEvent($("#utils_confirm"), " #utils_confirm_two", function() {
			if (funcTwo) {
				funcTwo();
			}
			layerUtils.iCustomClose();
		});
	}

	/**
	 * 通过壳子调用系统日期控件
	 * @param obj dom 对象，一般传 this 即可
	 */
	function selectDate(obj) {
		var currentDateStr = $(obj).val(),
			yearParam = "",
			monthParam = "",
			dayParam = "";
		currentDateStr = currentDateStr.replace(/-/g, "/");
		// 如果是有效的日期串，解析年、月、日
		if (validatorUtil.isDate(currentDateStr)) // 如果是有效的日期串，解析年、月、日
		{
			var tempDate = new Date(currentDateStr);
			yearParam = tempDate.getFullYear() + "";
			// 0~11 的值
			monthParam = (tempDate.getMonth() + 1 + "").length == 1 ? "0" + (tempDate.getMonth() + 1) : (tempDate.getMonth() + 1) + "";
			// 1~31 的值
			dayParam = (tempDate.getDate() + "").length == 1 ? "0" + tempDate.getDate() : tempDate.getDate() + "";
		}
		else
		{
			var dataNew = new Date().format("yyyy/MM/dd");
			var tempDate = new Date(dataNew);
			yearParam = tempDate.getFullYear() + "";
			// 0~11 的值
			monthParam = (tempDate.getMonth() + 1 + "").length == 1 ? "0" + (tempDate.getMonth() + 1) : (tempDate.getMonth() + 1) + "";
			// 1~31 的值
			dayParam = (tempDate.getDate() + "").length == 1 ? "0" + tempDate.getDate() : tempDate.getDate() + "";
		}
		var calendarParam = {
			"selector": $(obj).attr("id"),
			"year": yearParam,
			"month": monthParam,
			"day": dayParam,
			"moduleName":"open",
			"funcNo":"50250"
		};
		console.log("调用日期插件5："+JSON.stringify(calendarParam));
		external.callMessage(calendarParam);
	}

	/**
	 * 以 放大镜 的形式显示数字，如：电话号码、银行卡号
	 * @param obj 要处理的 dom 对象，一般传 this
	 * @param type 1 手机号码，2 银行卡
	 */
	function showBigNo(obj, type) {
		var showStr = $(obj).val();
		var originalStr = showStr.replace(/\s+/g, "");
		var styleStr = "background-color:#FFFFFF; color:#000000; border:1px solid #D83005;line-height:35px;" +
			"font-size:20px;padding:0px 5px;font-weight:bold;";
		if (type == 1) {
			if (originalStr.length > 3 && originalStr.length <= 7) {
				showStr = originalStr.substring(0, 3) + " " + originalStr.substring(3, 7);
			} else if (originalStr.length > 7 && originalStr.length <= 11) {
				showStr = originalStr.substring(0, 3) + " " + originalStr.substring(3, 7) + " " + originalStr.substring(7, 11);
			}
			if (gconfig.platform == 0) // 浏览器
			{
				styleStr += "width:145px;";
			} else if (gconfig.platform == 1) // android
			{
				styleStr += "width:133px;";
			} else // ios
			{
				styleStr += "width:143px;";
			}
		} else if (type == 2) {
			if (originalStr.length > 4 && originalStr.length <= 8) {
				showStr = originalStr.substring(0, 4) + " " + originalStr.substring(4, 8);
			} else if (originalStr.length > 8 && originalStr.length <= 12) {
				showStr = originalStr.substring(0, 4) + " " + originalStr.substring(4, 8) + " " + originalStr.substring(8, 12);
			} else if (originalStr.length > 12 && originalStr.length <= 16) {
				showStr = originalStr.substring(0, 4) + " " + originalStr.substring(4, 8) + " " + originalStr.substring(8, 12) +
					" " + originalStr.substring(12, 16);
			} else if (originalStr.length > 16 && originalStr.length <= 19) {
				showStr = originalStr.substring(0, 4) + " " + originalStr.substring(4, 8) + " " + originalStr.substring(8, 12) +
					" " + originalStr.substring(12, 16) + " " + originalStr.substring(16);
			} else if (originalStr.length > 19 && originalStr.length <= 21) {
				showStr = originalStr.substring(0, 4) + " " + originalStr.substring(4, 8) + " " + originalStr.substring(8, 12) +
					" " + originalStr.substring(12, 16) + " " + originalStr.substring(16, 20) + " " + originalStr.substring(20);
			}
			if (originalStr.length <= 16) {
				if (gconfig.platform == 0) // 浏览器
				{
					styleStr += "width:212px;";
				} else if (gconfig.platform == 1) // 安卓手机
				{
					styleStr += "width:188px;";
				} else // ios
				{
					styleStr += "width:198px;";
				}
			} else {
				if (gconfig.platform == 0) // 浏览器
				{
					styleStr += "width:253px;";
				} else if (gconfig.platform == 1) // 安卓手机
				{
					styleStr += "width:225px;";
				} else // ios
				{
					styleStr += "width:235px;";
				}
			}
		}
		var tipsIndex = $.layer({
			type: 4,
			closeBtn: false,
			shade: false,
			shadeClose: false,
			fix: true,
			title: false,
			area: ['auto', 'auto'],
			border: [10, 0.3, '#000', true],
			zIndex: 19930902,
			tips: {
				msg: showStr,
				follow: obj,
				guide: 0,
				isGuide: true,
				style: [styleStr, '#D83005']
			}
		});
		var widthDifference = ($(".xubox_tips").offset().left + $(".xubox_tips").width()) - $(window).width();
		if (widthDifference > 0) {
			$(".xubox_tips").css("margin-left", "-" + (widthDifference + 10) + "px");
			$(".xubox_tips").find("i").css("margin-left", (widthDifference + 10) + "px");
		}
		if (originalStr == "" && tipsIndex) {
			layer.close(tipsIndex);
		}
		appUtils.bindEvent($(obj), function() {
			if (tipsIndex) {
				layer.close(tipsIndex);
			}
		}, "blur");
	}

	/**
	 * 处理 iPhone 的兼容性
	 * @param obj 待处理的 input dom 对象，一般传 this
	 * @param maxLength 最大长度
	 */
	function dealIPhoneMaxLength(obj, maxLength) {
		var currentStr = $(obj).val();
		if (currentStr.length > maxLength) {
			$(obj).val(currentStr.substring(0, maxLength));
		}
	}

	/**
	 * 超时处理
	 * @param func 超时处理函数
	 * @param isSuccess 请求是否成功
	 * gconfig.ajaxTimeout 是配置文件中配置的超时时间
	 */
	var catchTimeout = null;

	function listenTimeout(func, isSuccess) {
		if (!isSuccess) {
			if (catchTimeout != null) {
				window.clearInterval(catchTimeout);
				catchTimeout = null;
			}
			catchTimeout = window.setInterval(function() {
				// 关闭加载层
				layerUtils.iLoading(false);
				func();
			}, gconfig.ajaxTimeout * 1000);
		} else {
			window.clearTimeout(catchTimeout);
			catchTimeout = null;
		}
	}

	/**
	 * 获取手机号并填充
	 * elements 输入框名称
	 */
	function getPhoneNo(elements) {
		//调用原生获取手机号码
		var phoneParam = {
			"funcNo": "50224"
		};
		var result = external.callMessage(phoneParam);
		console.log("本机号码："+JSON.stringify(result));
		if ((result.error_no == "0" || result.error_no == "1") && (result.results != undefined)) {
			var phone = result.results[0].phone;
			var phoneReg = /^[1-9]\d{10}$/;
			// 返回的数据是 +86手机号时，截取
			if (phone.length == 14) {
				phone = phone.substring(3);
			} else if (!phoneReg.test(phone)) {
				$(elements).val("");
				return;
			}
			$(elements).val(phone);
			// 将光标移到输入框末尾
			setCursorPosition(elements);
		} else {
//			layerUtils.iMsg(-1,"获取本机号码失败！");
		}
	}

	/**
	 * 设置输入框光标的位置
	 * obj 需要设置光标位置的 input dom 对象
	 * position 光标的位置，默认是输入框的末尾
	 */
	function setCursorPosition(obj, position) {
		var text = obj.createTextRange();
		text.collapse(true);
		text.moveStart("character", position ? position : obj.value.length);
		text.select();
	}

	/**
	 * 通过壳子调用密码控件
	 * @param data 密码值
	 * @param ele 元素id
	 */
	function getInput(data, ele) {
		$(ele).val(data); // 填充密码框
	}

	/**
	 * 通过壳子关闭密码控件
	 */
	function onFinish() {
		$("body").css("padding-bottom", "0").scrollTop(0);
	}

/**
     * 生成广告位置
     * @param bannerid
     * @param imgs
     * @param apagination
     */
    function initBanner(bannerid,imgs,apagination){
        var banner = document.getElementById(bannerid) ;
        banner.innerHTML = "";
        //组件广告页面
        var wrapper_index_head = document.createElement("div");
        wrapper_index_head.className = "swiper-wrapper";
        var litext ="";
        for(var j=0;j<imgs.length;j++){
            litext += "<div class='swiper-slide'>";
            var temp = "";
            if(imgs[j].url != ""){
                temp =  imgs[j].url;
            }
            litext += "<a  href='javascript:void(0)' onclick='onNewWindowOpen(\""+temp+"\")'><img style='width: 100%;height: 100%' src='"+imgs[j].src+"'/></a>";
            litext += "</div>";
        }
        wrapper_index_head.innerHTML = litext;
        banner.appendChild(wrapper_index_head);
        var pagination =    document.createElement("div");
        pagination.className = apagination;
        banner.appendChild(pagination);
//        console.log("=====>banner:["+banner.innerHTML+"]");
//        layerUtils.iAlert(banner.innerHTML);
        $(document).ready(function(){

            mySwiper = new Swiper("."+banner.className,{
                autoplay : 2000,//可选选项，自动滑动
                speed:1000,
                autoplayDisableOnInteraction:false,
                pagination: '.'+  pagination.className,
                loop:true,
                grabCursor: true,
                paginationClickable: true
            })  ;


        });

    }
    /**
     * 设置客服电话的位置
     * 当页面的高度大于 body 的高度时，客服电话固定在 body 底部在小屏机可能出现客服电话遮住按钮内容的情况
     * 为防止设置位置时客服电话闪动的情况（设置之前和之后会因为位置的改变而出现闪动），需要将客服电话设为 hide 状态
     * @param pageId 页面的 id
     * @param btnEle 页面底部按钮的 jquery 对象
     * @param phoneEle 客服电话的 jquery 对象
     */
    function setPhonePosition(pageId, btnEle, phoneEle)
    {
        var bodyHeight = $(document.body).height(),  // 页面可见区域的高度
            pageHeight = btnEle.offset().top + btnEle.height(),   // 页面实际的高度
            phoneHeight = 30,  // 客服电话的高度
            phoneOffsetTop = null;  // 客服电话的 top 偏移量

        if(bodyHeight > pageHeight)  // 当 body 高度大于页面高度时
        {
            phoneOffsetTop = bodyHeight - pageHeight - phoneHeight*2;
            if(phoneOffsetTop < 0)
            {
                phoneOffsetTop = 0;
            }

                phoneEle.css({"position":"relative","top":phoneOffsetTop+"px"}).show();  // 防止客服电话挡住按钮
        }
        else  // body 高度小于页面高度时
        {

                phoneEle.css("position","relative").show();  // 显示客服电话
        }
    }
    
    /**
	 * 关闭放大镜
	 */
	function closeBigNoTips()
	{
		var $tips = $("body>div[type='tips']");
		if($tips.length > 0)
		{
			$tips.remove();
		}
	}

	var utils = {
	    "initBanner":initBanner,
		"installCertificate": installCertificate,
		"layerTwoButton": layerTwoButton,
		"selectDate": selectDate,
		"showBigNo": showBigNo,
		"dealIPhoneMaxLength": dealIPhoneMaxLength,
		"setCursorPosition": setCursorPosition,
		"getPhoneNo": getPhoneNo,
		"getInput": getInput,
		"onFinish": onFinish,
		 "setPhonePosition":setPhonePosition,
          "getNearBranch":getNearBranch,
          "closeBigNoTips" : closeBigNoTips
	};

	module.exports = utils;
});

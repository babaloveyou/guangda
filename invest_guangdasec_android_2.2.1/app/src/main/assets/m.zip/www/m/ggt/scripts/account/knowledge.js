/**
* 知识测评
*/
define(function(require, exports, module){
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
		  service = require("investService").getInstance(),  //业务层接口，请求数据
		  global = require("gconfig").global,
		  layerUtils = require("layerUtils"),
		   util=require("utils"),
		  arrs=[],
		  mutilarrs=[],
		  _pageId = "#account_knowledge";
	/* 私有业务模块的全局变量 end */
	
	function init()
	{
		getKnowledgeQuestions();  // 获取问卷答题
		util.setContentHeight(_pageId +" .main",_pageId+" .header");
	}
	
	function bindPageEvent()
	{
		/* 提交答题  */
		appUtils.preBindEvent($(document),_pageId+" .ce_btn",function(){
			postRiskAssessmentData();  // 提交答题
		});
		
		//绑定返回
		appUtils.bindEvent($(_pageId+" .icon_back"),function(){
			appUtils.pageBack();
		});
	}
	
	function destroy()
	{
		arrs=[];
		mutilarrs=[];
		$(_pageId).remove();
		service.destroy();
	}
	
	/* 获取风险测评题库 */
	function getKnowledgeQuestions()
	{
		// 查询风险评测
		var survey_type = "3",
			queryTestParam = {"survey_type":survey_type};
		service.queryRiskToc(queryTestParam,function(data){
			var errorNo = data.error_no,
				errorInfo = data.error_info;
			if(errorNo=="0" && data.dsName)   //调用成功
			{
				$(data.questionList).each(function(i,ele){
					//遍列题目名称
					var id=ele.question_id,
						ibind,
						obj={};
					var name=ele.question_name;
					var type=ele.type;
					var htmltext;
					obj["qId"]=id;
					if(type=="0"){
						arrs.push(obj); //题目id数组
					}
					else{
						mutilarrs.push(obj);
					}
					if(i==0){
						ibind=id;
					}
					//遍列答案
					if(type=="0"){
						htmltext="<dl><dt>"+(i+1)+"、"+name+"</dt><dd>";
						$(data.answerList).each(function(idx,e){
							if(e.question_id==id){
								htmltext+="<p><a href='javascript:void(0);' name='"+id+"' id='"+(i+1)+"' value='"+e.answer_id+"' type='0'>"+e.answer_name+"</a></p>";
							}
						});
					}else{
						htmltext="<dl><dt>"+(i+1)+"、"+name+"<span>(多选)</span</dt><dd>";
						$(data.answerList).each(function(idx,e){
							if(e.question_id==id){
								htmltext+="<p><b href='javascript:void(0);' name='"+id+"' id='"+(i+1)+"' value='"+e.answer_id+"' type='1'>"+e.answer_name+"</b></p>";
							}
						});
					}
					
					htmltext+="</dd></dl>";
					$(_pageId+" .test_list").append(htmltext);
				});
				
				// 为选择按钮添加事件
				appUtils.bindEvent($(_pageId+" .test_list a"+","+" .test_list b"),function(){
					var quetype = $(this).attr("type");	 // 问题类型0：单选，1：多选
					var queid   = $(this).attr("id");
					if(quetype == 1)
					{
						$(this).toggleClass("active");
					}
					else
					{
						if($(this).hasClass("active"))
						{
							$(this).parent().parent().parent().find("dt").css("color","red");  // 未选择答案，则将该题标记为红色
							$(this).removeClass("active");
						}
						else
						{
							$(_pageId+" .test_list #"+queid).removeClass("active");
							$(this).parent().parent().parent().find("dt").css("color","#666666");	// 题目红色标记恢复黑色
							$(this).addClass("active");
						}
					}
				});
			}
			else{
				layerUtils.iAlert(errorInfo,-1);
			}
		},{"isLastReq":true,"isShowWait":true,"timeOutFunc":handleTimeout});
	}
	
	/* 处理请求超时 */
	function handleTimeout()
	{
		layerUtils.iConfirm("请求超时，是否重新加载？",function(){
			getRiskAssessQuestions();  // 再次风险测评题目
		});
	}
	
	/* 提交风险评测答案 */
	function postRiskAssessmentData()
	{
		var len=$(_pageId+" .test_list dl").length;
		var str="";   //题目，答案拼接的字符串
		var strs="";
		$(arrs).each(function(i,e){
			var val="";
			var types=$(_pageId+ " a[name='"+e.qId+"']").attr("type");
			if(types=="0"){
				val=$(_pageId+" .test_list a[name='"+e.qId+"'].active").attr("value");
			}
			if(val==undefined||val==""){
				strs+=$(_pageId+" a[name='"+e.qId+"']").attr("id")+"、";
			}else{
				str+=e.qId+"|"+val+"||,";
			}
		});
		$(mutilarrs).each(function(i,e){
			var val="";
			var types=$(_pageId+ " b[name='"+e.qId+"']").attr("type");
			if(types=="1"){
				$(_pageId+ " b[name='"+e.qId+"']").each(function(){
	                if($(this).hasClass("active")){
	                    val += $(this).attr("value")+"-";
	                }
	            });
	            if(val.indexOf("-")!=-1){
	            	val=val.substr(0,val.length-1);
	            }
			}
			if(val==undefined||val==""){
				strs+=$(_pageId+" b[name='"+e.qId+"']").attr("id")+"、";
			}else{
				str+=e.qId+"|"+val+"||,";
			}
		});
		str=str.substr(0,str.length-1);
		var strss=str.split(",");
		if(strss.length!=len){
			strs=strs.substr(0,strs.length-1);
			layerUtils.iMsg(-1,"第"+strs+"题没有选择，请检查后重新确认！");
		}else{
			var submitTestParam={
				"user_id":appUtils.getSStorageInfo("user_id"),
				"survey_type":"3",
				"answer_str":str
			};
			//提交风险评测答案
			service.submitTestAnswer(submitTestParam,function(data){
				var errorNo = data.error_no;
				var errorInfo = data.error_info;
				if(errorNo==0 && data.results.length != 0)	//调用成功,跳转到风险测评页面
				{
					var remark = data.results[0].total_score,   //风险等级评分
						riskdesc = data.results[0].define,  //风险评测文字等级
						define_value = data.results[0].define_value  //风险评测字母等级
					appUtils.pageInit("account/knowledge","account/knowledgeInfo",{"remark":remark,"riskdesc":riskdesc,"define_value":define_value});
				}
				else
				{
					layerUtils.iAlert(errorInfo,-1);
				}
			});
		}
	}
	
	var knowledge = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	
	module.exports = knowledge;
});
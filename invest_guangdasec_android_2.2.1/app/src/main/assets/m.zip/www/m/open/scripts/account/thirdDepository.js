/**
 * 三方存管
 */
define(function(require, exports, module){ 
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
		global = require("gconfig").global,
		platform = require("gconfig").platform,
	    service = require("investService").getInstance(),  //业务层接口，请求数据
		layerUtils = require("layerUtils"),
		utils = require("utils"),
		keyTelPanel = require("keyTelPanel"),
		validatorUtil = require("validatorUtil"),
		zzispwd = 1,  // zzispwd	密码方式，1 需要，0 不需要
		iscard = 1,  // iscard	是否需要银行卡，1 需要，0 不需要
		protocol = null,  // 协议保存
		cert_type = appUtils.getSStorageInfo("openChannel") == "new" ? "zd" : "zd", // tw:天威 zd:中登
		_pageId = "#account_thirdDepository";
	var external = require("external");
	var channelInfo = global.channelInfo;		//版本信息
	/* 私有业务模块的全局变量 end */
	
	function init()
	{
		$(_pageId+" .input_custom").click(function(){$(this).addClass("active")});	
//		if(platform == '2' || platform == '3'){
//			$(_pageId+" .input_text #bankcardPwd").removeAttr("readonly");
//		}
		
		//判断是否需要证书
		if(appUtils.getSStorageInfo("flag") == "1"){
			
			initPage();  // 初始化页面并检测证书是否存在
		}else{
			getBankList();	//加载银行
		}

	}
	
	function bindPageEvent(){
		/* 点击页面隐藏键盘 */
		appUtils.bindEvent($(_pageId),function(e){
			$(_pageId+" .input_custom").removeClass("active");   // 移除输入框的焦点
			keyTelPanel.closeKeyPanel();  // 关闭 js 键盘
			utils.closeBigNoTips();	//关掉放大镜
			$(_pageId+" #bankListPage").slideUp("fast"); // 隐藏银行卡列表
			/*if(platform == '1'){
				require("shellPlugin").callShellMethod("softKeyboardPlugin",null,null,{"isShow":false});  //关闭密码键盘
			}*/
			e.stopPropagation();  // 阻止冒泡
		});
		
		/* 签署银行相关协议  */
		appUtils.bindEvent($(_pageId+" .rule_check a"),function(){
			$(this).toggleClass("checked"); 
		});
				
		/* 选择银行绑定下拉框按钮事件  */
		appUtils.bindEvent($(_pageId+" #selectBank"),function(e){
			$(_pageId+" .input_custom").removeClass("active");   // 移除输入框的焦点
			keyTelPanel.closeKeyPanel();  // 关闭 js 键盘
			utils.closeBigNoTips();	//关掉放大镜
			/*if(platform == '1'){
				require("shellPlugin").callShellMethod("softKeyboardPlugin",null,null,{"isShow":false});  //关闭密码键盘
			}*/
			

			//若为标准版或者雪球版本则绑定下拉
			if(channelInfo == "3" || channelInfo == "7"){
				
				$(_pageId+" #bankListPage ul li").removeClass("active");
				$(_pageId+" #bankListPage").slideDown("fast");  // 显示银行下拉列表
			}

			e.stopPropagation();  // 阻止冒泡
		});

		/* 选择银行卡绑定选择某银行事件 */
		appUtils.bindEvent($(_pageId+" #bankcard"),function(e){
			$(_pageId+" .input_custom").removeClass("active");   // 移除输入框的焦点
			keyTelPanel.closeKeyPanel();  // 关闭 js 键盘
			validateSelectBank(); // 验证是否选择银行卡
			/*if(platform == '1'){
				require("shellPlugin").callShellMethod("softKeyboardPlugin",null,null,{"isShow":false});  //关闭密码键盘
			}*/
			e.stopPropagation();  // 阻止冒泡
		});
		
		/* 银行卡号输入控制（每四位分隔） */
//		appUtils.bindEvent($(_pageId+" #bankcard"),function(){
//			utils.dealIPhoneMaxLength(this,21); // 处理iphone兼容
//			utils.showBigNo(this,2);  // 调用放大镜插件
//		},"input");
		
		
		/*银行卡号输入*/
	    appUtils.bindEvent($(_pageId+" #input_text_bankcard"),function(e){
	    		e.stopPropagation();
	            $(_pageId+" #bankListPage").slideUp("fast");  // 隐藏银行下拉列表
				var loginPassword_keyboard = $(this);
				loginPassword_keyboard.find("em").html("");//清空
				$(_pageId+" .input_custom").removeClass("active"); // 移除输入框的焦点
				loginPassword_keyboard.addClass("active").find("em").css({color:"#9F9F9F"});  // 添加输入框的焦点
				keyTelPanel.init_keyPanel(function(value){
					var curValue = loginPassword_keyboard.find("em").html();  // 账号的值
					if(value == "del")
					{
						loginPassword_keyboard.find("em").html(curValue.slice(0, -1));
					}
					else
					{
						if(curValue.length < 19)
						{
							loginPassword_keyboard.find("em").html(curValue + value);
						}
						else
						{
							layerUtils.iMsg(-1, "银行卡号最多 19 位!");
						}
					}
//					utils.dealIPhoneMaxLength(this,21); // 处理iphone兼容
//					utils.showBigNo(this,2);  // 调用放大镜插件
					utils.dealIPhoneMaxLength($(_pageId+" #input_text_bankcard"),19); // 处理iphone兼容
					utils.showBigNo($(_pageId+"	#input_text_bankcard_keyboard"),2);  // 调用放大镜插件
				}, loginPassword_keyboard);
			//e.stopPropagation();
		});
		
		/* 点击密码框统一调用密码键盘   ------银行密码*/
		appUtils.bindEvent($(_pageId+" #input_text_pass"),function(e){
	    	e.stopPropagation();
			utils.closeBigNoTips();	//关掉放大镜
			if(!validateSelectBank()){
				return ;
			}
			$(_pageId+" #bankListPage").slideUp("fast"); // 隐藏银行卡列表
			var input_pass1_keyboard = $(this);
			input_pass1_keyboard.find("em").html("");  // 清空密码
			input_pass1_keyboard.attr("data-password","");  // 清空密码值
			$(_pageId+" .input_custom").removeClass("active");    // 移除输入框的焦点
			$(_pageId+" #input_text_pass .input_custom").addClass("active");
			input_pass1_keyboard.find("em").css({color:"#9F9F9F"});  // 添加输入框的焦点
			keyTelPanel.init_keyPanel(function(value){
				var curEchoText = input_pass1_keyboard.find("em").html();  // 密码回显文本
				var input_pass1_curPwd = input_pass1_keyboard.attr("data-password") || "";  // 密码值
				if(value == "del")
				{
					input_pass1_keyboard.find("em").html(curEchoText.slice(0, -1));
					input_pass1_keyboard.attr("data-password", input_pass1_curPwd.slice(0, -1));
				}
				else
				{
					if(input_pass1_curPwd.length < 6)
					{
						input_pass1_keyboard.attr("data-password", input_pass1_curPwd + value);  // 设置密码值
						input_pass1_keyboard.find("em").html(curEchoText + "*");
					}
					else
					{
						layerUtils.iMsg(-1, "银行密码最多 6位!");
					}
				}
				//validatePassword($(_pageId+" #input_text_pass"));
			}, input_pass1_keyboard);
			//e.stopPropagation();
		});
		
		/* 开通三方存管按钮绑定事件 */
		appUtils.bindEvent($(_pageId+" .ct_btn"),function(){
			signProtocol();  // 提交验签，并且提交三方存管信息
		});
	}
	
	function destroy()
	{
		$(_pageId+" input").val("");  // 把所有的input置空
		service.destroy();
	}
	
	/* 初始化页面 */
	function initPage()
	{
		layerUtils.iLoading(true);  // 开启等待层。。。
		// 本页面需要用到证书，如果进入本页面时，证书不存在就下载并安装证书
		var existsParam = {
			"userId" : appUtils.getSStorageInfo("user_id"),
			"mediaId" : "certificate",
			"type" : cert_type,
			"funcNo": "60000"
		};
//		require("shellPlugin").callShellMethod("fileIsExistsPlugin",function(data){
//			// 如果未检测到本地有证书，就安装证书
//			if(data.mediaId == "")
//			{
//				utils.installCertificate(getBankList);  // 下载安装证书，并且加载银行列表
//			}
//			else
//			{
//				getBankList(); //加载银行列表
//			}
//		},function(){
//			// 关闭等待层。。。
//			layerUtils.iLoading(false);
//		},existsParam);
	   var result = external.callMessage(existsParam);
       var error_no;
       if(platform == "1") {
//	       var result = JSON.parse(result);
	       error_no = result.error_no;
	       result = result.results[0];
       } else if (platform == "2") {
       	 error_no = result.error_no;
       	  result = result.results[0];
       }
		if (error_no == "0" && result.mediaId == "") {
			utils.installCertificate(getBankList);  // 下载安装证书，并且显示证券账户和协议
		} else {
		// 关闭等待层。。。
			layerUtils.iLoading(false);
			getBankList(); //加载银行列表
		}
	}
	
	/* 获取存管银行列表 */
	function getBankList()
	{
		var queryParam = {"bindtype" : "", "ispwd" : ""};
		service.queryBankList(queryParam,function(data){
			var errorNo = data.error_no;
			var errorInfo = data.error_info;
			$(_pageId+" .sel_list ul").html("");  // 清除页面的银行列表
			if(errorNo==0 && data.results.length != 0)
			{
				var bankJson = {};	//银行信息保存
								
				var results = data.results;
				var length = results.length;
				var itemElement = "";
				for(var i =0; i<length; i++)
				{
					var item = results[i],
				   		  bankcode = item.bankcode,  // 银行代码
						  bankname = item.bankname,  // 银行名称
						  zzbindtype = item.zzbindtype, // 绑定方式：1 一步式 2 预指定 3 同时支持两种方式
					      sortnum  = item.sortnum,  // 排序
					      smallimg = item.smallimg, // 图标
					      isbuffet = item.isbuffet, // 是否支持自助
					      sign_info = item.sign_info, // 提示信息简介
					      brief = item.brief; // 银行简介
				    zzispwd = item.zzispwd; // 密码方式：1 需要 0 不需要  
				    iscard = item.iscard; // 卡号方式：1 需要 0 不需要  
				    
					//若为光大银行版本
					if(channelInfo == "9" && bankcode == "0700"){
						
						bankJson.id = bankcode;	//银行代码
						bankJson.bankname = bankname;	//银行名称
						bankJson.zzbindtype = zzbindtype;	//一步式、二步式
						bankJson.signInfo = sign_info;	//
						bankJson.zzispwd = item.zzispwd;	//是否显示密码框
						bankJson.iscard = iscard;
					}
					//工商版本
					if(channelInfo == "6" && (bankcode == "300" || bankcode == "0300")){
						
						bankJson.id = bankcode;	//银行代码
						bankJson.bankname = bankname;	//银行名称
						bankJson.zzbindtype = zzbindtype;	//一步式、二步式
						bankJson.signInfo = sign_info;	//
						bankJson.zzispwd = item.zzispwd;	//是否显示密码框
						bankJson.iscard = iscard;
					}

					//建行版本，一步式
					if(channelInfo == "1" && (bankcode == "200" || bankcode == "0200")){
						
						bankJson.id = bankcode;	//银行代码
						bankJson.bankname = bankname;	//银行名称
						bankJson.zzbindtype = zzbindtype;	//一步式、二步式
						bankJson.signInfo = sign_info;	//
						bankJson.zzispwd = item.zzispwd;	//是否显示密码框
						bankJson.iscard = iscard;
					}
					
					//中国银行版本
					if(channelInfo == "4" && bankcode == "0600"){
						
						bankJson.id = bankcode;	//银行代码
						bankJson.bankname = bankname;	//银行名称
						bankJson.zzbindtype = zzbindtype;	//一步式、二步式
						bankJson.signInfo = sign_info;	//
						bankJson.zzispwd = item.zzispwd;	//是否显示密码框
						bankJson.iscard = iscard;
					}
					
					//农业银行版本
					if(channelInfo == "2" && bankcode == "0400"){
						
						bankJson.id = bankcode;	//银行代码
						bankJson.bankname = bankname;	//银行名称
						bankJson.zzbindtype = zzbindtype;	//一步式、二步式
						bankJson.signInfo = sign_info;	//
						bankJson.zzispwd = item.zzispwd;	//是否显示密码框
						bankJson.iscard = iscard;
					}
					
					//农业银行版本
					if(channelInfo == "a" && bankcode == "0500"){
						
						bankJson.id = bankcode;	//银行代码
						bankJson.bankname = bankname;	//银行名称
						bankJson.zzbindtype = zzbindtype;	//一步式、二步式
						bankJson.signInfo = sign_info;	//
						bankJson.zzispwd = item.zzispwd;	//是否显示密码框
						bankJson.iscard = iscard;
					}
				    
					itemElement += "<li><span bankname='"+bankname+"' id='"+bankcode+"' " +"zzispwd=\""+zzispwd+"\""+
									            "iscard=\""+iscard+"\"  zzbindtype=\""+zzbindtype+"\" sign-info=\""+sign_info+"\">"+bankname+"</span></li>";
				}
				$(_pageId+" .sel_list ul").html(itemElement);
				if((appUtils.getSStorageInfo("_prePageCode") == "account/showProtocol") || (appUtils.getSStorageInfo("_prePageCode") == "account/thirdDepository")){
					var bankNum = appUtils.getSStorageInfo("bankNum");
					var bankPwd = appUtils.getSStorageInfo("bankPwd",true);
					console.log(bankNum + "~~~~~~~~~~~~" + bankPwd);
					iscard = $(_pageId+" #selectBank").attr("iscard");
					$(_pageId+" #bankcard").val(bankNum);
					$(_pageId+"  #input_text_pass").attr("data-password",bankPwd);// 清空密码
					var countSum = "";
					if(bankPwd != null && bankPwd != undefined)
					{
						for(var i=0;i<bankPwd.length; i++){
							countSum +="*";
						}
						$(_pageId+"  #input_text_pass").find("em").html(countSum);  // 回显密码
					}
				}
				// 选择银行添加银行事件
				appUtils.bindEvent($(_pageId+" #bankListPage ul li span"),function(e){
					$(_pageId+" #bankListPage ul li").removeClass("active");
					$(this).parent().addClass("active");
					$(_pageId+" .protocolshow").show();
					var banckName = $(this).attr("bankname"),
						  id = $(this).attr("id"),
						  zzbindtype = $(this).attr("zzbindtype"),  // 绑定方式
						  signInfo = $(this).attr("sign-info");  // 提示信息
				    zzispwd = $(this).attr("zzispwd");  // 密码方式
				    iscard = $(this).attr("iscard");  // 是否需要银行卡号
					addBankItem(banckName,id,zzbindtype,signInfo,iscard);
					e.stopPropagation();
				});
				
				//如果为光大、工商版本
				if(channelInfo !="3" && channelInfo != "7" && bankJson.id){
					setTimeout(function(){
						zzispwd = bankJson.zzispwd;	//是否显示密码框
						addBankItem(bankJson.bankname,bankJson.id,bankJson.zzbindtype,bankJson.signInfo,bankJson.iscard);
						$(_pageId+" .protocolshow").show();	//显示协议
					},"600");
				}

			}
			else
			{
				layerUtils.iAlert(errorInfo,-1);
			}
		},true,true,handleTimeout);	
	}
	
	/* 处理请求超时 */
	function handleTimeout()
	{
		layerUtils.iConfirm("请求超时，是否重新加载？",function(){
			getBankList();  // 再次获取银行列表
		});
	}
	
	/* 为选择银行列表添加选中银行数据 */
	function addBankItem(banckName,id,zzbindtype,signInfo,iscard)
	{
		// 显示银行的签约信息
		if(signInfo != "" && signInfo != undefined)
		{
			$(_pageId+" #signInfo").html("温馨提示: "+signInfo);
		}
		else 
		{
			$(_pageId+" #signInfo").html(""); 
		}
		$(_pageId+" #input_text_bankcard").find("em").html("请输入银行卡号");  // 清空银行卡号值
//		$(_pageId+" #bankcardPwd").val(""); // 清空银行卡密码
		$(_pageId+"  #input_text_pass").attr("data-password","");// 清空密码
		$(_pageId+"  #input_text_pass").find("em").html("请输入6位数字银行密码");  // 清空密码
		$(_pageId+" #selectBank").html(banckName);  // 赋值银行卡名称
		$(_pageId+" #selectBank").attr("bankcode",id);
		$(_pageId+" #selectBank").attr("iscard",iscard);
		$(_pageId+" #selectBank").attr("zzbindtype",zzbindtype);
		getDepositoryAgreement(id);  // 获取银行协议内容
		
		if(channelInfo == "6"){
			
			$(_pageId+" .user_form .input_form:eq(1)").hide();  // 隐藏银行卡、密码输入框
		}else{
			if(zzbindtype == 1)   // 判断一步式
			{
				if(zzispwd == 0)  // 不需要输入密码
				{
					$(_pageId+" #input_text_pass").hide();  // 隐藏银行密码输入框
				}
				else   // 需要输入密码
				{
					$(_pageId+" #input_text_pass").show();  // 显示银行密码输入框
				}
				$(_pageId+" .user_form .input_form:eq(1)").show();  // 显示银行卡、密码输入框
				$(_pageId+" #bindInfo").hide();  // 隐藏预指定提示信息
			}
			if(zzbindtype == 2)  // 判断预指定(二步式)
			{
				if(iscard == 1)  // 需要银行卡
				{
					$(_pageId+" .user_form .input_form:eq(1)").show();  // 显示银行卡
					$(_pageId+" .user_form .input_form:eq(1) .input_text:eq(1)").hide();  // 隐藏密码
				}
				else // 不需要银行卡
				{
					$(_pageId+" .user_form .input_form:eq(1)").hide();  // 隐藏银行卡、密码输入框
				}
				$(_pageId+" #bindInfo").show();  // 显示预指定提示信息
			}
		}
		$(_pageId+" #bankListPage").slideUp("fast");  // 隐藏银行下拉列表

	}
	
	/* 签署协议 */
	function signProtocol()
	{
		iscard = $(_pageId + " #selectBank").attr("iscard");

		//非工商银行时，校验
		if(channelInfo != "6"){
			
			if((iscard == 1 || iscard == "") && !validateBankCorrect())  // 验证银行卡号
			{
				return false;
			}
			//密码框显示的时候才校验密码
			if($(_pageId + " .circular:eq(1)").css("display") == "block" 
					&& $(_pageId + " #input_text_pass").css("display") == "block"){
						
				if(zzispwd == 1)  // 验证是否需要密码
				{
					if(!validateBankPwd())
					{
						return false;
					}
				}
			}

		}else{
			$(_pageId+" #input_text_bankcard").find("em").html("");	//清空银行卡号	
		}

		if(!validateDepositProtocolSelect())  // 验证是否勾选协议
		{
			return false;
		}
		
		//判断是否需要证书
		if(appUtils.getSStorageInfo("flag") != "1"){
			
			//不验签协议，直接提交三方
			postThirdDepositoryData();
			return false;
		}

		// 进行协议签署
		var protocolArray = new Array(),  // 协议数组
			userid = appUtils.getSStorageInfo("user_id"),
			ipaddr  = appUtils.getSStorageInfo("ip"),
			macaddr = appUtils.getSStorageInfo("mac"),
			protocolid = protocol.econtract_no,
			protocolname = protocol.econtract_name,
			summary = protocol.econtract_md5,  // 协议内容MD5,签名摘要信息
			signParam = {
				"mediaId":protocolid,
				"content":summary,
				"userId":userid,
				"type": cert_type,
				"funcNo": "60001"
			};
		layerUtils.iLoading(true);  // 开启等待层......
		// 获取协议的数字签名值
//		require("shellPlugin").callShellMethod("signPlugin",function(data){
//			var protocoldcsign = data.ciphertext;  // 数字签名值
//			var protocolParam = {
//				"protocol_id" : protocolid,
//				"protocol_dcsign" : protocoldcsign,
//				"summary" : summary
//			};
//			protocolArray.push(protocolParam);   // 添加值到数组中
//			// 签署协议
//			var signProtocolParam = {
//				"user_id" : userid,
//				"jsondata" : JSON.stringify(protocolArray),
//				"ipaddr" : ipaddr,
//				"macaddr" : macaddr
//			};
//			// 新开中登验签
//			if(appUtils.getSStorageInfo("openChannel") == "new")
//			{
//				service.queryOpenCheckSign(signProtocolParam,postThirdDepositoryData,false);
//			}
//			// 转户天威验签
//			else if(appUtils.getSStorageInfo("openChannel") == "change")
//			{
//				service.queryOpenCheckSign(signProtocolParam,postThirdDepositoryData,false);
//			}
//		},function(){ layerUtils.iLoading(false); },signParam);
		var result = external.callMessage(signParam);
        var error_no;
       //android
       if(platform == "1"){
//	       var result = JSON.parse(result);
	       error_no = result.error_no;
	       result = result.results[0];
       }
       //ios
       if(platform == "2"){
	       error_no = result.error_no;
	       result = result.results[0];
       }
		if(error_no == "0") {
            
                var protocoldcsign = result.ciphertext;
            
			var protocolParam = {
				"protocol_id" : protocolid,
				"protocol_dcsign" : protocoldcsign,
				"summary" : summary
			};
			protocolArray.push(protocolParam);   // 添加值到数组中
			// 签署协议
			var signProtocolParam = {
				"user_id" : userid,
				"jsondata" : JSON.stringify(protocolArray),
				"ipaddr" : ipaddr,
				"macaddr" : macaddr
			};
			// 新开中登验签
			if(appUtils.getSStorageInfo("openChannel") == "new")
			{
				service.queryOpenCheckSign(signProtocolParam,postThirdDepositoryData,false);
			}
			// 转户天威验签
			else if(appUtils.getSStorageInfo("openChannel") == "change")
			{
				service.queryOpenCheckSign(signProtocolParam,postThirdDepositoryData,false);
			}
		} else {
			layerUtils.iLoading(false);  // 关闭等待层
		}

	}
	
	/* 提交三方存管银行数据 */
	function postThirdDepositoryData()
	{	
		service.getRSAKey({}, function(data) {
			if( data.error_no==0)	//请求获取rsa公钥成功
			{
				//密码采用rsa加密
				var results = data.results[0];
				var modulus = results.modulus;
				var publicExponent =  results.publicExponent;
				var endecryptUtils = require("endecryptUtils");
				
				//密码为空时
				if($(_pageId+"  #input_text_pass").find("em").html() == "请输入6位数字银行密码"){
					
					$(_pageId+"  #input_text_pass").find("em").html("");	//清空
				}
				
				//卡号清空
				if($(_pageId+" #input_text_bankcard").find("em").html() == "请输入银行卡号"){
				
					$(_pageId+" #input_text_bankcard").find("em").html("");	//清空账号
				}

				
				var bankpwd = endecryptUtils.rsaEncrypt(modulus, publicExponent, $(_pageId+"  #input_text_pass").attr("data-password").trim());
				var userid = appUtils.getSStorageInfo("user_id");
				var bankcode= $(_pageId+" #selectBank").attr("bankcode");
				var bankaccount = $(_pageId+" #input_text_bankcard").find("em").html();
				var thirdDepositParam = {
					"user_id":userid,
					"acct_clientid":"",
					"acct_fndacct":"",
					"bank_code":bankcode,
					"bank_account":bankaccount,
					"bank_pwd":bankpwd,
					"op_type":$(_pageId+" #selectBank").attr("zzbindtype")
				};
				// 调用service绑定存管银行
				service.bindBank(thirdDepositParam,function(data){
					var errorNo = data.error_no;
					var errorInfo = data.error_info;
					if(errorNo==0)	 // 调用成功,跳转到风险测评页面
					{
						cleanPageElement();
						appUtils.pageInit("account/thirdDepository","account/riskAssessment",{});
					}
					else
					{
						layerUtils.iLoading(false);
						layerUtils.iAlert(errorInfo,-1);
					}
				},false);
			}
			else
			{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		}, false);
	}
	
	/* 验证是否选择银行  */
	function validateSelectBank()
	{
		var obj = $(_pageId+" #selectBank");
		var value = obj.html();
		if(validatorUtil.isEmpty(value)||value=="请选择银行")
		{
			layerUtils.iMsg(-1,"请选择银行");
			return false;
		}
		return true;
	}
	
	/* 检验银行卡填写是否正确 */
	function validateBankCorrect()
	{
		var bankcard =$(_pageId+" #input_text_bankcard").find("em").html();
		if(bankcard == "")  // 验证通过的情况
		{
			layerUtils.iMsg(-1,"银行卡号不能为空！");
			return false;
		}
		if(!validatorUtil.isBankCode(bankcard))
		{
			layerUtils.iMsg(-1,"银行卡号格式有误，请重新输入！");
			return false;
		}
		return true;
	}
	
	/* 验证银行密码 */
	function validateBankPwd()
	{
		var cardPwd = $(_pageId+"  #input_text_pass").attr("data-password");  //银行卡密码
		if(!validatorUtil.isNumeric(cardPwd) || cardPwd.length !=6)
		{
			layerUtils.iMsg(-1,"银行卡密码有误，请重新输入！");
			return false;
		}
		return true;
	}
	
	/* 检测勾选阅读协议 */
	function validateDepositProtocolSelect()
	{
		if(!$(_pageId+" .icon_check").hasClass("checked"))
		{
			layerUtils.iMsg(-1,"请阅读并勾选三方存管协议!");
			return false;
		}
		return true;
	}
	
	/* 获取存管银行签约电子协议列表 */
	function getDepositoryAgreement(bankcode)
	{
		$(_pageId+" #protocolName").html("");  // 清空协议
		// 调用service查询存管银行协议
		var param = {"econtract_no" : bankcode};
		service.queryProtocolList(param,function(data){
			$(_pageId+" #protocolName").html("");
			if(data.error_no == 0)
			{
				if(data.results&&data.results.length>=1)
				{
					protocol = data.results[0];
					$(_pageId+" #protocolName").html("《"+protocol.econtract_name+"》");
					$(_pageId+" #protocolName").attr("protocolId",protocol.econtract_no);
					$(_pageId+" #protocolName").attr("protocolMd5",protocol.econtract_md5);
					// 预绑定查看银行协议内容的事件
					appUtils.preBindEvent($(_pageId+" #protocolName").parent(),"#protocolName",function(){
						if($(_pageId+"  #input_text_pass").attr("data-password") == undefined)
						{
							$(_pageId+"  #input_text_pass").attr("data-password","");
						}
						appUtils.setSStorageInfo("bankPwd",$(_pageId+"  #input_text_pass").attr("data-password").trim(),true);
						appUtils.setSStorageInfo("bankNum",$(_pageId+" #input_text_bankcard").find("em").html());
						appUtils.pageInit("account/thirdDepository","account/showProtocol",{"protocol_id":$(_pageId+" #protocolName").attr("protocolId")});
					});
				}
			}
			else
			{
				layerUtils.iAlert(data.error_info,-1);
			}
		});
	}
	
	/* 清理界面元素 */
	function cleanPageElement()
	{
		//清理页面元素
		$(_pageId+" #input_text_bankcard_keyboard em").html("请输入银行卡号");  // 卡号清理
		$(_pageId+" #input_text_pass").attr("data-password","");  // 密码清理
		$(_pageId+" #input_text_pass1_keyboard em").html("请输入6位数字交易密码");  // 密码清理
		
		$(_pageId+" .rule_check a").removeClass("checked");  // 取消勾选协议
		$(_pageId+" #selectBank").text("请选择银行");  // 清理银行卡的名字
		$(_pageId+" #bankcard").val("");  // 清理银行卡号
		$(_pageId+"  #input_text_pass").attr("data-password","");// 清空密码
		$(_pageId+"  #input_text_pass").find("em").html("");  // 清空密码
		$(_pageId+" #protocolName").text("《券商银行投资者三方协议》");  // 清理协议名
		$(_pageId+" #signInfo").html("");  // 清除银行签约信息
	}
	
	var thirdDepository = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	
	// 暴露对外的接口
	module.exports = thirdDepository;
});

/**
 * 合约状态
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils");
	var _pageId = "#rzxq_contractStatus ";
    
    /**
     * 初始化
     */
	function init() {

    }
	
	/**
	 * 事件绑定
	 */
	function bindPageEvent() {
		// 返回按钮
		appUtils.bindEvent($(_pageId + ".top_title .icon_back"), function(e){
			pageBack();
		});
		// 菜单栏跳转
		appUtils.bindEvent($(_pageId+'.tab_nav:first ul li a'), function(e){
			var pageCode = _pageId.replace("#","").replaceAll("_","/").replace(" ","");
			if($(this).attr("to-page")){
				var topage = $(this).attr("to-page");
				appUtils.pageInit(pageCode,topage,{});	
			}
			e.stopPropagation();
		 });
	}

	function destroy(){
	}
	
	/**
	 * 重写框架里面的pageBack方法
	 */
	function pageBack(){
		var fromPage = appUtils.getPageParam("fromPage");
		if(fromPage && fromPage=="userCenter"){
			appUtils.pageInit("rzxq/contractStatus","account/userCenter");
		}else{
			var param_index = {"funcNo":"50101","moduleName":"main"};
			require("external").callMessage(param_index);
		}
	}
	
	var base = {
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy,
		"pageBack": pageBack
	};
	module.exports = base;
});
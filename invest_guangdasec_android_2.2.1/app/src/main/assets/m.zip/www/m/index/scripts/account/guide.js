/**
 * 引导页
 */
define(function(require, exports, module){
	/*模块内部全局变量*/
	var appUtils = require("appUtils"),
		layerUtils = require("layerUtils"),
		utils = require("utils"),
		gconfig = require("gconfig"),
		VIscroll = require("vIscroll"),
		HIscroll = require("hIscroll"),
		myScroll = require("myScroll"),	
		global = gconfig.global,
		service = require("serviceImp"),  //业务层接口，请求数据
		_pageId = "#account_guide ";
	var carouselScroll = {"scroll":null,"_init":false};
	
	/*页面初始化方法*/
	function init()
	{
		$(_pageId+" .btn").css("margin-top",($(window).height()-185)+"px");
		$(_pageId+" #scroller_index_head li").height($(window).height());
		if(!carouselScroll._init)
		{
			var config = {
				wrapper: $(_pageId+" #wrapper_index_head"), //wrapper对象
				scroller: $(_pageId+" #scroller_index_head"), //scroller对象
				perCount: 1,  //每个可视区域显示的子元素
				showTab: true, //是否有导航点
				tabDiv: $(_pageId+" #tag_index_head"), //导航点集合对象
				auto: false, //是否自动播放
				interval: null, //自动播放定时器
				idxPage: 1, //记录当前scroll滚动到第几个page
				wrapperObj: null
			};
			carouselScroll.scroll = new HIscroll(config);
			carouselScroll._init = true;
			$(_pageId+" #scroller_index_head li").show();
		}
	}
	
	/*绑定页面事件的方法*/
	function bindPageEvent()
	{
		/*返回*/
		appUtils.bindEvent($(_pageId+" .icon_back,"+_pageId+" .fix_bot>.ce_btn"), function(e){
			appUtils.pageBack();
			e.stopPropagation();
		});
		
		/* 进入光大富尊主页 */
		appUtils.bindEvent($(_pageId+" .b1"),function(e){
		    appUtils.setLStorageInfo("isGuided", true);
//			require("external").callFunction("55033", "");
		    var param_index = {"funcNo":"50101","moduleName":"launcher"};
            require("external").callMessage(param_index);
            e.stopPropagation();
//			appUtils.pageInit("account/guide","account/active");
		});
	}
	
	/*页面销毁方法*/
	function destroy()
	{
		service.destroy();
	}
	
	/*向外暴露的 JSON 对象*/
	var guide = {
			"init" : init,
			"bindPageEvent" : bindPageEvent,
			"destroy" : destroy
	};
	
	/*对外暴露 JSON 对象*/
	module.exports = guide;
});
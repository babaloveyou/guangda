/**
 * 查询信用账户资产
 */
define(function(require, exports, module){
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
	    service = require("investService").getInstance(),  //业务层接口，请求数据
		global = require("gconfig").global,
		layerUtils = require("layerUtils"),
		validatorUtil = require("validatorUtil"),
		keyPanel = require("keyPanel"),//软键盘
		_pageId = "#account_netLogin";
	/* 私有业务模块的全局变量 end */
	
	function init()
	{
		//初始化登陆时密码和信用账号为空
		$(_pageId+" em").html("请输入交易密码");
		$(_pageId+" .fund_account").val("");
		$(_pageId+" #trade_pwd").val("");
	}
	
	function bindPageEvent()
	{
		/*初始化键盘*/
		appUtils.bindEvent($(_pageId+" #password") ,function(e){
			var input_pwd = $(this);
			input_pwd.find("em").html("");  // 清空密码
			input_pwd.attr("data-password","");  // 清空密码值
			$(_pageId+" .input_custom").addClass("active");
			setTimeout(function(){
				keyPanel.init_keyPanel(function(value){
					var curEchoText = input_pwd.find("em").html();  // 密码回显文本
					var input_pass_curPwd = input_pwd.attr("data-password") || "";  // 密码值
					var valInput=$(_pageId+" #trade_pwd");
					if(value == "del")
					{
						input_pwd.find("em").html(curEchoText.slice(0, -1));
						input_pwd.attr("data-password", input_pass_curPwd.slice(0, -1));
					}
					else
					{
						if(input_pass_curPwd.length < 6)
						{
							input_pwd.attr("data-password", input_pass_curPwd + value);  // 设置密码值
							input_pwd.find("em").html(curEchoText + "*");
							valInput.val(input_pass_curPwd + value);
						}
						else
						{
							layerUtils.iMsg(-1, "交易密码最多 6位!");
						}
					}
				}, input_pwd);
			},300);
			e.stopPropagation();	
		});

		//点击页面关闭软键盘
		appUtils.bindEvent($(_pageId),function(){
			keyPanel.closeKeyPanel();
			var mesTrade = $(_pageId+" em").html();
			if(mesTrade ==""){
				$(_pageId+" em").html("请输入交易密码");
			}
			$(_pageId+" .input_custom").removeClass("active");
		});
		
		appUtils.bindEvent($(_pageId+" .ce_btn"),function(){
			var fund_account = $(_pageId+" .fund_account").val(),   //信用账号
			tradepwd = $.trim($(_pageId+" #trade_pwd").val()),  //交易密码
			user_id = appUtils.getSStorageInfo("user_id");  //用户id
			if(checkAccount()){
				param = {
						"user_id" : user_id,
						"fund_account" : fund_account,
						"password" : tradepwd
				};
				//查询信用账户资金
				service.loginNetAccount(param,function(data){
					var error_no = data.error_no,
						error_info = data.error_info,
						result = data.results;
					if(error_no == "0" && result[0].err_no == "0"){
						var net_asset = result[0].net_asset;
						appUtils.setSStorageInfo("net_asset",net_asset);
						appUtils.pageInit("account/netLogin","account/netInfo",{});
					}else{
						if(error_no != "0"){
							layerUtils.iAlert(error_info,-1);
						}else {
							layerUtils.iAlert(result[0].err_msg,-1);
						}
					}
				});
			}
		});
		
		//绑定返回
		appUtils.bindEvent($(_pageId+" .icon_back"),function(){
			appUtils.pageBack();
		});
		
	}
	
	function checkAccount(){
		var fund_account = $(_pageId+" .fund_account").val(),
			fund_account_length = fund_account.length,
			fund_password_length = $.trim($(_pageId+" #trade_pwd").val()).length;
		if(fund_account_length < 8){
			layerUtils.iMsg(-1,"请输入8位数信用账号!");
			$(_pageId+" .fund_account").val("");
			$(_pageId+" .fund_account").html("");
			return false;
		}
		if(!validatorUtil.isNumeric(fund_account)){
			layerUtils.iMsg(-1,"请输入8位数信用账号!");
			$(_pageId+" .fund_account").val("");
			$(_pageId+" .fund_account").html("");
			return false;
		}
		if(fund_password_length < 6){
			layerUtils.iMsg(-1,"请输入6位数资金密码!");
			$(_pageId+" #trade_pwd").val("");
			$(_pageId+" #trade_pwd").html("");
			return false;
		}
		return true;
	}
	
	function destroy()
	{
		$(_pageId+" .fund_account").val("");
		$(_pageId+" #trade_pwd").val("");
		keyPanel.closeKeyPanel();
		service.destroy();
	}

	
	/* 清理界面元素*/
	function cleanPageElement()
	{
		
	}
	
	var netLogin = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	
	module.exports = netLogin;
});
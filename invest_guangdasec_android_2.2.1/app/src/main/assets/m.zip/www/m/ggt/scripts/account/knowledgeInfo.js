/*
 * 知识测评信息
 */
define(function(require, exports, module){
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
	    service = require("investService").getInstance(),  //业务层接口，请求数据
		global = require("gconfig").global,
		layerUtils = require("layerUtils"),
		knowledge_score = "",  //风险等级数字评分
		knowledgeFlag = "",  //1表示满足风险评测等级，2表示不满足
		knowledge_lvl_name = "",  //风险评测等级
		_pageId = "#account_knowledgeInfo";
	/* 私有业务模块的全局变量 end */
	
	function init()
	{
		cleanPageElement();
		//初始化处理
		initHandle();
	}
	
	function bindPageEvent()
	{
		//绑定确认键
		appUtils.bindEvent($(_pageId+" #confirm"),function(){
			appUtils.setSStorageInfo("knowledgeScore",knowledge_score);
			appUtils.pageInit("account/knowledgeInfo","account/mainPage",{"knowledgeFlag":knowledgeFlag});
		});
		
		//绑定重新评测按钮
		appUtils.bindEvent($(_pageId+" #reTest"),function(){
			appUtils.pageInit("account/knowledgeInfo","account/knowledge",{});
		});
		//绑定重新评测按钮
		appUtils.bindEvent($(_pageId+" .retest_style"),function(){
			appUtils.pageInit("account/riskInfo","account/knowledge",{});
		});
		//绑定返回按钮
		appUtils.bindEvent($(_pageId+" .icon_back"),function(){
			appUtils.setSStorageInfo("knowledgeScore",knowledge_score);
			appUtils.pageInit("account/knowledgeInfo","account/mainPage",{"knowledgeFlag":knowledgeFlag});
		});
	}
	
	function destroy()
	{
		service.destroy();
	}

	//初始化处理
	function initHandle(){
		var _prePageCode = appUtils.getSStorageInfo("_prePageCode");
		knowledge_score = appUtils.getSStorageInfo("knowledge_score");
		knowledge_lvl_name = appUtils.getSStorageInfo("knowledge_lvl_name");
		
		if(_prePageCode == "account/knowledge"){
			knowledge_score = appUtils.getPageParam("remark");
			knowledge_lvl_name = appUtils.getPageParam("riskdesc");
			appUtils.setSStorageInfo("knowledge_score",knowledge_score);
			appUtils.setSStorageInfo("knowledge_lvl_name",knowledge_lvl_name);
		}
		$(_pageId+" .chart_pic strong").html(knowledge_score);
		$(_pageId+" .test_chart h1").html(knowledge_lvl_name);
		if(knowledge_score){
			if(knowledge_score <=100 && knowledge_score >= 80){
				$(_pageId+" .retest_style").hide();
				knowledgeFlag = "1";
			}else{
				$(_pageId+" .retest_style").show();
				knowledgeFlag = "2";
			}
				$(_pageId+" #reTest").hide();
				$(_pageId+" #confirm").show();
		}
	}
	
	/* 清理界面元素*/
	function cleanPageElement()
	{
		$(_pageId+" #reTest").show();
		$(_pageId+" #confirm").hide();
	}
	
	var knowledgeInfo = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	
	module.exports = knowledgeInfo;
});
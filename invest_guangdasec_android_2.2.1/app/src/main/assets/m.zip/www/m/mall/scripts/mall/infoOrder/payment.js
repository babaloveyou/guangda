
/**
 *咨询--支付订单 
 */

define(function(require, exports, module)
	{	
	var service = require("mobileService"); //业务层接口，请求数据
	var appUtils = require('appUtils'),
	putils = require("putils"),
	constants=require("constants");//常量类
	layerUtils = require("layerUtils"),
	gconfig = require("gconfig"),
	global = gconfig.global;
	var _pageId ="#mall_infoOrder_payment";

	//1、初始化
	function init() 
	{
		info_back_resuls();

	}

	function info_back_resuls()
	{
		var pageInParam  = appUtils.getPageParam();
		var order_id=pageInParam.order_id;
		var tot_price=pageInParam.tot_price;
		var entrust_state=pageInParam.entrust_state;
		var product_name=pageInParam.product_name;
		var service_begin_time=pageInParam.service_begin_time;
		var service_end_time=pageInParam.service_end_time;
		var error_msg=pageInParam.error_msg;

		//防止直接到该页面
		if(order_id==null)
		{
			layerUtils.iMsg(1, "数据加载错误！");
			appUtils.pageInit("mall/infoOrder/payment","account/mainPage",{})
			return false;
		}


		if(entrust_state!=null&&entrust_state==constants.entrust_state.FAIL)
		{
			$(_pageId+" #sd").html(error_msg);
			$(_pageId+" h5").addClass(" no");
			$(_pageId+" #ddbh").html(order_id);
			$(_pageId+" #cpmc").html(product_name)
		}
		else if(entrust_state!=null&&entrust_state==constants.entrust_state.SUCCESS)
		{
			$(_pageId+" #sd").html("订单支付成功!");
			$(_pageId+" #ddbh").html(order_id);
			$(_pageId+" #fwzq").html(service_begin_time+'到'+service_end_time);
			$(_pageId+" #cpmc").html(product_name);
			$(_pageId+" #cpmc").append(" <h5>支付金额：￥<b><span id='jyje''></span></b></h5>")
			$(_pageId+" #jyje").html(tot_price);
		}
		else  
		{
			$(_pageId+" #sd").html("订单支付成功!");
			$(_pageId+" #ddbh").html(order_id);
			$(_pageId+" #fwzq").html(service_begin_time+' 到 '+service_end_time);
			$(_pageId+" #cpmc").html(product_name);
			$(_pageId+" #cpmc").append(" <h5><b>支付金额：￥<span id='jyje'></span></b></h5>")
			$(_pageId+" #jyje").html(tot_price);
		}
	}

	//2、事件 绑定
	function bindPageEvent()
	{


		//点击 个人中心
		appUtils.bindEvent($(_pageId+"  .n1"),function() {appUtils.pageInit("mall/infoOrder/payment","account/userCenter",{});});

		//点击 返回购物
		appUtils.bindEvent($(_pageId+"  .n2"),function(){appUtils.pageInit("mall/infoOrder/payment","account/mainPage",{});	});

		//点击 LOGO 
		appUtils.bindEvent($(_pageId+" .logo"),function(){appUtils.pageInit("mall/infoOrder/payment","account/mainPage")})

		// 点击 首页
		appUtils.bindEvent($(_pageId+" #mainPage"),function(){appUtils.pageInit("mall/infoOrder/payment","account/mainPage",{});});

		//点击 理财
		appUtils.bindEvent($(_pageId+" #finan"),function(){	appUtils.pageInit("mall/infoOrder/payment","mall/itemsFinan",{});});

		//点击 服务
		appUtils.bindEvent($(_pageId+" #serv"),function(){	appUtils.pageInit("mall/infoOrder/payment","mall/itemsServ",{});});

		//点击咨询
		appUtils.bindEvent($(_pageId+" #info"),function(){	appUtils.pageInit("mall/infoOrder/payment","mall/itemsinfo",{});});

		//点击 基金
		appUtils.bindEvent($(_pageId+" #fund"),function(){appUtils.pageInit("mall/infoOrder/payment","mall/itemsFund",{});});

		//点击 返回
		appUtils.bindEvent($(_pageId+" .icon_back"),function() {
			appUtils.pageInit("mall/infoOrder/payment","account/mainPage",{});
		});

		//点击 返回顶部
		appUtils.bindEvent($(_pageId+" .back_btn"),function(){$('body,html').animate({scrollTop:0},1000);return false;});

		//点击 个人中心  
		appUtils.bindEvent($(_pageId+"  .icon_info"),function(){
			appUtils.pageInit("mall/infoOrder/payment","account/userCenter",{});
		});

	}

	//3、销毁
	function destroy()
	{
		$(_pageId+" h5").removeClass(" no");

	}

	var payment =
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = payment;

	}); 
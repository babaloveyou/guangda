/**
 * 咨询--订单支付
 * 
 */
define(function(require, exports, module)
	{	
	var service = require("mobileService"); //业务层接口，请求数据
	var appUtils = require('appUtils'),
	putils = require("putils"),
	layerUtils = require("layerUtils"),
	constants=require("constants");//常量类
	gconfig = require("gconfig"),
	global = gconfig.global;
	var keyPanel = require("keyPanel"); //软键盘
	var _pageId ="#mall_infoOrder_orderPay";
	var timeNum = 0;
	var order_tot_price=0;

	//1、初始化
	function init()
	{	
		$(_pageId+" #che").hide(); // 将div显示
		$(_pageId+" .pay_btn a").attr("id","qrzf");
		$(_pageId+" #qrzf").attr('style',"background-color:#19e");

		findOrder();//查询订单
		$(_pageId+" #zjzh").html(appUtils.getSStorageInfo("fund_account")) //资金 账号
		$(_pageId+" #zhmc").html(appUtils.getSStorageInfo("user_name"));//账户名称
		$(_pageId+" #mobile_phone").val(appUtils.getSStorageInfo("mobile_phone"));//手机号码
		$(_pageId+" #user_mail").val(appUtils.getSStorageInfo("user_mail"));//邮箱地址
		var product_id=appUtils.getPageParam().product_id;//产品编号
		//防止直接到该页面
		if(product_id==null)
		{
			layerUtils.iMsg(1, "数据加载错误！");
			appUtils.pageInit("mall/infoOrder/orderPay","account/mainPage",{})
			return false;
		}

	}

	//初始化进来查询订单
	function findOrder(){
		var order_id=appUtils.getPageParam().order_id;   //订单编号
		var user_id=appUtils.getSStorageInfo("user_id"); //用户编号
		var param=
		{
			"user_id":user_id,
			"order_id":order_id,
			"product_sub_type":constants.product_sub_type.INFO
		}
		service.getOtherOrder(param,function(data){
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
			order_tot_price=data.results[0].order_tot_price;
			//判断是否是新订单(订单已确认)
			if(data.results[0].order_state!=constants.order_state.NEW)
			{
				layerUtils.iMsg(0,"订单已确认，请在我的订单中查看该订单",1);
				layerUtils.iLayerClose();
				layerUtils.iTipsClose();
				appUtils.pageInit("mall/infoOrder/orderPay","account/myOrder",{});
			}
			$(_pageId+" #order_price").val(data.results[0].order_price);
			$(_pageId+" #ddbh strong").html(data.results[0].order_id);//订单编号
			$(_pageId+" #zfje strong").html(data.results[0].order_tot_price);//总余额
			$(_pageId+" #fwfs strong").html(data.results[0].service_type_desc);//服务方式
			$(_pageId+" #fwzq strong:eq(0)").html(appUtils.getPageParam().rules_desc);
			//总资产
			queryAsset();
		});
	}

	//订单支付
	function orderPayment()
	{
		//加密
		service.getRSAKey({},function(data){
			if(data.error_no=="0")
			{
				var modulus = data.results[0].modulus;
				var publicExponent =data.results[0].publicExponent;
				var endecryptUtils = require("endecryptUtils");
				var trade_pwd=endecryptUtils.rsaEncrypt(modulus,publicExponent,$.trim($(_pageId+"  #trade_pwd").val()))
			}
			var param =
			{
				"fund_account":appUtils.getSStorageInfo("fund_account"),
				"order_id":  $(_pageId+" #ddbh strong").html(),
				"trade_pwd":trade_pwd
			}
			service.orderOtherPayment(param,function(data)
				{ 
				if(data.error_no!="0")
				{
					$(_pageId+" #password em").html("");//清空输入的值
					$(_pageId+" #trade_pwd").val("");//清空表单的值
					$(_pageId+" #qrzf").removeAttr("style");
					$(_pageId+" #qrzf").text("确定支付"); 
					layerUtils.iMsg(-1,data.error_info);
					layerUtils.iLoading(false);
					return false;
				}
				else
				{
					setTimeout(function(){
						getOrderInfo();
					},5000);
				}

				},{"isLastReq":false});
		},{"isLastReq":false})

	}

	//获取订单信息，轮循
	function getOrderInfo()
	{
		var param =
		{
			"user_id":appUtils.getSStorageInfo("user_id"),
			"order_id":$(_pageId+" #ddbh strong").html()
		}
		service.getOtherOrder(param,function(data){
			timeNum++;
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
			else
			{
				var results = data.results;
				var order_state = results[0].order_state;
				var entrust_state = results[0].entrust_state;
				var tot_price = results[0].order_tot_price;
				var product_name=results[0].product_name;
				var error_msg=results[0].error_msg
				if (order_state && order_state != constants.order_state.SUBMIT)
				{
					var param =
					{
						"order_id": $(_pageId+" #ddbh strong").html(),
						"tot_price": parseFloat(tot_price),
						"entrust_state": entrust_state,
						"order_state":order_state,
						"error_msg":error_msg,
						"product_name":product_name,
						"service_begin_time":$(_pageId+" #fwzq strong:eq(0)").html(),
						"service_end_time":$(_pageId+" #fwzq strong:eq(1)").html()
					};
					layerUtils.iLoading(false);
					appUtils.pageInit("mall/infoOrder/orderPay","mall/infoOrder/payment",param);
				}
				else
				{
					if(timeNum < 3)
					{
						setTimeout(function(){
							getOrderInfo();
						}, 5000);
					}
					else
					{
						var results = data.results;
						var order_state = results[0].order_state;
						var entrust_state = results[0].entrust_state;
						var tot_price = results[0].order_tot_price
						var param =
						{
							"order_id": $(_pageId+" #ddbh strong").html(),
							"tot_price": parseFloat(tot_price),
							"entrust_state": entrust_state,
							"order_state": order_state,
							"product_name":product_name,
							"service_begin_time":$(_pageId+" #fwzq strong:eq(0)").html(),
							"service_end_time":$(_pageId+" #fwzq strong:eq(1)").html()

						};
						layerUtils.iLoading(false);
						appUtils.pageInit("mall/infoOrder/orderPay","mall/infoOrder/payment",param);
					}
				}
			}
		},{"isLastReq":false});
	}

	//总资产
	function queryAsset()
	{
		var param={"fund_account" : appUtils.getSStorageInfo("fund_account")};

		/*调用查询资金接口*/
		service.queryAsset(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result = data.results;
			var pageInParam  = appUtils.getPageParam();
			var total_money=result[0].withdraw_money;//保存可用资金余额
			var order_id=pageInParam.order_id;

			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
			//页面展示
			$(_pageId+" #zzc").html(parseFloat(total_money).toFixed(2)) //总资产
			if(parseFloat($.trim(order_tot_price))>parseFloat($.trim(total_money)))
			{	
				$(_pageId+" #qrzf").attr('style',"background-color:gray");
				$(_pageId+" #qrzf").removeAttr("id");
				//				$(_pageId+" #password").removeAttr("id"); //
				//				$(_pageId+" #trade_pwd").removeAttr("id");//将 ‘交易密码’ id去除 disabled="disabled" 
				//				$(_pageId+" input[type='password']").attr("disabled","disabled");//将密码输入框设为不能输入 
				//				$(_pageId+" .pay_btn a").removeAttr("href");  //去除a标签手势
				//				$(_pageId+" .pay_btn a").removeAttr("id");  //去id
				$(_pageId+" #che").show(); // 将div显示
				var product_id=appUtils.getPageParam().product_id;//产品编号
				var param=
				{
					"order_id":order_id,
					"product_id":product_id
				}
				layerUtils.iConfirm("资金不足，是否进行转账？",function(){
					appUtils.pageInit("mall/infoOrder/orderPay","account/bankTransfer",param);
					return false;
				});
			}
		});
	}
	
	//推荐人
	function referrer(){
		var referrer_name=$(_pageId+" #Referrer").val();
//		var referrer_code=$(_pageId+" #Referrer").val();
		/*调用推荐人接口*/
		var param={
				"order_id":$(_pageId+" #ddbh strong").html(),
				"referrer_name":referrer_name
		};
		service.addReferrer(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result = data.results;
			if(error_no=="0")
			{
				
			}else{
				layerUtils.iAlert(error_info);
				layerUtils.iLoading(false);
				return false;
			}

		});
	}


	//填写预留信息（手机，邮箱）
	function mobile_phoneOrUser_mailInfo()
	{
		var order_id=appUtils.getPageParam().order_id;      //订单编号
		var user_mail =$.trim($(_pageId+" #user_mail" ).val());		//邮箱
		var mobile_phone=$.trim($(_pageId+" #mobile_phone").val());	//手机
		var param=
		{
			"order_id":order_id,
			"user_mail":user_mail,
			"mobile_phone":mobile_phone
		}
		service.mobile_phoneOrUser_mailInfo(param,function(data){
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
		})
	}

	//2、事件绑定
	function bindPageEvent()
	{
		/*初始化键盘*/
		appUtils.bindEvent($(_pageId+" #password") ,function(e){
			var input_pwd = $(this);
			input_pwd.find("em").html("");  // 清空密码
			input_pwd.attr("data-password","");  // 清空密码值
			$(_pageId+" .input_custom").addClass("active");
			keyPanel.init_keyPanel(function(value){
				var curEchoText = input_pwd.find("em").html();  // 密码回显文本
				var input_pass_curPwd = input_pwd.attr("data-password") || "";  // 密码值
				var valInput=$(_pageId+" #trade_pwd");
				if(value == "del")
				{
					input_pwd.find("em").html(curEchoText.slice(0, -1));
					input_pwd.attr("data-password", input_pass_curPwd.slice(0, -1));
					valInput.val(input_pwd.attr("data-password"));
				}
				else
				{
					if(input_pass_curPwd.length < 6)
					{
						input_pwd.attr("data-password", input_pass_curPwd + value);  // 设置密码值
						input_pwd.find("em").html(curEchoText + "*");
						valInput.val(input_pass_curPwd + value);
					}
					else
					{
						layerUtils.iMsg(-1, "交易密码最多 6位!");
					}
				}
			}, input_pwd);
			e.stopPropagation();
//			$(_pageId+" #password em").html("");
//			$(_pageId+" .input_custom").addClass(" active");
//			$(_pageId+" #trade_pwd").val("");
//			var passwordInput=$(_pageId+" #password em");
//			var valInput=$(_pageId+" #trade_pwd");
//			keyPanel.init_keyPanel(_pageId,valInput.val(),valInput,function(pw)
//				{
//				var ch="";
//				for(var i=0;i<pw.length;i++){
//					ch+="*";
//				}
//				passwordInput.html(ch);
//				valInput.val(pw);
//				valInput.text("");
//				},"num","密码");
//			e.stopPropagation();	
		});

		//点击页面关闭软键盘
		appUtils.bindEvent($(_pageId),function(){
			keyPanel.closeKeyPanel();
			$(_pageId+" .input_custom").removeClass(" active");
		});

		//提交订单
		appUtils.bindEvent($(_pageId+" .pay_btn #qrzf"),function() 
			{
			$(_pageId+" .input_custom").removeClass(" active");
			var name=$(_pageId+" .pay_btn a").attr("id");
			if(name==null||name=="")
			{
				return false;
			}

			var fund_money=$(_pageId+" #zzc").html();
			if(fund_money==""||fund_money==null||fund_money<="0")
			{
				return false;
			}

			//输入校验
			var check_user_mail =$.trim($(_pageId+" #user_mail" ).val());		//邮箱
			var check_mobile_phone=$.trim($(_pageId+" #mobile_phone").val());	//手机 
			var check_isNull=$.trim($(_pageId+" #trade_pwd").val());
			var filter_mobile=/^0?(13[0-9]|15[012356789]|18[0236789]|14[57])[0-9]{8}$/;
			var filter_mail  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;//验证邮箱

			if(check_mobile_phone==null||check_mobile_phone=="")
			{
				layerUtils.iMsg(0,"手机号码不能为空");
				return false;
			}
			if(filter_mobile.test(check_mobile_phone)!=true)
			{
				layerUtils.iMsg(0,"手机号码不合法");
				return false;
			}
			/*if(check_user_mail!="")
			{
				if(filter_mail.test(check_user_mail)!=true)
				{
					layerUtils.iMsg(0,"邮箱地址不合法");
					return false;
				}

			}*/

			if(check_isNull==null||check_isNull=="")
			{
				layerUtils.iMsg(0,"密码不能为空");
				return false;
			}
			$(this).css("background","#CDCDCD");
			$(_pageId+" #qrzf").text("支付中···"); 
			$(this).removeAttr("href");

			//填写预留信息（手机，邮箱）
			mobile_phoneOrUser_mailInfo();
			//添加推荐人
			referrer();
			
			//支付订单
			orderPayment();
			});

		//点击理财
		appUtils.bindEvent($(_pageId+" #finan"),function() {appUtils.pageInit("mall/infoOrder/orderPay","mall/itemsFinan",{});});

		//点击基金
		appUtils.bindEvent($(_pageId+" #fund"),function(){appUtils.pageInit("mall/infoOrder/orderPay","mall/itemsFund",{});});

		//点击 LOGO 
		appUtils.bindEvent($(_pageId+" .logo"),function(){appUtils.pageInit("mall/infoOrder/orderPay","account/mainPage")})

		//绑定返回事件
		appUtils.bindEvent($(_pageId+" .icon_back"),function(){appUtils.pageBack();});

		//点击 返回顶部
		appUtils.bindEvent($(_pageId+" .back_btn"),function(){$('body,html').animate({scrollTop:0},1000);return false;});

		//切换银联支付
		appUtils.bindEvent($(_pageId+" #ylzf"),function(){layerUtils.iMsg(0,"暂不支持银联支付");return false;})

		// 点击 链接 个人中心
		appUtils.bindEvent($(_pageId+" #grzx"),function(){appUtils.pageInit("mall/infoOrder/orderPay","account/userCenter")})

		//点击登录
		appUtils.bindEvent($(_pageId+" .icon_info"),function(){
			appUtils.pageInit("mall/infoOrder/orderPay","account/userCenter",{});
		});
	}


	//3、销毁
	function destroy()
	{
		appUtils.pageResetValue("mall_infoOrder_orderPay");
		$(_pageId+" #password em").html("");//清空输入的值
		$(_pageId+" #qrzf").removeAttr("style");
		$(_pageId+" #qrzf").text("确定支付"); 

	}	

	var orderPay =
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = orderPay;

	});
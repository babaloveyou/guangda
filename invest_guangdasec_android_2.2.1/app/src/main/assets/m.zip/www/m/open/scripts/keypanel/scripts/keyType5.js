/**
 * 股票键盘
 */
define(function (require, exports, module) {
	var keyPanelId = "KeyPanelStock",
		aKeyPanelHtml = null;
	
	/**
	 * 创建键盘字符串
	 */
	function createKeyPanelHtml()
	{
		if(aKeyPanelHtml)
		{
			aKeyPanelHtml = null;
		}
		aKeyPanelHtml = [];
		
		/**
		 * 自定属性 btn-type 1 字母或者数字，2 隐藏键盘，3 删除按钮，4 切换到数字键盘，5 切换到英文键盘，6 确定，7 空格，8 搜索，9 大小写切换，10 股票代码
		 */
		aKeyPanelHtml.push('<div class="word_table" id="KeyPanelStock" style="display: none;">');
		aKeyPanelHtml.push('<table width="100%" border="0" cellspacing="0" cellpadding="0">');
		aKeyPanelHtml.push('<tbody>');
		aKeyPanelHtml.push('<tr>');
		aKeyPanelHtml.push('<td width="25%">');
		aKeyPanelHtml.push('<div class="word_code_num">');
		aKeyPanelHtml.push('<a herf="javascript:void(0)" btn-type="10"><span>600</span></a>');
		aKeyPanelHtml.push('<a herf="javascript:void(0)" btn-type="10"><span>601</span></a>');
		aKeyPanelHtml.push('<a herf="javascript:void(0)" btn-type="10"><span>000</span></a>');
		aKeyPanelHtml.push('<a herf="javascript:void(0)" btn-type="10"><span>002</span></a>');
		aKeyPanelHtml.push('<a herf="javascript:void(0)" btn-type="10"><span>300</span></a>');
		aKeyPanelHtml.push('</div></td>');
		aKeyPanelHtml.push('<td width="75%">');
		aKeyPanelHtml.push('<table width="100%" border="0" cellspacing="0" cellpadding="0" class="word_num_table">');
		aKeyPanelHtml.push('<tbody>');
		aKeyPanelHtml.push('<tr class="col4">');
		aKeyPanelHtml.push('<td><a herf="javascript:void(0)" btn-type="1">1</a></td>');
		aKeyPanelHtml.push('<td><a herf="javascript:void(0)" btn-type="1">2</a></td>');
		aKeyPanelHtml.push('<td><a herf="javascript:void(0)" btn-type="1">3</a></td>');
		aKeyPanelHtml.push('</tr>');
		aKeyPanelHtml.push('<tr class="col4">');
		aKeyPanelHtml.push('<td><a herf="javascript:void(0)" btn-type="1">4</a></td>');
		aKeyPanelHtml.push('<td><a herf="javascript:void(0)" btn-type="1">5</a></td>');
		aKeyPanelHtml.push('<td><a herf="javascript:void(0)" btn-type="1">6</a></td>');
		aKeyPanelHtml.push('</tr>');
		aKeyPanelHtml.push('<tr class="col4">');
		aKeyPanelHtml.push('<td><a herf="javascript:void(0)" btn-type="1">7</a></td>');
		aKeyPanelHtml.push('<td><a herf="javascript:void(0)" btn-type="1">8</a></td>');
		aKeyPanelHtml.push('<td><a herf="javascript:void(0)" btn-type="1">9</a></td>');
		aKeyPanelHtml.push('</tr>');
		aKeyPanelHtml.push('<tr class="col3">');
		aKeyPanelHtml.push('<td><a class="hide" btn-type="2">&nbsp;</a></td>');
		aKeyPanelHtml.push('<td><a herf="javascript:void(0)" btn-type="1">0</a></td>');
		aKeyPanelHtml.push('<td><a class="del" btn-type="3">&nbsp;</a></td>');
		aKeyPanelHtml.push('</tr>');
		aKeyPanelHtml.push('</tbody>');
		aKeyPanelHtml.push('</table></td>');
		aKeyPanelHtml.push('</tr>');
		aKeyPanelHtml.push('</tbody>');
		aKeyPanelHtml.push('</table>');
		aKeyPanelHtml.push('</div>'); 
		
		return aKeyPanelHtml.join("");
	}
	
	var keyPanel = {
			createKeyPanelHtml: createKeyPanelHtml,
			keyPanelId: keyPanelId
	}

	//暴露对外的接口
	module.exports = keyPanel;	
});
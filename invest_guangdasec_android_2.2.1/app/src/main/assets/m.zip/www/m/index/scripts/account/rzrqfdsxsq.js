/*
 * 融资融券浮动授信申请
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	_pageId = "#account_rzrqfdsxsq ";
	
	/*
	 * 页面初始化
	 */
	function init(){
		service.queryRzrqAccount({"fund_account":appUtils.getSStorageInfo("fund_account")},function(data){
			if(data.error_no == 0){
				$(_pageId+" .user_box strong").html(data.results[0].rzrqzh);
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		});
		
	}
	
	/*
	 * 绑定页面事件
	 */
	function bindPageEvent(){
		
		//返回
		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(){
			appUtils.pageBack();
		});
		
		//点击协议
		appUtils.bindEvent($(_pageId+" .deal_box a"),function(){
			appUtils.pageInit("account/rzrqfdsxsq","account/showProtocol",{"econtract_no":"20150602_1"});
		});
		
		//协议选择框
		appUtils.bindEvent($(_pageId+" .icon_check"),function(){
			$(this).toggleClass("active");
		});
		
		//开通
		appUtils.bindEvent($(_pageId+" .btn_box2 a:eq(0)"),function(){
			if($(_pageId+" .icon_check").hasClass("active") == false){
				layerUtils.iMsg(-1,"开通前，请同意相关协议");
				return;
			}
			
			
			var par = {
				"fund_account":appUtils.getSStorageInfo("fund_account"),
				"scust_auth":1,
				"econtract_name":"光大证券股份有限融资融券浮动授信风险揭示书",
				"branch_no":appUtils.getSStorageInfo("branch_no")
			};
			service.ktOrQxFdsx(par,function(data){
				if(data.error_no == 0){
					if(data.error_no == 0){
					if(data.results[0].return_code == "0000"){
						layerUtils.iMsg(-1,"您已成功开通融资融券浮动授信");
					}else{
						layerUtils.iMsg(-1,"开通失败");
					}
				}else{
					layerUtils.iLoading(false);
					layerUtils.iAlert(data.error_info);
				}
				}else{
					layerUtils.iLoading(false);
					layerUtils.iAlert(data.error_info);
				}
			});
		});
		
		//取消
		appUtils.bindEvent($(_pageId+" .btn_box2 a:eq(1)"),function(){
			var par = {
				"fund_account":appUtils.getSStorageInfo("fund_account"),
				"scust_auth":0,
				"econtract_name":"光大证券股份有限融资融券浮动授信风险揭示书",
				"branch_no":appUtils.getSStorageInfo("branch_no")
			};
			service.ktOrQxFdsx(par,function(data){
				if(data.error_no == 0){
					if(data.results[0].return_code == "0000"){
						layerUtils.iMsg(-1,"您已成功取消融资融券浮动授信");
					}else{
						layerUtils.iMsg(-1,"取消失败");
					}
				}else{
					layerUtils.iLoading(false);
					layerUtils.iAlert(data.error_info);
				}
			});
		});
	}
	
	/*
	 * 销毁页面
	 */
	function destroy(){}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy
	};
	//暴露方法
	module.exports = base;
});
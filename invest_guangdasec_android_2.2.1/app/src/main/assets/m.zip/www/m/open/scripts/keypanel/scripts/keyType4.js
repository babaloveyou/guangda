/**
 * 英文键盘
 */
define(function (require, exports, module) {
	var keyPanelId = "KeyPanelAbc",
		aKeyPanelHtml = null;
	
	/**
	 * 创建键盘字符串
	 */
	function createKeyPanelHtml()
	{
		if(aKeyPanelHtml)
		{
			aKeyPanelHtml = null;
		}
		aKeyPanelHtml = [];
		
		/**
		 * 自定属性 btn-type 1 字母或者数字，2 隐藏键盘，3 删除按钮，4 切换到数字键盘，5 切换到英文键盘，6 确定，7 空格，8 搜索，9 大小写切换，10 股票代码
		 */
		aKeyPanelHtml.push('<div class="word_table" id="KeyPanelAbc" style="display: none;">');
		aKeyPanelHtml.push('<table width="100%" border="0" cellspacing="0" cellpadding="0" class="word_abc_table">');
		aKeyPanelHtml.push('<tbody>');
		aKeyPanelHtml.push('<tr class="col10">');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">q</a></td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">w</a></td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">e</a></td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">r</a></td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">t</a></td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">y</a></td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">u</a></td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">i</a></td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">o</a></td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">p</a></td>');
		aKeyPanelHtml.push('</tr>');
		aKeyPanelHtml.push('<tr class="col10">');
		aKeyPanelHtml.push('<td>&nbsp;</td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">a</a></td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">s</a></td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">d</a></td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">f</a></td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">g</a></td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">h</a></td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">j</a></td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">k</a></td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">l</a></td>');
		aKeyPanelHtml.push('<td>&nbsp;</td>');
		aKeyPanelHtml.push('</tr>');
		aKeyPanelHtml.push('<tr class="col10">');
		aKeyPanelHtml.push('<td colspan="3"><a class="caps" id="BSWord" btn-type="9">&nbsp;</a></td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">z</a></td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">x</a></td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">c</a></td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">v</a></td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">b</a></td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">n</a></td>');
		aKeyPanelHtml.push('<td colspan="2"><a herf="javascript:void(0)" btn-type="1">m</a></td>');
		aKeyPanelHtml.push('<td colspan="3"><a class="del" btn-type="3">&nbsp;</a></td>');
		aKeyPanelHtml.push('</tr>');
		aKeyPanelHtml.push('<tr class="col3">');
		aKeyPanelHtml.push('<td colspan="4"><a class="hide" btn-type="2">&nbsp;</a></td>');
		aKeyPanelHtml.push('<td colspan="4"><a class="btn" btn-type="4">123</a></td>');
		aKeyPanelHtml.push('<td colspan="8"><a class="space" btn-type="7">&nbsp;</a></td>');
		aKeyPanelHtml.push('<td colspan="4"><a class="btn" btn-type="8">搜索</a></td>');
		aKeyPanelHtml.push('</tr>');
		aKeyPanelHtml.push('</tbody>');
		aKeyPanelHtml.push('</table>');
		aKeyPanelHtml.push('</div>'); 
		
		return aKeyPanelHtml.join("");
	}
	
	var keyPanel = {
			createKeyPanelHtml: createKeyPanelHtml,
			keyPanelId: keyPanelId
	}

	//暴露对外的接口
	module.exports = keyPanel;	
});
/**
 * 手机前端Service层调用接口
 */

define(function(require,exports,module){
    var appUtils = require("appUtils");
    var gconfig = require("gconfig");
    var global = gconfig.global;
    var service = require("service");
    var serviceSingleton = new service.Service();

    /********************************公共代码部分********************************/
    function commonInvoke(paraMap, callback, ctrlParam, reqParamVo){
        reqParamVo.setReqParam(paraMap);
        ctrlParam = ctrlParam?ctrlParam:{};
        reqParamVo.setIsLastReq(ctrlParam.isLastReq);
        reqParamVo.setIsAsync(ctrlParam.isAsync);
        reqParamVo.setIsShowWait(ctrlParam.isShowWait);
        reqParamVo.setTimeOutFunc(ctrlParam.timeOutFunc);
        reqParamVo.setIsShowOverLay(ctrlParam.isShowOverLay);
        reqParamVo.setTipsWords(ctrlParam.tipsWords);
        reqParamVo.setDataType(ctrlParam.dataType);
        reqParamVo.setIsGlobal(ctrlParam.isGlobal);
        reqParamVo.setProtocol(ctrlParam.protocol);
        serviceSingleton.invoke(reqParamVo, callback);
    }

    function destroy(){
        serviceSingleton.destroy();
    }

    var mobileService = {
        //为了避免以前调用getInstance方法报错
        "getInstance": getInstance,
        "destroy": destroy
    };

    function getInstance(){
        return mobileService;
    }

    module.exports = mobileService;


    /********************************应用接口开始********************************/
     /**
      * 登陆资金账号(1004201)
      */
    mobileService.loginAccount = function(param,callback,ctrlParam){
       var paraMap = {};
		paraMap["funcNo"] = "1004201";
		paraMap["fund_account"] = param.fund_account;
	//	paraMap["password"] = param.password;
	//	paraMap["verify_code"] = param.verify_code;
		paraMap["branch_no"] = param.branch_no;

        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     * 查询信用资产
     */
    mobileService.loginNetAccount = function(param,callback,ctrlParam) {
    	var paraMap = {};
		paraMap["funcNo"] = "1004202";
		paraMap["user_id"] = param.user_id;
		paraMap["fund_account"] = param.fund_account;
		paraMap["password"] = param.password;

        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     * 查询问卷
     */
    mobileService.queryRiskToc = function(param,callback,ctrlParam) {
    	var paraMap = {};
		paraMap["funcNo"] = "1004209";
		//1：风险测评 2诚信测评 3：知识测评 4：机构风险测评 5机构诚信测评 6：机构知识测评 7查询全部
		paraMap["survey_type"] = param.survey_type;

        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };


    /**
     * 提交风险评测答案
     */
    mobileService.submitTestAnswer = function(param,callback,ctrlParam) {
    	var paraMap = {};
		paraMap["funcNo"] = "1004210";
		//1：风险测评 2诚信测评 3：知识测评 4：机构风险测评 5机构诚信测评 6：机构知识测评 7查询全部
		paraMap["survey_type"] = param.survey_type;
		paraMap["user_id"] = param.user_id;
		paraMap["answer_str"] = param.answer_str;
		
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     * 查询协议
     */
    mobileService.getSign = function(param,callback,ctrlParam) {
    	var paraMap = {};
		paraMap["funcNo"] = "1004203";
		paraMap["category_englishname"] = param.category_englishname;
		paraMap["category_no"] = param.category_no;
		paraMap["econtract_no"] = param.econtract_no;
		
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     * 签署协议
     */
    mobileService.queryOpenCheckSign = function(param,callback,ctrlParam) {
    	var paraMap = {};
 		paraMap["funcNo"] = "1004208";
 		paraMap["user_id"] = param.user_id;
 		paraMap["jsondata"] = param.jsondata;
 		paraMap["ipaddr"] = param.ipaddr;
 		paraMap["macaddr"] = param.macaddr;
 		paraMap["checksign"] = param.checksign;
 		
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };


    /**
     * 查看协议内容
     */
    mobileService.getProtocolInfo = function(param,callback,ctrlParam) {
    	 var paraMap = {};
 		paraMap["funcNo"] = "1004204";
 		paraMap["econtract_no"] = param.econtract_no;
 		paraMap["econtract_version"] = param.econtract_version;
 		
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };


    /**
     * 开通港股通权限
     */
    mobileService.openAccount = function(param,callback,ctrlParam) {
    	 var paraMap = {};
 		paraMap["funcNo"] = "1004221";
 		paraMap["user_id"] = param.user_id;
 		paraMap["trade_pwd"] = param.trade_pwd;
 		
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     * 发送验证码
     */
    mobileService.sendSmsCode = function(param,callback,ctrlParam) {
    	 var paraMap = {};
  		paraMap["funcNo"] = "1004222";
  		paraMap["mobile_no"] = param.mobile_no;
  		
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     * 检验验证码
     */
    mobileService.checkSmsCode = function(param,callback,ctrlParam) {
    	var paraMap = {};
 		paraMap["funcNo"] = "1004223";
 		paraMap["mobile_no"] = param.mobile_no;
 		paraMap["mobile_code"] = param.mobile_code;
 		
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
     * 提交电话号码修改
     */
    mobileService.submitMobileNo = function(param,callback,ctrlParam) {
    	var paraMap = {};
 		paraMap["funcNo"] = "1004224";
 		paraMap["user_id"] = param.user_id;
 		paraMap["contact_mobile"] = param.contact_mobile;
 		
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
	 * 功能:加入开通港股通跑批队列(1004225)
	 * 入参: callback: 回调函数
	 */
    mobileService.joinBatch = function(param,callback,ctrlParam) {
    	var paraMap = {};
		paraMap["funcNo"] = "1004225";
		paraMap["user_id"] = param.user_id;
		
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
	 * 功能:加入开通港股通跑批队列(1004216)
	 * 入参: callback: 回调函数
	 */
    mobileService.saveUserTemp = function(param,callback,ctrlParam) {
    	var paraMap = {};
		paraMap["funcNo"] = "1004216";
		paraMap["user_id"] = param.user_id;
		paraMap["current_step"] = param.current_step;
		
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

    /**
	 * 功能:切换资金账号重新登录(1000001)
	 * 入参: callback: 回调函数
	 */
    mobileService.changAccount = function(param,callback,ctrlParam) {
    	var paraMap = {};
		paraMap["funcNo"] = "1000001";
		paraMap["fundacc"] = param.fund_account;
		paraMap["branch_no"] = param.branch_no;
		
        var reqParamVo = new service.ReqParamVo();
        reqParamVo.setUrl(global.serverPath);
        commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };

   

    /********************************应用接口结束********************************/
});

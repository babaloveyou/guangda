/*
 * 设置预留资金
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	_pageId = "#xjb_setReserveFunds ";
	
	/*
	 * 页面初始化
	 */
	function init(){
		if($(_pageId).width()<=336){
			$(_pageId+" .mn_tab ul li a").css({"font-size":"10px"});
		}
		var par = {
			"branch_no":appUtils.getSStorageInfo("branch_no"),
			"fund_account":appUtils.getSStorageInfo("fund_account"),
			"market":"1"
		};
		service.queryYlkqje(par,function(data){
			if(data.error_no == 0){
				if(data.results.length>0 && "money" in data.results[0]){
					$(_pageId+" .input_box p").html(parseFloat(data.results[0].money).toFixed(2));
				}else{
					//layerUtils.iAlert("获取预留金额失败");
				}
			}else{
				layerUtils.iLoading(false);
				var error = data.error_info;
				//后台返回的提示信息不友好
				if(error.indexOf("SQL")> -1){
					error = error.split("SQL")[0];
					error = error.substring(0,error.length-2);
				}
			}
		});
	}
	
	/*
	 * 绑定页面事件
	 */
	function bindPageEvent(){
		
		//返回
		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(){
			appUtils.pageInit("xjb/setReserveFunds","account/userCenter",{});
		});
		
		//tab0
		appUtils.bindEvent($(_pageId+" .mn_tab .setReservationItem"),function(){
			appUtils.pageInit("xjb/setReserveFunds","xjb/setReservation");
		});
		
		//tab1
		appUtils.bindEvent($(_pageId+" .mn_tab .fastCashItem"),function(){
			appUtils.pageInit("xjb/setReserveFunds","xjb/fastCash",{});
		});
		
		//tab2
		appUtils.bindEvent($(_pageId+" .mn_tab .setReserveFundsItem"),function(){
			
		});
		
		//tab3
		appUtils.bindEvent($(_pageId+" .mn_tab .setStateItem"),function(){
			appUtils.pageInit("xjb/setReserveFunds","xjb/setState",{});
		});
		
		//tab4
		appUtils.bindEvent($(_pageId+" .mn_tab .queryQuotientItem"),function(){
			appUtils.pageInit("xjb/setReserveFunds","xjb/queryQuotient",{});
		});
	}
	
	/*
	 * 销毁页面
	 */
	function destroy(){
		
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy
	};
	//暴露方法
	module.exports = base;
});
/**
 * 股票质押合约状态
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils");
	var layerUtils = require("layerUtils");
	var validatorUtil = require("validatorUtil");
	var gconfig = require("gconfig");
	var global = gconfig.global;
	var service = require("serviceImp");  // 业务层接口，请求数据
	var _pageId = "#rzxq_stockRepay ";
    
    /**
     * 初始化
     */
	function init() {
        queryStockRepayList(); // 股票质押合约列表
		$(_pageId+".data").scrollTop(0);
		$(_pageId+".data").css("overflow-y","auto");
        var height_meau = $(window).height() - $(_pageId+".header").height() - $(_pageId+".top_nav").height() - 10;
		$(_pageId+".data").height(height_meau); //查询目录添加高度
    }
	
	/**
	 * 事件绑定
	 */
	function bindPageEvent() {
		// 返回按钮
		appUtils.bindEvent($(_pageId + ".top_title .icon_back"), function(e){
			pageBack();
		});
		// 菜单栏跳转
		appUtils.bindEvent($(_pageId+'.top_nav:first ul li a'), function(e){
			var pageCode = _pageId.replace("#","").replaceAll("_","/").replace(" ","");
			if($(this).attr("to-page")){
				var topage = $(this).attr("to-page");
				appUtils.pageInit(pageCode,topage,{});	
			}
			e.stopPropagation();
		 });
	}
    
	/**
	 * 查询股票质押列表
	 */
	function queryStockRepayList(){
		var userInfo =  JSON.parse(appUtils.getSStorageInfo("userinfo"));
		var account = userInfo.client_no;
		var branch_no = userInfo.branch_no;
		var param = {
			"account":account,
			"branch_no":branch_no
		};	
		service.query630(param,function(data){
			if(data.error_no == "0"){  
				var result = data.results;
				if(result && result.length>0){
					var data = "";
                    for(var i=0,len=result.length;i<len;i++){
                    	data += queryHTML(result[i],i+1);
                    }
                	$(_pageId + "#conList").html(data);
                	appUtils.bindEvent($(_pageId+".mn_bond .power"), function(e){
                		var market = $(this).attr("data-market"); // 市场
                		appUtils.setSStorageInfo("market",market);
                		appUtils.pageInit("rzxq/stockRepay","rzxq/sellRepay");
    				});
				}else{
					$(_pageId + ".no_data").show(); // 没有数据时显示的暂无数据图标
				}
			}else{
				layerUtils.iAlert(data.error_info,-1);
			}
		});
	}
	function queryHTML(element,index){
		var eleHTML = "";
	    	eleHTML += "<div class=\"mn_bond\">";
	    	eleHTML += "<div class=\"top_bond\">";
	    	eleHTML += "	<a href=\"javascript:void(0);\" class=\"power\" data-market="+element.market+">卖券还款</a>";
	    	eleHTML += "	<em>"+index+"</em><h3>"+element.zq_name+"</h3>";
		    eleHTML += "</div>";	
			eleHTML += "<table>";
			eleHTML += "	<tr>";
			eleHTML += "		<th width=\"20%\">股票代码</th>";
			eleHTML += "		<td width=\"20%\">"+element.zq_code+"</td>";
			eleHTML += "		<th width=\"20%\">协议编号</th>";
			eleHTML += "		<td width=\"20%\">"+element.xysbh+"</td>";
			eleHTML += "	</tr>";
			eleHTML += "	<tr>";
			eleHTML += "		<th>质押股数</th>";
			eleHTML += "		<td>"+element.bdsl+"</td>";
			eleHTML += "		<th>协议状态</th>";
			eleHTML += "		<td>"+element.xyszt+"</td>";
			eleHTML += "	</tr>";
			eleHTML += "	<tr>";
			eleHTML += "		<th>借款金额</th>";
			eleHTML += "		<td>"+element.cshjyje+"</td>";
			eleHTML += "		<th>借款利率</th>";
			eleHTML += "		<td>"+element.ghjg+"</td>";
			eleHTML += "	</tr>";
			eleHTML += "</table>";
			eleHTML += "</div>";
	    return eleHTML;
	}
	
	function destroy(){
		
	}
	
	/**
	 * 重写框架里面的pageBack方法
	 */
	function pageBack(){
		var fromPage = appUtils.getSStorageInfo("fromPage");
		if(fromPage && fromPage=="userCenter"){
			appUtils.clearSStorage("fromPage");
			appUtils.pageInit("rzxq/stockRepay","account/userCenter");
		}else{
			var param_index = {"funcNo":"50101","moduleName":"main"};
			require("external").callMessage(param_index);
		}
	}
	
	var base = {
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy,
		"pageBack": pageBack
	};
	module.exports = base;
});
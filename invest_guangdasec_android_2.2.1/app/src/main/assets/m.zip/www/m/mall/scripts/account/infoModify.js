/**
 * 资料修改
 */
define(function(require, exports, module) 
	{
	var appUtils = require("appUtils");
	var gconfig = require("gconfig");
	var service = require("mobileService"); //业务层接口，请求数据
	var global = gconfig.global;
	var validatorUtil = require("validatorUtil");
	var dateUtils= require("dateUtils");
	var layerUtils = require("layerUtils");
	var _pageId ="#account_infoModify";
	var user_id="";
	var gender ="";
	var identity_type ="";

	/*初始化*/
	function init()
	{
		queryUserInfo();
	}

	function bindPageEvent() 
	{

		/* 绑定返回事件 */
		appUtils.bindEvent($(_pageId+"  .icon_back"),function()
			{
			appUtils.pageBack();
			});

		/* 绑定LOGO事件 */
		appUtils.bindEvent($(_pageId+" .header .logo"),function(){
			appUtils.pageInit("account/infoModify","account/mainPage",{});
		});

		/* 绑定返回首页事件 */
		appUtils.bindEvent($(_pageId+" .icon_mall"),function(){
			appUtils.pageInit("account/infoModify","account/mainPage",{});
		});

		/* 重置*/
		/*appUtils.bindEvent($(_pageId+" .change_btn .n1") ,function(){
			destroy();
		});*/

		/* 下一步(确认查询)*/
		/*appUtils.bindEvent($(_pageId+" .change_btn .n2") ,function(){
			if(verifyInfo()) 
			{
				submitInfo(); // 校验数据
			}
		});*/
	}

	function queryUserInfo(){
		user_id =appUtils.getSStorageInfo("user_id");
		var account_name =appUtils.getSStorageInfo("account_name");
		var fund_account=appUtils.getSStorageInfo("fund_account");
		var risk_level_txt=appUtils.getSStorageInfo("risk_level_txt");
		var param={
			"user_id" : user_id,
			"account_name" : account_name
		};
		/*调用用户信息查询接口*/
		service.queryUserInfo(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result = data.results[0];
			if(error_no == "0" && result.length != 0)
			{
				gender=result.gender;
				identity_type=result.identity_type;
				if(gender==0){
					$(_pageId+" .gender").val("男");
				}if(gender==1){
					$(_pageId+" .gender").val("女");
				}else{
					$(_pageId+" .gender").val("未知");
				}
				if(identity_type==0){
					$(_pageId+" .identity_type").val("居民身份证");
				}
				$(_pageId+" .user_name").val(result.user_name);
				$(_pageId+" .account_name").val(account_name);
				$(_pageId+" .fund_account").val(fund_account);
				$(_pageId+" .risk_level_txt").val(risk_level_txt);
				$(_pageId+" .identity_num").val(result.identity_num);
				//日期转换 begin
				var  year = result.birthday.substr(0,4);
				var month =result.birthday.substr(4,5);
				var days=result.birthday.substr(6,3);
				var s=year+'-'+month+'-'+days;
				//日期转换 end 
				$(_pageId+" .birthday").val(result.birthday);
				$(_pageId+" .mobile_phone").val(result.mobile_phone);
				$(_pageId+" .user_mail").val(result.user_mail);
				$(_pageId+" .address").val(result.address);
				$(_pageId+" .post_code").val(result.post_code);
				$(_pageId+" .telephone").val(result.telephone);
				$(_pageId+" .qq_microblog").val(result.qq_microblog);
				$(_pageId+" .sina_microblog").val(result.sina_microblog);
				$(_pageId+" .qq").val(result.qq);
				$(_pageId+" .wechat").val(result.wechat);
			}
			else
			{
				layerUtils.iAlert(error_info);
			}
		});
	}

	/* 信息提交校验 */
	function verifyInfo()
	{
		var identity_num =$.trim($(_pageId+" .identity_num").val());
		var mobile_phone =$.trim($(_pageId+" .mobile_phone").val());
		var user_mail =$.trim($(_pageId+" .user_mail").val());
		var post_code =$.trim($(_pageId+" .post_code").val());
		var telephone=$.trim($(_pageId+" .telephone").val());
		var qq =$.trim($(_pageId+" .qq").val());
		// 验证身份证的格式
		if(user_mail!=""){
			if(!validatorUtil.isEmail(user_mail))
			{
				layerUtils.iMsg(-1,"请输入正确的邮箱号码!");
				return false;
			}
		}else{}
		
		if(post_code!=""){
			if(!validatorUtil.isPostalCode(post_code))
			{
				layerUtils.iMsg(-1,"邮编格式不正确,请重新输入");
				return false;
			}
		}


		if(mobile_phone!=""){
			if(!validatorUtil.isMobile(mobile_phone))
			{
				layerUtils.iMsg(-1,"请输入正确的手机号码!");
				return false;
			}
		}
		
		// 设置出生日期
		$(_pageId+" .identity_num").attr("birthday",identity_num.substring(6,10)+"-"+identity_num.substring(10,12)+"-"+identity_num.substring(12,14));
		return true;
	}

	/* 获取用户信息*/
	function setSubmitDataParam()
	{
		var param = {
			"user_id":user_id,
			"nick_name": "",
			"user_name" : $(_pageId+" .user_name").val(),
			"fund_account" : $(_pageId+" .fund_account").val(),
			"risk_level_txt" : $(_pageId+" .risk_level_txt").val(),
			"gender" : gender,
			"identity_type" :identity_type,
			"identity_num" : $(_pageId+" .identity_num").val(),
			"birthday" : $(_pageId+" .birthday").val(),
			"mobile_phone" : $(_pageId+" .mobile_phone").val(),
			"user_mail" : $(_pageId+" .user_mail").val(),
			"address" : $(_pageId+" .address").val(),
			"post_code" : $(_pageId+" .post_code").val(),
			"telephone" : $(_pageId+" .telephone").val(),
			"qq_microblog" : $(_pageId+" .qq_microblog").val(),
			"qq_microblog_uid" : "",
			"sina_microblog" : $(_pageId+" .sina_microblog").val(),
			"sina_microblog_uid" : "",
			"qq" : $(_pageId+" .qq").val(),
			"qq_uid" : "",
			"wechat" : $(_pageId+" .wechat").val(),
			"weixin_uid" :"",
			"update_time" : ""
		};
		return param;
	}

	function submitInfo(){
		// 开户信息资料提交
		var param = setSubmitDataParam();		
		/*调用查询资金接口*/
		service.submitInfo(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result = data.results;
			if(error_no == "0" && result.length != 0)
			{
				/*把手机号码存到session*/
				if(result[0].mobile_phone)
				{
					appUtils.setSStorageInfo("mobile_phone",result[0].mobile_phone);
				}
				/*把邮箱地址存到session*/
				if(result[0].user_mail)
				{
					appUtils.setSStorageInfo("user_mail",result[0].user_mail);
				}
				layerUtils.iMsg(-1,"修改信息成功!");
				appUtils.pageInit("account/infoModify","account/userCenter",{});
			}
			else
			{
				layerUtils.iAlert(error_info);
			}
		});
	}


	function destroy()
	{
		//清除数据

		$(_pageId+" input:not(:eq(0),:eq(1),:eq(2),:eq(3),:eq(4))").val("");


	}

	var changePassword = 
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = changePassword;

	});
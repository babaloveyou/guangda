/*
 * 风险测评信息
 */
define(function(require, exports, module){
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
	    service = require("investService").getInstance(),  //业务层接口，请求数据
		global = require("gconfig").global,
		layerUtils = require("layerUtils"),
		survey_score = "",  //风险等级数字评分
		riskFlag = "",  //1表示满足风险评测等级，2表示不满足
		rating_lvl_name = "",  //风险评测等级
		_pageId = "#account_riskInfo";
	/* 私有业务模块的全局变量 end */
	
	function init()
	{
		//初始化处理
		initHandle();
	}
	
	function bindPageEvent()
	{
		//绑定确认键
		appUtils.bindEvent($(_pageId+" #confirm"),function(){
			appUtils.setSStorageInfo("rating_lvl",rating_lvl_name);
			appUtils.pageInit("account/riskInfo","account/mainPage",{"riskFlag":riskFlag});
		});
		
		//绑定重新评测按钮
		appUtils.bindEvent($(_pageId+" #reTest"),function(){
			appUtils.pageInit("account/riskInfo","account/riskAssessment",{});
		});
		
		//绑定重新评测按钮
		appUtils.bindEvent($(_pageId+" #retry"),function(){
			appUtils.pageInit("account/riskInfo","account/riskAssessment",{});
		});
		
		//绑定返回按钮
		appUtils.bindEvent($(_pageId+" .icon_back"),function(){
			appUtils.setSStorageInfo("rating_lvl",rating_lvl_name);
			appUtils.pageInit("account/riskInfo","account/mainPage",{"riskFlag":riskFlag});
		});
		//绑定完成评测按钮
		appUtils.bindEvent($(_pageId+" #CompleteTest"),function(){
			appUtils.setSStorageInfo("rating_lvl",rating_lvl_name);
			appUtils.pageInit("account/riskInfo","account/mainPage",{"riskFlag":riskFlag});
		});
	}
	
	function destroy()
	{
		service.destroy();
	}

	//初始化处理
	function initHandle(){
		var _prePageCode = appUtils.getSStorageInfo("_prePageCode");
		var	survey_score = appUtils.getSStorageInfo("survey_score"); //风险评测分数
		var	rating_lvl_name = appUtils.getSStorageInfo("rating_lvl_name");  //风险评测等级
		
		if(appUtils.getSStorageInfo("risk_survey_valid") =="0")
		{
			$(_pageId+" #retry").hide()
			$(_pageId+" .notice").html('您的风险评测已过期或未做评测.');
			$(_pageId+" .notice").show();
			$(_pageId+" #reTest").show();
			$(_pageId+" #confirm").hide();
			if (rating_lvl_name == null) {
				$(_pageId+" .chart_pic").html("");
			} else {
				$(_pageId+" .chart_pic").html(rating_lvl_name);
			}
			riskFlag ="2";
		}
		else{
			if(_prePageCode == "account/riskAssessment"){
				survey_score = appUtils.getPageParam("remark");
				rating_lvl_name = appUtils.getPageParam("riskdesc");
				if(survey_score){
					appUtils.setSStorageInfo("survey_score",survey_score);
					appUtils.setSStorageInfo("rating_lvl_name",rating_lvl_name);
					if(survey_score <=35 && survey_score >= 10){
						$(_pageId+" .notice").hide();
						$(_pageId+" #retry").hide();
						$(_pageId+" #confirm").show();
						$(_pageId+" #sign").hide();
						riskFlag = "1"
					}else{
						$(_pageId+" .notice").show();
						$(_pageId+" .notice").html('您当前的风险承受能力为保守型，要求达到稳健型以上');
						$(_pageId+" #retry").show();
						$(_pageId+" #sign").show();
						$(_pageId+" #confirm").hide();
						getSign();
					}
					$(_pageId+" #reTest").hide();
					
				}
			}
			else{
				if(rating_lvl_name == "" || rating_lvl_name == "undefined" ||rating_lvl_name == "保守投资型"){
					$(_pageId+" #retry").show();
					$(_pageId+" .notice").show();
					$(_pageId+" .notice").html('您当前的风险承受能力为保守型，要求达到稳健型以上');
					$(_pageId+" #confirm").hide();
					$(_pageId+" #sign").show();
					$(_pageId+" #reTest").hide();
					getSign();
				}
				else{
					$(_pageId+" #retry").hide();
					$(_pageId+" .notice").hide();
					$(_pageId+" #confirm").show();
					$(_pageId+" #sign").hide();
					$(_pageId+" #reTest").hide();
					riskFlag = "1";
				}
			}
			appUtils.getSStorageInfo("survey_score");
			appUtils.getSStorageInfo("rating_lvl_name");
			$(_pageId+" .chart_pic").html(rating_lvl_name);
		}
	
	}
	
	
	//获取协议
	function getSign(){
		var param = {
			"category_englishname":"ggtfxcpprotcl",
			"category_no":"",
			"econtract_no":""
		};
		service.getSign(param,function(data){
			var error_no = data.error_no,
				error_info = data.error_info,
				result = data.results;
			if(error_no == "0" && result.length != 0){
				var results = data.results,
					  allProtocols = "";
				for(var i=0;i<results.length;i++)
				{
					allProtocols += "<div class=\"ce_btn\"><a  href=\"javascript:;\" protocol-id=\""+results[i].econtract_no+"\" id=\"protocol0"+i+"\">签署超风险协议函</a></div>";
						var md5=results[i].econtract_md5;
					// 预绑定查看协议的事件
					appUtils.preBindEvent($(_pageId+" #sign"),"#protocol0"+i,function(e){
						appUtils.pageInit("account/signProtocol","account/showProtocol",{"protocol_id" : $(this).attr("protocol-id"),"summary":md5,"_prePageCode":"account/riskInfo"});
						e.stopPropagation();
					});
				}
				$(_pageId+" #sign span:eq(0)").html(allProtocols);
			}else{
				layerUtils.iAlert(error_info,-1);
			}
		},{"isLastReq":true,"isShowWait":true,"timeOutFunc":handleTimeout});
	}
	
	/* 处理请求超时 */
	function handleTimeout()
	{
		layerUtils.iConfirm("请求超时，是否重新加载？",function(){
			getSign();  // 再次获取协议
		});
	}
	
	var riskInfo = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	
	module.exports = riskInfo;
});
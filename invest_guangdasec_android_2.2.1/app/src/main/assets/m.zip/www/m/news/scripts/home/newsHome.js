/**
 * 
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils");
	var layerUtils = require("layerUtils");
	var gconfig = require("gconfig");
    var global = gconfig.global;
    var common = require("common");
    var service_news = require("service_news");
	var _pageId = "#home_newsHome ";
	var hIscroll = require("hIscroll");
    var initHIscroll = {"scroll":null,"_init":false};
    var myHIscroll = {"scorll":null,"_init":false};
    var VIscroll = require("vIscroll");
    var vIscroll = {"scroll":null,"_init":false};
	
    var _redirect = false;   //记录是否是跳转到文章详情页
    var _current_page = 1;   //当前第几页
    var _num_page=global.num_page;   //每页多少条数据
    var _upHandleFlag=false;  //记录是否能上拉加载下一页
    var advertisingNum=global.advertising;	//广告图数量限制

    
    /**
     * 初始化
     */
	function init(){
		$(_pageId + " .banner_link iframe").width($(window).outerWidth(true));
		if(gconfig.platform == "0"){
			$(_pageId + ".main").height($(window).outerHeight(true) - $(_pageId + ".header").outerHeight(true) - $(_pageId + ".footer_inner").outerHeight(true));
			$(_pageId + ".main").css("overflow-y","auto");
		}else{
			if(gconfig.platform == "2"){
				if(appUtils.getLStorageInfo("h")){
					$(_pageId + ".main").height(appUtils.getLStorageInfo("h"));
				}else{
					var h = $(window).outerHeight(true) - $(_pageId + ".header").outerHeight(true) - $(_pageId + ".footer_inner").outerHeight(true);
					appUtils.setLStorageInfo("h",h);
					$(_pageId + ".main").height(h);
				}
			}else if(gconfig.platform == "1"){
				if(appUtils.getLStorageInfo("h")){
					$(_pageId + ".main").height(appUtils.getLStorageInfo("h"));
				}else{
					var h = $(window).outerHeight(true) - $(_pageId + ".header").outerHeight(true) - $(_pageId + ".footer_inner").outerHeight(true);
					appUtils.setLStorageInfo("h",h);
					$(_pageId + ".main").height(h);
				}
			}
			$(_pageId + ".main").css("overflow-y","auto");
		}
		
		//进来访问到内参页面
		$(_pageId+"#module ul li").removeClass("current").eq(0).addClass("current");
		$(_pageId + "#content2").hide();
		$(_pageId + ".back_top").show();
		$(_pageId + "#v_container_funds_list").show();
		//列表回顶部事件
		common.backTop(_pageId);
		
		//查询广告图
		queryAdvertisingOrIcon("0", queryAdvertisingCallBack);
		//查询图标
		queryAdvertisingOrIcon("1", queryIconCallBack);
		
		initVIScroll();   //上下滑动组件初始化
		
//		//查询推荐列表
		if(!appUtils.getSStorageInfo("flag")){
			queryRecommendListPage(_current_page);
		}else if($(_pageId + ".w_list ul").length == 0){
			queryRecommendListPage(_current_page);
		}else{
			var articleId=appUtils.getPageParam("articleId");  //获取文章详情页面传回的文章id
			var li=$(_pageId + ".w_list ul li");
			for(var i=0;i<li.length;i++){
				if($(li[i]).attr("articleid") == articleId){
					var em=$(_pageId + ".w_list ul li").eq(i);
					if(common.queryLikeStatus(articleId)>-1){ //加点赞状态
						//修改点赞数和点赞状态
						em.find(".w_bot .praise").addClass("on");
						common.queryBrowseLikeNum(articleId,em);
					}else{//取消点赞状态
						em.find(".w_bot .praise").removeClass("on");
						common.queryBrowseLikeNum(articleId,em);
						
					}
				}
			}
		}
		appUtils.setSStorageInfo("flag",false);
	}
	
	/**
	 * 事件绑定
	 */
	function bindPageEvent(){
		//要闻、直播、机会、内参模块间的切换
		appUtils.bindEvent($(_pageId+"#module ul li"), function(e){
//			$(this).addClass("current").siblings().removeClass("current");
//			$(_pageId + ".back_top").hide();
//			$(_pageId + "#content2").hide();
//			$(_pageId + "#v_container_funds_list").hide();
			if($(this).index() == 0){
//				$(_pageId + ".back_top").show();
//				$(_pageId + "#v_container_funds_list").show();
				//查询广告图
				queryAdvertisingOrIcon("0", queryAdvertisingCallBack);
				//查询图标
				queryAdvertisingOrIcon("1", queryIconCallBack);
			}else{
				_current_page = 1;
				if($(this).index() == 1){
					vIscroll._init = false; //尽量只初始化一次，保持性能
					vIscroll.scroll.destroy();
					appUtils.pageInit("home/newsHome","home/outLink",{"tabId":"1"});
//					var str='<iframe src="'+ global.importantNews +'" style="padding:1px;display:block" scrolling="yes" frameborder="0" height="100%" width="100%"></iframe>';
				}else if($(this).index() == 2){
					vIscroll._init = false; //尽量只初始化一次，保持性能
					vIscroll.scroll.destroy();
					appUtils.pageInit("home/newsHome","home/outLink",{"tabId":"2"});
//					var str='<iframe src="'+ global.liveBroadcast +'" scrolling="yes" frameborder="0" height="100%" width="100%"></iframe>';
//					var str='<iframe src="'+ global.liveBroadcast +'" style="padding:1px;display:block" scrolling="yes" frameborder="0" height="100%" width="100%"></iframe>';
//					$(_pageId+"#content2").html(str);
//					appUtils.sendDirect("http://120.27.166.179/mobileF10View/broadcast_list.html?p=HSJY_1010&u=abc123&t=orange&v=1.0&n=getDate()", true, "home/newsHome");
				}else if($(this).index() == 3){
					vIscroll._init = false; //尽量只初始化一次，保持性能
					vIscroll.scroll.destroy();
					appUtils.pageInit("home/newsHome","home/outLink",{"tabId":"3"});
//					var str='<iframe src="'+ global.chance +'" style="padding:1px;display:block" scrolling="yes" frameborder="0" height="100%" width="100%"></iframe>';
//					$(_pageId+"#content2").html(str);
//					appUtils.sendDirect("http://120.27.166.179/mobileF10View/chance_list.html?p=HSJY_1010&u=abc123&t=orange&v=1.0&n=getDate()", true, "home/newsHome");
				}
//				$(_pageId + "#content2").show();
			}
			e.stopPropagation();
		},"click");
//		//跳转交易
//		appUtils.bindEvent($(_pageId+".footer_inner .ui .row-1"), function(e){
//			window.location.href = "/m/trade/index.html";
//			e.stopPropagation();
//		});
	}
	
	/**
	 * 销毁
	 */
	function destroy(){
		$(_pageId+"#module ul li").eq(0).removeClass("current");
		$(_pageId + "#v_container_funds_list").show();
//		$(_pageId + "#content2").hide();
		if(!_redirect){  //跳转文章详情不销毁
			$(_pageId + ".w_list").html("").css("background-color","#fff");
		}
		initHIscroll._init = false; //尽量只初始化一次，保持性能
		initHIscroll.scroll.destroy();
		myHIscroll._init = false; //尽量只初始化一次，保持性能
		myHIscroll.scroll.destroy();
		_redirect=false;
	}
	
	
	//广告或图标查询
	function queryAdvertisingOrIcon(type,functionName){
		var param={
				"type":type
		};
		service_news.queryAdvertisementIcon(param,functionName);
	}
	
	//查询图标回调
	function queryIconCallBack(data){
		if(data.error_no == 0){
			var results=data.results;
			if(results.length>0){
				var num=0;
				var textColNum=0;  //文字栏目数目
				var strHTML='<div class="menu_nav">';
				for(var i = 0;i<results.length;i++){
					if(Math.floor(num / 4) == 0 && num<3){
						strHTML+='<a href="javascript:void(0);" catalogId="'+results[i].catalog_id+'">';
						strHTML+='<img src="'+global.serviceUrl+results[i].picture+'">'+results[i].name+'</a>';
						num++;
					}else{
						strHTML+='<a href="javascript:void(0);" catalogId="'+results[i].catalog_id+'">';
						strHTML+='<img src="'+global.serviceUrl+results[i].picture+'">'+results[i].name+'</a>';
						strHTML+='</div><div class="menu_nav">';
						num=0;
					}
				}
				if((results.length-textColNum) % 4 != 0){
					strHTML+='</div>';
				}else{
					strHTML = strHTML.substring(0, strHTML.length - 22);  //截取末尾多出的<div class="menu_nav">
				}
				
				//设置栏目展示
				$(_pageId+"#scroller_div1").html(strHTML);
				
				var programa=$(_pageId+".menu_nav");
				var emHTML="";
				for(var i=0;i<programa.length;i++){
						emHTML+='<em class="" style="border: 1px solid #999;"></em>';
				}
				//添加em
				$("#programa").html(emHTML);
				myHIscrollsss();  //初始化滑动组件
				//绑定栏目事件,进入列表
				appUtils.bindEvent($(_pageId + ".menu_nav a"), function(e){
					_current_page = 1;
					var catalogId = $(this).attr("catalogId");
					var catalogTit = $.trim($(this).text());
					appUtils.setSStorageInfo("catalogTit",catalogTit);
					appUtils.pageInit("home/newsHome","details/newsList",{"catalogId":catalogId});
					e.stopPropagation();
				},"click");
				//设置滑动组件初始页面（索引，时间）
				myHIscroll.scroll.scrollToPage(appUtils.getSStorageInfo("idxPage")?appUtils.getSStorageInfo("idxPage"):0,200);
			}
		}
	}
	
	//查询广告图回调
	function queryAdvertisingCallBack(data){
		if(data.error_no == 0){
			var results=data.results;
			var str="";
			var em="";
			//轮播的图片，只加载五张
			if(results.length>0 && results.length<=advertisingNum){
				for(var i=0;i<results.length;i++){
					str+=createIMG(results[i]);
					em+="<em class=''></em>";
				}
			}else{
				for(var i=0;i<advertisingNum;i++){
					str+=createIMG(arr[i]);
					em+="<em class=''></em>";
				}
			}
			
			$(_pageId + " #scroller_div").html(str);
			$(_pageId + ".dot").html(em);
			//banner图绑定点击事件
			appUtils.bindEvent($(_pageId + " #scroller_div img"), function(e){
				var link = $(this).attr("href");
				if(link){
					bannerLink(link);
				}
				e.stopPropagation();
			},"click");
 		}else{
 			layerUtils.iAlert(data.error_info);
 		}
		
		initHIScroll();
	}
	
	//banner图点击外链
	function bannerLink(link){
		//显示隐藏
		$(_pageId + " .banner_link").show();
		$(_pageId + " .back_top").hide();
		$(_pageId + " #v_container_funds_list").hide();
		$(_pageId + " #module").hide();
		$(_pageId + " .header .icon_back").show();
		//设置高度
		$(_pageId + ".main").height($(window).height() - $(_pageId + ".header").height() - $(_pageId + ".footer_inner").height());
		$(_pageId + ".main").css("overflow-y","auto");
		//设置连接
		$(_pageId + " .banner_link iframe").attr("src",link);
		//外链返回键
		appUtils.bindEvent($(_pageId + " .header .icon_back	"), function(e){
			$(_pageId + " .banner_link").hide();
			$(_pageId + " .back_top").show();
			$(_pageId + " #v_container_funds_list").show();
			$(_pageId + " #module").show();
			$(_pageId + " .header .icon_back").hide();
			e.stopPropagation();
		});
	}
	
	//生成轮播的图片
	function createIMG(element){
		var img="";
		img+="<div class='banner_box'>";
		img+="<img src='"+global.serviceUrl+element.picture+"' alt='' href='"+element.url+"'/>";
		img+="</div>";
		return img;
	}
	
	//查询推荐文章列表
	function queryRecommendListPage(page){
		var param = {
			"recommend":0,     //首页推荐，0推荐，1不推荐   
			"current_page":page,  //第几页
			"num_page":_num_page,    //每页多少条
		};
		service_news.queryRecommendListPage(param,queryInformationListCallBack,{"isLastReq":true,"isShowWait":true});
	}
	//查询微资讯列表回调
	function queryInformationListCallBack(data){
		if(data.error_no == 0){
			var results = data.results;
			var strHTML = "";
			if(results.length>0){
				if(_current_page == 1){//第一页
					strHTML += "<ul>";
					for (var i=0;i<results.length;i++){ 
						strHTML += createHTML(results[i]);
					}
					strHTML += "</ul>";
					//加载文章列表
					$(_pageId + ".w_list").html(strHTML).css("background-color","#fff");
				}else{
					for (var i=0;i<results.length;i++){ 
						strHTML += createHTML(results[i]);
					}
					$(_pageId + ".w_list ul").append(strHTML);
				}
				
				//点击跳转文章内容
				appUtils.bindEvent($(_pageId + ".w_list ul li"), function(e){
					var articleId = $(this).attr("articleId");   //文章编号
//					appUtils.setSStorageInfo("catalogTit",$.trim($(_pageId + ".tit").text()));
					appUtils.setSStorageInfo("catalogTit",$(this).attr("catalogTit"));  //栏目名称   标题显示
					var author=$(this).attr("author");   //文章作者
					_redirect = true;  //跳转文章详情
					appUtils.pageInit("home/newsHome","details/detailsShare",{"returnPage":"home/newsHome","catalogId":"5","articleId":articleId,"author":author});
					e.stopPropagation();
				},"click");
				
				//设置文章列表，标题和摘要超过指定行数用...显示
				common.setArticleList(_pageId,global.titLineNum,global.synopsisLineNum);
				
				//文章列表上点赞
				common.addLike(_pageId);
				
				//如果加载文章数目不小于每页显示数目
				if(results.length>=_num_page){
					$(_pageId + ".visc_pullUp").show();   //展示上拉加载下一页
					_upHandleFlag = true;   //能上拉加载下一页
					_current_page++;        //页数+1
				}else{
					_upHandleFlag = false;   //不能上拉加载下一页
					$(_pageId + ".visc_pullUp").css("display","none");  //隐藏上拉加载下一页
				}
			}else{
				if(_current_page == 1){  //第一页没有内容则显示
				strHTML += "<div class='no_data'>";
				strHTML += "<span class='icon'></span>";
				strHTML += "<p style='text-align:center;'>暂无列表信息</p>";
				strHTML += "</div>";
				$(_pageId + ".w_list").html(strHTML).css("background-color","#E0E0E0");
				layerUtils.iMsg(-1,"未查询到相应的文章列表信息");
				}
				_upHandleFlag = false;   //不能上拉加载下一页
				$(_pageId + ".visc_pullUp").css("display","none");  //隐藏上拉加载下一页
			}
		}else{
			layerUtils.iAlert(data.error_info);
		}
		initVIScroll();   //上下滑动组件初始化
	}
	
	//生成资讯列表HTML
	function createHTML(element){
		var strHTML = "";
		strHTML += "<li articleId='"+element.article_id+"' catalogTit='"+element.catalog_name+"' author='"+element.author+"')>";   		//编号
		strHTML += "<h6>"+element.title+"</h6>";   						//标题
		strHTML += "<p>"+element.brief+"</p>";   						//简介
		strHTML += "<div class='w_bot clearfix'>";
		strHTML += "<time><nobr>"+element.publish_date+"</nobr></time>";   //发布时间
		strHTML += "<em class='focus' focusNum='"+element.browse_num+"'>"+common.overAMillion(element.browse_num)+"</em>";		//浏览数
		if(common.queryLikeStatus(element.article_id)>-1){
			strHTML += "<em class='praise on' praiseNum='"+element.support_num+"'>"+common.overAMillion(element.support_num)+"</em>";   //点赞数
		}else{
			strHTML += "<em class='praise' praiseNum='"+element.support_num+"'>"+common.overAMillion(element.support_num)+"</em>";   //点赞数
		}
		strHTML += "</div>";
		strHTML += "</li>";
		return strHTML;
	}
	
	/*
	 * 初始化滑动组件
	 */
	function initHIScroll(){
//		if(!initHIscroll._init){
		if(initHIscroll.scroll && initHIscroll.scroll != null && initHIscroll.scroll != "undefined"){
			initHIscroll.scroll.destroy();
		}
			var config = {
					wrapper: $('#home_newsHome #wrapper_div'), //wrapper对象
					scroller: $('#home_newsHome #scroller_div'), //scroller对象
					perCount: 1,  //每个可视区域显示的子元素
					showTab: true, //是否有导航点
					tabDiv: $("#home_newsHome .dot"), //导航点集合对象
					auto: true, //是否自动播放
					interval:  null, //自动播放定时器
					idxPage: 1, //记录当前scroll滚动到第几个page
					wrapperObj: null,
					onScrollEnd :function(){//滑动后的回调函数
						
					}
				};
			initHIscroll.scroll = new hIscroll(config); //初始化，需要做if(!hIscroll._init)判断
			initHIscroll._init = true; //尽量只初始化一次，保持性能
//		}
	}
	
	function myHIscrollsss(){
//		if(!myHIscroll._init){
		if(myHIscroll.scroll && myHIscroll.scroll != null && myHIscroll.scroll != "undefined"){
			myHIscroll.scroll.destroy();
		}
			var config = {
					wrapper: $('#home_newsHome #wrapper_div1'), //wrapper对象
					scroller: $('#home_newsHome #scroller_div1'), //scroller对象
					perCount: 1,  //每个可视区域显示的子元素
					showTab: true, //是否有导航点
					tabDiv: $("#programa"), //导航点集合对象
					auto: false, //是否自动播放
					interval: null, //自动播放定时器
					idxPage: 1, //记录当前scroll滚动到第几个page
					wrapperObj: null,
					onScrollEnd :function(){//滑动后的回调函数
						appUtils.setSStorageInfo("idxPage",$(_pageId + "#programa .active").index());
					}
				};
			myHIscroll.scroll = new hIscroll(config); //初始化，需要做if(!hIscroll._init)判断
			myHIscroll._init = true; //尽量只初始化一次，保持性能
//		}
	}
	

	/**
	 * 初始化上下滑动组件（在初始化的时候调用这个）
	 */
	function initVIScroll(){
		if(!vIscroll._init){
			var config = {
				"isPagingType": false,		//false表示是微博那种累加形式，true表示分页形式
				"visibleHeight": $(_pageId + ".main").height(),//显示内容区域的高度，当isPaingType为false时传
				"container": $(_pageId+" #v_container_funds_list"),	
				"wrapper":$(_pageId+" #v_wrapper_funds_list"),	
				"downHandle": function() {				//下拉获取上一页数据方法
					_current_page = 1;
					queryRecommendListPage(_current_page);
				},
				"upHandle": function() {    //上拉加载下一页数据方法
					if(_upHandleFlag){
						queryRecommendListPage(_current_page);
					}
				},
				"wrapperObj": null
			};
			vIscroll.scroll = new VIscroll(config); 	//初始化，需要做if(!hIscroll._init)判断
			vIscroll._init = true; 						//尽量只初始化一次，保持性能
		}else{
			vIscroll.scroll.refresh();
		}
	}
	
	var base = {
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};
	module.exports = base;
});
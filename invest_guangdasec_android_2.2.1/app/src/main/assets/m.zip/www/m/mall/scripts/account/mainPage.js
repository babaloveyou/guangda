/*
 * 商城首页
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils"),
	putils = require("putils");
	var service = require("mobileService"); //业务层接口，请求数据
	var layerUtils = require("layerUtils");
	var HIscroll =require("hIscroll");
    var myHIscroll = null;
    var gconfig = require("gconfig");
    var global = gconfig.global;
    platform=gconfig.platform;
	constants=require("constants");//常量类
	//下标0的元素表示头部滑动，1、2、3分别表示推荐理财、推荐基金和推荐资讯
//	var myHIscroll= [{"scroll":null,"_init":false},{"scroll":null,"_init":false},{"scroll":null,"_init":false},{"scroll":null,"_init":false}];
	var _pageId = "#account_mainPage";
	var URL=global.url;
	var globalFunc = require("globalFunc");
	var curFundPage="";
	var fundFlag=false;
	var curFinanPage="";
	var finanFlag=false;
	var curInfoPage="";
	var infoFlag=false;
	var curOTCPage="";
	var otcFlag=false;
	
	function init(){
		
		initView();
//		//获取理财产品列表
//		getFinanProduct();
//		//基金产品列表2
//		getFundProduct();
//		//OTC产品列表3
//		getOTCProduct();
//		//咨询产品
//		getInfoProduct();
		//加载广告
		loadAdv();
		//查询模块数
		getInfoProductNO();
		

	}
	
	function bindPageEvent() {

        /* 绑定返回我的富尊主页 */
        appUtils.bindEvent($(_pageId+" #fuzun_wo"),function(e){
            var param_index = {"funcNo":"50101","moduleName":"financial-mall"};
            require("external").callMessage(param_index);
            e.stopPropagation();
        });
		//点击登录
		appUtils.bindEvent($(_pageId+" .icon_info"),function()
		{
            appUtils.pageInit("account/mainPage","account/userCenter",{});
        });

		/*点击 跳到到顶部*/
		appUtils.bindEvent($(_pageId+"  .back_app"),function(){	
			$('body,html').animate({
				scrollTop:0
			},1000);
			return false;
		});

		// 点击首页
		appUtils.bindEvent($(_pageId+" #mainPage"),function(){
			appUtils.pageInit("account/mainPage","account/mainPage",{});
		});

		//点击理财
		appUtils.bindEvent($(_pageId+" #finan"),function(){
			appUtils.pageInit("account/mainPage","mall/itemsFinan",{});
		});
		//点击个人中心
		appUtils.bindEvent($(_pageId+" .icon_search"),function(){
			appUtils.pageInit("account/mainPage","account/userCenter",{});
		});

		//点击基金
		appUtils.bindEvent($(_pageId+" #fund"),function(){
			appUtils.pageInit("account/mainPage","mall/itemsFund",{});
		});

		/*查看otc产品信息*/
		appUtils.bindEvent($(_pageId+" #otc") ,function(){
			appUtils.pageInit("account/mainPage","mall/itemsOTC",{});
		});

		//鼠标移入显示效果
		appUtils.bindEvent($(_pageId+" .icon_info"),function(){
			//	 $(this).css("background-color","red");
		},"mouseenter");

	}
	
	/**
	 * 清除滑动组件
	 */
	function initView(){
		if(myHIscroll){
			myHIscroll.destroy();
			myHIscroll = null;
		}
	}
	
	/*
	 * 加载广告
	 */
	function loadAdv() {
		var callBack = function(data) {
			var error_no = data.error_no;
			var error_info = data.error_info;
			var isFileState="";//广告是否有效0 无效1 有效

			if (error_no == 0) {
				
				var item = data.results;
//				var	jump_type=item[i].jump_type;
				//var it = item[0].id;
				var adItems = "";
				var sadItems = "";
				var j = 0;//统计有效广告个数
				var date_info = new Date().getTime();
				if (item.length == 0) {
//					adItems = "<li><img src='images/pic01.jpg'/></li>";
//					sadItems = "<em class='active'></em>";
				} else {
//					adItems = "<li><img src='images/pic01.jpg'/></li>";
//					sadItems = "<em class='active'></em>";/*
					for (var i = 0; i < item.length; i++) {
						// 广告控制在3个以内
						if (j++ > 2) {
							break;
						};
						var imgPath = item[i].image_url ? item[i].image_url : item[i].jump_url; // 图片地址
						var flag = item[i].flag; // 链接是否有效     是否启用1启用
						var _url = "";
						if (flag == "1") {
							_url = item[i].jump_url;
						} else {
							_url = "javascript:void(0)";
						}
						var is_open = item[i].is_open; // 文件状态是否有效  1 开放
						var	jump_type=item[i].jump_type;
						var	title=item[i].image_name;
						if (is_open != "1") {
							continue;
							
						}else{
							var is_open = "1";
							if (i == 0) {
								adItems += "<li jump_type='"+jump_type+"' title='"+title+"' url='"+_url+"'><img src='"
										+ (global.url +""+ imgPath) + 
										 "' width='100%' style='margin-bottom: 0.02rem;'/></li>";
/*								adItems += "<li url='"+_url+"'><img src='"
								+ (global.url +"/mall"+ imgPath) + 
								"' width='100%'/></li>";
*/								sadItems += "<em class='active'></em>";
							} else {
								adItems += "<li jump_type='"+jump_type+"'  title='"+title+"' url='"+_url+"'><img src='"
										+ (global.url +""+ imgPath) + 
										"' width='100%' style='margin-bottom: 0.02rem;'/></li>";
								sadItems += "<em></em>";
							}
						}

					}
				};
 
				if(is_open == "1"){
					$(_pageId + " #dots_box").html(""); // 显示点
					$(_pageId + " #banner").html(adItems); // 显示位置ul
					$(_pageId + " #dots_box").html(sadItems); //
					setTimeout(function(){
						HIscroll_init();
					},800);
				}
				
				//广告跳转
				appUtils.bindEvent($(_pageId + " #ad_index li"),function(){
					var Url=$(this).attr("url");
					var jump_type=$(this).attr("jump_type");
					var title=$(this).attr("title");
        			var toPage = "";
        			if(jump_type=="0"){//调原生不处理
        				
        			}else if(jump_type=="1"){//跳app
        				if(gconfig.platform == "2"){//ios     open-account 
        					var arr=Url.split(",");
        					Url=arr[1];
        					var module_name="";//跳转模块名
        					module_name=arr[0];
        					toPage={"prefix":"","suffix":Url,"prePage":""};
        					var param = {"funcNo":"50101","moduleName":module_name,"params":{"moduleName":"financial-mall","toPage":toPage}};
        					require("external").callMessage(param);
        					
        				}else{//android
        					toPage = Url;
        					var param = {"funcNo":"50101","moduleName":"open-account","params":{"moduleName":"financial-mall","toPage":toPage}};
        					require("external").callMessage(param);
        				}
        			}else{//跳http网页
//        				if(gconfig.platform == "2"){//ios     open-account 
//        					toPage={"prefix":"www/m/mall","suffix":"account/mainPage","prePage":Url};
//        				}else{//android
//        					toPage = Url;
//        				}
        				var param = {"funcNo":"50101","moduleName":"comm_web","params":{"moduleName":"financial-mall","url":Url,"title":title}}; 
    					require("external").callMessage(param);
        			}
					
        });
/*				appUtils.bindEvent(_pageId+" #ad_index li", function(e){user-center
					e.stopPropagation();
					var Url=$(this).attr("url");
						appUtils.sendDirect(Url);					
				});*/
				
			} else {
				layerUtils.iMsg(-1, error_info);

			}
		};
		var channel="";
		if(gconfig.platform == "2"){
		channel="1";
		}else{
		channel="0";
		}
		var param={
				"group_no" : "mall",
//				"channel":platform//0Android 1 iOS
				"channel":channel//0Android 1 iOS
		};
		service.sosAdv(param, callBack);
	}
	/**
	 * HIscroll左右滑动组件
	 */
	function HIscroll_init(){
		if(!myHIscroll){
	        var config = {
	            wrapper: $(_pageId+' #ad_index'), //wrapper对象
	            scroller: $(_pageId+' #banner'), //scroller对象
	            perCount: 1,  //每个可视区域显示的子元素，就是每个滑块区域显示几个子元素
	            showTab: true, //是否有导航点
	            tabDiv: $(_pageId+'#dots_box'), //导航点集合对象
	            auto: true //是否自动播放
	        };
	        myHIscroll = new HIscroll(config);
	        $(_pageId+'#banner li').show();
	    }
	}
	
	//绑定合并资产按钮
/*	function bindRzrq(){
		appUtils.bindEvent($(_pageId + " #ad_index li"),function(){
			appUtils.pageInit("account/marketCon","account/queryRzrqMoney",{"user_id":user_id});
		});

		appUtils.bindEvent($(_pageId + " #ad_index li"),function(){
        			var toPage = "";
					if(gconfig.platform == "2"){
						toPage={"prefix":"www/mall","suffix":"account/bankTransfer","prePage":"url"};
					}else{
						toPage = url;
					}
					var param = {"funcNo":"50101","moduleName":"financial-mall","params":{"moduleName":"user-center","toPage":toPage}};
					require("external").callMessage(param);
        });

	}*/
	//3000002获取产品模块数
	function getInfoProductNO(){
		var param={
				
		};
		service.getProductNO(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			if(error_no == 0)
			{
				var perData=data.results;
				var sloganTxt = "";
				if(perData){
					$(_pageId+" .t_product").empty(); 
					for(var i=0;i<perData.length;i++){
						var	assortment=perData[i].assortment;
						var	assortment_id=perData[i].assortment_id;
						var	slogan=perData[i].slogan;
						var	sort_id=perData[i].sort_id;

						//模块头部内容
						sloganTxt = '<h3 id="'+assortment_id+'" style="margin-top:0.1rem;background-color:#fff;"><em style="background-color:#ffa400;font-family:FangSong">'+assortment+'</em><span>'+slogan+'</span></h3>';
						$(_pageId+" .t_product").append(sloganTxt);
						getProduct(assortment_id);
					}
				}else{
					layerUtils.iMsg(-1,"暂时没有产品，敬请期待");
				}
				
			}
			
		});
	}
	//调300001查推荐产品
	function getProduct(assortment_id){
	var param  = {
			"assortment_id":assortment_id
		};
	service.getProduct(param,function(data){
		var error_no = data.error_no;
		var error_info = data.error_info;
		if(error_no == 0)
		{
			var perData=data.results;
			if(perData){
				var allProductStr = "";
				for(var i=perData.length-1;i>=0;i--){
					var product_id=perData[i].product_id;//产品ID
					var assortment_id =perData[i].assortment_id ;//产品ID
					var est_yield=perData[i].est_yield;//年化收益率
					var est_type=perData[i].est_type;//展示类型
					var product_name=perData[i].product_name;//产品名字
					var product_sell_date=perData[i].product_sell_date;//产品发行天数
					var slogan=perData[i].slogan;//产品广告语
					var product_profit=perData[i].product_profit;//
					var product_depict=perData[i].product_depict;//
					var sell_time=perData[i].sell_time;//产品发行时间
					var sell_type=perData[i].sell_type;//发行状态     0售罄1抢购2开售
					var product_link_type=perData[i].product_link_type;//链接模块
					var show_type="";
					var show_name="";
					if(est_yield.indexOf("%")>-1){
						var est_yieldFloat = parseFloat(est_yield).toFixed(2);
						var est_yield = est_yieldFloat.split(".");
						var head = est_yield[0];
						var foot = est_yield[1];
						show_type="<em style='font-size:0.3rem;line-height: 65px;'>"+head+"</em><em>.</em>"+foot+"<em>%</em>";
					}else if(!isNaN(est_yield)){
						if(est_yield.indexOf(".")>-1){
							var est_yieldFloat = parseFloat(est_yield).toFixed(4);
							var est_yield = est_yieldFloat.split(".");
							var head = est_yield[0];
							var foot = est_yield[1];
							show_type="<em style='font-size:0.3rem;line-height: 65px;'>"+head+"</em><em>.</em>"+foot+"<em></em>";
							}else{
								show_type="<em style='line-height: 70px;font-size:0.3rem;'>"+est_yield+"</em>";
							}
						
					} else{
						show_type="<em style='line-height: 70px;'>"+est_yield+"</em>";
					}
					if(est_type=="1"){
//						show_tpye="<img src='/m/mall/images/qiang.png'>";
						show_name="";	
					}else if(est_type=="0"){
						show_name="参考年化收益率";
					}else if(est_type=="2"){
						show_name="近3个月涨幅";	
					}else if(est_type=="3"){
						show_name="近一年涨幅";
					}else if(est_type=="4"){
						show_name="当前净值";
					}else if(est_type=="5"){
						show_name="七日年化收益率";
					}
					if(i != 0){
						sloganTxt = "";
					}
					if(sell_type){
						if(sell_type=="0"){
							allProductStrs = '<div class="t_xq clearfix" product_id='+product_id+' sell_type='+sell_type+' product_link_type ='+product_link_type +'>'
								+'<div class="ing ed"><p style="margin-top:0.15rem;"><span>售罄</span></p></div>'
								+'<div class="rate"><h2>'+show_type+'</h2></h2><p>'+show_name+'</p></div>'
								+'<div class="process"><h4>'+product_depict+'</h4><p>'+product_name+'</p><em class="day mr5">'+product_sell_date+'</em><em>'+product_profit+'</em></div>'
								+'</div>';
						}else if(sell_type=="1"){
							allProductStrs = '<div class="t_xq clearfix" product_id='+product_id+' sell_type='+sell_type+' product_link_type ='+product_link_type +'>'
								+'<div class="rate"><h2>'+show_type+'</h2><p>'+show_name+'</p></div>'
								+'<div class="process"><h4>'+product_depict+'</h4><p>'+product_name+'</p><em class="day mr5">'+product_sell_date+'</em><em>'+product_profit+'</em><em class="fast_buy" style="position:absolute; right: 0rem;" ></em></div>'
								+'</div>';
						}
						else{
							allProductStrs = '<div class="t_xq clearfix" product_id='+product_id+ ' sell_type='+sell_type+' product_link_type ='+product_link_type +'>'
								+'<div class="rate"><h2>'+show_type+'</h2></h2><p>'+show_name+'</p></div>'
								+'<div class="ing"><p>'+sell_time+'</p></div>'
								+'<div class="process"><h4>'+product_depict+'</h4><p>'+product_name+'</p><em class="day mr5">'+product_sell_date+'</em><em>'+product_profit+'</em></div>'
								+'</div>';
						}
						 
						$(_pageId+" .t_product").find("#" + assortment_id).after(allProductStrs);
					}
				}
				//绑定跳详情模块
				appUtils.bindEvent($(_pageId+" .clearfix"),function(){
					var product_id = $(this).attr("product_id"); // 协议ID
					var sell_type = $(this).attr("sell_type"); // 
					var product_link_type = $(this).attr("product_link_type"); // 
					var pageInParam = {
						"product_id" :  product_id,
						"sell_type" :  sell_type
					};
					if(product_link_type=="0"){//跳理财
							appUtils.pageInit("account/mainPage", "mall/itemsFinanInfo",pageInParam);
						
					}else if(product_link_type=="1"){//跳基金
							appUtils.pageInit("account/mainPage", "mall/itemsFundInfo",pageInParam);
						
					}else if(product_link_type=="3"){//调otc
							appUtils.pageInit("account/mainPage", "mall/itemsOTCInfo",pageInParam);
						
					}else if(product_link_type=="4" ){//预售产品,不让链接走。
						layerUtils.iMsg(-1,"预售产品，敬请期待");
					}else if(product_link_type=="2"){//调咨询
							appUtils.pageInit("account/mainPage", "mall/itemsInfoDetail",pageInParam);
					}
				});	
				
			}else{
				layerUtils.iMsg(-1,"暂无产品，敬请期待！！");
				
			}
			
		}else{
			layerUtils.iMsg(-1,error_info);
		}
	});}

	function destroy(){
		curFundPage="";
		fundFlag=false;
		curFinanPage="";
		finanFlag=false;
		curInfoPage="";
		infoFlag=false;
		initView();
		allProductStrs="";
		
		service.destroy();
	}

	var mainPage = {
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};
	module.exports = mainPage;	
	
});
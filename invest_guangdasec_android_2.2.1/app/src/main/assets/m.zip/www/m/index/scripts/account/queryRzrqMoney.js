/**
 * 光大富尊
 */
define(function(require, exports, module){ 
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
		layerUtils = require("layerUtils"),
		gconfig = require("gconfig"),
		global = gconfig.global,
		service = require("serviceImp"),  //业务层接口，请求数据
		_pageId = "#account_queryRzrqMoney ";
	/* 私有业务模块的全局变量 end */
	
	function init(){
		user_id = appUtils.getPageParam("user_id");
	}
	
	function bindPageEvent(){
		/* 返回  */
		appUtils.bindEvent($(_pageId+".icon_back"),function(e){
			appUtils.pageInit("account/queryRzrqMoney","account/marketCon",{"marketvalue":"0"});
		});
		
		//提交
		appUtils.bindEvent($(_pageId + ".ce_btn a"),function(){
			
			var zjaccount = $(_pageId + ".input_rz input").val();
			if(/^\d{8}$/.test(zjaccount)){
				var param = {"account":zjaccount,
							"user_id":user_id};
				service.queryxyMoney(param,function(data){
					var error_no = data.error_no;
					var error_info = data.error_info;
					
					if(error_no==0){
						var result = data.results;
						appUtils.pageInit("account/queryRzrqMoney","account/marketCon",{"marketvalue":result[0].xy_marketvalue});
					}else{
						layerUtils.iAlert(error_info);
					}
				});
			}else{
				layerUtils.iAlert("请输入正确的融资融券账号");
			}
		});
	}
	
	function destroy(){
		$(_pageId + ".input_rz input").val("");
	}
	
	var index = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	module.exports = index;
});
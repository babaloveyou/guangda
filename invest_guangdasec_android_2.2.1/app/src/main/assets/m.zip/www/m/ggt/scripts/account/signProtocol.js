/**
 * 签署协议
 */
define(function(require, exports, module){
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
	    service = require("investService").getInstance(),  //业务层接口，请求数据
		global = require("gconfig").global,
		layerUtils = require("layerUtils"),
		Map = require("map"),
		fristMap = null,  //  存放所有相关协议
	    protocolArray = new Array(),  // 存放协议签名值
	    countProtocol = 0, // 计算签署成功的数量
	    signFlag = "",  //1代表签了协议，2代表未签协议
		_pageId = "#account_signProtocol",
		 _prePageCode="";
	
	function init()
	{ 
		//初始化时获取前一个页面，区别机构和个人
		 _prePageCode = appUtils.getPageParam("_prePageCode");
		//查询协议
		getSign();
	}
	
	//绑定
	function bindPageEvent(){
		/* 绑定签署协议*/
		appUtils.bindEvent($(_pageId+" .rule_check span"),function(){
			$(this).toggleClass("checked"); //  切换勾选样式
		});
		
		//绑定提交申请
		appUtils.bindEvent($(_pageId+" .ce_btn"),function(){
			if(_prePageCode == "business/index"){
				var is_autoTask = appUtils.getSStorageInfo("is_autoTask");
				//直接开通港股通权限
				if(is_autoTask == 0){
					var param = {
						"user_id":appUtils.getSStorageInfo("user_id"),
                        "trade_pwd":"123321"
                        };
					//开通港股通权限
					service.openAccount(param,function(data){
						var error_no = data.error_no;
						var error_info = data.error_info;
						if(error_no == "0"){
							appUtils.pageInit("account/signProtocol","account/result",{});
						}else{
							layerUtils.iAlert(error_info,-1);
						}
					});
				}
				else{
					var param = {
						"user_id":appUtils.getSStorageInfo("user_id")
                        };
					//加入开通港股通跑批队列
					service.joinBatch(param,function(data){
						var error_no = data.error_no;
						var error_info = data.error_info;
						if(error_no == "0"){
							appUtils.pageInit("account/signProtocol","account/result",{});
						}else{
							layerUtils.iAlert(error_info,-1);
						}
					});
				}
			}
			else{
				//验签
				getSignProtocl();
			}
		});
		
		//绑定返回
		//绑定返回按钮
		appUtils.bindEvent($(_pageId+" .icon_back"),function(){
			appUtils.pageInit("account/signProtocol","account/mainPage",{"signFlag":signFlag});
		});
	}
	
	function destroy()
	{
		service.destroy();
	}
	
	//获取协议
	function getSign(){
		var param = {
			"category_englishname":"hkstprotcl",
			"category_no":"",
			"econtract_no":""
		};
		service.getSign(param,function(data){
			var error_no = data.error_no,
				error_info = data.error_info,
				result = data.results;
			if(error_no == "0" && result.length != 0){
				fristMap = new Map();
				var results = data.results,
					  allProtocols = "";
				var protocolMap = null;
				for(var i=0;i<results.length;i++)
				{
					protocolMap = new Map();
					protocolMap.put("protocolid",results[i].econtract_no);	//协议id
					protocolMap.put("protocolname",results[i].econtract_name);	//协议名
					protocolMap.put("summary",results[i].econtract_md5);	//协议内容MD5,签名摘要信息
					allProtocols += "<li><a href=\"javascript:;\" protocol-id=\""+results[i].econtract_no+"\" id=\"protocol0"+i+"\">《"+
						results[i].econtract_name+"》</a></li>";
					// 预绑定查看协议的事件
					appUtils.preBindEvent($(_pageId+" .rule_list ul"),"#protocol0"+i,function(e){
						appUtils.pageInit("account/signProtocol","account/showProtocol",{"protocol_id" : $(this).attr("protocol-id")});
						e.stopPropagation();
					});
					fristMap.put(i,protocolMap);
				}
				$(_pageId+" .rule_list ul").html(allProtocols);
			}else{
				layerUtils.iAlert(error_info,-1);
			}
		},{"isLastReq":true,"isShowWait":true,"timeOutFunc":handleTimeout});
	}
	
	/* 处理请求超时 */
	function handleTimeout()
	{
		layerUtils.iConfirm("请求超时，是否重新加载？",function(){
			getSign();  // 再次获取协议
		});
	}
	
	/* 获取签名值 */
	function getSignProtocl()
	{
		var keys = fristMap.keys();  // 协议的数量
		// 检查是否勾选签署协议
		if($(_pageId+" .rule_check span").hasClass("checked"))
		{
			layerUtils.iLoading(true);  // 开启等待层。。。
			var oneData  = fristMap.get(keys[countProtocol]); // 取出一个协议
			var protocolid = oneData.get("protocolid"); // 协议ID
			var protocolname = oneData.get("protocolname");  //协议名称
			var summary = oneData.get("summary");  // 协议内容MD5,签名摘要信息
			// 添加值到数组中
			var protocol = {
				"protocol_id" : protocolid,
				"summary" : summary
			}
			protocolArray.push(protocol);
			countProtocol++;
			if(countProtocol < keys.length)  // 通过比较，获取每个协议的签名值
			{
				getSignProtocl();  
			}else{
				submitProtocol();  //提交协议
			}
		}
		else
		{
			layerUtils.iAlert("请阅读并勾选同意签署以上全部协议！",-1);
			return false;
		}
	}
	
	// 提交协议
	function submitProtocol(){
		countProtocol = 0;  // 将签署协议的计数器置为 0
		var signProtocolParam = {
				"user_id" : appUtils.getSStorageInfo("user_id"),
				"jsondata" : JSON.stringify(protocolArray),
				"ipaddr" : "",
				"macaddr" : "",
				"checksign" : "0"
		};
		service.queryOpenCheckSign(signProtocolParam,function(data){
			var error_no = data.error_no,
				error_info = data.error_info;
			if(error_no == "0"){
				signFlag = "1";
				appUtils.pageInit("account/signProtocol","account/mainPage",{"signFlag":signFlag});
			}else{
				layerUtils.iAlert(error_info,-1);
			}
		});
	}
	
	var signProtocol = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
		
	module.exports = signProtocol;
});
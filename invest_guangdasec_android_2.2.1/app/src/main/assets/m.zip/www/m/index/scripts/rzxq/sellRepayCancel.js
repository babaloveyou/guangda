/**
 * 卖券还款撤单
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils");
	var layerUtils = require("layerUtils");
	var validatorUtil = require("validatorUtil");
	var putils = require("putils");
	var gconfig = require("gconfig");
	var global = gconfig.global;
	var service = require("serviceImp");  // 业务层接口，请求数据
	var _pageId = "#rzxq_sellRepayCancel ";
	var userInfo = null;
	var _market = "";
    
    /**
     * 初始化
     */
	function init() {
		userInfo = JSON.parse(appUtils.getSStorageInfo("userinfo"));
		var market = appUtils.getSStorageInfo("market");
		if(market){
			_market = market; // 查询撤单数据
		}
		queryCancel();
    }
	
	/**
	 * 事件绑定
	 */
	function bindPageEvent() {
		// 返回按钮
		appUtils.bindEvent($(_pageId + ".top_title .icon_back"), function(e){
			pageBack();
		});
		// 切换按钮
		appUtils.bindEvent($(_pageId + ".top_nav ul li:eq(0)"), function(e){
			appUtils.pageInit("rzxq/sellRepayCancel","rzxq/sellRepay");
		});
	}
    
    /**
     * 撤单数据查询
     */
	function queryCancel(){
		var account = userInfo.client_no;
		var branch_no = userInfo.branch_no;
		var market_code = _market;
		var param = {
			"account":account,
			"branch_no":branch_no,
			"market_code":market_code
		};	
		service.query699(param,function(data){
			if(data.error_no == "0"){  
				var result = data.results;
				if(result && result.length >0){
					var data = "";
                    for(var i=0,len=result.length;i<len;i++){
                    	data += queryHTML(result[i],i+1);
                    }
                	$(_pageId + "#conList").html(data);
                	$(_pageId + ".mn_count b").html(result.length);
                	appUtils.bindEvent($(_pageId+".mn_bond .revoke"), function(e){
                  		var $element = $(this).parent().parent().find("table");
                		var stockName = $(this).parent().find("h3").text(); // 股票名称
                		var stockCode = $element.find("tr:eq(0) td:eq(0)").text(); // 股票代码
                		var contractNum = $element.find("tr:eq(5) td:eq(0)").text(); // 合同号
                		var entrustNum = $element.find("tr:eq(2) td:eq(1)").text(); // 委托数量
        				var tipStr ="<div class=\"pop_header\">";
        				tipStr+="<h3>撤单确认</h3>";
        				tipStr+="</div>";
        				tipStr+="<div class=\"pop_main\">";
        				tipStr+="<ul>";
        				tipStr+="    <li>证券名称: <em>"+stockName+"</em></li>";
        				tipStr+="    <li>证券代码: <em>"+stockCode+"</em></li>";
        				tipStr+="    <li>合同编号: <em>"+contractNum+"</em></li>";
        				tipStr+="    <li>委托数量: <em>"+entrustNum+"</em></li>";
        				tipStr+="</ul>";
        				tipStr+="  </div>";
                		putils.btnConfirm(tipStr,function success(){
                			cofirmCancel(contractNum);
                		},function fail(){
                		});
    				});
				}else{
					$(_pageId + ".no_data").show(); // 没有数据时显示的暂无数据图标
					$(_pageId + ".mn_count b").html("0");
				}
			}else{
				layerUtils.iAlert(data.error_info,-1);
			}
		});
	}

	function queryHTML(element,index){
		var eleHTML = "";
		    eleHTML +="<div class=\"mn_bond\">";
		    eleHTML +="<div class=\"top_bond\">";
		    eleHTML +="	<a href=\"javascript:void(0);\" class=\"revoke\">撤单</a> ";
		    eleHTML +="	<em>"+index+"</em><h3"+element.zq_name+"</h3>";
			eleHTML +="</div>";	
            eleHTML +="<table>";
	        eleHTML +="<tr>";
		    eleHTML +="<th width=\"20%\">证券代码</th>";
		    eleHTML +="<td width=\"20%\">"+element.zq_code+"</td>";
		    eleHTML +="<th width=\"20%\">委托日期</th>";
		    eleHTML +="<td width=\"20%\">"+element.date+"</td>";
		    eleHTML +="</tr>";
		    eleHTML +="<tr>";
		    eleHTML +="<th>委托时间</th>";
		    eleHTML +="<td>"+element.wt_date+"</td>";
			eleHTML +="<th>买卖标志</th>";
			eleHTML +="<td>"+element.buy_sale_flag+"</td>";
			eleHTML +="</tr>";
			eleHTML +="<tr>";
			eleHTML +="<th>委托价格</th>";
			eleHTML +="<td>"+element.wt_price+"</td>";
			eleHTML +="<th>委托数量</th>";
			eleHTML +="<td>"+element.wt_mount+"</td>";
			eleHTML +="</tr>";
			eleHTML +="<tr>";
			eleHTML +="<th>成交数量</th>";
			eleHTML +="<td>"+element.cj_mount+"</td>";
			eleHTML +="<th>撤单数量</th>";
			eleHTML +="<td>"+element.cancle_mount+"</td>";
			eleHTML +="</tr>";
			eleHTML +="<tr>";
			eleHTML +="<th>成交金额</th>";
			eleHTML +="<td>"+element.cjje+"</td>";
			eleHTML +="<th>委托状态</th>";
			eleHTML +="<td>"+element.wtzt+"</td>";
			eleHTML +="</tr>";
			eleHTML +="<tr>";
			eleHTML +="<th>合&nbsp;同&nbsp;号</th>";
			eleHTML +="<td>"+element.ht_num+"</td>";
			eleHTML +="</tr>";
			eleHTML +="</table>";
			eleHTML +="</div>";
		    return eleHTML;
	}
	
    /**
     * 确认撤单
     */
	function cofirmCancel(contractNum){
		var account = userInfo.client_no;
		var branch_no = userInfo.branch_no;
		var market_code = _market;
		var param = {
			"account":account,
			"branch_no":branch_no,
			"market_code":market_code,
			"contract_no":contractNum
		};	
		service.query699(param,function(data){
			if(data.error_no == "0"){  
				var result = data.results;
				if(result && result.length>0){
					layerUtils.iAlert("撤单成功");
				}
			}else{
				layerUtils.iAlert(data.error_info,-1);
			}
		});
	}
	
	function destroy(){
		$(_pageId + "#conList").html("");
		$(_pageId + ".mn_count b").html("--");
	}
	
	/**
	 * 重写框架里面的pageBack方法
	 */
	function pageBack(){
		appUtils.pageInit("rzxq/sellRepay","rzxq/stockRepay");
	}
	
	var base = {
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy,
		"pageBack": pageBack
	};
	module.exports = base;
});
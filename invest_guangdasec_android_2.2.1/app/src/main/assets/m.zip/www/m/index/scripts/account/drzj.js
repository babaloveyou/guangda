/**
 * 查询当日资金变动
 */
define(function(require, exports, module){
	/*模块内部全局变量*/
	var appUtils = require("appUtils"),
		layerUtils = require("layerUtils"),
		gconfig = require("gconfig"),
		global = gconfig.global,
		service = require("serviceImp"), //业务层接口，请求数据
		_pageId = "#account_drzj ";
	
	/*页面初始化方法*/
	function init()
	{
		$(_pageId+" .hold_main").html("");
		var ext_syscode = appUtils.getPageParam("ext_syscode");
		if(ext_syscode === "1"){
			// 获取我的股票资金流水
			getFundMoneyInfo(); 
		}else if(ext_syscode === "2"){
			// 获取我的融资融券资金流水
			getMarginMoneyInfo(); 
		}else if(ext_syscode === "3"){
			// 获取我的OTC资金流水
			
		}else if(ext_syscode === "4"){
			// 获取我的期权资金流水
			
		}else{
			getFundMoneyInfo(); // 获取我的持仓
		}
	}
	
	/*绑定页面事件的方法*/
	function bindPageEvent()
	{
		/*返回*/
		appUtils.bindEvent($(_pageId+" .icon_back"), function(e){
			appUtils.pageBack();
			e.stopPropagation();
		});
	}
	/*页面销毁方法*/
	function destroy()
	{
		service.destroy();
	}
	
	/* 查询当日资金变动 */
	function getFundMoneyInfo()
	{
		var entrust_way = "SJWT";
		var branch_no = appUtils.getSStorageInfo("branch_no");
		var fund_account = appUtils.getSStorageInfo("fund_account");
		var cust_code = appUtils.getSStorageInfo("client_no");
		var param = {
			"entrust_way":entrust_way,
			"branch_no":branch_no,
			"fund_account":fund_account,
			"cust_code":cust_code,
		};
		service.queryTodayFund(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var res = data.results[0].data;
			if(error_no == "0" && res != undefined)
			{
				var len = res.length;
				$(_pageId+".len").html("("+len+")");
				var shtml = "";
				if(len == 0){
					shtml = "<ul class='hold_info clearfix'><li style='width:100%;text-align:center'>暂无数据</li></ul>";
				}
				for(var i = 0; i<len; i++)
				{
					var trans_date = res[i].trans_date; // 日期
					var fund_money = Number(res[i].fund_money).toFixed(2); // 发生金额
					var fund_balance = Number(res[i].fund_balance).toFixed(2); // 资金余额
					var apply_no = res[i].apply_no; // 流水号
					var remark = res[i].remark; // 备注
					shtml += "<ul class='hold_info clearfix'>";
					shtml += "<li><span>日期：</span>"+trans_date+"</li>";
					shtml += "<li><span>发生金额：</span>"+fund_money+"</li>";
					shtml += "<li><span>资金余额：</span>"+fund_balance+"</li>";
					shtml += "<li><span>备注：</span>"+remark+"</li>";
					shtml += "<li style='width:100%'><span>流水号：</span>"+apply_no+"</li>";
					shtml += "</ul>";
				}
				$(_pageId+" .hold_main").html(shtml);
			}
			else
			{
				layerUtils.iAlert(error_info);
			}
		});
	}
	
	/*
	 * 获取我的融资融券资金流水
	 */
	function getMarginMoneyInfo(){
		var fund_account = appUtils.getSStorageInfo("fund_account");
		var param = {
				"branchno":"",
				"account":fund_account
		};
		service.getMarginMoneyInfo(param,function(data){
			var errorNo = data.error_no;
			var errorInfo = data.error_info;
			if(errorNo === "0"){
				var result = data.results;
				$(_pageId+".len").html("("+result.length+")");
				if(result.length > 0){
					var arr = new Array();
					for(var i=0;i<result.length;i++){
						var item = result[i];
						var fsrq = item.fsrq;//日期
						var bdje = (+item.bdje).toFixed(2);//发生金额
						var bcye = (+item.bcye).toFixed(2);//资金余额
						var zy = item.zy;//备注
						var lsh = item.lsh;//流水号
						arr[i] = "<ul class='hold_info clearfix'>" +
								"<li><span>日期：</span>"+fsrq+"</li>" +
								"<li><span>发生金额：</span>"+bdje+"</li>" +
								"<li><span>资金余额：</span>"+bcye+"</li>" +
								"<li><span>备注：</span>"+zy+"</li>" +
								"<li style='width:100%'><span>流水号：</span>"+lsh+"</li></ul>";
					}
					$(_pageId+" .hold_main").html(arr.join(""));
				}else{
					$(_pageId+" .hold_main").html("<ul class='hold_info clearfix'><li style='width:100%;text-align:center'>暂无数据</li></ul>");
				}
			}else{
				layerUtils.iAlert(errorInfo);
			}
		});
	}
	
	/*向外暴露的 JSON 对象*/
	var wdcc = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	
	/*对外暴露 JSON 对象*/
	module.exports = wdcc;
});
/**
 * 汇添富-资讯
 * 
 * */
define(function(require, exports, module) {
	var gconfig = require("gconfig"),
		service = require("service"), 
		global = gconfig.global,
		serverPathTrade = global.newsUrl, //服务器URL
		serviceSingleton = new service.Service();
	/********************************公共代码部分********************************/
    function commonInvoke(paraMap, callback, ctrlParam, reqParamVo){
		reqParamVo.setReqParam(paraMap);
		ctrlParam = ctrlParam?ctrlParam:{};
		reqParamVo.setIsLastReq(ctrlParam.isLastReq);
		reqParamVo.setIsAsync(ctrlParam.isAsync);
		reqParamVo.setIsShowWait(ctrlParam.isShowWait);
		reqParamVo.setTimeOutFunc(ctrlParam.timeOutFunc);
		reqParamVo.setIsShowOverLay(ctrlParam.isShowOverLay);
		reqParamVo.setTipsWords(ctrlParam.tipsWords);
		reqParamVo.setDataType(ctrlParam.dataType);
		reqParamVo.setIsGlobal(ctrlParam.isGlobal);
		reqParamVo.setProtocol(ctrlParam.protocol);
		serviceSingleton.invoke(reqParamVo, callback);
	}
	function destroy(){
		serviceSingleton.destroy();
	}
	var service_news = { //对应的接口方法需要在这里暴露出来
		"getInstance": getInstance, //为了避免以前调用getInstance方法报错
		"destroy": destroy
	};
	function getInstance(){
		return service_news;
	}
	module.exports = service_news;
	
	/***应用接口......................................................开始*/
    
	//广告或图标分类查询
	service_news.queryAdvertisementIcon = function(param, callback, ctrlParam){
		var paraMap = {};
		paraMap["funcNo"] = "2000001";
		paraMap["type"] = param.type;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(serverPathTrade);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	};
	
	//查询咨询列表
	service_news.queryInformationList = function(param, callback, ctrlParam){
		var paraMap = {};
		paraMap["funcNo"] = "2000002";
		paraMap["catalog_id"] = param.catalog_id;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(serverPathTrade);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	};
	
	//文章内容查询
	service_news.queryArticleContent = function(param, callback, ctrlParam){
		var paraMap = {};
		paraMap["funcNo"] = "2000003";
		paraMap["article_id"] = param.article_id;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(serverPathTrade);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	};
	
	//浏览数和点赞数查询
	service_news.queryBrowseLikeNum = function(param, callback, ctrlParam){
		var paraMap = {};
		paraMap["funcNo"] = "2000004";
		paraMap["article_id"] = param.article_id;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(serverPathTrade);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	};
	
	//增加点赞数
	service_news.AddLikeNum = function(param, callback, ctrlParam){
		var paraMap = {};
		paraMap["funcNo"] = "2000005";
		paraMap["article_id"] = param.article_id;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(serverPathTrade);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	};
	
	//增加浏览数
	service_news.AddPageViews = function(param, callback, ctrlParam){
		var paraMap = {};
		paraMap["funcNo"] = "2000006";
		paraMap["article_id"] = param.article_id;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(serverPathTrade);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	};
	
	//减少点赞数
	service_news.reduceLikeNum = function(param, callback, ctrlParam){
		var paraMap = {};
		paraMap["funcNo"] = "2000007";
		paraMap["article_id"] = param.article_id;
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(serverPathTrade);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	};
	
	//查询咨询列表，分页
	service_news.queryInformationListPage = function(param, callback, ctrlParam){
		var paraMap = {};
		paraMap["funcNo"] = "2000008";
		paraMap["catalog_id"] = param.catalog_id;
		paraMap["current_page"]=param.current_page;  //第几页
		paraMap["num_page"]=param.num_page;    //每页多少条
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(serverPathTrade);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	};
	
	//首页推荐列表，分页
	service_news.queryRecommendListPage = function(param, callback, ctrlParam){
		var paraMap = {};
		paraMap["funcNo"] = "2000009";
		paraMap["recommend"] = param.recommend;   
		paraMap["current_page"]=param.current_page;  //第几页
		paraMap["num_page"]=param.num_page;    //每页多少条
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(serverPathTrade);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
	};
	
	/***应用接口......................................................结束*/
});
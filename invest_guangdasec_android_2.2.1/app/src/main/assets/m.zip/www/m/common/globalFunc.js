define(function(require,exports,module){
	var appUtils = require("appUtils"),
		shellPlugin = require("shellPlugin"),
		gconfig = require("gconfig"),
		global = gconfig.global,
		layerUtils = require("layerUtils"),
		pop_tipText = "<div class=\"pop_tips\" style=\"display:none;\"><p></p> </div>",
		isPlay = true,
	    rankNew = 1;
	
	/**
	 * 生成一定范围随机数
	 * */
	 function random(min,max){
		    return Math.floor(min+Math.random()*(max-min));
	}
	 
	function isPlatLogin()
	{
		 var plat_userInfo = getPlatUserInfo();
		 if(plat_userInfo)
		 {
			 return true;
		 }
		 else
		 {
			 return false;
		 }	 
	}
	
	function isTradeLogin()
	{
		 var userInfo = getTradeUserInfo();
		 if(userInfo)
		 {
			 return true;
		 }else
		 {
			 return false;
		 }
	}
	
	function isPlatLogin()
	{
		 var plat_userInfo = getPlatUserInfo();
		 if(plat_userInfo)
		 {
			 return true;
		 }else
		 {
			 return false;
		 }	 
	}
	
	/**
	 * 判断用户是否激活
	 * */
	function isUserActive()
	{
		 var isUserActive = appUtils.getSStorageInfo("_isActived");
		 if(isUserActive === "true")
		 {
			 return true;
		 }else
		 {
			 return false;
		 }	 
	}
	
	/**
	 * 获得统一登录信息
	 * */
	function getPlatUserInfo()
	{
		return JSON.parse(appUtils.getSStorageInfo("plat_userInfo",true));
	}

	/**
	 * 获得统一登录信息
	 * */
	function getTradeUserInfo()
	{
		return JSON.parse(appUtils.getSStorageInfo("userInfo",true));
	}
	
	/**
	 * 删除平台统一登录信息
	 * */
	function clearPlatUserInfo()
	{
		appUtils.clearSStorage("plat_userInfo");
	}
	
	/**
	 * 删除交易登录信息
	 * */
	function clearUserInfo()
	{
		appUtils.clearSStorage("userInfo");
	}
	
	 //输入框激活
	 function inputActive(ui){
		 ui.addClass("active");
		 var curWord = ui.children("em").html();
		 if(curWord == ui.attr("data-role")) {
			 ui.children("em").html("");
		 }
		 if(ui.parents(".input_text").siblings(".input_text").children(".input_custom").hasClass("active")){
			 removeInputActive(ui);
		 }
	 }
	 
	 /*
	  * 移除其他input激活状态
	  * */
	 function removeInputActive(ui)
	 {
		 var allInput = ui.parents(".input_text").siblings(".input_text");
		 for(var i=0;i<allInput.length;i++)
		 {
			var curData =  allInput.eq(i).children(".input_custom").children("em").html();
			var oldData = allInput.eq(i).children(".input_custom").attr("data-role");
			allInput.eq(i).children(".input_custom").removeClass("active");
			if(curData == "")
			{
				allInput.eq(i).children(".input_custom").children("em").html(oldData);
				allInput.eq(i).children(".input_custom").removeClass('active');
			}	 
		 }	 
	 }
	 
	function showTip(flag,word,time)
	{
		if(!time)
		{
			time = 1000;
		}	
		var pop_tip = $('.pop_tips');
		if(pop_tip.length <= 0)
		{
			$("#content").append(pop_tipText);
		}
		if(flag)
		{
			$(".pop_tips p").html(word);
			$(".pop_tips").fadeIn(time);
			setTimeout(function(){
				$(".pop_tips").fadeOut(time);	
			}, 1500);
		}else
		{
			$(".pop_tips p").html(word);
			$(".pop_tips").fadeOut(time);
		}	
	}
	/**
	 * flag true 显示,false隐藏
	 * id   父容器ID
	 * */
	function showTipDetail(flag,id)
	{
		if(flag)
		{
			$(id+" .pop_tips").show();
		}else
		{
			$(id+" .pop_tips").hide();
		}	
	}
	
	function getCurTime()
	{
		return new Date().format("HH:mm:ss");
	}
	
	function setDocumentTitle(title)
	{
		document.title = title;
	}
	
	/**
	 * 投顾是否可以签约
	 * @return {
	 * 				signFlag : true 可签约，false 不可签约
	 * 				realAmount : 优惠后价格
	 * 			}
	 */
	function investCanSign()
	{
		var signFlag = true; // 签约标识
		var realAmount = ""; // 优惠后价格
		var userInfo = getTradeUserInfo();
		var prodBuyInfo = JSON.parse(appUtils.getSStorageInfo("prodBuyInfo", true)); // 产品购买信息
		if(userInfo && prodBuyInfo) // 当两者都不为空时
		{
			var bottomVal = prodBuyInfo.ratio[0].bottomValue; // 资产范围最小值（单位：万）
			realAmount = prodBuyInfo.ratio[0].realAmount; // 优惠后价格
			bottomVal *= 10000;
			var assetVal = userInfo.assetVal; // 总资产
			if(assetVal < bottomVal) // 资产小于最低资产时
			{
				signFlag = false;
			}
		}
		return {
			signFlag : signFlag,
			realAmount : realAmount
		};
	}
	
	/**
	 * 清除 session 中的用户数据
	 */
	function clearUserInfoInSess()
	{
		appUtils.clearSStorage("_loginInPageCode");
		appUtils.clearSStorage("_loginInPageParam");
		appUtils.clearSStorage("_isLoginIn"); // 清除已登录标识
		appUtils.clearSStorage("StockAccount");
		appUtils.clearSStorage("trade_jsessionid");
		appUtils.clearSStorage("clientinfo");
		appUtils.clearSStorage("userInfo"); // 清除交易登录 userInfo
		appUtils.clearSStorage("plat_userInfo"); // 清除统一登录 userInfo
		appUtils.clearSStorage("SignContractList");// 清除投顾签约
		require.async("project/scripts/invest/index", function(invest_index){
			invest_index.addSignClass(); // 清除投顾签约样式
		});
		if(gconfig.platform == 1) // 安卓
		{
			shellPlugin.callShellMethod("tradeLogoutPlugin", null, function(data){
				layerUtils.iAlert("调用插件失败，失败原因：" + data);
			}, {});
		}
	}
	
	/**
	 * 获取用户手机号码和硬件UDID
	 * @param getMobileCallback 获取手机号的回调函数
	 */
	function getMobileNo(getMobileCallback){
		var isActived = appUtils.getSStorageInfo("_isActived");
		if(isActived == null || typeof(isActived) == 'undefined'){
			shellPlugin.callShellMethod("localstoragePlugin", function(data){
			    var r = Math.random();
	            var comcss = "project/css/common.css?r="+r;
    		 	require.async(comcss, function(){
    		 		var $common = $("link[href*='project/css/common.css']");
    		 		$common.filter(":lt(" + $common.length - 1 + ")").remove();
	            });
				var mobileNoUdid = data.value;
				var arrA = [];
				if(mobileNoUdid)
				{
					arrA = mobileNoUdid.split("|");
				}
				var mobileNo = "";
				var udid = ""; // 设备 id
				if(arrA.length == 2)
				{
					mobileNo = arrA[0];
					udid = arrA[1];		
					global.hardId = udid;
				}	
				if(mobileNo && mobileNo != "null" && mobileNo != "undefined" && mobileNo != "")
				{
					var param={
							"phone":mobileNo,
							"hardsn":udid
						};
					plat_service.queryClientActive(param,function(data){
						if (data.error_no == 0){
							if(data.results[0].flag == "1")//存在
							{
								 appUtils.setSStorageInfo("_isActived","true");
								 //保存在本地
								 appUtils.setLStorageInfo("tradeMobileNum", mobileNo);
							}	
							if(getMobileCallback)
							{
								getMobileCallback();
							}
						}else
						{
							layerUtils.iLoading(false);
							layerUtils.iAlert(data.error_info);
						}
					});
				}
				else
				{
					if(getMobileCallback)
					{
						getMobileCallback();
					}
				}
			},  function(data){
				layerUtils.iAlert("调用插件失败，失败原因：" + data);
			}, {action:"getUDID",key:"phoneNum"});
		}
		else // 已激活时
		{
			if(!global.hardId || !appUtils.getLStorageInfo("tradeMobileNum")) // 硬件 id 或者手机号为空时
			{
				shellPlugin.callShellMethod("localstoragePlugin", function(data){
					var mobileNoUdid = data.value;
					var arrA = [];
					if(mobileNoUdid)
					{
						arrA = mobileNoUdid.split("|");
					}
					var mobileNo = "";
					var udid = ""; // 设备 id
					if(arrA.length == 2)
					{
						mobileNo = arrA[0];
						udid = arrA[1];		
						global.hardId = udid;
					}
					appUtils.setLStorageInfo("tradeMobileNum", mobileNo);
					if(getMobileCallback)
					{
						getMobileCallback();
					}
				},  function(data){
					layerUtils.iAlert("调用插件失败，失败原因：" + data);
				}, {action:"getUDID",key:"phoneNum"});
			}
			else
			{
				if(getMobileCallback)
				{
					getMobileCallback();
				}
			}
		}
	}
	
	/**
	 * 显示自定义 tips
	 * @param showText 要显示的文本内容
	 * @param showTime 显示的时间
	 */
	function showCustomTips(showText, showTime)
	{
		showTime = showTime || 2;
		var aHtml = [];
		aHtml.push('<div class="tips_cover">');
		aHtml.push('<div class="tips">');
		aHtml.push('<span>' + showText + '</span>');
		aHtml.push('</div>');
		aHtml.push('</div>');
		var $tips = $(aHtml.join(""));
		$("body").append($tips);
		var $span = $tips.find("span");
		var textWidth = showText.length * Number($span.css("font-size").slice(0, -2)) + 10;
		$span.css("width", textWidth); // 设置提示框宽度
		setTimeout(function(){
			$tips.remove();
		}, showTime * 1000);
	}
			
	/**
	 * 显示遮罩层
	 * 
	 * */
	function showOverLay(flag)
	{
		if(flag)
		{
			if(gconfig.platform == 1){
				require("shellPlugin").callShellMethod("switchBottomMenuPlugin", function(){
				}, function(data){
					layerUtils.iAlert("调用底部插件失败，失败原因：" + data);
				},{"enable":"false"});
			}	
			$("#iLoading_overlay_ytz").show();
			
		}else
		{
			if(gconfig.platform == 1){
				require("shellPlugin").callShellMethod("switchBottomMenuPlugin", function(){
				}, function(data){
					layerUtils.iAlert("调用底部插件失败，失败原因：" + data);
				},{"enable":"true"});
			}	
			$("#iLoading_overlay_ytz").hide();
		}	
		
	}

	/**
	 * 校验是否是手机号
	 * @param mobileNo 手机号
	 */
	function isMobileNo(mobileNo)
	{
		var mobileReg = /^1\d{10}$/;
		return mobileReg.test(mobileNo);
	}
	
	/**
	 * 获取UDID
	 * */
	function getMobileUDID(callback){
		shellPlugin.callShellMethod("getDeviceUDIDPlugin", function(data){
			if(data && data.UUID) // 硬件信息不为空时
			{
			    var r = Math.random();
	            var comcss = "project/css/style_hq.css?r="+r;
    		 	require.async(comcss, function(){
    		 		var $common = $("link[href*='project/css/style_hq.css']");
    		 		$common.lt($common.length - 1).each(function(){
    		 			$(this).remove();
    		 		});
	            });
				global.hardId = data.UUID; // 硬件信息，设备唯一 ID
				if(callback)
				{
					callback();
				}	
			}
			else
			{
				if(callback)
				{
					callback();
				}
			}
		}, function(data){
			layerUtils.iAlert("调用“获得设备唯一ID”插件失败，失败原因：" + data);
			if(callback)
			{
				callback();
			}
		}, {});
	}
	
	/**
	 * 重载所有图片
	 * @param $imgList jquery img 集合
	 */
	function reloadAllImg($imgList)
	{
		$imgList.each(function(){
			var $currImg = $(this);
			var sCurrImgSrc = $currImg.attr("src");
			$currImg.attr("src", sCurrImgSrc);
		});
	}
	
	/**
	 * 向服务器发送请求，独立于框架的 ajax 请求，框架里面的 ajax 请求会在切换页面时被丢弃，有些场合不需要在切换页面时丢弃请求
	 * @param serverPath 服务器地址
	 * @param queryParam 请求参数
	 * @param callback 回调函数
	 */
	function invokeServer(serverPath, queryParam, callback)
	{
		$.post(serverPath, queryParam, callback);
	}
	
	/**
	 * 保存数据到壳子里面，作为 session 数据保存
	 * @param key 存储的 key
	 * @param value 存储的内容
	 * @param isEncrypt 是否是加密存储， boolean
	 */
	function setSStorageInfo(key, value, isEncrypt)
	{
		var saveParam = {
				key: key,
				value: value,
				isSave: false,
				isEncrpt: isEncrypt,
				action: "save"
		};
		shellPlugin.callShellMethod("save2FilePlugin", null, function(data){
			layerUtils.iAlert("调用 save2FilePlugin 失败，失败原因：" + data);
		}, saveParam);
	}
	
	/**
	 * 保存数据到壳子里面，作为 local 数据保存
	 * @param key 存储的 key
	 * @param value 存储的内容
	 * @param isEncrypt 是否是加密存储， boolean
	 */
	function setLStorageInfo(key, value, isEncrypt)
	{
		var saveParam = {
				key: key,
				value: value,
				isSave: true,
				isEncrpt: isEncrypt,
				action: "save"
		};
		shellPlugin.callShellMethod("save2FilePlugin", null, function(data){
			layerUtils.iAlert("调用 save2FilePlugin 失败，失败原因：" + data);
		}, saveParam);
	}
	
	/**
	 * 切换页面插件
	 * @param headerTitle 头部标题的名称
	 * @param curModuleName 当前模块的模块名
	 * @param nextModuleName 下一个模块的模块名
	 * @param needBottomBtn 是否需要底部导航按钮， boolean
	 * @param needTopBackIcon 是否需要返回图标， boolean
	 * @param childModule 子模块，JSON 字符串，如 {pageCode : "business/index", pageParam : {amount : 1000}}
	 */
	function switchPagePlugin(headerTitle, curModuleName, nextModuleName, needBottomBtn, needTopBackIcon, childModule)
	{
		var switchPageParam = {
				title: headerTitle,
				curModuleName: curModuleName,
				nextModuleName: nextModuleName,
				needBtn: needBottomBtn,
				needTopBackIcon: needTopBackIcon,
				childModule: childModule
		};
		shellPlugin.callShellMethod("switchPagePlugin", null, function(data){
			layerUtils.iAlert("调用 switchPagePlugin 失败，失败原因：" + data);
		}, switchPageParam);
	}
	
	/**
	 * 跳转页面
	 * @param moduleName 模块名
	 * @param childModule 子模块，JSON 字符串，如 {pageCode : "business/index", pageParam : {amount : 1000}}
	 */
	function switchPage(moduleName, childModule)
	{
		if(typeof(childModule) == "string")
		{
			childModule = JSON.parse(childModule);
		}
		var pageCode = childModule.pageCode;
		var pageInParam = childModule.pageParam;
		var oMainPage = {
				touch: "business/index",
				kinbao: "business/index",
				invest: "business/index"
		};
		appUtils.pageInit(oMainPage[moduleName], pageCode, pageInParam);
	}
	
	/**
	 * 模块内跳页
	 * @param childModule 子模块，JSON 字符串，如 {pageCode : "business/index", pageParam : {amount : 1000}}
	 */
	function switchPageInModule(childModule)
	{
		if(typeof(childModule) == "string")
		{
			childModule = JSON.parse(childModule);
		}
		var pageCode = childModule.pageCode;
		var pageInParam = childModule.pageParam;
		var curPageCode = appUtils.getSStorageInfo("_curPageCode"); 
		appUtils.pageInit(curPageCode, pageCode, pageInParam);
	}
	
	/**
	 * 处理返回首页悬浮框 
	 * @ele 返回按钮的 Html dom节点值
	 */
	function backIndex(ele)
	{
		appUtils.bindEvent(ele, function(){
			require("external").callFunction("55030",{}); // 返回首页
		});
	}
	
       
       /**
        * 处理返回首页悬浮框
        * @ele 返回按钮的 Html dom节点值
        */
       function openBackIndex(ele,key)
       {
       appUtils.bindEvent(ele, function(){
       	   require("external").callFunction("55030",{"key":key}); // 返回首页
         });
       }
       
       
	var index = {
			"inputActive":inputActive,
			"showTip":showTip,
			"showTipDetail":showTipDetail,
			"removeInputActive":removeInputActive,
			"isPlatLogin":isPlatLogin,
			"isUserActive":isUserActive,
			"isTradeLogin":isTradeLogin,
			"getPlatUserInfo":getPlatUserInfo,
			"clearPlatUserInfo":clearPlatUserInfo,
			"getTradeUserInfo":getTradeUserInfo,
			"random":random,
			"getCurTime":getCurTime,
			"setDocumentTitle":setDocumentTitle,
			"investCanSign" : investCanSign,
			"clearUserInfoInSess" : clearUserInfoInSess,
			"getMobileNo":getMobileNo,
			"showCustomTips" : showCustomTips,
			"showOverLay":showOverLay,
			"isMobileNo" : isMobileNo,
			"getMobileUDID":getMobileUDID,
			"reloadAllImg" : reloadAllImg,
			"invokeServer" : invokeServer,
			"setSStorageInfo": setSStorageInfo,
			"setLStorageInfo": setLStorageInfo,
			"switchPagePlugin": switchPagePlugin,
			"switchPage": switchPage,
			"switchPageInModule": switchPageInModule,
			"backIndex": backIndex,
            "openBackIndex":openBackIndex
		};

	module.exports = index;
});
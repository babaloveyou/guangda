/**
 * OTC列表
 */
define(function(require, exports, module)
	{	
	var service = require("mobileService"); //业务层接口，请求数据
	var appUtils = require('appUtils'),
	putils = require("putils"),
	layerUtils = require("layerUtils"),
	gconfig = require("gconfig"),
	global = gconfig.global,
	platform=gconfig.platform,
	convDict = require("convDict");
	var _pageId ="#mall_itemsOTC ";
	var validatorUtil=require("validatorUtil");
	var constants=require("constants");//常量类
	var pagingObjArr = [{"total_pages":0,"curr_page":0}]; //消息分页对象数组，这个页面只有一个分页，简单分页
	var URL=global.url;
	var globalFunc = require("globalFunc");
	var search_value="";
	
	//1、初始化
	function init() {
		var inst_code="";
		configInfo(search_value); 
		//globalFunc.backIndex($(_pageId+" .back_app")); // 返回App首页
		$(_pageId+" .tab_nav ul li:eq(3)").addClass(" active").siblings("li").removeClass(" active");
	}

	//初始化咨询产品
	function configInfo(search_value){
		var cust_code=appUtils.getSStorageInfo("cust_code");
		var param=
		{
			"cust_code":cust_code,
			"product_shelf":constants.product_shelf.SHELF_ON,
			"inst_code":search_value,
			"page":"1",
			"numPerPage":"3"
		}
		service.findOTC(param,function(data){
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
			
			otcItems(data);
		});
	}

	//处理咨询产品
	function otcItems(data)
	{
		var total_pages = data.results[0].totalPages;
		var curr_page = data.results[0].currentPage;
		var total_rows = data.results[0].totalRows;
		total_pages = total_pages ? total_pages:0;
		curr_page = curr_page ? curr_page:0;
		total_rows=total_rows?total_rows:0;
		pagingObjArr[0].total_pages=total_pages;
		$(_pageId+" em[name='totalPage']").html(total_pages);
		pagingObjArr[0].curr_page=curr_page;
		$(_pageId+" em[name='curPage']").html(curr_page);
		//显示多少条数据
		$(_pageId+" em[name='total_rows']").html(total_rows);

		var allRecommendStr ="";
		var list =  data.results[0].data;
		var len = list.length;
		for( var i = 0; i<len ; i++)
		{
			var perData = list[i];
			allRecommendStr += handlePerItem(perData,i);
		}
		$(_pageId+" #OTClist").html(allRecommendStr);

		//绑定跳转详情事件
		appUtils.bindEvent($(_pageId+" #OTClist .pro_box[product_id]"),function()
			{	
				
				var ban = $(this).attr("ban");
				var pageInParam=
				{
					"product_id" : $(this).attr("product_id")
				};
//				if (ban == "false") {
//					layerUtils.iMsg(-1,"该产品已售罄");
//				}
					pageInParam.is_buy = ban;
					appUtils.setSStorageInfo("product_id",$(this).attr("product_id"));//存
					appUtils.pageInit("mall/itemsOTC", "mall/itemsOTCInfo", pageInParam);
					return false;

			});

		//上一页、下一页disabled效果
		if (pagingObjArr[0].curr_page==pagingObjArr[0].total_pages) {
			$(_pageId + " span[name='aNextPage']").removeClass("blue");
			$(_pageId + " span[name='aPrePage']").addClass("blue");
		}
		else if (pagingObjArr[0].curr_page == 1) {
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + " span[name='aNextPage']").addClass("blue");
		}
		else {
			$(_pageId + " span[name='aPrePage']").addClass("blue");
			$(_pageId + " span[name='aNextPage']").addClass("blue");
		}

		if (pagingObjArr[0].total_pages<2) {
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + "  span[name='aNextPage']").removeClass("blue");
		}

		if (pagingObjArr[0].curr_page ==1&&pagingObjArr[0].total_pages==0) {
			$(_pageId+" #isNull").html("暂无数据");
			$(_pageId + " span[name='aPrePage']").removeClass("blue");
			$(_pageId + " span[name='aNextPage']").removeClass("blue");
		}

	}

	//显示咨询产品  
	function handlePerItem(perData, idx,flag)
	{
		var product_id = perData.product_id;//ID
		var inst_sname= perData.inst_sname;//产品名称
		var ent_buy_limit=perData.ent_buy_limit; //起投金额
		var mgr_org_sname=perData.mgr_org_sname;//管理人名称
		var risk_lvl=perData.risk_lvl;//风险等级
		var pro_deadline=perData.pro_deadline;//投资期限
		var est_yield=perData.est_yield;//约定年化收益率
		var inst_code=perData.inst_code;//产品代码
		var est_yield_new = est_yield;
		if(parseFloat(est_yield_new)==0){
			est_yield_new="--";
		}
		if(est_yield_new.length< 1){
			est_yield_new="--";
		}
//		if(est_yield.indexOf(".") > 0){
//			est_yield = est_yield.replaceAll("0+?$", "");//去掉多余的0    
//			est_yield = est_yield.replaceAll("[.]$", "");//如最后一位是.则去掉
//			if(est_yield.length > 1 && est_yield.length <4){
//				est_yield_new =  parseFloat(est_yield).toFixed(2);
//			}else if(est_yield.length >= 4){
//				est_yield_new = est_yield;
//			}else{
//				est_yield = "--";
//				$(_pageId+" .annual_earning p em").empty();
//				$(_pageId+" #str").empty();
//			}
//	     }
		
//		est_yield_new = est_yield_new || "--";
//		est_yield_new = est_yield_new.replaceAll("%", "");
		var details = "";
		var ban = true;
		//富尊网或掌上富尊在产品销售额度已经满的时候，可以显示“卖完了”，并变灰显示不允许goumai
		var buy_type=perData.buy_type;
		if(buy_type && buy_type=="0"){
			details = '<em class="high_risk" style="float: right;background-color:#CFCFCF;border: 1px solid #cfcfcf;">已售罄</em>';
			ban = false;
//			$(_pageId + " #OTClist .pro_box[product_id]").unbind(); // 解绑
		} else if (buy_type && buy_type=="1") {
			details = '<em class="high_risk" style="float: right;background-color:#F9C77D;border: 1px solid #F9C77D;">可购买</em>';
		}
		
		if(risk_lvl == "4" || risk_lvl == "5"){
			var oneRecommendStr="<div class='pro_box' product_id="+product_id+" ban="+ ban +"><div class='name_box'><h3>"+inst_sname+"("+inst_code+")<em class='high_risk'>高风险</em></h3>" +
			"<p>管理人：<span>"+mgr_org_sname+"</span>"+ details +"</p> </div>" +
			"<div class='earning_box clearfix'><div class='earning_left'><p><span   style='font-size:20px;'>"+est_yield_new+"</span><em></em></p>" +
			"<em class='high_risk'>参考年化收益率</em></div>" +
			"<div class='earning_right'><p>起购金额<span>"+ent_buy_limit+"</span>元</p><p>产品期限<span>"+pro_deadline+"</span></p>" +
			"<p>风险等级<span class='fw_bold'>高</span></p></div></div></div>";
		}else if(risk_lvl == "2" || risk_lvl == "3"){
			var oneRecommendStr="<div class='pro_box' product_id="+product_id+"><div class='name_box'><h3>"+inst_sname+"("+inst_code+")<em class='medium_risk'>中风险</em></h3>" +
			"<p>管理人：<span>"+mgr_org_sname+"</span>"+ details +"</p> </div>" +
			"<div class='earning_box clearfix'><div class='earning_left'><p><span   style='font-size:20px;' >"+est_yield_new+"</span><em></em></p>" +
			"<em class='medium_risk'>参考年化收益率</em></div>" +
			"<div class='earning_right'><p>起购金额<span>"+ent_buy_limit+"</span>元</p><p>产品期限<span>"+pro_deadline+"</span></p>" +
			"<p>风险等级<span class='fw_bold'>中</span></p></div></div></div>";
		}else{
			var oneRecommendStr="<div class='pro_box' product_id="+product_id+"><div class='name_box'><h3>"+inst_sname+"("+inst_code+")<em class='low_risk'>低风险</em></h3>" +
			"<p>管理人：<span>"+mgr_org_sname+"</span>"+ details +"</p> </div>" +
			"<div class='earning_box clearfix'><div class='earning_left'><p><span   style='font-size:20px;' >"+est_yield_new+"</span><em></em></p>" +
			"<em class='low_risk'>参考年化收益率</em></div>" +
			"<div class='earning_right'><p>起购金额<span>"+ent_buy_limit+"</span>元</p><p>产品期限<span>"+pro_deadline+"</span></p>" +
			"<p>风险等级<span class='fw_bold'>低</span></p></div></div></div>";
		}
		
		if(est_yield_new == "--"){
			oneRecommendStr = oneRecommendStr.replace(/<em>%<\/em>/ig, '');
		}
		
		return oneRecommendStr;
	}

	//处理上一页，下一页
	function handlePreNextPage(direction)
	{	
		var total_pages = pagingObjArr[0].total_pages;
		var   curr_page = pagingObjArr[0].curr_page;
		var   curPageNo = parseInt(curr_page) + direction ;
		var cust_code=appUtils.getSStorageInfo("cust_code");
		if(curPageNo>0 && curPageNo <= total_pages && curPageNo != curr_page) //有效执行跳转页面条件
		{
			var param=
			{
				"cust_code":cust_code,
				"product_shelf":constants.product_shelf.SHELF_ON,
				"inst_code":search_value,
				"page":curPageNo,
				"numPerPage":"3"
			}
			service.findOTC(param,function(data)
				{
				if(data.error_no!="0")
				{
					layerUtils.iAlert(data.error_info);
					layerUtils.iLoading(false);
					return false;
				}
				//富尊网或掌上富尊在产品销售额度已经满的时候，可以显示“卖完了”，并变灰显示不允许goumai
//				var perData=data.results[0].data;
//				for(var i=0;i<perData.length;i++){
//					var buy_type=perData[i].buy_type;
//				}
//				if(buy_type=="0"){
//					$(_pageId + " #OTClist .pro_box[product_id]").unbind(); // 解绑
//					layerUtils.iMsg(-1,"售罄");
//					
//				}
				
				otcItems(data);

				});
		}
		else
		{	 
			return false;
		}
	}


	//2、事件绑定
	function bindPageEvent()
	{
		 /* 搜索 */
        appUtils.bindEvent($(_pageId+" #search_value"),function(){
        	search_value = $(_pageId+" #search_value").val();
//        	if(validatorUtil.isCnAndEn(search_value) || validatorUtil.isAlphaNumeric(search_value) || search_value == ""){
        	if(!search_value == ""){
        		configInfo(search_value);
        	}else{
        		layerUtils.iMsg(-1,"输入字符不符合规范");
        	}
        },"blur");
		
        /* 绑定返回我的富尊主页 */
        appUtils.bindEvent($(_pageId+" .header .back_app"),function(e){
            var param_index = {"funcNo":"50101","moduleName":"main"};
            require("external").callMessage(param_index);
            e.stopPropagation();
        });
		// 点击上一页、下一页 
		appUtils.bindEvent($(_pageId+" span[name='aPrePage']"),function(){	
			handlePreNextPage(-1);
		});
		appUtils.bindEvent($(_pageId+" span[name='aNextPage']"),function(){
			handlePreNextPage(1);
		});

		// 点击首页 
		appUtils.bindEvent($(_pageId+" #mainPage"),function(){appUtils.pageInit("mall/itemsOTC","account/mainPage",{});});

		// 点击理财
		appUtils.bindEvent($(_pageId+" #finan"),function(){appUtils.pageInit("mall/itemsOTC","mall/itemsFinan",{});});

		//点击资讯
		appUtils.bindEvent($(_pageId+" #info"),function()	{appUtils.pageInit("mall/itemsOTC","mall/itemsInfo",{});});

		// 点击基金 
		appUtils.bindEvent($(_pageId+" #fund"),function(){appUtils.pageInit("mall/itemsOTC","mall/itemsFund",{});});

		// 点击服务 
		appUtils.bindEvent($(_pageId+" #serv"),function(){appUtils.pageInit("mall/itemsOTC","mall/itemsServ",{});});

		//点击 LOGO 
		appUtils.bindEvent($(_pageId+" .logo"),function(){appUtils.pageInit("mall/itemsOTC","account/mainPage")});

		//点击 返回顶部
		appUtils.bindEvent($(_pageId+" .back_btn"),function(){$('body,html').animate({scrollTop:0},1000);return false;});


		//点击 个人中心 
		appUtils.bindEvent($(_pageId+"  .icon_info"),function()
			{
				appUtils.pageInit("mall/itemsOTC","account/userCenter",{});
			});

	}

	//3、销毁
	function destroy()
	{
		 $(_pageId+" #search_value").val("");
		 search_value = "";
		var product_id ="";
	} 

	var itemsOTC =
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};
	module.exports = itemsOTC;

	});
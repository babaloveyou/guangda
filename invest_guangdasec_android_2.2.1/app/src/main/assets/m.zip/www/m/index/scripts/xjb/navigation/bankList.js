/*
 * 风险揭示书、协议展示
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	_pageId = "#xjb_navigation_bankList ";
	/*
	 * 页面初始化
	 */
	function init(){
		//设置高度
		$(_pageId+" .main").height($(window).height() - $(_pageId + " header").height());
		$(_pageId+" .main").css("overflow-y","auto");
		$(_pageId + " .banner_link iframe").width($(window).outerWidth(true));
		//可签约银行列表
		$(_pageId+" .main iframe").attr("src",global.backList);
	}
	
	
	
	/*
	 * 绑定页面事件
	 */
	function bindPageEvent(){
		//返回
		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(){
			pageBack();
		});
	}
	
	/*
	 * 销毁页面
	 */
	function destroy(){

	}
	
	function pageBack(){
		appUtils.pageInit("xjb/navigation/bankList","xjb/navigation/fastCashNo",{});
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy,
			"pageBack":pageBack
	};
	//暴露方法
	module.exports = base;
});
/**
 * 融资行权委托
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils");
	var layerUtils = require("layerUtils");
	var validatorUtil = require("validatorUtil");
	var gconfig = require("gconfig");
	var global = gconfig.global;
	var service = require("serviceImp"); 
	var _pageId = "#rzxq_conRZXQEntrust ";
	var exercise_price = ""; // 行权价格
	var withholding_tax = ""; // 代扣税率
	var exercise_price = ""; // 行权价格
	var balance_money = ""; // 可用金额
	var self_money = "";
	var securities_code = "";
	var option_code ="";
	var _market = "";
    /**
     * 初始化
     */
	function init() {
		userInfo =  JSON.parse(appUtils.getSStorageInfo("userinfo"));
		queryUserInfo(); // 查询可用余额
		var infos = appUtils.getPageParam("infos");
		securities_code = infos.securities_code; // 正股代码
		option_code = infos.option_code; // 期权代码
		exercise_price = infos.exercise_price?Number(infos.exercise_price):0; // 行权价格
		withholding_tax = infos.withholding_tax?Number(infos.withholding_tax):0; // 代扣税率
		_market = infos.market?Number(infos.market):0; // 代扣税率
		$(_pageId + ".mn_bond table tr:eq(0) td:eq(0)").html(securities_code); 
		$(_pageId + ".mn_bond table tr:eq(0) td:eq(1)").html(option_code);
		$(_pageId + ".mn_bond table tr:eq(1) td:eq(0)").html(exercise_price);
		$(_pageId + ".mn_bond table tr:eq(1) td:eq(1)").html(withholding_tax);
    }
	
	/**
	 * 事件绑定
	 */
	function bindPageEvent() {
		// 返回按钮
		appUtils.bindEvent($(_pageId + ".top_title .icon_back"), function(e){
			pageBack();
		});
		// 拟行权数量联动
		appUtils.bindEvent($(_pageId + "#xqNum"), function(e){
			var xqNum = Number($(this).val());
			//自有资金 > = 行权数量 *行权价格 *代扣税率 +行权数量 *行权价格 *(1-最高融资比例) 
			var self_money = xqNum*exercise_price*withholding_tax + xqNum*exercise_price*(1-0.8);
			var selfMoney = 0;
			balance_money = balance_money>0?Number(balance_money):0;
			if(self_money>balance_money){
				$(_pageId + "#selfMoney").val(balance_money);
				selfMoney = Number(balance_money);
			}else{
				$(_pageId + "#selfMoney").val(self_money.toFixed(3));
				selfMoney = Number(self_money);
			}
			//融资行权总金额 =行权数量 *行权价格 *(1+代扣税率)=自有资金 +申请融资金额 
			var needMoney = Number(xqNum*exercise_price*(1+withholding_tax));
			$(_pageId + "#needMoney").text(needMoney.toFixed(3));
			$(_pageId + "#rzMoney").val((needMoney-selfMoney).toFixed(3));
		},"keyup");
		// 自有资金
		appUtils.bindEvent($(_pageId + "#selfMoney"), function(e){
			var selfMoney = $(this).val();
			var needMoney = $(_pageId + "#needMoney").text();
			balance_money = balance_money>0?Number(balance_money):0;
			needMoney = needMoney>0?Number(needMoney):0;
			if(selfMoney > needMoney){
				selfMoney = needMoney;
			}else if(selfMoney>balance_money){
				selfMoney = balance_money;
			}
			$(this).val(selfMoney);
			$(_pageId + "#rzMoney").val((needMoney-Number(selfMoney)).toFixed(3));
		},"keyup");
		// 确认还款
		appUtils.bindEvent($(_pageId+'.mn_btn .btn'), function(e){
            submitPay(); // 确认还款
			e.stopPropagation();
		 });
	}

	/**
	 * 查询可用余额
	 */
	function queryUserInfo(){
		var account = userInfo.client_no;
		var branch_no = userInfo.branch_no;
		var param = {
			"account":account,
			"branch_no":branch_no
		};	
		service.queryUserInfo(param,function(data){
			if(data.error_no == "0"){  
				var result = data.results;
				if(result && result.length>0){
					balance_money = result[0].available_funds?Number(result[0].available_funds):"";
					$(_pageId + "#selfMoney").attr("placeholder","可用:"+balance_money);
				}
			}else{
				layerUtils.iAlert(data.error_info,-1);
			}
		});
	}
	
	/**
	 * 确认还款
	 */
	function submitPay(){
		var xqNum = $(_pageId + "#xqNum").val();
		var password = $(_pageId + "#password").val();
		if(validatorUtil.isEmpty(xqNum)){
			layerUtils.iMsg(-1,"请输入行权数量");
			return false;
		}
		if(validatorUtil.isEmpty(password)){
			layerUtils.iMsg(-1,"请输入交易密码");
			return false;
		}
		  // 密码加密
		service.getRSAKey({},function(data){
			if(data.error_no === "0"){
				var results = data.results[0];
				var modulus = results.modulus;
				var publicExponent = results.publicExponent;
				var endecryptUtils = require("endecryptUtils");
				if(password){
					password = endecryptUtils.rsaEncrypt(modulus,publicExponent,$.trim(password));
				}		
				var account = userInfo.client_no;
				var branch_no = userInfo.branch_no;
				var business_class = "2";
				var financing_amount = $(_pageId + "#rzMoney").val();
				var contract_number = appUtils.getSStorageInfo("contract_number"); 
				var param = {
					"account":account,
					"branch_no":branch_no,
					"trade_pwd":password
			    };	
				service.safeCheck(param,function(data){ // 校验密码
					if(data.error_no == "0"){  
						var param = {
								"account":account,
								"branch_no":branch_no,
								"market":_market,
								"business_class":business_class,
								"option_code":option_code,
								"positive_unit_code":securities_code,
								"exercise_amount":xqNum,
								"financing_amount":financing_amount,
								"contract_number":contract_number
							};	
							service.rzxq691(param,function(data){
								if(data.error_no == "0"){  
									var result = data.results;
									if(result && result.length>0){
										layerUtils.iAlert("还款成功");
										appUtils.pageInit("rzxq/conRZXQEntrust","rzxq/conQZXQ");
									}
								}else{
									clearMSG();
									layerUtils.iAlert(data.error_info,-1);
								}
							});
					}else{
						$(_pageId + "#password").val("");
						layerUtils.iAlert(data.error_info,-1);
					}
				});	
			}
		});		
	}
	
	// 清空数据
	function clearMSG(){
		$(_pageId + "#xqNum").val("");
		$(_pageId + "#selfMoney").val("");
		$(_pageId + "#rzMoney").val("");
		$(_pageId + "#password").val("");
		$(_pageId + "#needMoney b").text("--");
	}
	
	function destroy(){
		clearMSG();
	}
	
	/**
	 * 重写框架里面的pageBack方法
	 */
	function pageBack(){
		appUtils.pageInit("rzxq/conRZXQEntrust","rzxq/conQZXQ");
	}
	
	var base = {
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy,
		"pageBack": pageBack
	};
	module.exports = base;
});
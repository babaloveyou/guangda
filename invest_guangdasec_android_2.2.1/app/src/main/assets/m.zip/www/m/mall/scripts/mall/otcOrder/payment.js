/**
 * 理财--支付完成
 */

define(function(require, exports, module)
	{
	var service = require("mobileService"); //业务层接口，请求数据
	var appUtils = require('appUtils'),
	putils = require("putils"),
	constants=require("constants");//常量类
	layerUtils = require("layerUtils"),
	gconfig = require("gconfig"),
	global = gconfig.global;
	var _pageId ="#mall_otcOrder_payment";

	//1、初始化
	function init()
	{	
		finan_back_resuls();
	}

	function finan_back_resuls()
	{

		var pageInParam  = appUtils.getPageParam();
		var order_id=pageInParam.order_id;
		var trd_qty=pageInParam.trd_qty;
		var trd_id=pageInParam.trd_id;
		var trd_amt=pageInParam.trd_amt;
		var order_state=pageInParam.order_state;
		var inst_sname=pageInParam.inst_sname;
		var entrust_state=pageInParam.entrust_state;
		var _prePageCode = appUtils.getSStorageInfo("_prePageCode");

		//防止直接跳过
		if(order_id==null)
		{
			layerUtils.iMsg(1, "数据加载错误！");
			appUtils.pageInit("mall/otcOrder/payment","account/mainPage",{});
			return false;
		}


		if(entrust_state!=null&&entrust_state==constants.entrust_state.FAIL)
		{
			if(_prePageCode=="account/myProduct"){
				$(_pageId+" #sd").html("订单处理失败！！！");
				$(_pageId+" #inst_sname").html(inst_sname);
				$(_pageId+" .money_box").html("<span id='trd_amt'>"+trd_qty+"</span>份<br>赎回份额");
				$(_pageId+" #order_id").html(order_id);
			}else{
				$(_pageId+" #sd").html("订单处理失败！！！");
				$(_pageId+" #inst_sname").html(inst_sname);
				$(_pageId+" #trd_amt").html(trd_amt);
				$(_pageId+" #order_id").html(order_id);
			}
		}
		else if(entrust_state!=null&&entrust_state==constants.entrust_state.SUCCESS)
		{
			if(_prePageCode=="account/myProduct"){
				$(_pageId+" #sd").html("您的委托已受理");
				$(_pageId+" #inst_sname").html(inst_sname);
				$(_pageId+" #order_id").html(order_id);
				$(_pageId+" .money_box").html("<span id='trd_amt'>"+trd_qty+"</span>份<br>赎回份额");
			}else{
				$(_pageId+" #sd").html("您的委托已受理");
				$(_pageId+" #inst_sname").html(inst_sname);
				$(_pageId+" #order_id").html(order_id);
				$(_pageId+" .money_box").html("￥<span id='trd_amt'>"+trd_amt+"</span><br>购买金额");
			}
		}
		else  
		{
			if(_prePageCode=="account/myProduct"){
				$(_pageId+" #sd").html("订单委托已受理");
				$(_pageId+" #inst_sname").html(inst_sname);
				$(_pageId+" #order_id").html(order_id);
				$(_pageId+" .money_box").html("<span id='trd_amt'>"+trd_qty+"</span>份<br>赎回份额");
			}else{
				$(_pageId+" #sd").html("订单委托已受理");
				$(_pageId+" #inst_sname").html(inst_sname);
				$(_pageId+" .money_box").html("￥<span id='trd_amt'>"+trd_amt+"</span><br>购买金额");
				$(_pageId+" #order_id").html(order_id);
			}
		}

	}

	//2、事件 绑定
	function bindPageEvent()
	{
		//点击 理财
		appUtils.bindEvent($(_pageId+" #finan"),function(){	
			appUtils.pageInit("mall/otcOrder/payment","mall/itemsFinan",{});
		});

		//点击 基金
		appUtils.bindEvent($(_pageId+" #fund"),function(){
			appUtils.pageInit("mall/otcOrder/payment","mall/itemsFund",{});
		});

		//点击资讯
		appUtils.bindEvent($(_pageId+" #info"),function(){
			appUtils.pageInit("mall/otcOrder/payment","mall/itemsInfo",{});
		});

		//绑定返回事件
		appUtils.bindEvent($(_pageId+" .icon_close"),function() {
			appUtils.pageInit("mall/otcOrder/payment","account/mainPage",{});
		}); 
		
		//点击我的订单
		appUtils.bindEvent($(_pageId+"  #myOrder"),function(){
			appUtils.pageInit("mall/otcOrder/payment","account/myOrder",{});
		});
	}





	//3、销毁
	function destroy()
	{
		$(_pageId+" h5").removeClass(" no");

	}

	var payment =
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = payment;

	});
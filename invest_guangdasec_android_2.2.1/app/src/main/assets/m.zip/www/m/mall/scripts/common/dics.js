/**
 * 商城数据字典
 */
define(function(require, exports, module){
	function tranType(product_status){
		switch(product_status){
		case "0":
		case "6": return "111";break;
		case "1": return "110";break;
		case "2": return "";break;
		case "3": return "";break;
		case "4": return "";break;
		case "5": return "";break;
		case "7": return "";break;
		case "8": return "";break;
		case "9": return "";break;
		case "10": return "";break;
		default: return "-1";break;
//		public static final String PRODUCT_BUY_TYPE0="110";//认购
//		public static final String PRODUCT_BUY_TYPE1="111";//	申购
//		public static final String PRODUCT_BUY_TYPE2="112";//赎回
//		public static final String PRODUCT_BUY_TYPE3="113";//快速赎回
//		public static final String PRODUCT_BUY_TYPE4="115";//定时定额申购
//		public static final String PRODUCT_BUY_TYPE5="129";//分红设置
//		public static final String PRODUCT_BUY_TYPE6="20B";//买入
//		public static final String PRODUCT_BUY_TYPE7="20S";//卖出
//		public static final String PRODUCT_BUY_TYPE8="125";//-撤单确认
//		public static final String PRODUCT_STUTAS_FX = "1"; //发行
//		public static final String PRODUCT_STUTAS_FXCG = "2"; //发行成功
//		public static final String PRODUCT_STUTAS_FXSB = "3"; //发行失败
//		public static final String PRODUCT_STUTAS_JJTZJY = "4"; //基金停止交易
//		public static final String PRODUCT_STUTAS_TZSG = "5"; //停止申购
//		public static final String PRODUCT_STUTAS_TZSH = "6"; //停止赎回
//		public static final String PRODUCT_STUTAS_QYDJ = "7"; //权益登记
//		public static final String PRODUCT_STUTAS_HLFF = "8"; //红利发放
//		public static final String PRODUCT_STUTAS_JJDB = "9"; //基金封闭
//		public static final String PRODUCT_STUTAS_JJZZ = "10"; //基金终止
		}
	}

	//接口500006中fund_no对应的数据字典
	function dicFund_no(fund_no){
		switch(fund_no){
			case "S0014027": return "基础风险测评指标";break;
			case "S0012065": return "产品问卷测评指标";break;
			case "S0012066": return "协议签署指标";break;
			case "OTHERS": return "其他指标";break;
			default: return "不存在的类型";
		}
	}

	//适当性500006接口中除205类型的产品问卷会返回合格与不合格之外,其他问卷会返回测评等级
	function dicQuestion(level){
		switch(level){
			case "0": return "未评级";break;
			case "1": return "积极投资型";break;
			case "2": return "稳健投资型";break;
			case "3": return "保守投资型";break;
			case "4": return "谨慎型";break;
			case "5": return "稳健型";break;
			case "6": return "平衡型";break;
			case "7": return "进取型";break;
			case "8": return "激进型";break;
			default: return "未评级";
		}
	}
	//投资期限字典
	function dicInvestDeadline(inve_peri){
		switch(inve_peri) {
			case "1":
				return "短期-0到1年";
			case "2":
				return "中期-1到5年";
			case "3":
				return "长期-5年以上";
			case "4":
				return "无固定期限";
			default: return "--";
		}
	}
	//投资品种字典
	function dicInvestVaritey(inve_vari){
		switch(inve_vari) {
			case "1":
				return "债券、货币市场基金、债券基金、信托等固定收益类投资品种";
			case "2":
				return "股票、混合型基金、偏股型基金、股票型基金、信托等权益类投资品种";
			case "3":
				return "期货、融资融券";
			case "4":
				return "复杂或高金融产品";
			case "5":
				return "其他产品";
			default: return "--";
		}
	}

	var dics = {
			"tranType" : tranType,
			"dicQuestion" : dicQuestion,
			"dicInvestDeadline":dicInvestDeadline,
			"dicInvestVaritey":dicInvestVaritey
	};
	// 暴露对外的接口
	module.exports = dics;
});
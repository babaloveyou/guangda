/**
 * 融资合约还款委托
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils");
	var layerUtils = require("layerUtils");
	var validatorUtil = require("validatorUtil");
	var gconfig = require("gconfig");
	var global = gconfig.global;
	var service = require("serviceImp");  // 业务层接口，请求数据
	var _pageId = "#rzxq_conRepayEntrust ";
	var userInfo = null;
	var financing_agreement_no = "";
    
    /**
     * 初始化
     */
	function init() {
		userInfo =  JSON.parse(appUtils.getSStorageInfo("userinfo"));
		queryUserInfo(); // 查询可用余额
		var infos = appUtils.getPageParam("infos");
		var financing_date =infos.financing_date; // 融资日期
		financing_agreement_no =infos.financing_agreement_no; // 协议编号
		var protocol_state = infos.protocol_state; // 协议状态
		var exercise_code = infos.exercise_code; // 行权代码
		var financing_amount = infos.financing_amount; // 融资金额
		var return_amount = infos.return_amount; // 已归还金额
		var interest_paid = infos.interest_paid; // 已收利息
		var interest_not_received = infos.interest_not_received; // 未收利息
		var needPay = Number(financing_amount) + Number(interest_not_received) - Number(return_amount) - Number(interest_paid); // 需还金额
		$(_pageId + ".mn_trad table tr:eq(0) td").html(financing_date); 
		$(_pageId + ".mn_trad table tr:eq(1) td").html(financing_agreement_no);
		$(_pageId + ".mn_trad table tr:eq(2) td").html(protocol_state);
		$(_pageId + ".mn_trad table tr:eq(3) td").html(exercise_code); 
		$(_pageId + ".mn_trad table tr:eq(4) td").html(financing_amount);
		$(_pageId + ".mn_trad table tr:eq(5) td").html(return_amount);
		$(_pageId + ".mn_trad table tr:eq(6) td").html(interest_paid); 
		$(_pageId + ".mn_trad table tr:eq(7) td").html(interest_not_received);
		$(_pageId + ".mn_cont .input_box span:eq(1) b").html(needPay);
    }
	
	/**
	 * 事件绑定
	 */
	function bindPageEvent() {
		// 返回按钮
		appUtils.bindEvent($(_pageId + ".top_title .icon_back"), function(e){
			pageBack();
		});
		// 确认还款
		appUtils.bindEvent($(_pageId+'.mn_btn .btn'), function(e){
			submitPay(); // 还款
			e.stopPropagation();
		 });

	}

	/**
	 * 查询可用余额
	 */
	function queryUserInfo(){
		var account = userInfo.client_no;
		var branch_no = userInfo.branch_no;
		var param = {
			"account":account,
			"branch_no":branch_no
		};	
		service.queryUserInfo(param,function(data){
			if(data.error_no == "0"){  
				var result = data.results;
				if(result && result.length>0){
					var available_funds = result[0].available_funds;
					$(_pageId + ".balance").text(available_funds);
				}
			}else{
				layerUtils.iAlert(data.error_info,-1);
			}
		});
	}
	
	/**
	 * 确认还款
	 */
	function submitPay(){
		var available_funds = $(_pageId + ".balance").text();
		//var needPay = $(_pageId + ".mn_cont .input_box span:eq(1) b").html();
		var payMoney = $(_pageId + "#payMoney").val();
		var password = $(_pageId + "#password").val();
		if(validatorUtil.isEmpty(payMoney)){
			layerUtils.iMsg(-1,"请输入还款金额");
			return false;
		}else if(!validatorUtil.isNumberFloat(payMoney)){
			layerUtils.iMsg(-1,"请输入正确还款金额");
			return false;
		}else if(Number(payMoney)>Number(available_funds)){
			layerUtils.iMsg(-1,"可用资金不足");
			return false;
		}
		if(validatorUtil.isEmpty(password)){
			layerUtils.iMsg(-1,"请输入交易密码");
			return false;
		}
        // 密码加密
		service.getRSAKey({},function(data){
			if(data.error_no === "0"){
				var results = data.results[0];
				var modulus = results.modulus;
				var publicExponent = results.publicExponent;
				var endecryptUtils = require("endecryptUtils");
				if(password){
					password = endecryptUtils.rsaEncrypt(modulus,publicExponent,$.trim(password));
				}		
				var account = userInfo.client_no;
				var branch_no = userInfo.branch_no;
				var return_amount = payMoney;
				var param = {
					"account":account,
					"branch_no":branch_no,
					"trade_pwd":password
				};	
				service.safeCheck(param,function(data){ // 校验密码
					if(data.error_no == "0"){  
						var params = {
							"account":account,
							"branch_no":branch_no,
							"financing_agreement_no":financing_agreement_no,
							"return_amount":return_amount
						};	
						service.rzhk694(params,function(data){
							if(data.error_no == "0"){  
								var result = data.results;
								if(result && result.length>0){
									layerUtils.iAlert("还款成功");
									appUtils.pageInit("rzxq/conRepayEntrust","rzxq/conRepay");
								}
							}else{
								clearMSG();
								layerUtils.iAlert(data.error_info,-1);
							}
						});
					}else{
						clearMSG();
						layerUtils.iAlert(data.error_info,-1);
					}
			    });
			}
		 });
	}
	
	// 清除数据
	function clearMSG(){
		$(_pageId + "#payMoney").val("");
		$(_pageId + "#password").val("");
	}
	
	function destroy(){
		clearMSG();
	}
	
	/**
	 * 重写框架里面的pageBack方法
	 */
	function pageBack(){
		appUtils.pageInit("rzxq/conRepayEntrust","rzxq/conRepay");
	}
	
	var base = {
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy,
		"pageBack": pageBack
	};
	module.exports = base;
});
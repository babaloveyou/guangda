/**
 * 合约还款
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils");
	var layerUtils = require("layerUtils");
	var validatorUtil = require("validatorUtil");
	var gconfig = require("gconfig");
	var putils = require("putils");
	var global = gconfig.global;
	var service = require("serviceImp");  // 业务层接口，请求数据
	var _pageId = "#rzxq_conRepay ";
    
    /**
     * 初始化
     */
	function init() {
        queryConRepayList(); // 查询合约还款列表
		$(_pageId+".data").scrollTop(0);
		$(_pageId+".data").css("overflow-y","auto");
        var height_meau = $(window).height() - $(_pageId+".header").height() - $(_pageId+".top_nav").height() - 10;
		$(_pageId+".data").height(height_meau); //查询目录添加高度
    }
	
	/**
	 * 事件绑定
	 */
	function bindPageEvent() {
		// 返回按钮
		appUtils.bindEvent($(_pageId + ".top_title .icon_back"), function(e){
			pageBack();
		});
		// 菜单栏跳转
		appUtils.bindEvent($(_pageId+'.top_nav:first ul li a'), function(e){
			var pageCode = _pageId.replace("#","").replaceAll("_","/").replace(" ","");
			if($(this).attr("to-page")){
				var topage = $(this).attr("to-page");
				appUtils.pageInit(pageCode,topage,{});	
			}
			e.stopPropagation();
		 });
	}
	
	/**
	 * 查询合约还款列表
	 */
	function queryConRepayList(){
		var userInfo =  JSON.parse(appUtils.getSStorageInfo("userinfo"));
		var account = userInfo.client_no;
		var branch_no = userInfo.branch_no;
		var param = {
			"account":account,
			"branch_no":branch_no
		};	
		service.query693(param,function(data){
			if(data.error_no == "0"){  
				var result = data.results;
				if(result && result.length>0){
					var data = "";
                    for(var i=0,len=result.length;i<len;i++){
                    	data += queryHTML(result[i],i+1);
                    }
                	$(_pageId + "#conList").html(data);
                	appUtils.bindEvent($(_pageId+".mn_bond .revoke"), function(e){
                		var $element = $(this).parent().parent().find("table");
                		var protocol_state = $element.attr("data-type");
                		if(protocol_state=='待清算'){
                      		var market = $element.find("tr:eq(2) td:eq(0)").text();
                    		var xq_num = $element.find("tr:eq(2) td:eq(1)").text(); // 行权数量
                    		var xq_price = $element.find("tr:eq(3) td:eq(0)").text(); // 行权价格
                    		var financing_agreement_no = $element.find("tr:eq(0) td:eq(1)").text(); // 协议编号
                    		var exercise_code = $element.find("tr:eq(1) td:eq(1)").text(); // 行权代码
                    		var financing_amount = $element.find("tr:eq(3) td:eq(1)").text(); // 融资金额
                    		var tax = $element.find("tr:eq(6) td:eq(0)").text(); // 税金
                    		var fee = $element.find("tr:eq(6) td:eq(1)").text(); // 费用
                    		var tipStr ="<div class=\"pop_header\">";
                    		tipStr+="<h3>撤单确认</h3>";
                    		tipStr+="</div>";
                    		tipStr+="<div class=\"pop_main\">";
                    		tipStr+="<ul>";
                    		tipStr+="    <li>协议编号: <em>"+financing_agreement_no+"</em></li>";
                    		tipStr+="    <li>行权代码: <em>"+exercise_code+"</em></li>";
                    		tipStr+="    <li>行权数量: <em>"+xq_num+"</em></li>";
                    		tipStr+="    <li>行权价格: <em>"+xq_price+"</em></li>";
                    		tipStr+="    <li>融资金额: <em>"+financing_amount+"</em></li>";
                    		tipStr+="    <li>行权税金: <em>"+tax+"</em></li>";
                    		tipStr+="    <li>行权费用: <em>"+fee+"</em></li>";
                    		tipStr+="</ul>";
                    		tipStr+="  </div>";
                    		putils.btnConfirm(tipStr,function success(){
                    			conCancel(market,financing_agreement_no);
                    		},function fail(){
                    		});
                		}else{
                			layerUtils.iMsg(1,"不可撤单");
                		}
    				});
                	appUtils.bindEvent($(_pageId+".mn_bond .repay"), function(e){
                		var $element = $(this).parent().parent().find("table");
                		var protocol_state = $element.attr("data-type");
                		if(protocol_state=='待质押'||protocol_state=='已质押未还清'){
                    		var financing_date = $element.find("tr:eq(0) td:eq(0)").text(); // 融资日期
                    		var financing_agreement_no = $element.find("tr:eq(0) td:eq(1)").text(); // 协议编号
                    		var protocol_state = $element.find("tr:eq(1) td:eq(0)").text(); // 协议状态
                    		var exercise_code = $element.find("tr:eq(1) td:eq(1)").text(); // 行权代码
                    		var financing_amount = $element.find("tr:eq(3) td:eq(1)").text(); // 融资金额
                    		var return_amount = $element.find("tr:eq(4) td:eq(0)").text(); // 已归还金额
                    		var interest_paid = $element.find("tr:eq(5) td:eq(0)").text(); // 已收利息
                    		var interest_not_received = $element.find("tr:eq(5) td:eq(1)").text(); // 已未收利息
                    		var infos = {
                    			"financing_date":financing_date,
                    			"financing_agreement_no":financing_agreement_no,
                    			"protocol_state":protocol_state,
                    			"exercise_code":exercise_code,
                    			"financing_amount":financing_amount,
                    			"return_amount":return_amount,
                    			"interest_paid":interest_paid,
                    			"interest_not_received":interest_not_received,
                    		};
                    		appUtils.pageInit("rzxq/conQZXQ","rzxq/conRepayEntrust",{"infos":infos});
                		}else{
                			layerUtils.iMsg(1,"不可还款");
                		}
    				});
				}else{
					$(_pageId + ".no_data").show(); // 没有数据时显示的暂无数据图标
				}
			}else{
				layerUtils.iAlert(data.error_info,-1);
			}
		});
	}
	
	function queryHTML(element,index){
		var eleHTML = "";
		    eleHTML += "<div class=\"mn_bond\">";
		    eleHTML += "<div class=\"top_bond\">";
		    eleHTML += "<a href=\"javascript:void(0)\" class=\"revoke\">撤单</a>";
		    eleHTML += "<a href=\"javascript:void(0)\" class=\"repay cur\">还款</a>";
		    eleHTML += "<em>"+index+"</em><h3>"+element.positive_unit_code+"</h3>";
			eleHTML += "</div>";	
			eleHTML += "<table data-type="+element.protocol_state+">";
			eleHTML += "<tr>";
		    eleHTML += "	<th width=\"20%\">融资日期</th>";
		    eleHTML += "	<td width=\"20%\">"+element.financing_date+"</td>";
			var financing_agreement_no = element.financing_agreement_no;
//			if(financing_agreement_no.length > 16) {
//				financing_agreement_no = "<marquee>"+financing_agreement_no+"</marquee>";
//			}
		    eleHTML += "	<th width=\"20%\">协议编号</th>";
		    eleHTML += "	<td width=\"20%\">"+financing_agreement_no+"</td>";
		    eleHTML += "</tr>";
			eleHTML += "<tr>";
			eleHTML += "	<th>协议状态</th>";
			eleHTML += "	<td>"+element.protocol_state+"</td>";
			eleHTML += "	<th>行权代码</th>";
			eleHTML += "	<td>"+element.exercise_code+"</td>";
			eleHTML += "</tr>";
			eleHTML += "<tr>";
		    eleHTML += "	<th>市&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;场</th>";
		    eleHTML += "	<td>"+element.market_code+"</td>";
			eleHTML += "	<th>行权数量</th>";
			eleHTML += "	<td>"+element.exercise_amount+"</td>";
			eleHTML += "</tr>";
			eleHTML += "<tr>";
			eleHTML += "	<th>行权价格</th>";
			eleHTML += "	<td>"+element.exercise_price+"</td>";
			eleHTML += "	<th>融资金额</th>";
			eleHTML += "	<td>"+element.financing_amount+"</td>";
			eleHTML += "</tr>";
			eleHTML += "<tr>";
			eleHTML += "	<th>归还金额</th>";
			eleHTML += "	<td>"+element.return_amount+"</td>";
			eleHTML += "	<th>融资利率</th>";
			eleHTML += "	<td>"+element.financing_rate+"</td>";
			eleHTML += "</tr>";
			eleHTML += "<tr>";
			eleHTML += "	<th>已收利息</th>";
			eleHTML += "	<td>"+element.interest_paid+"</td>";
			eleHTML += "	<th>未收利息</th>";
			eleHTML += "	<td>"+element.interest_not_received+"</td>";
			eleHTML += "</tr>";
			eleHTML += "<tr>";
			eleHTML += "	<th>税&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;金</th>";
			eleHTML += "	<td>"+element.tax+"</td>";
			eleHTML += "	<th>行权费用</th>";
			eleHTML += "	<td>"+element.exercise_fees+"</td>";
			eleHTML += "</tr>";
			eleHTML += "</table>";
			eleHTML += "</div>";
		return eleHTML;
	}
	
	/**
	 * 撤单
	 */
	function conCancel(market,financing_agreement_no){
		var userInfo =  JSON.parse(appUtils.getSStorageInfo("userinfo"));
		var account = userInfo.client_no;
		var branch_no = userInfo.branch_no;
		var param = {
			"account":account,
			"branch_no":branch_no,
			"financing_agreement_no":financing_agreement_no,
			"market":market
		};	
		service.rzcd692(param,function(data){
			if(data.error_no == "0"){  
				queryConRepayList();
				layerUtils.iAlert("撤单成功",-1);
			}else{
				layerUtils.iAlert(data.error_info,-1);
			}
		});
	}
	
	function destroy(){
	}
	
	/**
	 * 重写框架里面的pageBack方法
	 */
	function pageBack(){
		var fromPage = appUtils.getSStorageInfo("fromPage");
		if(fromPage && fromPage=="userCenter"){
			appUtils.clearSStorage("fromPage");
			appUtils.pageInit("rzxq/conRepay","account/userCenter");
		}else{
			var param_index = {"funcNo":"50101","moduleName":"main"};
			require("external").callMessage(param_index);
		}
	}
	
	var base = {
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy,
		"pageBack": pageBack
	};
	module.exports = base;
});
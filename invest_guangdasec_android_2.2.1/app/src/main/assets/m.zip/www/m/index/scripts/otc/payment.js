/**
 * 理财--支付完成
 */

define(function(require, exports, module)
	{
	var service = require("serviceImp"); //业务层接口，请求数据
	var appUtils = require('appUtils'),
	layerUtils = require("layerUtils"),
	gconfig = require("gconfig"),
	global = gconfig.global;
	var _pageId ="#otc_payment";

	//1、初始化
	function init()
	{	
		finan_back_resuls();
	}

	function finan_back_resuls()
	{
		var pageInParam  = appUtils.getPageParam();
		var order_id=pageInParam.order_id;
		var trd_qty=pageInParam.trd_qty;
		var order_state=pageInParam.order_state;
		var inst_sname=pageInParam.inst_sname;
		var entrust_state=pageInParam.entrust_state;

		//防止直接跳过
		if(order_id==null)
		{
			layerUtils.iMsg(1, "数据加载错误！");
			appUtils.pageInit("otc/payment","account/userCenter",{});
			return false;
		}


		if(entrust_state!=null&&entrust_state=="2")
		{
			$(_pageId+" #sd").html("订单处理失败！！！");
			$(_pageId+" #inst_sname").html(inst_sname);
			$(_pageId+" #trd_amt").html(trd_qty);
			$(_pageId+" #order_id").html(order_id);
		}
		else if(entrust_state!=null&&entrust_state=="1")
		{
			$(_pageId+" #sd").html("您的委托已受理");
			$(_pageId+" #inst_sname").html(inst_sname);
			$(_pageId+" #order_id").html(order_id);
			$(_pageId+" .money_box").html("<span id='trd_amt'>"+trd_qty+"</span>份<br>赎回份额");
		}
		else  
		{
			$(_pageId+" #sd").html("订单委托已受理");
			$(_pageId+" #inst_sname").html(inst_sname);
			$(_pageId+" #order_id").html(order_id);
			$(_pageId+" .money_box").html("<span id='trd_amt'>"+trd_qty+"</span>份<br>赎回份额");
		}

	}

	//2、事件 绑定
	function bindPageEvent()
	{
		/* 点击理财  */
		appUtils.bindEvent($(_pageId+" #finan"),function(e){
			var toPage = "";
			if(gconfig.platform == "2"){
				toPage={"prefix":"www/m/mall","suffix":"mall/itemsFinan"};
			}else{
				toPage = "/mall/index.html#!/mall/itemsFinan.html";
			}
			var param = {"funcNo":"50101","moduleName":"user-center","params":{"moduleName":"financial-mall","toPage":toPage}};
			require("external").callMessage(param);
		});
		
		/* 点击资讯  */
		appUtils.bindEvent($(_pageId+" #info"),function(e){
			var toPage = "";
			if(gconfig.platform == "2"){
				toPage={"prefix":"www/m/mall","suffix":"mall/itemsInfo"};
			}else{
				toPage = "/mall/index.html#!/mall/itemsInfo.html";
			}
			var param = {"funcNo":"50101","moduleName":"user-center","params":{"moduleName":"financial-mall","toPage":toPage}};
			require("external").callMessage(param);
		});
		
		/* 点击基金  */
		appUtils.bindEvent($(_pageId+" #fund"),function(e){
			var toPage = "";
			if(gconfig.platform == "2"){
				toPage={"prefix":"www/m/mall","suffix":"mall/itemsFund"};
			}else{
				toPage = "/mall/index.html#!/mall/itemsFund.html";
			}
			var param = {"funcNo":"50101","moduleName":"user-center","params":{"moduleName":"financial-mall","toPage":toPage}};
			require("external").callMessage(param);
		});

		//绑定返回事件
		appUtils.bindEvent($(_pageId+" .icon_close"),function() {
			appUtils.pageInit("otc/payment","account/userCenter",{});
		}); 
		
		/* 点击我的订单  */
		appUtils.bindEvent($(_pageId+" #myOrder"),function(e){
			var toPage = "";
			if(gconfig.platform == "2"){
				toPage={"prefix":"www/m/mall","suffix":"account/myOrder"};
			}else{
				toPage = "/mall/index.html#!/account/myOrder.html";
			}
			var param = {"funcNo":"50101","moduleName":"user-center","params":{"moduleName":"financial-mall","toPage":toPage}};
			require("external").callMessage(param);
		});
	}





	//3、销毁
	function destroy()
	{
		$(_pageId+" h5").removeClass(" no");

	}

	var payment =
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = payment;

	});
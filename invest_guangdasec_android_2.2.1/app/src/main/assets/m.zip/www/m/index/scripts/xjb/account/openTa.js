/*
 * 开通ta帐号
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	_pageId = "#xjb_account_openTa ";
	/*
	 * 页面初始化
	 */
	function init(){
		//设置页面高度
		$(_pageId+" .main").height($(window).height() - $(_pageId + " header").height());
		$(_pageId+" .main").css("overflow-y","auto");
		category_englishname = appUtils.getPageParam("category_englishname");
		$(_pageId + " .main .definbtn_01").css("background","#1199EE");
		$(_pageId + " .main .definbtn_01").addClass("isBlue");
		if(category_englishname == "" || category_englishname == null || category_englishname == undefined){
   			layerUtils.iAlert("没有找到协议英文名");
   			return;
   		}
		
		//查询协议编号
		service.queryXyname({"category_englishname":category_englishname},function(data){
			if(data.error_no == 0){
				$(_pageId+" .risk_entry").html("");
				service.queryXyInfo({"econtract_no":data.results[0].econtract_no},function(data){
					if(data.error_no == 0){
						var result = data.results[0];
						var content = result.econtract_content;
						$(_pageId + " .main div").append(content);
						$(_pageId + " .main div font:eq(0)").css("display","none");
						$(_pageId + " .main div font:eq(1) strong:eq(0)").css({"display":"block","text-align":"center"});
					}else{
						layerUtils.iLoading(false);
						layerUtils.iAlert(data.error_info);
					}
				});
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		});
	}
 
	/*
	 * 绑定页面事件
	 */
	function bindPageEvent(){
		//开户
		appUtils.bindEvent($(_pageId + " .definbtn_01"),function(e){
			if($(this).hasClass("isBlue")){
				$(_pageId + " .main .definbtn_01").css("background","#bebebe");
				$(_pageId + " .main .definbtn_01").removeClass("isBlue");
				openTAAccount();
			}
				// openTa();
//				appUtils.pageInit("xjb/account/index","xjb/account/fxcp",{"fxcp":_fxcp,"isTa":_isTa});
			e.stopPropagation();
		});
		//返回
		appUtils.bindEvent($(_pageId+" .icon_back>span"),function(){
			pageBack();
		});
	}
	
	// //我要开户
	// function openTa(){
		// var today=new Date();
		// var h=today.getHours();
		// var m=today.getMinutes();
		// var s=today.getSeconds();
		// //var str=h+":"+m+":"+s;
		// var str=h*60*60+m*60+s;
		// if(str>=34200 && str<=54000){
			// openTAAccount();
		// }else{
// //			openTAAccount();
			// layerUtils.iAlert("请在09:30:00与15:00:00之间开户!");
		// }
	// };

	/**
   	 * 开通TA账户
   	 */
   	function openTAAccount(){
		//获取手机号
		var mobilePhone = require("external").callMessage({"funcNo":"50043","key":"mobilePhone"}).results[0].value;
		
   		var user=appUtils.getSStorageInfo("userinfo");
   		var userinfo=JSON.parse(user);
   		var s="1002";
   		if(userinfo.user_type=="0"){
   			s="1001";
   		}
   		var param = {
   			"branch_no":appUtils.getSStorageInfo("branch_no"),
   			"account":appUtils.getSStorageInfo("fund_account"),
   			"ezt_name":userinfo.user_code,
   			"ticket":"",
   			"survey_sn":s,
			"entrust_way":"SJWT",
			"mobile_channel":require("gconfig").platform,
			"mobile":mobilePhone
   		};
   		service.openTAAccount(param,function(data){
   			if(data.error_no == 0){
   				layerUtils.iMsg(0,"已为您开通了TA账户，马上进入下一步...");
   				setTimeout(function(){
   					appUtils.pageInit("xjb/account/openTa","xjb/account/index",{});	
   				},2000);

   			}else{
				if(!$(this).hasClass("isBlue")){
				$(_pageId + " .main .definbtn_01").css("background","#1199EE");
				$(_pageId + " .main .definbtn_01").addClass("isBlue");
				}
   				layerUtils.iLoading(false);
   				var error = data.error_info;
   				//后台返回的提示信息不友好
   				if(error.indexOf("SQL")> -1){
   					error = error.split("SQL")[0];
   					error = error.substring(0,error.length-2);
   				}
   				layerUtils.iAlert(error);
   			}
   		});
   	}
	
	/*
	 * 销毁页面
	 */
	function destroy(){
		$(_pageId+" .main div").html("");
	}
	
	function pageBack(){
		appUtils.pageInit("xjb/account/openTa","xjb/account/index",{});
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy,
			"pageBack":pageBack
	};
	//暴露方法
	module.exports = base;
});
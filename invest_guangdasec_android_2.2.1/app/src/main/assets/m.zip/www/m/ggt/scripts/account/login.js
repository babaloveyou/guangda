/**
 * 资金账号登陆
*/
define(function(require, exports, module){
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
		service = require("investService").getInstance(),  //业务层接口，请求数据
		global = require("gconfig").global,
		layerUtils = require("layerUtils"),
		validatorUtil = require("validatorUtil"),
		startCountDown = null,
		_pageId = "#account_login",
		key = 1,
		steps = ["uploadimg","idconfirm","witness",
		        	 "certintall","capitalacct",
		         	 "stkacct","setpwd","tpbank",
		       	     "risksurvey","visitsurvey","success"
  	    ],
		stepMap = {"uploadimg":"account/uploadPhoto","idconfirm":"account/personInfo","witness":"account/videoNotice",
	               		   "certintall":"account/digitalCertificate","capitalacct":"account/signProtocol","stkacct":"account/signProtocol",
	               		   "setpwd":"account/setPwd","tpbank":"account/thirdDepository",
	              		   "risksurvey":"account/riskAssessment","visitsurvey":"account/openConfirm","success":"account/accountResult"
	    },
		stepMap0 = {"uploadimg":"account/uploadPhotoChange","witness":"account/digitalCertificate"};
	/* 私有业务模块的全局变量 end */	
	
	function init()
	{
		$(_pageId+" .code_box img").attr("src",global.serverUrl+"/nImgServlet?key="+Math.random());
	}
	
	function bindPageEvent(){
		
		/* 绑定返回事件 */
		appUtils.bindEvent($(_pageId+" .header .icon_back"),function(){
			appUtils.pageBack();
		});
		
		/* 切换图形验证码 */
		appUtils.bindEvent($(_pageId+" .btn_refresh"),function(){
			$(_pageId+" .code_box img").attr("src",global.serverUrl+"/nImgServlet?key="+Math.random());
		});
		
		/* 校验图形验证码 */
		appUtils.bindEvent($(_pageId+" .mobile_form .pic_code"),function(){
		},"input");
		
		/* 绑定资金密码输入*/
		appUtils.bindEvent($(_pageId+" .password"),function(){
			var password = $(_pageId+" .password").val();
			if(password != ""){
				$(_pageId+" .btn_clear").show();
			}else if(password == ""){
				$(_pageId+" .btn_clear").hide();
			}
			if(!$(_pageId+" btn_clear").is(":hidden")){
				appUtils.bindEvent($(_pageId+" .btn_clear"),function(){
					$(_pageId+" .password").val("");
					$(_pageId+" .btn_clear").hide();
				});
			}
		},"input");
		
		/* 下一步(继续开户) */
		appUtils.bindEvent($(_pageId+" .ce_btn a") ,function(){
			//检查输入的信息
			if(checkInfo()){
				//登陆资金账号
				loginAccount();
			}
		});
		
	}
	
	function destroy()
	{
		$(_pageId+" .account").val("");   //清除资金账号
		$(_pageId+" .password").val("");  //清除密码
		$(_pageId+" .code").val("");  // 清除验证码
		service.destroy();
	}
	
	/* 验证输入信息*/
	function checkInfo(){
		var account_str = $(_pageId+" .account").val().length;
		//==========================================================
//			password_str = $(_pageId+" .password").val().length,
//			code_str = $(_pageId+" .code").val().length;
		
		//==========================================================
		if(account_str == 0){
			layerUtils.iMsg(-1,"请输入资金账号！");
			return false;
		}
		/*
		if(password_str == 0){
	    	layerUtils.iMsg(-1,"请输入资金密码！");
			return false;
	    }
		if(code_str == 0)
		{
			layerUtils.iMsg(-1,"请输入验证码！");
			return false;
		}
		if(!(6<=password_str<=20)){
			layerUtils.iMsg(-1,"请输入6-20位的资金密码！");
			return false;
		}
		*/
		return true;
	}
	
	//登陆资金账号
	function loginAccount(){
		
		//======================只用到了资金号和营业部编号           资金号是从标准版的输入框中获取的，营业部编号写死了，这是为了打通设定的。=======================
		var fund_account = $(_pageId+" .account").val();
		password = $(_pageId+" .password").val(),
//		code = $(_pageId+" .code").val();
		//把交易密码加密存到session中
		appUtils.setSStorageInfo("password",password,true);
		var param = {
			"fund_account" : fund_account,
			"password" : password,
//			"verify_code" : code
			"branch_no":"403"
		};
		
		//=================================================
		//登陆资金账号
		service.loginAccount(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result = data.results;
			if(error_no == "0" && result.length != 0){
				
				//==============================为了跑通，将login.flag的判断注释了 ，因为我们标准版没法登陆，请注意==================================
//				if(result[0].login_flag == "1"){
				//沪A账户是否指定交易
				appUtils.setSStorageInfo("is_regTrade",result[0].is_regTrade);
				//是否需要跑批
				appUtils.setSStorageInfo("is_autoTask",result[0].is_autoTask);
			    //开通港股通备注
				appUtils.setSStorageInfo("ggtopen_remark",result[0].ggtopen_remark);
			    //当前步骤
				appUtils.setSStorageInfo("current_step",result[0].current_step);
			    //证件类型
				appUtils.setSStorageInfo("idtype",result[0].idtype);
			    //证件有效截止日期
				appUtils.setSStorageInfo("idenddate",result[0].idenddate);
			    //证件有效开始日期
				appUtils.setSStorageInfo("idbegindate",result[0].idbegindate);
			    //沪A账号是否加挂
				appUtils.setSStorageInfo("isadd",result[0].isadd);
			    //港股通开立标志
				appUtils.setSStorageInfo("ggtopen_flag",result[0].ggtopen_flag);
			    //风险测评分数
				appUtils.setSStorageInfo("survey_score",result[0].survey_score);
			    //风险测评是否有效
				appUtils.setSStorageInfo("risk_survey_valid",result[0].risk_survey_valid);
			    //风险测评等级
				appUtils.setSStorageInfo("rating_lvl",result[0].rating_lvl);
			    //知识测评分数
				appUtils.setSStorageInfo("knowledge_score",result[0].knowledge_score);
			    //营业部编号
				appUtils.setSStorageInfo("branchno",result[0].branchno);
			    //用户编号
				appUtils.setSStorageInfo("user_id",result[0].user_id);
			    //风险测评等级名称
				appUtils.setSStorageInfo("rating_lvl_name",result[0].rating_lvl_name);
			    //客户姓名
				appUtils.setSStorageInfo("custname",result[0].custname);
			    //沪A账号
				appUtils.setSStorageInfo("shaaccount",result[0].shaaccount);
			    //证券账户资产总值
				appUtils.setSStorageInfo("marketvalue",result[0].marketvalue);
			    //电话号码
				appUtils.setSStorageInfo("mobileno",result[0].mobileno);
			    //客户类型
				appUtils.setSStorageInfo("cust_type",result[0].cust_type);
			    //信用证券账户总资产
				appUtils.setSStorageInfo("net_asset",result[0].net_asset);
			    //联系地址
				appUtils.setSStorageInfo("address",result[0].address);
			    //身份证是否在有效期内
				appUtils.setSStorageInfo("idenddate_valid",result[0].idenddate_valid);
			    //身份证号
				appUtils.setSStorageInfo("idno",result[0].idno);
			    //下一步入口
				nextStep(result[0]);
					
			//==========================================================  ===之间是跑通注释的
//				}
//				else if(result[0].login_flag == "0"){
//					layerUtils.iMsg(-1,result[0].login_reason);
//				}
		    //==========================================================
			}else{
				layerUtils.iAlert(error_info,-1);
			}
		});
	}
	
	/* 下一步入口 */
	/*function nextStep(res, opacctkind_flag)
	{
		var pageCode = "";
		var currentStep = res["lastcomplete_step"];  //断点：上次走的最后一步
		appUtils.setSStorageInfo("currentStep",currentStep);
		if(currentStep && currentStep.length > 0)
		{
			var index = steps.indexOf(currentStep);
			if(index < (steps.length-1))
			{
				currentStep = steps[index + 1];
			}
			if(opacctkind_flag == "0")
			{
				pageCode = stepMap[currentStep];
			}
			else
			{
				pageCode = stepMap0[currentStep];
				if(!(pageCode && pageCode.length > 0))
				{
					pageCode = stepMap[currentStep];
				}
			}
		}
		if(pageCode && pageCode.length > 0)
		{
			// 如果是直接跳转到 视频认证 页面，将 QQ 保存到 session 中
			if(pageCode == "account/videoNotice")
			{
				appUtils.setSStorageInfo("qq",res.im_code);
			}
			appUtils.pageInit("account/login",pageCode,{});
		}
		else
		{
			appUtils.pageInit("account/login","account/selDepartment",{});
		}
	}*/
	function nextStep(res){
		/*var pageCode = "";
		var currentStep = res["current_step"];
		if(currentStep && currentStep.length > 0)
		{
			
		}
		else
		{
			appUtils.pageInit("account/login","account/mainPage",{});
		}*/
//		if(res.ggtopen_flag == "1" || res.ggtopen_flag == "2"){
//			appUtils.pageInit("account/login","account/result",{});
//		}else{
//			if(appUtils.getSStorageInfo("current_step") == "account/result"){
//				appUtils.pageInit("account/login","account/result",{});
//			}
//			else{
//				appUtils.pageInit("account/login","account/mainPage",{});
//			}
//		}
		var ggtopen_flag = appUtils.getSStorageInfo("ggtopen_flag");  // 开通港股通标志 
		var cust_type = appUtils.getSStorageInfo("cust_type"); // 判断普通用户还是机构用户
		var current_step = appUtils.getSStorageInfo("current_step"); // 当前步骤
		if(ggtopen_flag == "1" || (ggtopen_flag == "2" && current_step == "ktha/Success") || (ggtopen_flag == "3" && current_step == "ktha/Success")){
			appUtils.pageInit("business/index","account/result",{});
		}
		else{
			if(current_step == "account/result"){
				appUtils.pageInit("business/index","account/result",{});
			}
			else{
			    //如果是机构户直接跳转到协议页面
			    if(cust_type=="2"){
			    	appUtils.pageInit("business/index","account/signProtocol",{"_prePagecode":"business/index"}); 
			    }
			    else{
				 	appUtils.pageInit("business/index","account/mainPage",{});      
			    }
			}
		}
	}
	
	var login = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	
	//暴露接口
	module.exports = login;
});
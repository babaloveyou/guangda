/**
 * 光大富尊
 */
define(function(require, exports, module){
	/* 私有业务模块的全局变量 begin */
	var appUtils = require("appUtils"),
		layerUtils = require("layerUtils"),
		service = require("serviceImp"), //业务层接口，请求数据
		gconfig = require("gconfig"),
		chartsUtils = require("chartsUtils"),
		global = gconfig.global,
		_pageId = "#account_userCenter ";
	var result = "",//用户登录信息
		arr = "",//获得资金账号的集合    ----fundList
		stockCodeList = "",//股票账号集合
		stockSize = "",//股票账号的长度
		nowNumberStock = "",//当前是第一个股票账号
		cust_act_flag = "", //激活状态
		nowTradeCode = "";//当前的账号
		var otcFlag = false;
		var custTypeFlag = false;

	/* 私有业务模块的全局变量 end */

	function init(){
		service.getAllProtocolId("",function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			if(error_no == "0"){
				var resultPro = data.results[0];
				appUtils.setSStorageInfo("pro_code_fxjss",resultPro.pro_code_fxjss);
				appUtils.setSStorageInfo("pro_code_ht",resultPro.pro_code_ht);
				appUtils.setSStorageInfo("pro_code_qys",resultPro.pro_code_qys);
				appUtils.setSStorageInfo("pro_code_t0_fwxy",resultPro.pro_code_t0_fwxy);
				appUtils.setSStorageInfo("pro_code_t0_fxjs",resultPro.pro_code_t0_fxjs);
				// 重置账户信息
				$(_pageId+" #fundList").css("margin-left","0px");
				$(_pageId+" #stockCon .pre").removeClass("active");
				$(_pageId+" #stockCon .next").removeClass("active");
				//显示登录后的信息
				result = JSON.parse(appUtils.getSStorageInfo("userinfo"));
				appUtils.setSStorageInfo("jsessionid",result.jsessionid); //测试
				$(_pageId+" #trade li:eq(0)").addClass("active").siblings().removeClass("active");
				var newName = appUtils.getPageParam("newName");
				cust_act_flag = appUtils.getPageParam("cust_act_flag");
				if(cust_act_flag != "1"){
					cust_act_flag = result.cust_act_flag;
				}
				if(newName){
					result.cust_dname = newName;
					$(_pageId+" #fundList").css("margin-left","0px");
					$(_pageId+" #trade li:eq(0)").addClass("active").siblings().removeClass("active");
				}
				showUserinfo();
				// 判断是E账号登录的时候，获取OTC账户信息，否则隐藏OTC账户信息
				if(result.login_flag !="E"){
					//$(_pageId+" .otc_open").hide();
					$(_pageId+" .info_box #otcAccount").hide(); //测试
				}else{
		//			useableMoney();   //2015.05.19注释
					otcAccoInfo();
					$(_pageId+" .otc_open").show();
					//$(_pageId+" .info_box #otcAccount").show(); //测试
				}
				if(result.user_code){
					otcRiskResult();
					$(_pageId+" #riskLevel").show();
				}else{
					$(_pageId+" #riskLevel").hide();
				}
			}else{
				layerUtils.iAlert(error_info);
				return false;
			}
		});
	}

	function bindPageEvent(){
		/*返回到主页*/
		appUtils.bindEvent($(_pageId+" .icon_back"),function(e){
			var param_index = {"funcNo":"50101","moduleName":"main"};
			require("external").callMessage(param_index);
			e.stopPropagation();
		});

		/* 切换 账户按钮和业务办理按钮 */
		appUtils.bindEvent($(_pageId+" .two li"),function(){
			$(this).addClass("active").siblings().removeClass("active");
			var id = this.id;
			if(id == "account"){
				$(_pageId+" .user_nav:eq(0)").show().siblings(".user_nav").hide();
			}
			else{
				$(_pageId+" .user_nav:eq(1)").show().siblings(".user_nav").hide();
			}
		});

		/* 点击我的持仓 */
		appUtils.bindEvent($(_pageId+" #wdcc"),function(e){
			if(!nowTradeCode){
				return false;
			}
			var tradeCode = JSON.parse(nowTradeCode);
			appUtils.pageInit("account/userCenter", "account/wdcc",{"ext_syscode":tradeCode.ext_syscode});

		});

		/* 点击当日委托查询  */
		appUtils.bindEvent($(_pageId+" #drwt"),function(e){
			if(!nowTradeCode){
				return false;
			}
			var tradeCode = JSON.parse(nowTradeCode);
			appUtils.pageInit("account/userCenter", "account/drwt",{"ext_syscode":tradeCode.ext_syscode});
		});

		/* 点击当日资金变动  */
		appUtils.bindEvent($(_pageId+" #drzj"),function(e){
			if(!nowTradeCode){
				return false;
			}
			var tradeCode = JSON.parse(nowTradeCode);
			appUtils.pageInit("account/userCenter", "account/drzj",{"ext_syscode":tradeCode.ext_syscode});
		});

		/* 点击我的资讯产品  */
		appUtils.bindEvent($(_pageId+" #zxcp"),function(e){
			var toPage = "";
			if(gconfig.platform == "2"){
				toPage={"prefix":"www/m/mall","suffix":"account/myProduct"};
			}else{
				toPage = "/mall/index.html#!/account/myProduct.html";
			}
			var param = {"funcNo":"50101","moduleName":"financial-mall","params":{"moduleName":"user-center","toPage":toPage}};
			require("external").callMessage(param);
		});
		
		//开通otc账户  和 激活E账号
		//appUtils.bindEvent($(_pageId+" .info_table tr:eq(3) a"),function(){
		 appUtils.bindEvent($(_pageId+" .more"),function(){
			var turnType = $(this).attr("data-type");  // 跳转类别
			if(turnType=="1"){ //当E账号登陆的时候
				if(custTypeFlag){
					//layerUtils.iMsg(-1,"机构不允许开OTC户");
					return false;
				}else{
					appUtils.pageInit("account/userCenter","otc/riskDisclosure",{});
				}
			}else{ //当资金账号登陆的时候
				if(result.login_flag === "E"){
					return false;
				}else{
					appUtils.pageInit("account/userCenter","account/activateAgre",{"cust_code":result.user_code});
				}
			}
		});

		/* 点击我的金融产品  */
		appUtils.bindEvent($(_pageId+" #jrcp"),function(e){
			var toPage = "";
			if(gconfig.platform == "2"){
				toPage={"prefix":"www/m/mall","suffix":"account/myProduct"};
			}else{
				toPage = "/mall/index.html#!/account/myProduct.html";
			}
			var param = {"funcNo":"50101","moduleName":"financial-mall","params":{"moduleName":"user-center","toPage":toPage}};
			require("external").callMessage(param);
		});

		/* 点击我的借款  */
		appUtils.bindEvent($(_pageId+" #wdjk"),function(e){
			var toPage = "";
			if(gconfig.platform == "2"){
				toPage={"prefix":"www/m/xdt","suffix":"business/borrowRecord"};
			}else{
				toPage = "/xdt/index.html#!/business/borrowRecord.html";
			}
			var param = {"funcNo":"50101","moduleName":"fund-loan","params":{"moduleName":"user-center","toPage":toPage}};
			require("external").callMessage(param);
		});

		/* 点击我要借款  */
		appUtils.bindEvent($(_pageId+" #wyjk"),function(e){
			var toPage = "";
			if(gconfig.platform == "2"){
				toPage={"prefix":"www/m/xdt","suffix":"business/borrowIndex"};
			}else{
				toPage = "/xdt/index.html#!/business/borrowIndex.html";
			}
			var param = {"funcNo":"50101","moduleName":"fund-loan","params":{"moduleName":"user-center","toPage":toPage}};
			require("external").callMessage(param);
		});

		/* 点击我要还款  */
		appUtils.bindEvent($(_pageId+" #wyhk"),function(e){
			var toPage = "";
			if(gconfig.platform == "2"){
				toPage={"prefix":"www/m/xdt","suffix":"business/repayList"};
			}else{
				toPage = "/xdt/index.html#!/business/repayList.html";
			}
			var param = {"funcNo":"50101","moduleName":"fund-loan","params":{"moduleName":"user-center","toPage":toPage}};
			require("external").callMessage(param);
		});

		/* 点击开港股通  */
		appUtils.bindEvent($(_pageId+" #ggtqy"),function(e){
			var toPage = "";
			if(gconfig.platform == "2"){
				toPage={"prefix":"www/m/ggt","suffix":"business/index"};
			}else{
				toPage = "/ggt/index.html#!/business/index.html";
			}
			var param = {"funcNo":"50101","moduleName":"ggt","params":{"moduleName":"user-center","toPage":toPage}};
			require("external").callMessage(param);
		});

		/* 点击现金宝  */
		appUtils.bindEvent($(_pageId+" #xjb"),function(e){
			// appUtils.pageInit("account/userCenter","xjb/account/index",{})
			stepCheck();
		});
		
		/* 点击创业板转签  */
		appUtils.bindEvent($(_pageId+" #cybzq"),function(e){
			appUtils.pageInit("account/userCenter","account/cybzq",{"fromPage":"userCenter"});
		});
		
		/* 点击融资行权 */
		appUtils.bindEvent($(_pageId+" #rzxq"),function(e){
			appUtils.pageInit("account/userCenter","rzxq/contractStatus",{"fromPage":"userCenter"});
		});

		/* 点击融资融券浮动授信申请 */
		appUtils.bindEvent($(_pageId+" #fdsx"),function(e){
			appUtils.pageInit("account/userCenter","account/rzrqfdsxsq",{});//签署电子合同
		});


		/* 点击开港股通  */
		appUtils.bindEvent($(_pageId+".no_open"),function(e){
			var toPage = "";
			if(gconfig.platform == "2"){
				toPage={"prefix":"www/m/ggt","suffix":"business/index"};
			}else{
				toPage = "/ggt/index.html#!/business/index.html";
			}
			var param = {"funcNo":"50101","moduleName":"ggt","params":{"moduleName":"user-center","toPage":toPage}};
			require("external").callMessage(param);
		});

		/* 点击安全退出  */
		appUtils.bindEvent($(_pageId+" .ce_btn>a"),function(e){
			layerUtils.iConfirm("确定要退出吗？",function(){
				var param = {"funcNo":"70004"};
				require("external").callMessage(param);
			});
		});

		//点击交易部分导航栏
		appUtils.bindEvent($(_pageId+" #trade li"),function(){
			var $li = $(this);
			var liId = $li.attr("id");
			var liClass = $li.attr("class");
			if(result.login_flag === "E"){
				$(_pageId+" #fundList").css("margin-left","0px");
				if(liId === "OTC_3" && otcFlag == false){
					layerUtils.iAlert("您还未开通OTC账户！！！");
					return false;
				}
				if(liId === "margin_2"){  
					if((arr)&&(arr.length>0)){
						var minArr = new Array();
						var minMark = 0;
						for(var i=0;i<arr.length;i++){
							if(JSON.parse(arr[i]).ext_syscode == "2"){
								minArr[minMark] = arr[i];
								minMark++;
							}
						}
					}
					var falg =  minArr[0];
					if(!falg){
						layerUtils.iMsg(-1,"您暂时没有融资融券账号！");
						return false;
					}
				}
				if(liClass){
					return false;
				}else{
					if(liId === "OTC_3"){
						useableMoney();
					}
					$li.addClass("active").siblings().removeClass("active");
					var mark = liId.split("_")[1];
					//对用户的资金账号集合进行遍历
					traverseArr(mark);
				}
			}else{
				if(liId === "stock_1"){
					return false;
				}else{
					layerUtils.iAlert("请用E账通登录查看");
					return false;
				}
			}
			
		});

		//切换账号 
		appUtils.bindEvent($(_pageId+" #stockCon .user_num span"),function(){
			if($(_pageId+" #stock_1").attr("class")){//只有股票才有多个账号
				var $span = $(this);
				var spanClass = $span.attr("class");
				var divWidth = $(_pageId+" .user_num").width();
				if(spanClass === "next active"){
					$(_pageId+" #fundList").animate({
						"marginLeft":"-="+divWidth+"px"
					});
					nowNumberStock++;
					if(nowNumberStock == stockSize){
						$(_pageId+" .next").removeClass("active");
					}
					$(_pageId+" .pre").addClass("active");
					nowTradeCode = stockCodeList[nowNumberStock-1];//当前股票账号 
				}
				if(spanClass === "pre active"){
					$(_pageId+" #fundList").animate({
						"marginLeft":"+="+divWidth+"px"
					});
					nowNumberStock--;
					if(nowNumberStock == 1){
						$(_pageId+" #stockCon .pre").removeClass("active");
					}
					$(_pageId+" #stockCon .next").addClass("active");
					nowTradeCode = stockCodeList[nowNumberStock-1];//当前股票账号
				}
				if((!spanClass)||(spanClass.trim() === "pre")||(spanClass.trim() === "next")){
					return false;
				}
				//获得 当前 资金账号
				getNowE_Fund("1");
			}
		});

//		//激活E账通
//		appUtils.bindEvent($(_pageId+" .info_table tr:eq(2) a"),function(){
//			if(result.login_flag === "E"){
//				return false;
//			}else{
//				appUtils.pageInit("account/userCenter","account/activateAgre",{"cust_code":result.user_code});
//			}
//		});

		//修改登录名
//		appUtils.bindEvent($(_pageId+" .info_table tr:eq(0) a"),function(){
//			appUtils.pageInit("account/userCenter","account/updateName",{"cust_dname":result.cust_dname});
//		});
		appUtils.bindEvent($(_pageId+" .icon_option"),function(){
			appUtils.pageInit("account/userCenter","account/updateName",{"cust_dname":result.cust_dname});
	    });

		appUtils.bindEvent($(_pageId),function(){
		});

		//退市整理
		appUtils.bindEvent($(_pageId + " #tszl"),function(){
			appUtils.pageInit("account/userCenter","account/marketCon",{"fromPage":"userCenter"});
		});

		//风险警示
		appUtils.bindEvent($(_pageId + " #fxjs"),function(){
			appUtils.pageInit("account/userCenter","account/riskCautionPage",{"fromPage":"userCenter"});
		});
		
		//柜台产品
		appUtils.bindEvent($(_pageId + " #GTProduct"),function(){
			appUtils.pageInit("account/userCenter","otc/otcGT");
		});
		
		/* 点击我的订单  */
		appUtils.bindEvent($(_pageId+" #myOrder"),function(e){
			var toPage = "";
			if(gconfig.platform == "2"){
				toPage={"prefix":"www/m/mall","suffix":"account/myOrder","prePage":"fz_userCenter"};
			}else{
				toPage = "/mall/index.html#!/account/myOrder.html?prePage=fz_userCenter";
			}
			var param = {"funcNo":"50101","moduleName":"financial-mall","params":{"moduleName":"user-center","toPage":toPage}};
			require("external").callMessage(param);
		});
		
		/* 点击我要购买  */
		appUtils.bindEvent($(_pageId+" #buy"),function(e){
			var toPage = "";
			if(gconfig.platform == "2"){
				toPage={"prefix":"www/m/mall","suffix":"mall/itemsOTC"};
			}else{
				toPage = "/mall/index.html#!/mall/itemsOTC.html";
			}
			var param = {"funcNo":"50101","moduleName":"financial-mall","params":{"moduleName":"user-center","toPage":toPage}};
			require("external").callMessage(param);
		});
		
		/* 点击重新测评 */
		appUtils.bindEvent($(_pageId+" #riskTest"),function(e){
			appUtils.pageInit("account/userCenter","otc/riskAssessment",{});
			e.stopPropagation();
		},"click");
		
		/* 切换账号*/  
		appUtils.bindEvent($(_pageId+" .change"),function(e){  //测试
			var fundlist = null;
			if(result.fundlist){
				fundlist = JSON.parse(result.fundlist);
			}else{
				fundlist = [{"fund_account":result.fund_account,"ext_syscode":"1","ext_sysname":"集中交易"}];
			}
			var fundAccount = appUtils.setSStorageInfo("fund_account");
			if(!fundAccount){
				fundAccount = result.fund_account;
			}
			var html = "";
			//"1":"集中交易","2":"融资融券","3":"OTC","4":"个股期权","5":"黄金交易","6":"三方交易","7":"B股系统","8":"大CIF"
			for(var i = 0,len = fundlist.length; i<len; i++){
				var ext_syscode = fundlist[i].ext_syscode;
				var ext_sysname = fundlist[i].ext_sysname;
				var fund_account = fundlist[i].fund_account;
				
				html +="<li data-type="+ext_syscode+">";
			    html +="   <p>"+ext_sysname+"</p>";
			    html +="   <strong>"+fund_account+"</strong>";
			    if(ext_syscode!="1" || 	fund_account == fundAccount){
				   html +="<span class=\"icon_radio active\"></span>";
			    }else{
			       html +="<span class=\"icon_radio\"></span>";
			    }
				html +="</li>";
			}
			$(_pageId+" .pop_switch ul").html(html);
			appUtils.bindEvent($(_pageId+" .pop_switch ul li"),function(e){
				var $checkBox = $(this).find("span");
				var accountType = $(this).attr("data-type");
				if(accountType=="1"){
				$(_pageId+" .pop_switch ul li").each(function(){
				    //用$(this)可以访问正在循环的元素 
					var accountType = $(this).attr("data-type");
					if(accountType=="1"){
						 $(this).find("span").removeClass("active");
					}
				});
				$checkBox.addClass("active");
				result.fund_account = $(this).find("strong").text();
				require("external").callMessage({"funcNo":"50040","key":"switchAccountResults","value":[result]});
				
				}
			});
			$(_pageId+" .backdrop").show();
			$(_pageId+" .pop_switch").slideToggle();
			e.stopPropagation();
		});
		
		/*隐藏框*/
		appUtils.bindEvent($(_pageId+" .pop_switch .ce_btn a"),function(e){ //测试
			 $(_pageId+" .pop_switch").slideToggle();
			 $(_pageId+" .backdrop").hide();
	    	 if($(this).index()=="0"){
	    		 appUtils.pageInit("account/userCenter","account/userCenter",{});
	    	 }
			 e.stopPropagation();
		});

	}

	function destroy(){
		$(_pageId+" .no_open").hide();
	}
	
	/*otc风险测评结果*/
	function otcRiskResult(){
		//var cust_code=appUtils.getSStorageInfo("cust_code");
		//var ticket=appUtils.getSStorageInfo("ticket");
		cust_code = result.user_code;  //测试
		ticket = result.ticket;  //测试
		var value_type = "";
		if(result.login_flag != "E"){
			value_type = result.user_type;
		}else{
			value_type = appUtils.getSStorageInfo("cust_type");
		}
		var survey_sn = "";
		if(value_type == "0"){
			survey_sn = "1001";
		}else if(value_type == "1"){
			survey_sn = "1002";
		}else{
			survey_sn = "1001";
		}
		var param={
				"cust_code" : cust_code,
				"survey_sn": survey_sn,
				"ticket" : ticket
		};

		/*调用适当性风测结果接口*/
		service.newRiskResult(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var result = data.results;
			if(error_no == "0" && result.length != 0){
				var risk_name = result[0].risk_name;
				$(_pageId+" #riskLevel  span").html(risk_name);
			}else{
				layerUtils.iAlert(error_info);
			}
		});
	}

	/*
	 * 查询是否有交易账户
	 */
	function otcAccoInfo(){
//		var cust_code=appUtils.getSStorageInfo("cust_code");
//		var fundlist=appUtils.getSStorageInfo("fundlist");
//		var ticket=appUtils.getSStorageInfo("ticket");
		var cust_code = result.user_code; //测试
		var fundlist = result.fundlist; //测试
        var ticket = result.ticket; //测试
		fundlist = eval(fundlist);
		var fund_accountList="";
		if(fundlist.length>1){
			for(var i = 0; i< fundlist.length; i++){
				fund_accountList +=fundlist[i].fund_account+",";
			}
		}else{
			fund_accountList =fundlist[0].fund_account+",";
		}
		fund_accountList=fund_accountList.substring(0,fund_accountList.length-1);
		var param={
				"cust_code" : cust_code,
				"cuacct_code" : fund_accountList,
				"ticket" : ticket
		};

		/*查询是否有交易账户*/
		service.otcAccoInfo(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var results = data.results;
			if(error_no == "0" && results.length != 0){
				var otcflag = results[0].otcflag;
				var cuacct_code = results[0].cuacct_code;
				$(_pageId+" #cuacct_code").html(cuacct_code);
				if(otcflag == "1"){
					otcFlag = true;
					otcProduct();
//					$(_pageId+" .info_table tr:eq(3) a").hide();
//					$(_pageId+" .info_table tr:eq(3) span").html("您已开通OTC账户");
					$(_pageId+" .more").hide(); //测试
					$(_pageId+" .info_box #otcAccount span").html("您已开通OTC账户"); //测试
				}else{
					otcFlag = false;
					var cust_type = appUtils.getSStorageInfo("cust_type");//0个人，1机构
					cust_type = result.cust_type;
//					if(cust_type == "1"){
//						custTypeFlag = true;
//						$(_pageId+" .info_table tr:eq(3) a").css({
//							"color":"gray",
//							"border":"1px solid gray"
//						});
//					}
//					$(_pageId+" .info_table tr:eq(3) a").show();
//					$(_pageId+" .info_table tr:eq(3) span").html("开通OTC账户");
					$(_pageId+" .more").show().text("开通OTC账户");; //测试
					$(_pageId+" .info_box #otcAccount span").html("您未开通OTC账户");  //测试
					if(cust_type == "1"){
						custTypeFlag = true;
						$(_pageId+" .more").css({
							"background":"gray",
						});
				    }
				}
			}else{
				layerUtils.iAlert(error_info);
			}
		});
	}
	
	/**
     * 300023：三方存管可用资金查询
     * 
     */
	function useableMoney(){
		var cust_code = result.user_code; //测试
		var mobilePhone = require("external").callMessage({"funcNo":"50043","key":"mobilePhone"}).results[0].value;
        var ticket = result.ticket; //测试
		var param ={
				"cust_code" : cust_code,
				"mobile" : mobilePhone,
				"ticket" : ticket
		};

		/*三方存管可用资金查询*/
		service.useableMoney(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var results = data.results;
			if(error_no == "0"){
				if(results.length != 0){
					var fund_avl = results[0].fund_avl;
					if(fund_avl == ""){
						fund_avl = "0.00";
					}
					$(_pageId+" #useableMoney").html(fund_avl);
				}else{
					$(_pageId+" #useableMoney").html("0.00");
				}
			}else{
				layerUtils.iAlert(error_info);
			}
		});
	}
	
	/*
	 * 查询OTC持仓
	 */
	function otcProduct(){
//		var cust_code=appUtils.getSStorageInfo("cust_code");
//		var ticket=appUtils.getSStorageInfo("ticket");
		var cust_code = result.user_code; //测试
		var ticket = result.ticket;  //测试
		var param =
		{
			"user_code" : cust_code,
			"page_recnum" :"",
			"page_reccnt" :"8",
			"ticket" :ticket
		};

		/*查询OTC持仓*/
		service.otcProduct(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var results = data.results;
			if(error_no == "0"){
				if(results.length != 0){
					var all_mkt_val = results[0].all_mkt_val;
					if(all_mkt_val == ""){
						all_mkt_val = 0;
					}
					$(_pageId+" #marketMoney").html(all_mkt_val);
					$(_pageId+" #totalMoney").html(all_mkt_val);
				}else{
					$(_pageId+" #marketMoney").html("0");
					$(_pageId+" #totalMoney").html("0");
				}
			}else{
				layerUtils.iAlert(error_info);
			}
		});
	}
	
	/*
	 * 显示登录后的用户信息
	 */
	function showUserinfo(){
		//个人信息部分************************************************/
		if(result.login_flag === "E"){//E账号登录
//			$(_pageId+" .info_table tr:eq(0) a").show();
//			$(_pageId+" .info_table tr:eq(0) th").html("登录名");
//			$(_pageId+" .info_table tr:eq(0) span").html(result.cust_dname);
//			$(_pageId+" .info_table tr:eq(2) span").html(result.user_code);
			$(_pageId+" .icon_option").show(); //测试
			$(_pageId+" .info_box #eAccount span").html(result.user_code); //测试
			$(_pageId+" .info_box #loginName span").html(result.cust_dname); //测试
			$(_pageId+" .more").attr("data-type","1");
			$(_pageId+" .info_box #loginName").show();
			$(_pageId+" .info_box #otcAccount").show();
		}else{//资金账号登录
//			$(_pageId+" .info_table tr:eq(0) a").hide();
//			$(_pageId+" .info_table tr:eq(0) th").html("资金账号");
//			$(_pageId+" .info_table tr:eq(0) span").html(result.fund_account);
//			if(cust_act_flag === "1"){
//				$(_pageId+" .info_table tr:eq(2) span").html(result.user_code);
//			}
			$(_pageId+" .more").attr("data-type","0");
			$(_pageId+" .icon_option").hide(); //测试
			if(cust_act_flag === "1"){  //测试
				$(_pageId+" .info_box #eAccount span").html(result.user_code);
		    }else{
		    	$(_pageId+" .info_box #eAccount span").html("您未激活E账通");
		    }
			$(_pageId+" .info_box #loginName").hide();
		}
//		$(_pageId+" .info_table tr:eq(1) td").html(result.user_name);
//		$(_pageId+" .info_table tr:eq(4) td").html(result.vip_credit);
//		$(_pageId+" .info_table tr:eq(5) td").html(result.last_login_time);
//		if(cust_act_flag === "1"){
//			$(_pageId+" .info_table tr:eq(2) a").hide();
//		}else{
//			$(_pageId+" .info_table tr:eq(2) a").show();
//		}
		$(_pageId+" .info_box #lastLogin span").html(result.last_login_time); //测试
		$(_pageId+" .info_box .point span").html(result.vip_credit); //测试
//		var fundAccount = appUtils.setSStorageInfo("fund_account");
//		if(!fundAccount){
//			fundAccount = result.fund_account;
//		}
		$(_pageId+" .info_box #mainAccount span").html(result.fund_account); //测试
		if(cust_act_flag === "1"){
			$(_pageId+" .more").hide();
	    }else{
	    	$(_pageId+" .more").show().text("E账通激活");
	    } 
		//交易部分************************************************/
		if(result.login_flag === "E"){
//			$(_pageId+" .level span:eq(1)").html(result.risk_level_txt);
			var fundList = result.fundlist;
			if(fundList.length>0){
				var fundListStr = fundList.replace(/(\[)|(\])/g,"");
				arr = fundListStr.split("},");
				for(var i=0;i<arr.length;i++){
					if(i === arr.length-1){
						arr[i] = arr[i];
					}else{
						arr[i] = arr[i] +"}";
					}
				}
				//对用户的资金账号集合进行遍历
				traverseArr("1");
			}
		}else{
			//显示股票的信息
			showStockInfo("0");
		}
		//业务部分************************************************/


	}

	/*
	 * 对用户的资金账号集合进行遍历
	 */
	function traverseArr(mark){
		if((arr)&&(arr.length>0)){
			var minArr = new Array();
			var minMark = 0;
			for(var i=0;i<arr.length;i++){
				if(JSON.parse(arr[i]).ext_syscode === mark){
					minArr[minMark] = arr[i];
					minMark++;
				}
			}
			stockCodeList = minArr;//股票账号集合
			stockSize = minMark;//股票账号的大小
			nowNumberStock = 1;//当前股票账号默认为第一个
			nowTradeCode = minArr[0];//当前账号默认
			if(minArr.length>1){
				$(_pageId+" #stockCon .next").addClass("active");
			}else{
				$(_pageId+" #stockCon .pre").removeClass("active");
				$(_pageId+" #stockCon .next").removeClass("active");
			}
			//获得 当前 资金账号
			getNowE_Fund(mark);
			switch (mark){
				case "1":
					//显示股票信息
					showStockInfo("1");
					break;
				case "2":
					if(nowTradeCode){
						$(_pageId+" #marginCon").show().siblings().hide();
					}
					//获取融资融券信息
					showMarginInfo();
					break;
				case "3":
					$(_pageId+" #OTCCon").show().siblings().hide();
					break;
				case "4":
					$(_pageId+" #optionCon").show().siblings().hide();
					break;
				default:
					$(_pageId+" #stockCon").show().siblings().hide();
					break;
			}
		}
	}

	/*
	 * 资金账号登录   0/E账号登录    1 
	 * 显示股票的信息
	 */
	function showStockInfo(loginMark){
		//设置strong标签的width
		$(_pageId+" #stockCon").show().siblings().hide();
		var divWidth = $(_pageId+" .user_num").width();
		var fundStr = "";
		if(loginMark === "0"){
			//fundStr = "<strong style=\"width: "+divWidth+"px;display: inline-block;\">账号  "+result.fund_account+"</strong>";
			fundStr = "<strong style=\"width: "+divWidth+"px;display: inline-block;\">账号  "+result.fund_account+"("+result.user_name+")</strong>"; //测试
			queryUserrRiskEval(result.fund_account,"1");
			//$(_pageId+" .level span:eq(1)").html(result.risk_level_txt);
			// 查询用户资产
			nowTradeCode = JSON.stringify({"fund_account":result.fund_account});
			queryAsset(result.fund_account);
		}else{
			if(stockCodeList.length>0){
				for(var j=0;j<stockCodeList.length;j++){
					//fundStr += "<strong style=\"width: "+divWidth+"px;display: inline-block;\">账号"+JSON.parse(stockCodeList[j]).fund_account+"</strong>";
				     fundStr += "<strong style=\"width: "+divWidth+"px;display: inline-block;\">账号"+JSON.parse(stockCodeList[j]).fund_account+"("+result.user_name+")</strong>"; //测试
				}
			}
		}
		$(_pageId+" #fundList").html(fundStr);
	}

	/*
	 * 显示融资融券信息
	 */
	function showMarginInfo(){
//		if(!nowTradeCode){
//			layerUtils.iMsg(-1,"您暂时没有融资融券账号！");
//			return false;
//		}
		var tradeCode = JSON.parse(nowTradeCode);
		var param = {
			"branchno":"",
			"currency":"1",
			"account":tradeCode.fund_account
		};
		service.queryMarginInfo(param,function(data){
			var errorNo = data.error_no;
			var errorInfo = data.error_info;
			if(errorNo === "0"){
				var result = data.results;
				var item = result[0];
				var $marginCon = $(_pageId+" #marginCon");
				//显示饼图
				pieChart([+((+item.available_funds).toFixed(2)),+((+item.market_value).toFixed(2))]);

				//显示条行比例
				barProportion([+((+item.available_funds).toFixed(2)),+((+item.market_value).toFixed(2))]);

				$marginCon.find(".chart_box strong").html((+item.total_property).toFixed(2));
				$marginCon.find(".rz_info div:eq(0) p:eq(0) span").html((+item.available_funds).toFixed(2));
				$marginCon.find(".rz_info div:eq(0) p:eq(1) span").html((+item.total_debt).toFixed(2));
				$marginCon.find(".rz_info div:eq(0) p:eq(2) span").html((+item.funds_debt).toFixed(2));
				$marginCon.find(".rz_info div:eq(0) p:eq(3) span").html((+item.available_security_deposit).toFixed(2));
				$marginCon.find(".rz_info div:eq(0) p:eq(4) span").html((+item.available_financing).toFixed(2));

				$marginCon.find(".rz_info div:eq(1) p:eq(0) span").html((+item.market_value).toFixed(2));
				$marginCon.find(".rz_info div:eq(1) p:eq(1) span").html((+item.assure_rate).toFixed(2));
				$marginCon.find(".rz_info div:eq(1) p:eq(2) span").html((+item.stock_debt).toFixed(2));
				$marginCon.find(".rz_info div:eq(1) p:eq(3) span").html((+item.credit_amount).toFixed(2));
				$marginCon.find(".rz_info div:eq(1) p:eq(4) span").html((+item.available_secu_amount).toFixed(2));
			}else{
				layerUtils.iAlert(errorInfo);
			}
		});
	}

	/* 获取用户信息 */
//	function getUserInfo()
//	{
//		var user_id = appUtils.getSStorageInfo("user_id");
//		var param = {"user_id" : user_id};
//		service.queryUserInfo(param,function(data){
//			var error_no = data.error_no;
//			var error_info = data.error_info;
//			var results = data.results[0];
//			if(error_no == 0){
//				var user_name = results.user_name; // 用户名
//				var vip_level = results.vip_level?results.vip_level:"1"; // 会员等级
//				var fund_account = results.fund_account; // 富尊号
//				var vip_credit = results.vip_credit; // 会员积分
//				var risk_level_txt = results.risk_level_txt; // 风险测评等级
//				var last_login_time = results.last_login_time; // 上次登录时间
//				$(_pageId+".user_name").html(user_name);
//				$(_pageId+".vip_level").html(vip_level);
//				$(_pageId+".fund_account").html(fund_account);
//				$(_pageId+".vip_credit").html(vip_credit);
//				$(_pageId+".risk_level_txt").html(risk_level_txt);
//				$(_pageId+".last_login_time").html(last_login_time);
//			}
//			else{
//				layerUtils.iLoading(false);
//				layerUtils.iAlert(error_info);
//			}
//		},false);
//	}

	/*
	 * 获得 当前 资金账号
	 * 获得E账号的 当前下的资金账号信息
	 */
	function getNowE_Fund(mark){
		if(!nowTradeCode){
			return false;
		}
		var fund = JSON.parse(nowTradeCode);
		if(mark === "1"){
			//查询用户资产
			queryAsset(fund.fund_account);
		}
		//查询用户的风险测评
		if(mark=="1" || mark=="2"){
			queryUserrRiskEval(fund.fund_account,mark);
		}
	}

	/*
	 *  查询用户资产 
	 */
	function queryAsset(fund_account){
		var param = {
			"fund_account" : fund_account
		};
		service.queryAsset(param, function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			if(error_no === "0"){
				var result = data.results;
				if(result && result.length > 0){
					for(var i=0;i<result.length;i++){
						var item = result[i];
						var money_type = item.money_type;
						switch (money_type){
							case "0"://RMB
								$(_pageId+" .rmb strong:eq(0)").html((+item.total_money).toFixed(2));
								$(_pageId+" .rmb strong:eq(1)").html((+item.useable_money).toFixed(2));
								break;
							case "1"://$
								$(_pageId+" .us strong:eq(0)").html((+item.total_money).toFixed(2));
								$(_pageId+" .us strong:eq(1)").html((+item.useable_money).toFixed(2));
								break;
							case "2"://HK
								$(_pageId+" .hk strong:eq(0)").html((+item.total_money).toFixed(2));
								$(_pageId+" .hk strong:eq(1)").html((+item.useable_money).toFixed(2));
								break;
							default:
								$(_pageId+" .rmb strong:eq(0)").html((+item.total_money).toFixed(2));
								$(_pageId+" .rmb strong:eq(1)").html((+item.useable_money).toFixed(2));
								break;
						}
					}
				}
			}else{
				layerUtils.iAlert(error_info);
			}
		});
	}


	/*
	 * 查询用户的风险测评
	 * 获取对应资金账号的风险测评
	 */
	function queryUserrRiskEval(fund_account,mark){
		var ip = appUtils.getSStorageInfo("ip");
		var mac = appUtils.getSStorageInfo("mac");
		var param = {
			"branchno":"",
			"account":fund_account,
			"messageType":mark,
			"ip":ip,
			"mac":mac
		};
		service.getUserinfoByFund(param,function(data){
			var errorNo = data.error_no;
			var errorInfo = data.error_info;
			if(errorNo === "0"){
				var result = data.results;
				if(result && result.length>0){
					var item = result[0];
					$(_pageId+" .level span:eq(1)").html(item.risk_level_txt);
					//保存用户信息到session
					keepUserinfoToSession(item);
				}
			}else{
				layerUtils.iAlert(errorInfo);
			}
		});
	}

	/*
	 * 保存用户信息到session
	 */
	function keepUserinfoToSession(item){
		appUtils.setSStorageInfo("user_id",item.user_id);
		appUtils.setSStorageInfo("fund_account",item.fund_account);
		appUtils.setSStorageInfo("client_no",item.client_no);
		if(item.branch_no){
			appUtils.setSStorageInfo("branch_no",item.branch_no);	
		}
		
	}
	/* 查询负债 */
//	function queryMyLoadMoney(fund_account,total_money){
//		var param = {"fund_account" : fund_account, "page":1, "size":1};
//		service.queryLoanInfo(param, function(data){
//			var error_no = data.error_no;
//			var error_info = data.error_info;
//			if(error_no == 0){
//				var results = data.results[0].data;
//				var shouldRepay = "0.00";  // 负债
//				if(results != ""){
//					shouldRepay = results[0].shouldRepay;
//					shouldRepay = Number(shouldRepay).toFixed(2);
//				}
//				var fzl = shouldRepay/total_money || 0;  //负债率
//				if(fzl != "0"){
//					fzl = (fzl*100).toFixed(2)+"%";
//				}
//				else{
//					fzl = "0.00%";
//				}
//				$(_pageId+".info_part:eq(1) table:eq(0) .fz").html(shouldRepay);
//				$(_pageId+".info_part:eq(1) table:eq(0) .fzl").html(fzl);
//				queryGgt(fund_account); // 查询港股通开通状态
//			}
//			else{
//				layerUtils.iLoading(false);
//				layerUtils.iAlert(error_info);
//			}
//		},false);
//	}

	/* 查询港股通开通状态 */
	function queryGgt(fund_account){
		service.queryGgt({"fund_account":fund_account},function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			if(error_no == 0){
				var openGGT_flag = data.results[0].openGGT_flag;
				if(openGGT_flag == "1"){
					$(_pageId+" .ggt_state").html("已开通");
				}
				else{
					$(_pageId+" .no_open").show();
				}
			}else{
				layerUtils.iAlert(error_info);
			}
		});
	}

	/*
	 * 显示饼图
	 * 总收益的饼图 pieChart
	 */
	function pieChart(data){
		var htmlStr = "<div id=\"circle\" style=\"background: #99C942;width: 100px;height: 100px;border-radius: 50%;\">" +
			"<div id=\"pie_right\" style=\"width: 100px;height: 100px;position: absolute;border-radius: 50%;clip: rect(0, auto, auto, 50px);\">" +
			"<div id=\"right\" style=\"position: absolute;width: 100px;height: 100px;background: #668BD1;border-radius: 50%;clip: rect(0, auto, auto, 50px);\"></div></div>" +
			"<div id=\"pie_left\" style=\"width: 100px;height: 100px;position: absolute;border-radius: 50%;clip: rect(0, 50px, auto, auto);\">" +
			"<div id=\"left\" style=\"width: 100px;height: 100px;position: absolute;background: #668BD1;border-radius: 50%;clip: rect(0, 50px, auto, auto);\"></div></div>";
		$(_pageId+" .chart_box dt").html(htmlStr);
		$(_pageId+" #circle").css("marginLeft",$(_pageId+" .chart_box dt").width() - 100+"px");
		var sum = data[0]+data[1];
		var usable = data[0]/sum*100;
		var deg = usable * 3.6;
		if(deg > 180){
			$(_pageId+" #right").css('transform', "rotate(180deg)");
			$(_pageId+" #left").css('transform', "rotate(" + (deg - 180) + "deg)");
		}else{
			$(_pageId+" #right").css('transform', "rotate(" + deg + "deg)");
		}
	}

	/*
	 * 显示条行比例
	 * 显示可用、股票的条形比例
	 */
	function barProportion(data){
		var sum = data[0]+data[1];
		var usablePro = (data[0]/sum*100).toFixed(2);
		var stockPro = (data[1]/sum*100).toFixed(2);
		var usableProPer = usablePro + "%";
		var stockProPer = stockPro + "%";
		if(+usablePro >= 50){
			$(_pageId+" .rz_info .part:eq(0) .stat").html("<em style=\"width: "+usableProPer+"; color:#333333; text-align:right;\">"+usableProPer+"</em>");
			$(_pageId+" .rz_info .part:eq(1) .stat").html("<em style=\"width: "+stockProPer+"\"></em>"+stockProPer+"");
		}else{
			$(_pageId+" .rz_info .part:eq(0) .stat").html("<em style=\"width: "+usableProPer+"\"></em>"+usableProPer+"");
			$(_pageId+" .rz_info .part:eq(1) .stat").html("<em style=\"width: "+stockProPer+"; color:#333333; text-align:right;\">"+stockProPer+"</em>");
		}
	}

	/**
	 * 流程检测 --- 现金宝
	 */
	function stepCheck(){
		//记录进入现金宝的信息
		var par = {
			"fund_account":appUtils.getSStorageInfo("fund_account"),
			"branch_no":appUtils.getSStorageInfo("branch_no"),
			"entrust_way":"SJWT",
			"mac":appUtils.getSStorageInfo("mac"),
			"ip":appUtils.getSStorageInfo("ip"),
		};
		service.recordInfo(par,function(data){
			if(data.error_no == 0){
				//用E帐通登录时没有营业部编号
				if(appUtils.getSStorageInfo("branch_no")==null || appUtils.getSStorageInfo("branch_no") ==undefined){
					appUtils.setSStorageInfo("branch_no",data.results[0].branch_no);
				}
				//查询用户进入到了哪一步
				var user=appUtils.getSStorageInfo("userinfo");
				var userinfo=JSON.parse(user);
				var s="1002";
				if(userinfo.user_type=="0"){
					s="1001";
				}
				var param = {
					"fund_account":appUtils.getSStorageInfo("fund_account"),
					"sign":4,
					"ezt_name":userinfo.user_code,
					"ticket":"",
					"survey_sn":s
				};
				service.isCompleteStep(param,function(data){
					if(data.error_no == 0){
						var result = data.results[0];
						appUtils.setSStorageInfo("xjb_fromPage","userCenter");
						if(result.sfkh == "1" && result.sfqsdzht == "1"){//已经开户  合同已签署
							appUtils.pageInit("account/userCenter","xjb/navigation/index",{});
						}else{ //不满足进入现金宝业务
							appUtils.pageInit("account/userCenter","xjb/account/index",{});//走开户
						}
					}else{
						layerUtils.iLoading(false);
						layerUtils.iAlert(data.error_info);
					}
				});
			}else{
				layerUtils.iLoading(false);
				layerUtils.iAlert(data.error_info);
			}
		});
	}
    
	var userCenter = {
		"init" : init,
		"bindPageEvent" : bindPageEvent,
		"destroy" : destroy
	};
	module.exports = userCenter;
});

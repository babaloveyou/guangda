/**
 * 程序入口配置读取
 * 项目开发时需要的自定义配置
 * 另外：configuration为系统配置模块或者配置模板
 * 这里可以扩展，支持多个系统共用一个项目：
 * 思路：在最开始的地方做一个sysCode的获取，然后在这个模块初始化时赋不同系统的configuration配置模块的引用，
 * 当然还要做修改的地方，比如地址栏hash处理，需要增加sysCode（涉及到的模块main和appUtils）
 */
define(function(require, exports, module) {
	var configuration = {
	//		"platform": "2",
			"defaultPage": {"pageCode": "account/mainPage", "jsonParam":{}},
			"seaBaseUrl": "/m/",
			"projName": "mall",
//			"firstLoadCss": ["/css/app_style.css","/css/style.css"],
			"firstLoadCss": ["/css/app_style.css","/css/style.css","/css/common.css","/css/ui-font.css"],
//			"firstLoadCss": ["/css/style.css"],
//			"firstLoadCss": ["/css/common.css"],
//			"firstLoadCss": ["/css/ui-font.css"],
			"layerTheme": "d",
			"resultsParser": {"error_no": "error_no", "error_info": "error_info"},
			"filters": {
//				"-999": {"pageCode": "account/userLogin", "jsonParam": {}, "error_info":"请先登录"}, //用户没有登陆
				"-999": {"moduleAlias":"common", "moduleFuncName":"filterLoginOut"} //用户没有登陆或者登陆超时
			},
//			"loginPage": {"pageCode": "account/userLogin", "jsonParam":{}},
			// 引导页配置
			"guidePage": {"pageCode": "", "jsonParam":{}},
			// 项目别名配置
			"pAlias": {
				"putils": "mall/scripts/common/putils",
				"mobileService": "mall/service/mobileService_sc",
				"constants": "mall/scripts/constants/serviceConstants",
				"keyPanel": "mall/scripts/keypanel_xf/scripts/keyTelPanel",
				"shellMallService": "mall/shellFunction/mallService", // 调用壳子的 service 文件
				"nativePluginService": "mall/shellFunction/nativePluginService", // 调用壳子的 service 文件
				"globalFunc": "common/globalFunc",
				"common": "common/common"
			},
			"checkPermission": {"moduleAlias":"common", "moduleFuncName":"checkPermission_mall"},
			"firstLoadIntf": {"moduleAlias":"common", "moduleFuncName":"firstLoadFunc"},
			"global": {
				"hardId" : "",
				"phone" : "",
//				"checkLoginPageCode": ["account/userCenter","account/bankTransfer","account/changeResults","account/infoModify","account/myOrder","account/myProduct","account/riskAssessment","account/totalAssets","mall/finanOrder/confirmOrder","mall/finanOrder/orderPay","mall/finanOrder/payment","mall/fundOrder/confirmOrder","mall/fundOrder/orderPay","mall/fundOrder/payment","mall/infoOrder/confirmOrder","mall/infoOrder/orderPay","mall/infoOrder/payment","otc/riskDisclosure"],
				"checkLoginPageCode": ["account/userCenter","account/bankTransfer","account/changeResults","account/infoModify","account/myOrder","account/myProduct","account/riskAssessment","account/totalAssets","mall/finanOrder/confirmOrder","mall/finanOrder/orderPay","mall/finanOrder/payment","mall/fundOrder/confirmOrder","mall/fundOrder/orderPay","mall/fundOrder/payment","mall/infoOrder/confirmOrder","mall/infoOrder/orderPay","mall/infoOrder/payment","otc/riskDisclosure","mall/otcOrder/confirmOrder","mall/itemsOTCInfo"],
				"aesKey": "thinkive", //加密key，位数必须为4的倍数
				"protocol":"ajax", //协议
				"appro_cust":"S0010025",//客户基本信息查询
				"appro_risk":"S0014027",//适当性风测类别
				"appro_ques":"S0012065",//适当性问卷调查类别
				"contract_mark":"S0012066",//适当性产品需签署协议标志
				"organization_mark":"S0012071",//登记机构交易状态不正常或未开户标志
				"contract_mark_xjb":"S0014056",//现金宝功能号
				"appro_append":"S0010023",//适当性附加题类别
				"quesScore":"合格",//适当性问卷调查合格分数
				"append_single":"10011",//适当性附加题个人调查表编码
				"append_org":"10021",//适当性附加题机构调查表编码
				"other_level":"4",//适当性除风测201和205类型的产品问卷之外的问卷类型返回值大于某个等级的配置项
				
				// 仿真外网测试地址
//		         "url" : "http://116.236.247.175:84",
//		         "validateimg" : "http://116.236.247.175:83/servlet/Image", // 验证码地址
//				 "serverPath" : "http://116.236.247.175:83/servlet/json", // 商城接入层
//		         "serverPath_open" : "http://116.236.247.175:81/servlet/json", // 激活（开户）接入地址
//		         "serverPath_fz" : "http://116.236.247.175:84/servlet/json", // 富尊网接入地址
//		         "serverPath_xdt" : "http://116.236.247.175:82/erz/servlet/json", // 小贷接入地址
//				 "loginPath" : "http://116.236.247.175:83/servlet/TokenAction?function=tokenAuth", // 统一登陆
//				 "switchPath" : "http://116.236.247.175:83/servlet/TokenAction?function=ChangeAccount" // 切换登陆

//				 // 仿真内网测试环境（原始）
//				 "url":"http://10.0.29.154:83",
//		         "validateimg" : "http://10.0.29.154:83/servlet/Image",
//				 "serverPath":"http://10.0.29.154:83/servlet/json",  // 商城
//				 "serverPath_open" : "http://10.0.29.154:81/servlet/json", // 激活接入地址
//				 "serverPath_fz" : "http://10.0.29.154:84/servlet/json", // 富尊接入地址
//			     "serverPath_xdt" : "http://10.0.29.154:82/erz/servlet/json", // 小贷接入地址
//				 "loginPath" : "http://10.0.29.154:83/servlet/TokenAction?function=tokenAuth", // 统一登陆
//				 "switchPath" : "http://10.0.29.154:83/servlet/TokenAction?function=ChangeAccount" // 切换登陆	
				
				// 全真环境
//				 "url":"http://10.0.74.49:84",
//		         "validateimg" : "http://10.0.74.49:83/servlet/Image",
//				 "serverPath":"http://10.0.74.49:83/servlet/json",  // 商城
//				 "serverPath_open" : "http://10.0.74.49:81/servlet/json", // 激活接入地址
//				 "serverPath_fz" : "http://10.0.74.49:83/servlet/json", // 富尊接入地址
//			     "serverPath_xdt" : "http://10.0.74.49:82/rz/servlet/json", // 小贷接入地址
//				 "loginPath" : "http://10.0.74.49:83/servlet/TokenAction?function=tokenAuth", // 统一登陆
//				 "switchPath" : "http://10.0.74.49:83/servlet/TokenAction?function=ChangeAccount" // 切换登陆
				// 仿真内网测试环境
//				 "url":"http://10.84.134.24:83",
//		         "validateimg" : "http://10.84.134.24:83/servlet/Image",
//				 "serverPath":"http://10.84.134.24:83/servlet/json",  // 商城
//				 "serverPath_open" : "http://10.84.134.24:81/servlet/json", // 激活接入地址
//				 "serverPath_fz" : "http://10.84.134.24:84/servlet/json", // 富尊接入地址
//			     "serverPath_xdt" : "http://10.84.134.24:82/erz/servlet/json", // 小贷接入地址
//				 "loginPath" : "http://10.84.134.24:83/servlet/TokenAction?function=tokenAuth", // 统一登陆
//				 "switchPath" : "http://10.84.134.24:83/servlet/TokenAction?function=ChangeAccount" // 切换登陆

					 
					 
				// 内网测试地址
//		         "url" : "http://10.0.39.116:8081",
//		         "validateimg" : "http://10.0.39.116:8081/servlet/Image", // 验证码地址
//				 "serverPath" : "http://10.0.39.116:8081/servlet/json", // 商城接入层
//		         "serverPath_open" : "http://10.0.39.112:8080/servlet/json", // 激活（开户）接入地址
//		         "serverPath_fz" : "http://10.0.39.118:8080/servlet/json", // 富尊网接入地址
//		         "serverPath_xdt" : "http://10.0.39.115:8081/erz/servlet/json", // 小贷接入地址
//				 "loginPath" : "http://10.0.39.116:8081/servlet/TokenAction?function=tokenAuth", // 统一登陆
//				 "switchPath" : "http://10.0.39.116:8081/servlet/TokenAction?function=ChangeAccount" // 切换登陆	 

				 // 生产环境
				 "url":"https://e.ebscn.com",
		         "validateimg" : "https://sc.ebscn.com/servlet/Image",
				 "serverPath":"https://sc.ebscn.com/servlet/json",  // 商城
				 "serverPath_open" : "https://ekh.ebscn.com/servlet/json", // 激活接入地址
				 "serverPath_fz" : "https://e.ebscn.com/servlet/json", // 富尊接入地址
			     "serverPath_xdt" : "https://e.ebscn.com/rz/servlet/json", // 小贷接入地址
				 "loginPath" : "https://sc.ebscn.com/servlet/TokenAction?function=tokenAuth", // 统一登陆
				 "switchPath" : "https://sc.ebscn.com/servlet/TokenAction?function=ChangeAccount" // 切换登陆
			},
			"isDirectExit": false,
			"ajaxTimeout": 30
//			"isClickShadeHide": false
		};
		//暴露对外的接口
		module.exports = window.configuration = configuration;
});
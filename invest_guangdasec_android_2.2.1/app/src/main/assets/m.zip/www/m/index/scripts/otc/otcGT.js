/**
 * 风险测评结果
 */
define(function(require, exports, module) 
	{
	var appUtils = require("appUtils");
	var gconfig = require("gconfig");
	var service = require("serviceImp");//业务层接口，请求数据
	var global = gconfig.global;
	var layerUtils = require("layerUtils");
	var putils = require("putils");
	var constants=require("constants");//常量类
	var keyPanel = require("keyPanel");//软键盘
	var _pageId ="#otc_otcGT ";
	var timeNum = 0;

	/*初始化*/
	function init()
	{
		otcProduct();
	}

	/*
	 * 查询OTC持仓
	 */
	function otcProduct(){
		var cust_code=appUtils.getSStorageInfo("cust_code");
		var ticket=appUtils.getSStorageInfo("ticket");
		var param =
		{
			"user_code" : cust_code,
			"page_recnum" :"",
			"page_reccnt" :"8",
			"ticket" :ticket
		};

		/*查询OTC持仓*/
		service.otcProduct(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			var results = data.results;
			if(error_no == "0"){
				if(results.length != 0){
					var OTCStr = "";
					for(var i = 0; i < results.length; i++){
						var inst_code = results[i].inst_code;//产品代码
						var inst_sname = results[i].inst_sname;//产品名称
						var mkt_val = results[i].mkt_val;//最新市值
						var net_val = results[i].net_val;//最新净值
						var inst_avl = results[i].inst_avl;//可用份额
						var inst_bln = results[i].inst_bln;//当前份额
						var current_cost = results[i].current_cost;//买入成本
						var redeemflag = results[i].redeemflag;//赎回标识 1行,0不行
						var redflag = results[i].redflag;//分红设置标识
						OTCStr +="<div class='bar_inner'><ul>" ;
						OTCStr +="<li><span>产品代码：</span><em>"+inst_code+"</em></li>";
						OTCStr +="<li><span>产品名称：</span><em>"+inst_sname+"</em></li><li><span>当前份额：</span><em>"+inst_bln+"</em></li>";
						OTCStr +="<li><span>可用份额：</span><em>"+inst_avl+"</em></li><li><span>最新市值：</span><em>"+mkt_val+"</em></li>";
						OTCStr +="<li><span>最新净值：</span><em>"+net_val+"</em></li><li><span>成本价：</span><em>"+current_cost+"</em></li>";
						if(redeemflag == "0" && redflag == "0"){
							OTCStr +="<li class='operate_box'><span>操作：</span><em><a href='javascript:void(0);' class=\"dividendsWay\" style=\"background:gray\" data-redflag=\""+results[i].redflag+"\" data-inst_id=\""+results[i].inst_id+"\" data-inst_code=\""+results[i].inst_code+"\" data-ta_code=\""+results[i].ta_code+"\" data-ta_acct=\""+results[i].ta_acct+"\" data-trans_acct=\""+results[i].trans_acct+"\"   data-name=\""+results[i].inst_sname+"\" data-fund_account=\""+results[i].cuacct_code+"\">分红设置</a><a href='javascript:void(0);' style=\"background:gray\" class=\"redemption\" data-redeemflag=\""+results[i].redeemflag+"\" data-fund_account=\""+results[i].cuacct_code+"\" data-inst_id=\""+results[i].inst_id+"\" data-inst_code=\""+results[i].inst_code+"\"  data-name=\""+results[i].inst_sname+"\" data-redeem_amount=\""+results[i].inst_avl+"\" data-ta_code=\""+results[i].ta_code+"\" data-ta_acct=\""+results[i].ta_acct+"\" data-trans_acct=\""+results[i].trans_acct+"\" data-iss_code=\""+results[i].iss_code+"\">赎回</a></em></li>" ;
						}else if(redeemflag == "0" && redflag == "1"){
							OTCStr +="<li class='operate_box'><span>操作：</span><em><a href='javascript:void(0);' class=\"dividendsWay\" data-redflag=\""+results[i].redflag+"\" data-inst_id=\""+results[i].inst_id+"\" data-inst_code=\""+results[i].inst_code+"\" data-ta_code=\""+results[i].ta_code+"\" data-ta_acct=\""+results[i].ta_acct+"\" data-trans_acct=\""+results[i].trans_acct+"\"   data-name=\""+results[i].inst_sname+"\" data-fund_account=\""+results[i].cuacct_code+"\">分红设置</a><a href='javascript:void(0);' style=\"background:gray\" class=\"redemption\" data-redeemflag=\""+results[i].redeemflag+"\" data-fund_account=\""+results[i].cuacct_code+"\" data-inst_id=\""+results[i].inst_id+"\" data-inst_code=\""+results[i].inst_code+"\"  data-name=\""+results[i].inst_sname+"\" data-redeem_amount=\""+results[i].inst_avl+"\" data-ta_code=\""+results[i].ta_code+"\" data-ta_acct=\""+results[i].ta_acct+"\" data-trans_acct=\""+results[i].trans_acct+"\" data-iss_code=\""+results[i].iss_code+"\">赎回</a></em></li>" ;
						}else if(redeemflag == "1" && redflag == "0"){
							OTCStr +="<li class='operate_box'><span>操作：</span><em><a href='javascript:void(0);' class=\"dividendsWay\" style=\"background:gray\" data-redflag=\""+results[i].redflag+"\" data-inst_id=\""+results[i].inst_id+"\" data-inst_code=\""+results[i].inst_code+"\" data-ta_code=\""+results[i].ta_code+"\" data-ta_acct=\""+results[i].ta_acct+"\" data-trans_acct=\""+results[i].trans_acct+"\"   data-name=\""+results[i].inst_sname+"\" data-fund_account=\""+results[i].cuacct_code+"\">分红设置</a><a href='javascript:void(0);' class=\"redemption\" data-redeemflag=\""+results[i].redeemflag+"\" data-fund_account=\""+results[i].cuacct_code+"\" data-inst_id=\""+results[i].inst_id+"\" data-inst_code=\""+results[i].inst_code+"\"  data-name=\""+results[i].inst_sname+"\" data-redeem_amount=\""+results[i].inst_avl+"\" data-ta_code=\""+results[i].ta_code+"\" data-ta_acct=\""+results[i].ta_acct+"\" data-trans_acct=\""+results[i].trans_acct+"\" data-iss_code=\""+results[i].iss_code+"\">赎回</a></em></li>" ;
						}else{
							OTCStr +="<li class='operate_box'><span>操作：</span><em><a href='javascript:void(0);' class=\"dividendsWay\" data-redflag=\""+results[i].redflag+"\" data-inst_id=\""+results[i].inst_id+"\" data-inst_code=\""+results[i].inst_code+"\" data-ta_code=\""+results[i].ta_code+"\" data-ta_acct=\""+results[i].ta_acct+"\" data-trans_acct=\""+results[i].trans_acct+"\"   data-name=\""+results[i].inst_sname+"\" data-fund_account=\""+results[i].cuacct_code+"\">分红设置</a><a href='javascript:void(0);'  class=\"redemption\" data-redeemflag=\""+results[i].redeemflag+"\" data-fund_account=\""+results[i].cuacct_code+"\" data-inst_id=\""+results[i].inst_id+"\" data-inst_code=\""+results[i].inst_code+"\"  data-name=\""+results[i].inst_sname+"\" data-redeem_amount=\""+results[i].inst_avl+"\" data-ta_code=\""+results[i].ta_code+"\" data-ta_acct=\""+results[i].ta_acct+"\" data-trans_acct=\""+results[i].trans_acct+"\" data-iss_code=\""+results[i].iss_code+"\">赎回</a></em></li>" ;
						}
						OTCStr +="</ul></div>";
								
					    $(_pageId+" .bar_detail").html(OTCStr);
					    
					    /* 绑定赎回事件 */
						appUtils.bindEvent($(_pageId+" .redemption"),function(){
							var name=$(this).attr("data-name");
							var inst_code=$(this).attr("data-inst_code");
							var redeem_amount=$(this).attr("data-redeem_amount");
							var inst_id = $(this).attr("data-inst_id");
							var cuacct_code = $(this).attr("data-fund_account");
							var iss_code = $(this).attr("data-iss_code");
							var trans_acct = $(this).attr("data-trans_acct");
							var ta_code = $(this).attr("data-ta_code");
							var ta_acct = $(this).attr("data-ta_acct");
							var redeemflag = $(this).attr("data-redeemflag");
							if(redeemflag =="0"){
								return false;
							}
							var param=
							{
								"date":""
							};
							service.dealTimeSyn(param,function(data){
								if(data.error_no!="0")
								{
									layerUtils.iAlert(data.error_info);
									layerUtils.iLoading(false);
									return false;
								} 
								else if(data.results[0].is_trade=='0')
								{
									layerUtils.iAlert("当前是非交易时间，otc产品暂停交易。");
									return false;
								}
								else{
									layerUtils.layerCustom('<div class="popbox pop_rebuy" id="iLayer_myProd">	<div class="ptitle"><h2>赎回我的理财</h2></div>	<div class="pmain"><p class="input_text0"></p><p class="input_text0"></p><p class="input_text0"></p><p class="input_text0">	<label>赎回份额</label><input type="number" class="t1 order_quantity" placeholder="赎回份额"/></p><div class="input_text0">	<label>交易密码</label><div id="password"  class="t1 trade_pwd  input_custom" style="color:#A9A9A9;"><em>交易密码</em></div><input style="display:none" type="password"  class="t1"  id="trade_pwd" ></div><p class="input_text0">	<a href="javascript:void(0);" class="btn"  id="iLayer_redeemBtn">赎回</a><a href="javascript:void(0);" class="btn2" id="iLayer_closeBtn">关闭</a></p></div></div>');
									var allRecommendStr0 =  "";
									var allRecommendStr1=  "";
									var allRecommendStr2 =  "";
									allRecommendStr0 += "<label>产品代码:</label>"+inst_code;
									allRecommendStr1 += "<label>产品名称:</label>"+name;
									allRecommendStr2 += "<label>可用份额:</label>"+parseFloat(redeem_amount).toFixed(2);
									$(" .pop_rebuy .input_text0:eq(0)").append(allRecommendStr0);
									$(" .pop_rebuy .input_text0:eq(1)").append(allRecommendStr1);
									$(" .pop_rebuy .input_text0:eq(2)").append(allRecommendStr2);
									appUtils.bindEvent($x("iLayer_myProd", "iLayer_redeemBtn"), function() {
										otcRedemption(inst_code, inst_id, cuacct_code, iss_code, trans_acct, ta_code, ta_acct ,redeem_amount); 
									});
									appUtils.bindEvent($x("iLayer_myProd", "iLayer_closeBtn"), function() {
										layerUtils.iCustomClose(); 
										keyPanel.closeKeyPanel();
									});
									//验证输入数字金额合法性
									appUtils.bindEvent($(" .order_quantity"),function(e){
										$(" .input_custom").removeClass(" active");
										var order_quantity =$(" .order_quantity").val();
										if(!/^(\d+|[1-9])\.?\d{0,2}$/.test(order_quantity)){
											$(" .order_quantity").val("");
										}
									});

									/*初始化键盘*/
									appUtils.bindEvent($(" #password") ,function(e){
										var input_pwd = $(this);
										input_pwd.find("em").html("");  // 清空密码
										input_pwd.attr("data-password","");  // 清空密码值
										$(" .input_custom").addClass("active");
										keyPanel.init_keyPanel(function(value){
											var curEchoText = input_pwd.find("em").html();  // 密码回显文本
											var input_pass_curPwd = input_pwd.attr("data-password") || "";  // 密码值
											var valInput=$(" #iLayer_myProd #trade_pwd");
											if(value == "del")
											{
												input_pwd.find("em").html(curEchoText.slice(0, -1));
												input_pwd.attr("data-password", input_pass_curPwd.slice(0, -1));
												valInput.val(input_pwd.attr("data-password"));
											}
											else
											{
												if(input_pass_curPwd.length < 6)
												{
													input_pwd.attr("data-password", input_pass_curPwd + value);  // 设置密码值
													input_pwd.find("em").html(curEchoText + "*");
													valInput.val(input_pass_curPwd + value);
												}
												else
												{
													layerUtils.iMsg(-1, "交易密码最多 6位!");
												}
											}
										}, input_pwd);
										e.stopPropagation();
									});

									//点击页面关闭软键盘
									appUtils.bindEvent($(" #iLayer_myProd"),function(){
										keyPanel.closeKeyPanel();
										$(" .input_custom").removeClass("active");
									});

									//判断输入是否合法
									appUtils.bindEvent($(" .order_quantity"),function(){putils.numberLimit($(this));},"keyup");
								}
							});
						},"click");
						
						/* 分红方式 */
						appUtils.bindEvent($(_pageId+" .dividendsWay"),function(){
							var name=$(this).attr("data-name");
							var cuacct_code = $(this).attr("data-fund_account");
							var inst_code = $(this).attr("data-inst_code");
							var trans_acct = $(this).attr("data-trans_acct");
							var ta_code = $(this).attr("data-ta_code");
							var ta_acct = $(this).attr("data-ta_acct");
							var inst_id = $(this).attr("data-inst_id");
							var redflag = $(this).attr("data-redflag");
							if(redflag =="0"){
								return false;
							}
							var param=
							{
								"date":""
							};
							service.dealTimeSyn(param,function(data){
								if(data.error_no!="0")
								{
									layerUtils.iAlert(data.error_info);
									layerUtils.iLoading(false);
									return false;
								} 
								else if(data.results[0].is_trade=='0')
								{
									layerUtils.iAlert("当前是非交易时间，理财和基金产品暂停交易。");
									return false;
								}else{
									layerUtils.layerCustom('<div class="popbox pop_rebuy" id="iLayer_myProd">	<div class="ptitle"><h2>分红方式</h2></div>	<div class="pmain"><p class="input_text0"></p><p class="input_text0"></p><p class="input_text0"><select class="fhType" style="width:120px"> <option value ="0">红利再投资</option><option value ="1">现金分红</option></select></p><p class="input_text0">	<a href="javascript:void(0);" class="btn"  id="iLayer_redeemBtn">确认</a><a href="javascript:void(0);" class="btn2" id="iLayer_closeBtn">关闭</a></p></div></div>');
									var allRecommendStr0 =  "";
									var allRecommendStr1 =  "";
									var allRecommendStr2 =  "";
									allRecommendStr0 += "<label>产品代码:</label>"+inst_code;
									allRecommendStr1 += "<label>产品名称:</label>"+name;
									allRecommendStr2 += "<label>分红方式:</label>";
									$(" .pop_rebuy .input_text0:eq(0)").append(allRecommendStr0);
									$(" .pop_rebuy .input_text0:eq(1)").append(allRecommendStr1);
									$(" .pop_rebuy .input_text0:eq(2)").append(allRecommendStr2);
									
									//分红
									appUtils.bindEvent($x("iLayer_myProd", "iLayer_redeemBtn"), function() {
										otcdividendsWay(cuacct_code, inst_code, trans_acct, ta_code, ta_acct,inst_id); 
									});
									//关闭
									appUtils.bindEvent($x("iLayer_myProd", "iLayer_closeBtn"), function() {
										layerUtils.iCustomClose(); 
									});
									}
								});
						},"click");
					}
				}else{
					layerUtils.iAlert("您尚未购买柜台市场产品！");
				}
			}else{
				layerUtils.iAlert(error_info);
			}
		});
	}
	
	/*otc分红*/
	function otcdividendsWay(cuacct_code, inst_code, trans_acct, ta_code, ta_acct,inst_id){
		var fenhong_type =$("#iLayer_myProd .fhType").val();
		var cust_code =appUtils.getSStorageInfo("cust_code");
		var ticket =appUtils.getSStorageInfo("ticket");
		var param =
		{
			"cust_code" :cust_code,
			"cuacct_code" :cuacct_code,
			"ta_code" : ta_code,
			"ta_acct" : ta_acct,
			"trans_acct":trans_acct,
			"inst_code" :inst_code,
			"inst_id" :inst_id,
			"div_method":fenhong_type,
			"ticket" :ticket
		};
		service.otcFH(param,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			if(error_no =="0")
			{
				layerUtils.iCustomClose();
				layerUtils.iMsg(-1,"分红方式设置已受理");
			}
			else
			{
				layerUtils.iCustomClose();
				layerUtils.iAlert(error_info);
			}
		});
	}
	
	/* otc赎回 */
	function otcRedemption(inst_code, inst_id, cuacct_code, iss_code, trans_acct, ta_code, ta_acct ,redeem_amount){
		var order_quantity =$.trim($("#iLayer_myProd .order_quantity").val());
		var trade_pwd =$.trim($("#iLayer_myProd  #trade_pwd").val());
		//alert(trade_pwd);
		if(trade_pwd==""){
			layerUtils.iMsg(-1,"交易密码不能为空！！！");
			return false;
		}
		if(order_quantity==""){
			layerUtils.iMsg(-1,"份额不能为空！！！");
			return false;
		}
		if(order_quantity<=0){
			layerUtils.iMsg(-1,"份额必须大于零！！！");
			return false;
		}
		//加密
		service.getRSAKey({},function(data){
			if(data.error_no=="0")
			{
				var modulus = data.results[0].modulus;
				var publicExponent =data.results[0].publicExponent;
				var endecryptUtils = require("endecryptUtils");
				var _trade_pwd=endecryptUtils.rsaEncrypt(modulus,publicExponent,trade_pwd);
				var cust_code =appUtils.getSStorageInfo("cust_code");
				var ticket =appUtils.getSStorageInfo("ticket");
				var mobilePhone = require("external").callMessage({"funcNo":"50043","key":"mobilePhone"}).results[0].value;
				if(parseFloat(order_quantity)<=parseFloat(redeem_amount)){
					var param =
					{
						"cust_code" :cust_code,
						"cuacct_code" :cuacct_code,
						"ta_code" : ta_code,
						"ta_acct" : ta_acct,
						"trans_acct" : trans_acct,
						"iss_code" : iss_code,
						"inst_code" : inst_code,
						"inst_id" :inst_id,
						"trd_qty":order_quantity ,
						"trade_pwd" :  _trade_pwd,
						"mobile" : mobilePhone,
						"ticket" : ticket
					};
					service.otcRedemption(param,function(data){
						var error_no = data.error_no;
						var error_info = data.error_info;
						if(error_no =="0")
						{
							layerUtils.iCustomClose();
							var order_id=data.results[0].order_id;
							layerUtils.iLoading(true);
							setTimeout(function(){
								otcOrderInfo(order_id);
							}, 3000);
						}
						else
						{
							layerUtils.iLoading(false);
							layerUtils.iAlert(error_info);
						}
					},{"isLastReq":false});
				}else{
					layerUtils.iLoading(false);
					layerUtils.iMsg(-1,"赎回份额不能大于当前可用份额");
				}
			}
		},{"isLastReq":false});
	}
	
	//获取订单信息，轮循
	function otcOrderInfo(order_id)
	{
		var ticket=appUtils.getSStorageInfo("ticket");
		var param =
		{
			"ticket" : ticket,
			"order_id":order_id//订单编号,
		};
		service.getOTCOrder(param,function(data){
			timeNum++;
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
			else
			{
				var results = data.results;
				var order_state = results[0].order_state;//0-新建,1-待提交,2-提交成功,3-失败,4-提交,5-取消,6-撤单,7-已退款
				var trd_qty = results[0].trd_qty;
				var inst_sname=results[0].inst_sname;
				var order_id=results[0].order_id;
				var entrust_state = results[0].entrust_state;
				if (order_state && order_state != "1")
				{
					var param =
					{
						"order_id": order_id,
						"trd_qty": parseFloat(trd_qty),
						"order_state":order_state,
						"entrust_state": entrust_state,
						"inst_sname":inst_sname

					};
					layerUtils.iLoading(false);
					appUtils.pageInit("otc/otcGT","otc/payment",param);
				}
				else
				{
					if(timeNum < 3)
					{
						setTimeout(function(){
							otcOrderInfo();
						}, 5000);
					}
					else
					{
						var results = data.results;
						var order_state = results[0].order_state;
						var trd_qty = results[0].trd_qty;
						var entrust_state = results[0].entrust_state;
						var inst_sname=results[0].inst_sname;
						var order_id=results[0].order_id;
						var param =
						{
								"order_id": order_id,
								"trd_qty": parseFloat(trd_qty),
								"entrust_state": entrust_state,
								"order_state":order_state,
								"inst_sname":inst_sname

						};
						layerUtils.iLoading(false);
						appUtils.pageInit("otc/otcGT","otc/payment",param);
					}
				}
			}
		},{"isLastReq":false});
	}
	
	function bindPageEvent() 
	{

		/* 绑定返回事件 */
		appUtils.bindEvent($(_pageId+" .top_title .icon_back"),function(){
			var param = {
					"gtFlag" : "1"
			};
			appUtils.pageInit("otc/otcGT","account/userCenter",param);
		});
		
	}

	function destroy()
	{
		service.destroy();
	}

	var otcGT  = 
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = otcGT ;

	});
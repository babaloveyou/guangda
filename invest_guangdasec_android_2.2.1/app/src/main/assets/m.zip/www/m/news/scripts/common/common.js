/**
 * 资讯模块公用 js
 */
define("news/scripts/common/common", function(require, exports, module) {
    var appUtils = require("appUtils"),
	    gconfig = require("gconfig"),
	    global = gconfig.global,
	    external = require("external"),
	    layerUtils = require("layerUtils"),
	    service_news = require("service_news"),
	    //记录点赞文章id
    	clickEle=null,  //文章点赞元素
    	isLike=[];  //记录已点赞文章id
    var clamp = require("clamp");
    
	function firstLoadFunc(){
		 require("external").callMessage({"funcNo": "50100", "moduleName":"news"});
		
		if(appUtils.getSStorageInfo("isLike") == null){
			appUtils.setSStorageInfo("isLike",isLike);
		}
		
		$("#iTranEffect").fadeOut();
		//在pc端可使用键盘输入股票代码（方便调试）
		if(gconfig.platform == "0"){ 
			external.callMessage = function(){};
		}
		
		//JS重写，如果不重写，便是JS自带的
    	Number.prototype.toFixed=function (d) { 
    		var s=this+""; 
    	    if(!d)d=0; 
    		if(s.indexOf(".")==-1)s+="."; 
    		s+=new Array(d+1).join("0"); 
    		if(new RegExp("^(-|\\+)?(\\d+(\\.\\d{0,"+(d+1)+"})?)\\d*$").test(s)){
    			var s="0"+RegExp.$2,pm=RegExp.$1,a=RegExp.$3.length,b=true;
    			if(a==d+2){
    				a=s.match(/\d/g); 
    				if(parseInt(a[a.length-1])>4){
    					for(var i=a.length-2;i>=0;i--){
    						a[i]=parseInt(a[i])+1;
    						if(a[i]==10){
    							a[i]=0;
    							b=i!=1;
    						}else break;
    					}
    				}
    				s=a.join("").replace(new RegExp("(\\d+)(\\d{"+d+"})\\d$"),"$1.$2");
    			}if(b)s=s.substr(1); 
    			return (pm+s).replace(/\.$/,"");
    			}return this+"";
    	};
	}
	
	
	function bindStockEvent(_pageId){
	}
	
	//列表回顶部
	function backTop(_pageId){
		appUtils.bindEvent($(_pageId+".back_top img"), function(e){
			var hight_list = $(_pageId + ".visc_scroller").css("transform");
			hight_list=hight_list.substring(22,hight_list.length-1);
			var n=(-40-hight_list)/100;  //每次加多少   100定时器执行次数
			var i=0;  //控制定时器执行次数
			var id=setInterval(function(){
				i++;
				hight_list = Number(hight_list) + Number(n);
				$(_pageId + ".visc_scroller").css({"transform":" translate(0px, "+hight_list+"px)"});
				if(i>=100){
					clearInterval(id);
				}
			},1);
//			$(_pageId + ".visc_scroller").css({"transform":" translate(0px, -100px)"});
			e.stopPropagation();
		});
	}
	
	//设置文章列表，标题和摘要超过指定行数用...显示
	function setArticleList(_pageId,titLineNum,synopsisLineNum){
		var tit=$(_pageId + ".w_list ul li h6");  //标题
		var synopsis=$(_pageId + ".w_list ul li p");  //摘要
		for(var i = 0; i<tit.length; i++){
			$clamp(tit[i],{clamp:titLineNum});
			$clamp(synopsis[i],{clamp:synopsisLineNum});
		}
	}
	//文章列表上点赞
	function addLike(_pageId){
		appUtils.bindEvent($(_pageId+" .w_list .praise"),function(e){
			clickEle=$(this);
			var articleId=clickEle.parent().parent().attr("articleId");
			if(clickEle.attr("class") == "praise"){
				addLikeNum(articleId);
			}else{
				reduceLikeNum(articleId);
			}
			e.stopPropagation();
		},"click");
	}
	//增加点赞数
	function addLikeNum(articleId){
		var parme = {
				"article_id":articleId
		};
		service_news.AddLikeNum(parme,addLikeNumCallBack);
	}
	//点赞回调
	function addLikeNumCallBack(data){
		if(data.error_no == 0){
			clickEle.addClass("on");
			clickEle.attr("praiseNum",parseInt(clickEle.attr("praiseNum"))+1);
			clickEle.text(overAMillion(clickEle.attr("praiseNum")));  //页面显示内容+1
			//将文章id添加到点赞状态记录中
			var articleId=clickEle.parent().parent().attr("articleId");
			addLikeStatus(articleId);
		}
	}
	//取消点赞
	function reduceLikeNum(articleId){
		var parme = {
				"article_id":articleId
		};
		service_news.reduceLikeNum(parme,reduceLikeNumCallBack);
	}
	//取消点赞回调
	function reduceLikeNumCallBack(data){
		if(data.error_no == 0){
			clickEle.removeClass("on");
			clickEle.attr("praiseNum",parseInt(clickEle.attr("praiseNum"))-1);
			clickEle.text(overAMillion(clickEle.attr("praiseNum")));
			//将文章id从点赞状态记录中删除
			var articleId=clickEle.parent().parent().attr("articleId");
			removeLikeStatus(articleId);
		}
	}
	//将文章id添加到点赞状态记录----增加
	function addLikeStatus(articleId){
		var likeArticleId = appUtils.getSStorageInfo("isLike",isLike);
		likeArticleId.push(articleId);
		appUtils.setSStorageInfo("isLike",likeArticleId);
	}
	//将文章id从点赞状态记录删除----删除
	function removeLikeStatus(articleId){
		var likeArticleId=appUtils.getSStorageInfo("isLike",isLike);
		likeArticleId.splice(queryLikeStatus(articleId),1);
		appUtils.setSStorageInfo("isLike",likeArticleId);
	}
	
	//处理点赞数，数量过万改以万为单位...
	function overAMillion(num){
		num = Number(num);
		if(num >= 100000000){
			num = (num/100000000).toFixed(1) + "亿";
		}else if(num >= 10000){
			num = (num/10000).toFixed(1) + "万";
		}
		return num;
	}

	//查询点赞状态
	function queryLikeStatus(articleId){
		return $.inArray(articleId, appUtils.getSStorageInfo("isLike"));
	}
	
	//查询浏览量和点赞数
	function queryBrowseLikeNum(articleId,em){
		//查询点赞数回调
		var queryBrowseLikeNumCallBack = function(data){
			if(data.error_no == 0){
				var results=data.results;
				if(results.length > 0){
					var praiseNum = results[0].support_num;
					var browse_Num = results[0].browse_num;
					//修改点赞数
					em.find(".w_bot .praise").attr("praisenum",praiseNum).text(common.overAMillion(praiseNum));
					//修改浏览量
					em.find(".w_bot .focus").attr("focusnum",browse_Num).text(common.overAMillion(browse_Num));
				}
			}else{
			}
		};
		var param={"article_id":articleId};
		//查询点赞数
		service_news.queryBrowseLikeNum(param,queryBrowseLikeNumCallBack,{});
	}
	
    var common = {
    	"firstLoadFunc":firstLoadFunc,
    	"bindStockEvent":bindStockEvent,
    	"addLike":addLike,
    	"overAMillion":overAMillion,
    	"queryLikeStatus":queryLikeStatus,
    	"addLikeStatus":addLikeStatus,
    	"removeLikeStatus":removeLikeStatus,
    	"setArticleList":setArticleList,
    	"backTop":backTop,
    	"queryBrowseLikeNum":queryBrowseLikeNum
    };

    module.exports = common;
});
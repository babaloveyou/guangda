/*
 * 风险测评
 */
define(function(require,exports,module){
	
	var appUtils = require("appUtils"),
	layerUtils = require("layerUtils"),
	global = require("gconfig").global,
	service = require("serviceImp"), //业务层接口，请求数据
	_pageId = "#xjb_account_fxcp ";
	var allQuesArray = "";

	/*初始化*/
	function init()
	{
		$(_pageId+" .test_main").html("");
		getRiskAssessQuestions();  //获取问卷答题
		allQuesArray = [];
	}

	function bindPageEvent() 
	{
		/* 绑定返回事件 */
		appUtils.bindEvent($(_pageId+" .top_title .icon_back"),function(){
			pageBack();
		});

	}
	
	function getRiskAssessQuestions(){
		var value_type = "";
		var cust_code=appUtils.getSStorageInfo("cust_code");
		var result = JSON.parse(appUtils.getSStorageInfo("userinfo"));
		if(result.login_flag != "E"){
			value_type = result.user_type;
		}else{
			value_type = appUtils.getSStorageInfo("cust_type");
		}
		var survey_sn = "";
		if(value_type == "0"){
			survey_sn = "1001";
		}else if(value_type == "1"){
			survey_sn = "1002";
		}else{
			survey_sn = "1001";
		}
		var ticket=appUtils.getSStorageInfo("ticket");
		var queryTestParam = {
				"cust_code": cust_code,
				"survey_sn": survey_sn,
				"ticket": ticket
		};
		//查询风险评测
		service.queryTestQuestion(queryTestParam,function(data){
			var errorNo = data.error_no;
			var errorInfo = data.error_info;
			if(errorNo==0 && data.results.length != 0)	//调用成功,跳转到风险测评页面
			{
				var results = data.results;
				for(var i = 0; i < results.length; i++)
				{
					var oneQuestion = {},  // 一个题目
					answerNo = 0;  // 答案编号  
					oneQuestion.question_no = results[i].question_no;  // 题目 id
					oneQuestion.question_title = results[i].question_title;  // 题目
					oneQuestion.question_type = results[i].question_type;  // 题目类型
					oneQuestion.answerArray = [];  // 答案数组
					var answers =results[i].answers;
					answers = answers.replaceAll("=",":'");
					answers = answers.replaceAll("}, ","'},");
					answers = answers.replaceAll("}]","'}]");
					answers = answers.replaceAll(", ","',");
					/*answers = answers.replaceAll("%","");*/
					answers = answers.replaceAll("\n","");
					answers = answers.replaceAll("\r","");
					var data = "";
					eval("data="+answers); 
					//							alert(JSON.stringify(data));
					for(var j = 0; j < data.length; j++)
					{
						oneQuestion.answerArray[answerNo] = {};   // 创建一个答案对象
						oneQuestion.answerArray[answerNo].option_id = data[j].option_id;  // 答案 id
						oneQuestion.answerArray[answerNo].option_no = data[j].option_no;  // 答案 no
						oneQuestion.answerArray[answerNo].description = data[j].description;  // 答案内容
						oneQuestion.answerArray[answerNo++].selection_mark = data[j].selection_mark;  // 答案分数
					}
					allQuesArray.push(oneQuestion);  // 将题目放到题目数组中
					oneQuestion = {};
					answerNo = 0;
					oneQuestion.question_no = results[i].question_no;  // 题目 id
					oneQuestion.question_title = results[i].question_title;  // 题目
					oneQuestion.answerArray = [];  // 答案数组
				}

				fillQuestions();  // 填充风险测评题目

			}
			else
			{
				layerUtils.iMsg("-1",errorInfo);
			}
		},{timeOutFunc:true});
	}


	/*填充题目到页面中*/
	function fillQuestions()
	{
		var allQuesStr="";
		for(var i = 0; i < allQuesArray.length; i++)
		{
			allQuesStr += "<dl class=\"part\">";  
			if(allQuesArray[i].question_type=="0"){
				allQuesStr += "<dt question_no='"+allQuesArray[i].question_no+"'><em>"+(i+1)+"</em>"+allQuesArray[i].question_title+"</dt>";  // 题目
			}else{
				allQuesStr += "<dt question_no='"+allQuesArray[i].question_no+"'><em>"+(i+1)+"</em>"+allQuesArray[i].question_title+"(多选)</dt>";  // 题目
			}
			var answerArray = allQuesArray[i].answerArray;  // 答案数组
			for(var j = 0; j < answerArray.length; j++)
			{
				allQuesStr += "<dd>"; // 答案
				allQuesStr += '<span  class="icon_radio" id="'+allQuesArray[i].question_no+'" question_type="'+allQuesArray[i].question_type+'" option_no="'+answerArray[j].option_no+'" ans-mark ="'+answerArray[j].selection_mark+'" >'+answerArray[j].description+'</span>';
				allQuesStr += "</dd>";
			}
			allQuesStr += "</dl>";
		}
		allQuesStr +="<div class=\"btn\"><a class=\"definbtn_01\" href=\"javascript:void(0);\">提交</a></div>";
		$(_pageId+" .test_main").html(allQuesStr);
		$(_pageId + " .main .definbtn_01").css("background","#1199EE");

		//为选择按钮添加事件
		appUtils.bindEvent($(_pageId+" .test_main dl dd span"),function(){
			var question_no=$(this).attr("id");
			var question_type=$(this).attr("question_type");
			if(question_type=="0"){
				if($(this).hasClass("active"))
				{
					$(this).parent().parent().prev("dt").css("color","red");  //未选择答案，则将该题标记为红色
					$(this).removeClass("active");
				}
				else
				{
					$(_pageId+" .test_main #"+question_no).removeClass("active");
					$(this).parent().parent().prev("dt").css("color","#666666");	// 题目红色标记恢复黑色
					$(this).addClass("active");
				}
			}else{
				if($(this).hasClass("active"))
				{
					$(this).parent().parent().prev("dt").css("color","red");  //未选择答案，则将该题标记为红色
					$(this).removeClass("active");
				}
				else
				{
					$(this).parent().parent().prev("dt").css("color","#666666");	// 题目红色标记恢复黑色
					$(this).addClass("active");
				}
			}
		});

		/*确定按钮*/
		appUtils.bindEvent($(_pageId+" .btn"), function(){
			if(validateNext())  // 校验下一步条件
			{
				postRiskAnswer();  // 提交风险测评答案
			}
		});

	}

	/*校验下一步条件*/
	function validateNext()
	{
		var bAllChoose = true,  // boolean 类型的变量，题目是否全部答完
		aNoSelQuesNo = [];  // array 类型的变量，没有选择的问题编号数组
		$(_pageId+" .test_main dl").each(function(index, obj){
			if(!$(obj).children("dd").children("span").hasClass("active"))
			{
				bAllChoose = false;
				aNoSelQuesNo.push(index+1);
			}
		});
		if(!bAllChoose)  // 当有题未选择答案时
		{
			layerUtils.iAlert("您还有【"+aNoSelQuesNo.join("、")+"】未完成");
		}
		return bAllChoose;
	}

	/**
	 * 获取风险测评答案
	 * 返回的数据格式：34_58|34_57|34_56
	 */
	function getRiskAnswer()
	{
		var riskAnswerStr = "",  // 测评答案字符串
		queId = null,  // 题目 id
		ansId = null;  // 答案 id
		$(_pageId+" .test_main dl").each(function(){
			queId = $(this).children("dt").attr("question_no");
			$(this).children("dd").children("span[class='icon_radio active']").each(function(){
				ansId = $(this).attr("option_no");
				riskAnswerStr += queId+"_"+ansId+"|";
			})
		});
		var riskAnswerStr1=riskAnswerStr.substring(0,riskAnswerStr.length-1);
		return riskAnswerStr1;
	}
	
	/*提交风险测评答案*/
	function postRiskAnswer()
	{
		var cust_code=appUtils.getSStorageInfo("cust_code");
		var ticket=appUtils.getSStorageInfo("ticket");
		var value_type = "";
		var result = JSON.parse(appUtils.getSStorageInfo("userinfo"));
		if(result.login_flag != "E"){
			value_type = result.user_type;
		}else{
			value_type = appUtils.getSStorageInfo("cust_type");
		}
		var survey_sn = "";
		if(value_type == "0"){
			survey_sn = "1001";
		}else if(value_type == "1"){
			survey_sn = "1002";
		}else{
			survey_sn = "1001";
		}
		var riskAnswerParam = {
			"cust_code" : cust_code,
			"ticket" : ticket,
			"survey_sn": survey_sn,
			"cust_type": value_type,
			"content" : getRiskAnswer()  // 获取风险测评答案
		};
		service.submitQuestionAnswer(riskAnswerParam,function(data){
			var error_no = data.error_no;
			var error_info = data.error_info;
			if(error_no == 0){

				var results = data.results[0];
				var risk_name=results.risk_name;
				var risk_fraction=results.risk_fraction;
//				if(appUtils.getSStorageInfo("_prePageCode")=="account/userCenter"){
					layerUtils.layerCustom('<div class="popbox pop_rebuy" id="iLayer_myProd">	<div class="ptitle"><h2>风险测评提示信息</h2></div>	<div class="pmain"><p class="input_text1" style="text-align:center;"><img  src="images/1.png"/><lable>风险测评提交成功!</lable></p><p class="input_text1"  style="text-align:center;"></p><p class="input_text1"  style="text-align:center;"></p><p class="input_text1">	<a href="javascript:void(0);" class="btn1"  id="iLayer_redeemBtn" >确定</a></p></div></div>');
					var allRecommendStr1 =  "";
					var allRecommendStr2=  "";
					allRecommendStr1 += "<label>您的风险分数:</label>"+risk_fraction;
					allRecommendStr2 += "<label>您的风险等级:</label>"+risk_name;
					$(" .pop_rebuy .input_text1:eq(1)").append(allRecommendStr1);
					$(" .pop_rebuy .input_text1:eq(2)").append(allRecommendStr2);
					
					appUtils.bindEvent($x("iLayer_myProd", "iLayer_redeemBtn"), function() {
						layerUtils.iCustomClose(); 
						appUtils.pageInit("xjb/account/fxcp","xjb/account/index",{});
					});
//				}else{
//					appUtils.pageInit("otc/riskAssessment","otc/riskResult",{});
//				}
			}else{
				layerUtils.iAlert(error_info);
			}
		});

	}

	/* 处理请求超时 */
	function handleTimeout()
	{
		layerUtils.iConfirm("请求超时，是否重新加载？",function(){
			getRiskAssessQuestions();  // 再次风险测评题目
		});
	}

	function destroy()
	{
//		service.destroy();
	}
	
	function pageBack(){
		appUtils.pageInit("xjb/account/fxcp","xjb/account/index",{});
	}
	
	var base = {
			"init":init,
			"bindPageEvent":bindPageEvent,
			"destroy":destroy,
			"pageBack":pageBack
	};
	//暴露方法
	module.exports = base;
});
/**
 * 服务--确认订单
 */
define(function(require, exports, module)
	{	
	var service = require("mobileService"); //业务层接口，请求数据
	var appUtils = require('appUtils'),
	putils = require("putils"),
	layerUtils = require("layerUtils"),
	constants=require("constants");//常量类
	gconfig = require("gconfig"),
	global = gconfig.global;
	var save_value= null;
	var _pageId ="#mall_servOrder_confirmOrder";
	var URL=global.url;
	//1、初始化
	function init() 
	{
		//提交订单按钮不能用
		$(_pageId+" #tjdd").hide();
		var product_id=appUtils.getPageParam().product_id;
		//防止直接到该页面
		if(product_id==null)
		{
			layerUtils.iMsg(1, "数据加载错误！");
			appUtils.pageInit("mall/servOrder/confirmOrder","account/mainPage",{})
			return false;
		}
		//查询服务产品详情
		findServiceInfo();
		//查询协议
		findAgreement();
	}


	//查询服务产品详情
	function findServiceInfo(){
		var product_id=appUtils.getPageParam().product_id;
		var param=
		{
			"product_id":product_id
		}
		service.findServInfo(param,function(data){
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}
			var  product_name=appUtils.getPageParam().product_name;
			var  service_desc=appUtils.getPageParam().service_desc;
			var  rules_desc=appUtils.getPageParam().rules_desc;
			var  relrs_price=appUtils.getPageParam().relrs_price;
			$(_pageId+" .pro_thumb").html("<img src="+URL+data.results[0].img_url_l+">");//图片
			$(_pageId+" .cpmc").html(data.results[0].product_name);
			$(_pageId+" #fwfs").html(service_desc);
			$(_pageId+" #dj").html(rules_desc);
			$(_pageId+" #zj").html(relrs_price);
			$(_pageId+" #je").html(relrs_price);


		})
	}

	//查询协议
	function findAgreement()
	{
		var product_id = appUtils.getPageParam().product_id;//产品编号
		var user_id = appUtils.getSStorageInfo("user_id");  //用户编号
		var flag = true ;		  // 签署协议标识，true 为已签署
		var showDataList =[];	  //显示结果集
		var _agreement_id;		  //协议编号
		var _agreement_title ;    //协议标题
		var results=null; 		  //保存结果集

		var param =
		{
			"user_id":user_id,
			"product_id":product_id
		};
		service.findAgreement(param,function(data)
			{
			if(data.error_no != "0") 
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			}

			results= data.results; //保存结果集
			allProtocolStr = "";   //所有协议字符串

			for (var i=0;i<results.length;i++)
			{
				if(results[i].agreement_type=="1")     //1 是电子协议书
				{
					allProtocolStr += '<li><a href="javascript:;" agreement_id='+results[i].agreement_id+' agreement_title='+results[i].agreement_title+'>'+results[i].agreement_title+'</a></li>';

				}
				else if(results[i].agreement_type=="2")//2 电子合同
				{
					allProtocolStr += '<li><a href="javascript:;" agreement_id='+results[i].agreement_id+' agreement_title='+results[i].agreement_title+'>'+results[i].agreement_title+'</a></li>';
				}
				_agreement_id = results[i].agreement_id;
				_agreement_title = results[i].agreement_title ;
			}


			var param=
			{
				"_agreement_id":_agreement_id,
				"product_id": product_id,
				"_agreement_title":_agreement_title,
				"results":results,
				"flag":flag,
				"product_sub_type":"2"

			}
			appUtils.pageInit("mall/servOrder/confirmOrder","mall/signOtherProtocol",param);

			$(_pageId+" #ifSignProt").html(allProtocolStr);

			//阅读协议
			appUtils.bindEvent($(_pageId+" #ifSignProt  li a[agreement_id]"),function(){
				var pageInParam = {
					"agreement_id" :$(this).attr("agreement_id"),
					"agreement_title":$(this).attr("agreement_title"), 
					"results":results
				};
				appUtils.pageInit("mall/servOrder/confirmOrder","mall/protocol",pageInParam);
			}); 
			});
	}

	//提交订单
	function commitOrder()
	{
		var product_id =appUtils.getPageParam().product_id;     //产品编号
		var rules_id =appUtils.getPageParam().rules_id;         //购买类型编号
		var service_type =appUtils.getPageParam().service_type; //服务类型
		var user_id =appUtils.getSStorageInfo("user_id");		//用户编号

		//检查是否可以提交订单
		var param=
		{
			"product_id":product_id,
			"user_id":user_id
		}
		service.checkOthorOrderSubmit(param,function(data){
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			} 
			//风险等级 =1时
			if(data.results[0].is_risk==constants.is_risk.YES)
			{
				var param =
				{
					"user_id":user_id,
					"product_id":product_id,
					"rules_id":rules_id,
					"service_type":service_type
				};
				service.servBuy(param,function(data) 
					{
					if(data.error_no!="0")
					{
						layerUtils.iAlert(data.error_info);
						layerUtils.iLoading(false);
						return false;
					} 
					var param=
					{
						"product_id":product_id,
						"order_id":data.results[0].order_id,
						"order_tot_price":data.results[0].order_tot_price
					}

					appUtils.pageInit("mall/servOrder/confirmOrder","mall/servOrder/orderPay",param) 
					});
			}

			//风险等级 =2时
			else if (data.results[0].is_risk==constants.is_risk.LOW)
			{
				layerUtils.iConfirm("您的风险等级低于该产品的风险等级，您是否继续购买",function()
					{
					var param =
					{
						"user_id":user_id,
						"product_id":product_id,
						"rules_id":rules_id,
						"service_type":service_type
					};
					service.servBuy(param,function(data) 
						{
						if(data.error_no!="0")
						{
							layerUtils.iAlert(data.error_info);
							layerUtils.iLoading(false);
							return false;
						} 
						var param=
						{
							"product_id":product_id,
							"order_id":data.results[0].order_id,
							"order_tot_price":data.results[0].order_tot_price
						}
						appUtils.pageInit("mall/servOrder/confirmOrder","mall/servOrder/orderPay",param) 
						});
					});

			}

			//风险等级 =3时
			else if(data.results[0].is_risk==constants.is_risk.Theree)
			{
				layerUtils.iConfirm("该产品的风险等级已过期，请重新测评!",-1,function()
					{
					appUtils.pageInit("mall/servOrder/confirmOrder","account/riskAssessment",{});
					});
			}
			//风险等级 =其它时
			else

			{
				layerUtils.iMsg(0,"没有进行风险评测");

			}

		})
	}

	//判断是否是交易日
	function dealTimeSyn()
	{
		var param=
		{
			"date":""
		}
		service.dealTimeSyn(param,function(data){
			if(data.error_no!="0")
			{
				layerUtils.iAlert(data.error_info);
				layerUtils.iLoading(false);
				return false;
			} 
			if(data.results[0].is_trade=='0')
			{
				layerUtils.iAlert("非交易日不能购买!!!",0);
				return false;
			}
			commitOrder();//提交订单

		})
	}
	//2、事件绑定
	function bindPageEvent()
	{	


		//点击 提交订单
		appUtils.bindEvent($(_pageId+" .n2"),function(){
			if(!$(_pageId+" #signProtocol").prop("checked"))
			{
				layerUtils.iAlert("请同意并签署此购买合同！");
				return false;
			}
			dealTimeSyn();//判断是否是交易日
		})

		//点击理财
		appUtils.bindEvent($(_pageId+" #finan"),function(){appUtils.pageInit("mall/servOrder/confirmOrder","mall/itemsFinan",{});});

		//点击基金
		appUtils.bindEvent($(_pageId+" #fund"),function(){appUtils.pageInit("mall/servOrder/confirmOrder","mall/itemsFund",{});});

		//点击 返回
		appUtils.bindEvent($(_pageId+" .icon_back"),function(){appUtils.pageBack();});

		//点击 返回顶部
		appUtils.bindEvent($(_pageId+" .back_btn"),function(){$('body,html').animate({scrollTop:0},1000);return false;});

		//点击 LOGO 
		appUtils.bindEvent($(_pageId+" .logo"),function(){appUtils.pageInit("mall/servOrder/confirmOrder","account/mainPage")})

		//点击 继续选购
		appUtils.bindEvent($(_pageId+" .n1"),function(){appUtils.pageInit("mall/servOrder/confirmOrder","account/mainPage")});		

		//判断输入是否合法
		appUtils.bindEvent($(_pageId+" #buyValue"),function(){putils.numberLimit($(this));},"keyup");

		//控制输入不能为空
		appUtils.bindEvent($(_pageId+" #buyValue"),function(){

			if($(this).val()==null||$(this).val()==""){
				$(this).val(0);
			}
			$(this).val(putils.moneyFormat($(this).val()));
			$(_pageId+" #zj").html($(_pageId+" #buyValue").val());
		},"blur");

		//点击登录
		appUtils.bindEvent($(_pageId+" .icon_info"),function(){
			appUtils.pageInit("mall/servOrder/confirmOrder","account/userCenter",{});
		});
	}

	//3、销毁
	function destroy()
	{

	}

	var confirmOrder =
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = confirmOrder;

	});
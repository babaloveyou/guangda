/**
 * 转账查询-结果
 */
define(function(require, exports, module) {
	var appUtils = require("appUtils");
	var gconfig = require("gconfig");
	var service = require("mobileService"); //业务层接口，请求数据
	var global = gconfig.global;
	var layerUtils = require("layerUtils");
	var _pageId="#account_fundRiskAssessment ";
	var product_code="";
	var prePage = "";

	
	
	/*初始化*/
	function init()
	{
		$(_pageId+" .test_list").html("");
		var pageInParam  = appUtils.getPageParam();
		prePage = pageInParam.prePage;
		product_code=pageInParam.product_code;
		allQuesArray = [];
		personInfo();
		/*if(appUtils.getSStorageInfo("_prePageCode")=="mall/finanOrder/confirmOrder"){
			getFinanRiskAssessQuestions(product_code);  //获取问卷答题
		}
		else{*/
			getRiskAssessQuestions();  //获取问卷答题
		//}
	}

	function bindPageEvent() 
	{
		/* 绑定返回事件 */
		appUtils.bindEvent($(_pageId+" .top_title .icon_back"),function(){
			if(prePage == "fz_marketCon"){
				if(gconfig.platform == "2"){
					toPage={"prefix":"www/m/index","suffix":"account/marketCon","prePage":"mall_fundRiskAssessment"};
				}else{
					toPage = "/index/index.html#!/account/marketCon.html?prePage=mall_fundRiskAssessment";
				}
				var param = {"funcNo":"50101","moduleName":"user-center","params":{"moduleName":"financial-mall","toPage":toPage}};
				require("external").callMessage(param);
			}else if(prePage == "fz_userCenter"){
				if(gconfig.platform == "2"){
					toPage={"prefix":"www/m/index","suffix":"account/userCenter","prePage":"mall_fundRiskAssessment"};
				}else{
					toPage = "/index/index.html#!/account/userCenter.html?prePage=mall_fundRiskAssessment";
				}
				var param = {"funcNo":"50101","moduleName":"user-center","params":{"moduleName":"financial-mall","toPage":toPage}};
				require("external").callMessage(param);
			}else{
				appUtils.pageBack();
			}
		});

		/* 绑定返回首页事件 */
		appUtils.bindEvent($(_pageId+" .icon_mall"),function(){
			appUtils.pageInit("account/userCenter","account/mainPage",{});
		});

	}

	function personInfo(){
		// 获取个人信息枚举
		var allPersonInfoStr="";
		var user_name=appUtils.getSStorageInfo("user_name");
		var account_name=appUtils.getSStorageInfo("account_name");
		var fund_account=appUtils.getSStorageInfo("fund_account");
		var risk_level_txt=appUtils.getSStorageInfo("risk_level_txt");
		if(risk_level_txt == null || risk_level_txt == ""){
			risk_level_txt ="--";
		}
		allPersonInfoStr += '<p ><span>用户：</span>'+user_name+'</p>'+
		'<p ><span>已开通账户：</span>'+"资金账户"+"("+fund_account+")"+'</p>'+
		'<p ><span>风险承受能力：</span>'+risk_level_txt+'</p>';
		$(_pageId+" .info_box").html(allPersonInfoStr);  // 填充个人信息
	}
	
	//理财产品专属风险测评
    function getFinanRiskAssessQuestions(product_code){

		var queryTestParam = {
				"risk_type_id":product_code
					};
		//查询风险评测
		service.queryEval(queryTestParam,function(data){
			var errorNo = data.error_no;
			var errorInfo = data.error_info;
			if(errorNo==0 && data.results.length != 0)	//调用成功,跳转到风险测评页面
			{
				var results = data.results;
				for(var i = 0; i < results.length; i++)
				{
					var oneQuestion = {},  // 一个题目
					answerNo = 0;  // 答案编号  
					oneQuestion.question_id = results[i].question_id;  // 题目 id
					oneQuestion.question_title = results[i].question_title;  // 题目
					oneQuestion.answerArray = [];  // 答案数组
					var answers =results[i].answers;
					answers = answers.replaceAll("=",":'");
					answers = answers.replaceAll("}, ","'},");
					answers = answers.replaceAll("}]","'}]");
					answers = answers.replaceAll(", ","',");
					/*answers = answers.replaceAll("%","");*/
					answers = answers.replaceAll("\n","");
					answers = answers.replaceAll("\r","");
					var data = "";
					eval("data="+answers); 
					//							alert(JSON.stringify(data));
					for(var j = 0; j < data.length; j++)
					{
						oneQuestion.answerArray[answerNo] = {};   // 创建一个答案对象
						oneQuestion.answerArray[answerNo].option_id = data[j].option_id;  // 答案 id
						oneQuestion.answerArray[answerNo].description = data[j].description;  // 答案内容
						oneQuestion.answerArray[answerNo++].selection_mark = data[j].selection_mark;  // 答案分数
					}
					allQuesArray.push(oneQuestion);  // 将题目放到题目数组中
					oneQuestion = {};
					answerNo = 0;
					oneQuestion.question_id = results[i].question_id;  // 题目 id
					oneQuestion.question_title = results[i].question_title;  // 题目
					oneQuestion.answerArray = [];  // 答案数组
				}

				fillQuestions();  // 填充风险测评题目

			}
			else
			{
				layerUtils.iMsg("-1",errorInfo);
			}
		},true,true,handleTimeout);
	
    }
    
	function getRiskAssessQuestions(){

		var queryTestParam = {"risk_type_id":""};
		//查询风险评测
		service.queryEval(queryTestParam,function(data){
			var errorNo = data.error_no;
			var errorInfo = data.error_info;
			if(errorNo==0 && data.results.length != 0)	//调用成功,跳转到风险测评页面
			{
				var results = data.results;
				for(var i = 0; i < results.length; i++)
				{
					var oneQuestion = {},  // 一个题目
					answerNo = 0;  // 答案编号  
					oneQuestion.question_id = results[i].question_id;  // 题目 id
					oneQuestion.question_title = results[i].question_title;  // 题目
					oneQuestion.answerArray = [];  // 答案数组
					var answers =results[i].answers;
					answers = answers.replaceAll("=",":'");
					answers = answers.replaceAll("}, ","'},");
					answers = answers.replaceAll("}]","'}]");
					answers = answers.replaceAll(", ","',");
					/*answers = answers.replaceAll("%","");*/
					answers = answers.replaceAll("\n","");
					answers = answers.replaceAll("\r","");
					var data = "";
					eval("data="+answers); 
					//							alert(JSON.stringify(data));
					for(var j = 0; j < data.length; j++)
					{
						oneQuestion.answerArray[answerNo] = {};   // 创建一个答案对象
						oneQuestion.answerArray[answerNo].option_id = data[j].option_id;  // 答案 id
						oneQuestion.answerArray[answerNo].description = data[j].description;  // 答案内容
						oneQuestion.answerArray[answerNo++].selection_mark = data[j].selection_mark;  // 答案分数
					}
					allQuesArray.push(oneQuestion);  // 将题目放到题目数组中
					oneQuestion = {};
					answerNo = 0;
					oneQuestion.question_id = results[i].question_id;  // 题目 id
					oneQuestion.question_title = results[i].question_title;  // 题目
					oneQuestion.answerArray = [];  // 答案数组
				}

				fillQuestions();  // 填充风险测评题目

			}
			else
			{
				layerUtils.iMsg("-1",errorInfo);
			}
		},true,true,handleTimeout);
	}


	/*填充题目到页面中*/
	function fillQuestions()
	{
		var allQuesStr="";
		for(var i = 0; i < allQuesArray.length; i++)
		{
			allQuesStr += "<dl>";  
			allQuesStr += "<dt question_id='"+allQuesArray[i].question_id+"'><em>"+(i+1)+"</em>"+allQuesArray[i].question_title+"</dt>";  // 题目
			var answerArray = allQuesArray[i].answerArray;  // 答案数组
			for(var j = 0; j < answerArray.length; j++)
			{
				allQuesStr += "<dd>"; // 答案
				allQuesStr += '<span  class="icon_radio" id="'+allQuesArray[i].question_id+'" option_id="'+answerArray[j].option_id+'" ans-mark ="'+answerArray[j].selection_mark+'" >'+answerArray[j].description+'</span>';
				allQuesStr += "</dd>";
			}
			allQuesStr += "</dl>";
		}
		allQuesStr +="<div class=\"btn\"><a href=\"javascript:void(0);\">提交</a></div>";
		$(_pageId+" .test_list").html(allQuesStr);

		//为选择按钮添加事件
		appUtils.bindEvent($(_pageId+" .test_list dl dd span"),function(){
			var question_id=$(this).attr("id");
			if($(this).hasClass("active"))
			{
				$(this).parent().parent().prev("dt").css("color","red");  //未选择答案，则将该题标记为红色
				$(this).removeClass("active");
			}
			else
			{
				$(_pageId+" .test_list #"+question_id).removeClass("active");
				$(this).parent().parent().prev("dt").css("color","#666666");	// 题目红色标记恢复黑色
				$(this).addClass("active");
			}
		});

		/*确定按钮*/
		appUtils.bindEvent($(_pageId+" .btn"), function(){
			if(validateNext())  // 校验下一步条件
			{
				postRiskAnswer();  // 提交风险测评答案
			}
		});

	}

	/*校验下一步条件*/
	function validateNext()
	{
		var bAllChoose = true,  // boolean 类型的变量，题目是否全部答完
		aNoSelQuesNo = [];  // array 类型的变量，没有选择的问题编号数组
		$(_pageId+" .test_list dl").each(function(index, obj){
			if(!$(obj).children("dd").children("span").hasClass("active"))
			{
				bAllChoose = false;
				aNoSelQuesNo.push(index+1);
			}
		});
		if(!bAllChoose)  // 当有题未选择答案时
		{
			layerUtils.iAlert("您还有【"+aNoSelQuesNo.join("、")+"】未完成");
		}
		return bAllChoose;
	}

	/**
	 * 获取风险测评答案
	 * 返回的数据格式：34_58|34_57|34_56
	 */
	function getRiskAnswer()
	{
		var riskAnswerStr = "",  // 测评答案字符串
		queId = null,  // 题目 id
		ansId = null;  // 答案 id
		$(_pageId+" .test_list dl").each(function(){
			queId = $(this).children("dt").attr("question_id");
			ansId = $(this).children("dd").children("span[class='icon_radio active']").attr("option_id");
			riskAnswerStr += queId+"_"+ansId+"|";
		});
		var riskAnswerStr1=riskAnswerStr.substring(0,riskAnswerStr.length-1);
		return riskAnswerStr1;
	}
	
	/*提交理财风险测评答案*/
	function postFinanRiskAnswer(){

		//		layerUtils.iLoading(true);
		var user_id=appUtils.getSStorageInfo("user_id");
		var riskAnswerParam = {
			"user_id" : user_id,
			"risk_type_id" : product_code,
			"content" : getRiskAnswer()  // 获取风险测评答案
		};
		service.submitTestAnswer(riskAnswerParam,function(data){
			if(data.error_no == 0){
				var results = data.results[0];
				var risk_name=results.risk_name;
				var risk_fraction=results.risk_fraction;
				appUtils.setSStorageInfo("risk_level_txt",risk_name);
				
				//从原生获取商城用户信息值
				var param_data = {"funcNo":"50041","key":"mall_data"};
				var resultVo =  require("external").callMessage(param_data);
				var res = resultVo.results[0].value;
				res.risk_level_txt = risk_name;
				// 再次把最新用户信息保存至商城session里
				var param_data = {"funcNo":"50040","key":"mall_data","value":JSON.stringify(res)};
				require("external").callMessage(param_data); //把result存在原生壳子

				layerUtils.layerCustom('<div class="popbox pop_rebuy" id="iLayer_myProd">	<div class="ptitle"><h2>风险测评提示信息</h2></div>	<div class="pmain"><p class="input_text1" style="text-align:center;"><img  src="images/1.png"/><lable>风险测评提交成功!</lable></p><p class="input_text1"  style="text-align:center;"></p><p class="input_text1"  style="text-align:center;"></p><p class="input_text1">	<a href="javascript:void(0);" class="btn1"  id="iLayer_redeemBtn" >确定</a></p></div></div>');
				var allRecommendStr1 =  "";
				var allRecommendStr2=  "";
				allRecommendStr1 += "<label>您的风险分数:</label>"+risk_fraction;
				allRecommendStr2 += "<label>您的风险等级:</label>"+risk_name;
				$(" .pop_rebuy .input_text1:eq(1)").append(allRecommendStr1);
				$(" .pop_rebuy .input_text1:eq(2)").append(allRecommendStr2);
				appUtils.bindEvent($x("iLayer_myProd", "iLayer_redeemBtn"), function() {
					layerUtils.iCustomClose(); 
					if(appUtils.getSStorageInfo("_prePageCode")=="mall/finanOrder/confirmOrder"){
						var pageInParam  = appUtils.getPageParam();
						var product_name= pageInParam.product_name;
						var product_id=pageInParam.product_id;
						var tot_price=pageInParam.tot_price;
						var param={
								"product_name":product_name,
								"product_id":product_id,
								"tot_price":tot_price
						}
						appUtils.pageInit("account/fundRiskAssessment","mall/finanOrder/confirmOrder",param);
					}else{
						personInfo();
						$(document.body).ScrollTo(0);
						$(_pageId+" .test_list dl dd span").removeClass("active");
					}
				});
				
			}
			else{
				layerUtils.iAlert(data.error_info);
			}
		});

	}
	
	/*提交风险测评答案*/
	function postRiskAnswer()
	{
		//		layerUtils.iLoading(true);
		var user_id=appUtils.getSStorageInfo("user_id");
		var riskAnswerParam = {
			"user_id" : user_id,
			"risk_type_id" : "0",
			"content" : getRiskAnswer()  // 获取风险测评答案
		};
		service.submitTestAnswer(riskAnswerParam,function(data){
			if(data.error_no == 0){
				var results = data.results[0];
				var risk_name=results.risk_name;
				var risk_fraction=results.risk_fraction;
				appUtils.setSStorageInfo("risk_level_txt",risk_name);

				//从原生获取商城用户信息值
				var param_data = {"funcNo":"50041","key":"mall_data"};
				var resultVo =  require("external").callMessage(param_data);
				var res = resultVo.results[0].value;
				res.risk_level_txt = risk_name;
				// 再次把最新用户信息保存至商城session里
				var param_data = {"funcNo":"50040","key":"mall_data","value":JSON.stringify(res)};
				require("external").callMessage(param_data); //把result存在原生壳子

				layerUtils.layerCustom('<div class="popbox pop_rebuy" id="iLayer_myProd">	<div class="ptitle"><h2>风险测评提示信息</h2></div>	<div class="pmain"><p class="input_text1" style="text-align:center;"><img  src="images/1.png"/><lable>风险测评提交成功!</lable></p><p class="input_text1"  style="text-align:center;"></p><p class="input_text1"  style="text-align:center;"></p><p class="input_text1">	<a href="javascript:void(0);" class="btn1"  id="iLayer_redeemBtn" >确定</a></p></div></div>');
				var allRecommendStr1 =  "";
				var allRecommendStr2=  "";
				allRecommendStr1 += "<label>您的风险分数:</label>"+risk_fraction;
				allRecommendStr2 += "<label>您的风险等级:</label>"+risk_name;
				$(" .pop_rebuy .input_text1:eq(1)").append(allRecommendStr1);
				$(" .pop_rebuy .input_text1:eq(2)").append(allRecommendStr2);
				appUtils.bindEvent($x("iLayer_myProd", "iLayer_redeemBtn"), function() {
					layerUtils.iCustomClose(); 
					if(appUtils.getSStorageInfo("_prePageCode")=="mall/finanOrder/confirmOrder"){
						var pageInParam  = appUtils.getPageParam();
				    	var product_name= pageInParam.product_name;
					    var product_id=pageInParam.product_id;
					    var tot_price=pageInParam.tot_price;
						var param =
						{
								"product_name":product_name,
								"product_id":product_id,
								"tot_price":tot_price,
								"product_code":product_code
						};
						appUtils.pageInit("account/fundRiskAssessment","mall/finanOrder/confirmOrder",param);
					}else if(appUtils.getSStorageInfo("_prePageCode")=="mall/fundOrder/confirmOrder"){
						var pageInParam  = appUtils.getPageParam();
						var product_name= pageInParam.product_name;
						var product_id=pageInParam.product_id;
						var tot_price=pageInParam.tot_price;
						var param =
						{
							"product_name":product_name,
							"product_id":product_id,
							"tot_price":tot_price
						};
						appUtils.pageInit("account/fundRiskAssessment","mall/fundOrder/confirmOrder",param);
					}else if(prePage == "fz"){
						if(gconfig.platform == "2"){
							toPage={"prefix":"www/m/index","suffix":"account/marketCon","prePage":"sc"};
						}else{
							toPage = "/index/index.html#!/account/marketCon.html?prePage=sc";
						}
						var param = {"funcNo":"50101","moduleName":"user-center","params":{"moduleName":"financial-mall","toPage":toPage}};
						require("external").callMessage(param);
					}
					else{
						personInfo();
						$(document.body).ScrollTo(0);
						$(_pageId+" .test_list dl dd span").removeClass("active");
					}
				});
				
			}
			else{
				layerUtils.iAlert(data.error_info);
			}
		});

	}

	/* 处理请求超时 */
	function handleTimeout()
	{
		layerUtils.iConfirm("请求超时，是否重新加载？",function(){
			getRiskAssessQuestions();  // 再次风险测评题目
		});
	}

	function destroy()
	{
		service.destroy();
	}

	var changeResults = 
	{
		"init" : init,
		"bindPageEvent": bindPageEvent,
		"destroy": destroy
	};

	module.exports = changeResults;

});
/**
 * 手机前端service层调用接口
 **/
define(function(require,exports,module){
	var appUtils = require("appUtils");
	var gconfig = require("gconfig");
	var global = gconfig.global;
	var service = require("service");
	var serviceSingleton = new service.Service();
	
	/********************************公共代码部分********************************/
    function commonInvoke(paraMap, callback, ctrlParam, reqParamVo){
		reqParamVo.setReqParam(paraMap);
		ctrlParam = ctrlParam?ctrlParam:{};
		reqParamVo.setIsLastReq(ctrlParam.isLastReq);
		reqParamVo.setIsAsync(ctrlParam.isAsync);
		reqParamVo.setIsShowWait(ctrlParam.isShowWait);
		reqParamVo.setTimeOutFunc(ctrlParam.timeOutFunc);
		reqParamVo.setIsShowOverLay(ctrlParam.isShowOverLay);
		reqParamVo.setTipsWords(ctrlParam.tipsWords);
		reqParamVo.setDataType(ctrlParam.dataType);
		reqParamVo.setIsGlobal(ctrlParam.isGlobal);
		reqParamVo.setProtocol(ctrlParam.protocol);
		serviceSingleton.invoke(reqParamVo, callback);
	}
    /* 获取用户手机号码 */
	function getPhone(){
		var phone = "";
		if(global.phone){
			phone = global.phone;
		}
		else{
			// 获取壳子里的手机号
			var key = {key : "phone"};
//			phone = require("external").callFunction("55601",JSON.stringify(key)); 
			global.phone = phone;
		}
		return phone;
	}
	function destroy(){
		serviceSingleton.destroy();
	}
	var mobileService = {
		"getInstance": getInstance, //为了避免以前调用getInstance方法报错
		"destroy": destroy
	};
	function getInstance(){
		return mobileService;
	}
	module.exports = mobileService;
	
	/********************************应用接口开始********************************/
	
	/**
	 * ezt账号用户登入(100007)
	 * @Author:黎志勇
	 * @param login_value 登录值
	 * @param type类型：1 账户名,2 手机,3 邮箱,7 身份证
	 * @param login_pwd 登录密码
	 * @param callback 回调函数
	 */
	mobileService.eztLogin = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "100007";
		paraMap["user_id_type"] = param.login_type;
		paraMap["user_id"] = param.ezt_account;
		paraMap["trade_pwd"] = param.trade_pwd;
		paraMap["ticket"] = param.vf_code;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
	/**
	 * 商城账号用户登入(1000207)
	 * @Author:黎志勇
	 * @param login_value 登录值
	 * @param type类型：1 账户名,2 手机,3 邮箱,7 身份证
	 * @param login_pwd 登录密码
	 * @param callback 回调函数
	 */
	mobileService.userLogin = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000207";
		paraMap["login_value"] = param.login_value;
		paraMap["type"] = "1";
		paraMap["login_pwd"] = param.login_pwd;
		paraMap["ticket"] = param.vf_code;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
	
	/**
	 * 资金账号用户登入(1001103)
	 * @param fund_account 资金账号
	 * @param trade_pwd 交易密码
	 * @param callback 回调函数
	 *//*
	mobileService.fundLogin = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1001103";
		paraMap["fund_account"] = param.fund_account;
		paraMap["trade_pwd"] = param.trade_pwd;
		paraMap["ticket"] = param.vf_code;
		paraMap["mac"] = param.mac;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };*/
    /**
     * 资金账号用户登入(100006)
     * @param fund_account 资金账号
     * @param trade_pwd 交易密码
     * @param callback 回调函数
     */
	mobileService.fundLogin = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "100006";
		paraMap["fund_account"] = param.fund_account;
		paraMap["trade_pwd"] = param.trade_pwd;
		paraMap["ticket"] = param.vf_code;
		paraMap["mac"] = param.mac;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
	
	/**
	 * 查询图片信息(1000311)
	 * @Author:黎志勇
	 * @param img_class   图片所属分类
	 * @param img_type 图片类别
	 * @param img_vesting 图片归属
	 * @param callback 回调函数
	 */
	mobileService.showPic = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000311";
		paraMap["img_class"] = param.img_class;
		paraMap["img_type"] = param.img_type;
		paraMap["img_vesting"] = param.img_vesting;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
	
	/**
	 * 查询用户存管信息(1001111)
	 * @Author:黎志勇
	 * @param fund_account   资金账号
	 * @param callback 回调函数
	 */
	mobileService.accountBank = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1001111";
		paraMap["fund_account"] = param.fund_account;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
	
	/**
	 * @Author:黎志勇
	 * 用户关注查询(1000260)
	 * @param user_id 用户编号
	 * @param product_sub_type产品类别
	 * @param page 当前页数
	 * @param numPerPage 单页显示记录数
	 * @param callback 回调函数
	 */
	mobileService.queryMyAttention = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000260";
		paraMap["user_id"] = param.user_id;
		paraMap["product_sub_type"] = param.product_sub_type;
		paraMap["page"] = param.page;
		paraMap["numPerPage"] = param.numPerPage;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
	
	/**
	 * @Author:黎志勇
	 * 用户订单查询(1000238)
	 * @param user_id 用户编号
	 * @param product_sub_type产品类别
	 * @param page 当前页数
	 * @param numPerPage 单页显示记录数
	 * @param callback 回调函数
	 */
	mobileService.queryMyOrder = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000238";
		paraMap["user_id"] = param.user_id;
		paraMap["product_sub_type"] = param.product_sub_type;
		paraMap["page"] = param.page;
		paraMap["numPerPage"] = param.numPerPage;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
	
	/**
	 * @Author:黎志勇
	 * 用户订单查询(1000239)
	 * @param user_id 用户编号
	 * @param product_sub_type产品类别
	 * @param page 当前页数
	 * @param numPerPage 单页显示记录数
	 * @param callback 回调函数
	 */
	mobileService.queryUserOrder = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000239";
		paraMap["user_id"] = param.user_id;
		paraMap["product_sub_type"] = param.product_sub_type;
		paraMap["order_state"] = param.order_state;
		paraMap["page"] = param.page;
		paraMap["numPerPage"] = param.numPerPage;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
	
    /**
     * @Author:fufx
     * 兴业银行产品查询(300046)
     */
    mobileService.bankXing = function(param,callback,ctrlParam)
    {
    	var paraMap = {};
    	paraMap["funcNo"] = "300046";
//    	paraMap["entrust_way"] = "SJWT";
    	var reqParamVo = new service.ReqParamVo();
    	reqParamVo.setUrl(global.serverPath);
    	commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
	/**
	 * @Author:黎志勇
	 * 查询份额(1001609)
	 * @param fund_account 资金账号
	 * @param product_sub_type 产品类别
	 * @param page 当前页数
	 * @param numPerPage 单页显示记录数
	 * @param callback 回调函数
	 * @param isLastReq 是否最后一次请求
	 * @param isShowWait 是否显示等待层
	 */
	mobileService.queryShare = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1001609";
		paraMap["fund_account"] = param.fund_account;
		paraMap["product_sub_type"] = param.product_sub_type;
		paraMap["page"] = param.page;
		paraMap["numPerPage"] = param.numPerPage;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
	
	/**
	 * @Author:黎志勇
	 * 订单撤销(1000250)
	 * @param old_order_id 原订单编号
	 * @param callback 回调函数
	 * @param isLastReq 是否最后一次请求
	 * @param isShowWait 是否显示等待层
	 */
	mobileService.undoOrder = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000250";
		paraMap["old_order_id"] = param.old_order_id;
		paraMap["trade_pwd"] = param.trade_pwd;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    
    /**
	 * @Author:黎志勇
	 * 取消订单(1000251)
	 * @param old_order_id 原订单编号
	 * @param callback 回调函数
	 * @param isLastReq 是否最后一次请求
	 * @param isShowWait 是否显示等待层
	 */
    mobileService.cancelOrder = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000251";
		paraMap["old_order_id"] = param.old_order_id;
		paraMap["product_sub_type"] = param.product_sub_type;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Author:黎志勇
	 * 赎回(1000252)
	 * @param product_id 产品编号
	 * @param user_id 用户编号
	 * @param order_quantity 赎回份额
	 * @param order_channel 订单渠道
	 * @param money_type 币种
	 * @param trade_pwd 交易密码
	 * @param callback 回调函数
	 */
    mobileService.Redemption = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000252";
	    paraMap["product_id"] = param.product_id;
		paraMap["user_id"] = param.user_id;
		paraMap["order_quantity"] = param.order_quantity;
		paraMap["order_channel"] = param.order_channel;
		paraMap["money_type"] = param.money_type;
		paraMap["trade_pwd"] = param.trade_pwd;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Author:黎志勇
	 * 查询资金(1001113)
	 * @param fund_account   资金账号
	 * @param callback 回调函数
	 */
    mobileService.queryAsset = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1001113";
		paraMap["fund_account"] = param.fund_account;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * 获取用户风险评测试题(1000303)
	 * @Author:黎志勇
	 * @param risk_type_id 试题类号
	 * @param callback 回调函数
	 */
    mobileService.queryEval = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000303";
	    paraMap["risk_type_id"] = param.risk_type_id;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * 提交风险测评(1000304)
	 * @Author:黎志勇
	 * @param user_id 用户编号
	 * @param risk_type_id 试题类号
	 * @param content 提交数据
	 * @param callback 回调函数
	 */
    mobileService.submitTestAnswer = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000304";
		paraMap["user_id"] = param.user_id;
		paraMap["risk_type_id"] = param.risk_type_id;
		paraMap["content"] = param.content;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * 查询银证转账流水(1001108)
	 * @Author:黎志勇
	 * @param fund_account   资金账号
	 * @param page 当前页数
	 * @param numPerPage 单页显示记录数
	 * @param trans_type 转账类别
	 * 	@param bank_no   银行编号
	 * @param money_type 币种
	 * @param start_date 开始日期
	 * @param end_date 结束日期
	 * @param callback 回调函数
	 */
    mobileService.changeQuery = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1001108";
		paraMap["fund_account"] = param.fund_account;
		paraMap["page"] = param.page;
		paraMap["numPerPage"] = param.numPerPage;
		paraMap["trans_type"] = param.trans_type;
		paraMap["bank_no"] = param.bank_no;
		paraMap["money_type"] = param.money_type;
		paraMap["start_date"] = param.start_date;
		paraMap["end_date"] = param.end_date;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * 银证转账(1001107)
	 * @Author:黎志勇
	 * @param fund_account   资金账号
	 * @param trans_type 转账类别
	 * 	@param bank_no   银行编号
	 * @param fund_amount 转账金额
	 * @param fund_pwd 资金密码
	 * @param callback 回调函数
	 * @param isLastReq 是否最后一次请求
	 * @param isShowWait 是否显示等待层
	 */
    mobileService.bankTrans = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1001107";
		paraMap["fund_account"] = param.fund_account;
		paraMap["trans_type"] = param.trans_type;
		paraMap["bank_no"] = param.bank_no;
		paraMap["fund_amount"] = param.fund_amount;
		paraMap["fund_pwd"] = param.fund_pwd;
		paraMap["trade_pwd"] = param.trade_pwd;
		paraMap["bank_pwd"] = param.bank_pwd;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * 查询用户信息(1000203)
	 * @param user_id 用户编号
	 * @param account_name 账户名
	 * @param callback 回调函数
	 * @param isLastReq 是否最后一次请求
	 * @param isShowWait 是否显示等待层
	 */
    mobileService.queryUserInfo = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000203";
		paraMap["user_id"] = param.user_id;
		paraMap["account_name"] = param.account_name;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * 修改用户信息(1000205)
	 * @Author:黎志勇
	 * @param user_id   用户编号
	 * @param user_name 用户姓名
	 * @param nick_name 用户昵称
	 * @param gender   性别
	 * @param birthday  生日
	 * @param identity_type 证件类型
	 * @param identity_num  证件号码
	 * @param mobile_phone 手机号码
	 * @param user_mail 邮箱
	 * @param telephone   固定电话
	 * @param address  通信地址
	 * @param post_code 邮编
	 * @param qq_microblog   QQ微博
	 * @param qq_microblog_uid QQ微博UID
	 * @param sina_microblog 新浪微博账号
	 * @param sina_microblog_uid   新浪微博UID
	 * @param qq  QQ号
	 * @param qq_uid QQ_UID 
	 * @param wechat  微信
	 * @param weixin_uid 微信UID 
	 * @param update_time  信息更新时间
	 * @param callback 回调函数
	 */
    mobileService.submitInfo = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000205";
		paraMap["user_id"] = param.user_id;
		paraMap["user_name"] = param.user_name;
		paraMap["nick_name"] = param.nick_name;
		paraMap["gender"] = param.gender;
		paraMap["birthday"] = param.birthday;
		paraMap["identity_type"] = param.identity_type;
		paraMap["identity_num"] = param.identity_num;
		paraMap["mobile_phone"] = param.mobile_phone;
		paraMap["user_mail"] = param.user_mail;
		paraMap["address"] = param.address;
		paraMap["telephone"] = param.telephone;
		paraMap["post_code"] = param.post_code;
		paraMap["qq_microblog"] = param.qq_microblog;
		paraMap["qq_microblog_uid"] = param.qq_microblog_uid;
		paraMap["sina_microblog"] = param.sina_microblog;
		paraMap["sina_microblog_uid"] = param.sina_microblog_uid;
		paraMap["qq"] = param.qq;
		paraMap["qq_uid"] = param.qq_uid;
		paraMap["wechat"] = param.wechat;
		paraMap["weixin_uid"] = param.weixin_uid;
		paraMap["update_time"] = param.update_time;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 查询理财产品信息(分页列表)(1000240)
	 * @param product_shelf :上架状态
	 * @param page：当前页数
	 * @param numPerPage ：单页显示记录数
	 * @param recommend_type :推荐属性   1首页推荐 2购买推荐
	 * @param fina_type：理财分类  0低风险  1高风险  2理财类  3混合型  4现金类
	 * @param is_hot_sale 是否按照热销排序  1排序 0或其他不排
	 * @param callback 回调函数
	 */
    mobileService.findFinan = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="1000240";
		paraMap["product_shelf"]=param.product_shelf;
		paraMap["page"]=param.page;
		paraMap["numPerPage"]=param.numPerPage;
		paraMap["recommend_type"]=param.recommend_type;
		paraMap["fina_type"]=param.fina_type;
		paraMap["is_hot_sale"]=param.is_hot_sale;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 查询基金产品信息(分页列表)(1000241)
	 * @param product_shelf :上架状态
	 * @param comp_ecommend_type:组合产品推荐  1 进取型组合推荐 2 保守型组合推荐 3 稳定型组合推荐
	 * @param recommend_type :推荐属性   1首页推荐 2购买推荐
	 * @param fund_type：基金类型
	 * @param register_corp_code :基金公司
	 * @param risk_level: 风险等级
	 * @param amount : 基金规模
	 * @param create_time : 成立时间  时间格式yyyy-MM-dd
	 * @param page：当前页数
	 * @param numPerPage ：单页显示记录数
	 * @param is_hot_sale 是否按照热销排序  1排序 0或其他不排
	 * @param callback 回调函数
	 */
    mobileService.findFund = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="1000241";
		paraMap["comp_ecommend_type"]=param.comp_ecommend_type;
		paraMap["recommend_type"]=param.recommend_type;
		paraMap["fund_type"]=param.fund_type;
		paraMap["register_corp_code"]=param.register_corp_code;
		paraMap["risk_level"]=param.risk_level;
		paraMap["amount"]=param.amount;
		paraMap["create_time"]=param.create_time;
		paraMap["is_nav"]=param.is_nav;
		paraMap["performance_sort"]=param.performance_sort;
		paraMap["product_performance"]=param.product_performance;
		paraMap["page"]=param.page;
		paraMap["numPerPage"]=param.numPerPage;
		paraMap["is_hot_sale"]=param.is_hot_sale;
		paraMap["product_shelf"]=param.product_shelf;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		paraMap["product_status"] = "y";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 查询咨询产品信息(分页列表)(1000242)
	 * @param product_shelf :上架状态
	 * @param page：当前页数
	 * @param numPerPage ：单页显示记录数
	 * @param recommend_type :推荐属性   1首页推荐 2购买推荐
	 * @param brand_id :品牌编号
	 * @param is_hot_sale 是否按照热销排序  1排序 0或其他不排
	 * @param info_type 资讯产品类别
	 * @param father_product_id 父产品编号
	 * @param callback 回调函数
	 * @param isLastReq 是否最后一次请求
	 * @param isShowWait 是否显示等待层
	 */
    mobileService.findInfo = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="1000242";
		paraMap["product_shelf"]=param.product_shelf;
		paraMap["page"]=param.page;
		paraMap["numPerPage"]=param.numPerPage;
		paraMap["recommend_type"]=param.recommend_type;
		paraMap["brand_id"]=param.brand_id;
		paraMap["is_hot_sale"]=param.is_hot_sale;
		paraMap["info_type"]=param.info_type;
		paraMap["father_product_id"]=param.father_product_id;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Author:黎志勇
	 * @Title 查询服务产品信息(分页列表)(1000249)
	 * @param product_shelf :上架状态
	 * @param page：当前页数
	 * @param numPerPage ：单页显示记录数
	 * @param callback 回调函数
	 */
    mobileService.findService = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="1000249";
		paraMap["product_shelf"]=param.product_shelf;
		paraMap["page"]=param.page;
		paraMap["numPerPage"]=param.numPerPage;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 查询服务产品信息(分页列表)(1000249)
	 * @param product_shelf :上架状态
	 * @param page：当前页数
	 * @param numPerPage ：单页显示记录数
	 * @param recommend_type :推荐属性   1首页推荐 2购买推荐
	 * @param is_hot_sale 是否按照热销排序  1排序 0或其他不排
	 * @param callback 回调函数
	 */
    mobileService.findServ = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="1000249";
		paraMap["product_shelf"]=param.product_shelf;
		paraMap["page"]=param.page;
		paraMap["numPerPage"]=param.numPerPage;
		paraMap["recommend_type"]=param.recommend_type;
		paraMap["is_hot_sale"]=param.is_hot_sale;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 查询理财产品信息(单个)(1000243)
	 * @param product_id 产品编号
	 * @param product_sub_type
	 */
    mobileService.finanInfo = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="1000243";
		paraMap["product_id"]=param.product_id;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Author:龙沅文
	 * @Title 查询基金产品信息(单个)(1000244)
	 * @param product_id 产品编号
	 */
    mobileService.fundInfo = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="1000244";
		paraMap["product_id"]=param.product_id;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 查询服务产品信息(单个)(1000248)
	 * @param product_id   产品编号
	 * @param rules_id     规则编号
	 * @param service_type 服务方式
	 */
    mobileService.findServInfo = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="1000248";
		paraMap["product_id"]=param.product_id;
		paraMap["rules_id"]=param.rules_id;
		paraMap["service_type"]=param.service_type;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 查询咨询产品信息(单个)(1000245)
	 * @param product_id   产品编号
	 * @param rules_id     规则编号
	 * @param service_type 服务方式
	 */
    mobileService.findInfoDetail = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="1000245";
		paraMap["product_id"]=param.product_id;
		paraMap["rules_id"]=param.rules_id;
		paraMap["service_type"]=param.service_type;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 查询价格规则和服务方式(1000247)(非金融产品)
	 * @param product_id   产品编号
	 */
    mobileService.findPriceRule = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="1000247";
		paraMap["product_id"]=param.product_id;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 新增关注(1000261)
	 * @param user_id   用户编号
	 * @param product_sub_type 产品类别
	 * @param product_id  产品编号
	 */
    mobileService.addAttention = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000261";
		paraMap["user_id"] = param.user_id;
		paraMap["product_sub_type"] = param.product_sub_type;
		paraMap["product_id"] = param.product_id;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 取消关注(1000262)
	 * @param user_id  用户编号
	 * @param product_id 产品编号
	 */
    mobileService.cancerAttention = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000262";
		paraMap["user_id"] = param.user_id;
		paraMap["product_id"] = param.product_id;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 用户关注查询(1000260)
	 * @param user_id  用户编号
	 * @param product_sub_type  产品类别
	 * @param page  当前页
	 * @param numPerPage  每页显示多少条数据
	 *
	 */
    mobileService.userAttentionFind = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000260";
		paraMap["user_id"] = param.user_id;
		paraMap["product_sub_type"] = param.product_sub_type;
		paraMap["page"] = param.page;
		paraMap["numPerPage"] = param.numPerPage;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**@time 2016-4-29 15:22:55
	 * @Title 理财购买(10002320)
	 * @param product_id 产品编号
	 * @param user_id  用户编号
	 * @param tot_price 购买金额
	 */
    mobileService.finanPuy = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "10002320";
		paraMap["product_id"] = param.product_id;
		paraMap["user_id"] = param.user_id;
		paraMap["tot_price"] = param.tot_price;
		paraMap["risk_level"] = param.risk_level;
		paraMap["order_channel"] = param.order_channel;
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
/*    *//**
     * @Title 理财购买(1000232)
     * @param product_id 产品编号
     * @param user_id  用户编号
     * @param tot_price 购买金额
     *//*
    mobileService.finanPuy = function(param,callback,ctrlParam)
    {
    	var paraMap = {};
    	paraMap["funcNo"] = "1000232";
    	paraMap["product_id"] = param.product_id;
    	paraMap["user_id"] = param.user_id;
    	paraMap["tot_price"] = param.tot_price;
    	paraMap["order_channel"] = param.order_channel;
    	paraMap["phone"] = getPhone();
    	paraMap["entrust_way"] = "SJWT";
    	
    	var reqParamVo = new service.ReqParamVo();
    	reqParamVo.setUrl(global.serverPath);
    	commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
*/    
    /**
	 * @Title 基金购买(1000231)
	 * @param product_id 产品编号
	 * @param user_id  用户编号
	 * @param tot_price 购买金额
	 */
    mobileService.fundPuy = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000231";
		paraMap["product_id"] = param.product_id;
		paraMap["user_id"] = param.user_id;
		paraMap["tot_price"] = param.tot_price;
		paraMap["order_channel"] = param.order_channel;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 支付订单 (1000234)(金融产品)
	 * @param order_id 订单编号
	 * @param fund_account  资金账号
	 * @param trade_pwd   交易密码
	 */
    mobileService.orderPayment = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000234";
		paraMap["order_id"] = param.order_id;
		paraMap["fund_account"] = param.fund_account;
		paraMap["trade_pwd"] = param.trade_pwd;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 支付订单 (1000257)(非金融产品)  注:后期可能后修改
	 * @param order_id 		订单编号
	 * @param fund_account  资金账号
	 * @param trade_pwd     交易密码
	 */
    mobileService.orderOtherPayment = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000257";
		paraMap["order_id"] = param.order_id;
		paraMap["fund_account"] = param.fund_account;
		paraMap["trade_pwd"] = param.trade_pwd;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 金融订单查询(1000236)
	 * @param user_id:用户id
	 * @param order_id：订单id
	 * @param product_sub_type：产品类别
	 */
   mobileService.getFinancialOrder = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000236";
		paraMap["user_id"] =param.user_id;
		paraMap["order_id"] =param. order_id;
		paraMap["product_sub_type"] = param.product_sub_type; //可不传
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    /**
     * @Title 开通柜台基金账户(500010)
     */
    mobileService.fundAccount  = function(param,callback,ctrlParam)
    {
    	var paraMap = {};
    	paraMap["funcNo"] = "500010";
    	paraMap["fund_account"] =param.fund_account;
    	paraMap["product_code"] =param. product_code;
 //   	paraMap["mac"] =param. mac;
    	paraMap["entrust_way"] = "SJWT";
    	
    	var reqParamVo = new service.ReqParamVo();
    	reqParamVo.setUrl(global.serverPath);
    	commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Author:龙沅文:
	 * @Title 非金融订单查询(1000237)
	 * @param user_id:用户id
	 * @param order_id：订单id
	 * @param product_sub_type：产品类别
	 */
    mobileService.getOtherOrder = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000237";
		paraMap["user_id"] =param.user_id;
		paraMap["order_id"] =param. order_id;
		paraMap["product_sub_type"] = param.product_sub_type;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 查询签署(1000305)(金融产品，非金融产品)   注：两类产品调同一接口，只需根据传入的产品编号（product_id）查询出不同的协议
	 * @param product_id 产品编号
	 * @param user_id  用户编号
	 */
    mobileService.findAgreement = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000305";
		paraMap["product_id"] = param.product_id;
		paraMap["user_id"] = param.user_id;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    /**
	 * @Title 查询签署(500011)(金融产品，非金融产品)   
	 */
    mobileService.showSign = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "500011";
		paraMap["inst_id"] = param.inst_id;
		paraMap["tran_type"] = param.tran_type;
//		paraMap["cust_code"] = param.cust_code;
//		paraMap["ticket"] = param.ticket;
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    /**
	 * @Title 签署协议(1000306)(金融产品)
	 * @param product_id 产品编号
	 * @param agreement_id  协议编号
	 * @param user_id  用户编号
	 */
  /*  mobileService.signAgreement = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000306";
		paraMap["product_id"] = param.product_id;
		paraMap["user_id"] = param.user_id;
		paraMap["agreement_id"] = param.agreement_id;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };*/
    /**
     * @Title 签署协议(500005)(金融产品)
     */
    mobileService.signAgreement= function(param,callback,ctrlParam)
    {
    	var paraMap = {};
    	paraMap["funcNo"] = "500005";
    	paraMap["cust_code"] = param.cust_code;
    	paraMap["fund_account"] = param.fund_account;//资金账号
    	paraMap["pro_code"] = param.pro_code;
    	paraMap["ticket"] = param.ticket;
    	paraMap["mobile"] = param.mobile;
    	paraMap["mobile_channel"] = param.mobile_channel;
    	paraMap["entrust_way"] = "SJWT";
	    paraMap["com_sign"] =param.com_sign;
	    paraMap["sign_mode"] =  param.sign_mode;
	    paraMap["risk_uncover"] = param.risk_uncover;
    	var reqParamVo = new service.ReqParamVo();
    	reqParamVo.setUrl(global.serverPath);
    	commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 判断协议是否签署(1000305)(非金融产品)
	 * @param product_id 产品编号
	 * @param user_id  用户编号
	 */
    mobileService.isAgreement = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000305";
		paraMap["product_id"] = param.product_id;
		paraMap["user_id"] = param.user_id;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 签署协议(1000306)(非金融产品)
	 * @param product_id 产品编号
	 * @param product_sub_type  产品类型
	 * @param user_id  用户编号
	 */
    mobileService.signOtherAgreement = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
        paraMap["funcNo"] = "1000306";
		paraMap["product_id"] = param.product_id;
		paraMap["user_id"] = param.user_id;
		paraMap["product_sub_type"] = param.product_sub_type;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * 查询理财产品信息(1000240)分页
	 * @param product_shelf   上架状态
	 * @param page 当前页数
	 * @param numPerPage 单页显示记录数
	 * @param recommend_type   推荐属性(1首页推荐 2购买推荐 )
	 * @param fina_type  理财分类( 0低风险  1高风险  2理财类  3混合型  4现金类 )
	 * @param is_hot_sale 是否按照热销排序 1排序 0或其他不排（按照销量排序  热销推荐）
	 * @param callback 回调函数
	 * @param isLastReq 是否最后一次请求
	 * @param isShowWait 是否显示等待层
	 */
    mobileService.getFinancialProduct = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000240";
		paraMap["product_shelf"] = param.product_shelf;
		paraMap["page"] = param.page;
		paraMap["numPerPage"] = param.numPerPage;
		paraMap["recommend_type"] = param.recommend_type;
		paraMap["fina_type"] = param.fina_type;
		paraMap["is_hot_sale"] = param.is_hot_sale;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 银行理财产品判断是否是首次购买(1001900)
	 * @param fund_account 资金账号
	 * @param product_id 产品编号
	 * @param product_code 产品代码
	 * @param product_sub_type 产品类型
	 */
    mobileService.isFirstBuyFinan = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1001900";
		paraMap["product_id"] = param.product_id;
		paraMap["fund_account"] = param.fund_account;
		paraMap["product_code"]=param.product_code;
		paraMap["product_sub_type"]=param.product_sub_type;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 基金产品判断是否是首次购买(1001611)
	 * @param fund_account 资金账号
	 * @param product_id 产品编号
	 */
    mobileService.isFirstBuyFund = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1001611";
		paraMap["product_id"] = param.product_id;
		paraMap["fund_account"] = param.fund_account;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 加密(1000000)
	 */
    mobileService.getRSAKey = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000000";
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Author:lzy
	 * @param :user_id 用户编号
	 * @param :product_id 产品编号
	 * @Title 获取是否需要密码
	 */
    mobileService.queryPwd = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1001112";
		paraMap["bank_no"] = param.bank_no;
		paraMap["trans_type"] = param.trans_type;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    /**
     * 500006：产品适当性匹配 (金融产品)
     * 
     */
    mobileService.appropriateMatch = function(param,callback,ctrlParam)
    {
    	var paraMap = {};
    	paraMap["funcNo"]="500006";
    	paraMap["cust_code"]=param.cust_code;
    	paraMap["fund_account"]=param.fund_account;
    	paraMap["tran_type"]=param.tran_type;
    	paraMap["inst_id"]=param.inst_id;
    	paraMap["ticket"]=param.ticket;
    	paraMap["entrust_way"] = "SJWT";
    	
    	var reqParamVo = new service.ReqParamVo();
    	reqParamVo.setUrl(global.serverPath);
    	commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 检测是否可以提交订单 (金融产品)
	 * @param :user_id 用户编号
	 * @param :product_id 产品编号
	 * 
	 */
    mobileService.checkOrderSubmit = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000258";
		paraMap["user_id"] = param.user_id;
		paraMap["product_id"] = param.product_id;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    /**
     * @Title 广告查询902001
     * @time 2016-5-25 16:58:05
     * @author fufx
     * 
     */
    mobileService.sosAdv = function(param,callback,ctrlParam)
    {
    	var paraMap = {};
    	paraMap["funcNo"] = "902001";
    	paraMap["group_no"] = param.group_no;
    	paraMap["channel"] = param.channel;
    
//    	paraMap["entrust_way"] = "SJWT";
    	
    	var reqParamVo = new service.ReqParamVo();
    	reqParamVo.setUrl(global.serverPath);
    	commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title :检测是否可以提交订单 (非金融产品)(1000259)
	 * @param :user_id 用户编号
	 * @param :product_id 产品编号
	 */
    mobileService.checkOthorOrderSubmit = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000259";
		paraMap["user_id"] = param.user_id;
		paraMap["product_id"] = param.product_id;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 服务产品购买 (1000230)
	 * @param :user_id 用户编号
	 * @param :product_id	产品编号
	 * @param :rules_id	价格规则编号
	 * @param :service_type	服务规则
	 * @param :order_quantity  数量
	 */
    mobileService.servBuy = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000230";
		paraMap["user_id"] = param.user_id;
		paraMap["product_id"] = param.product_id;
		paraMap["rules_id"] = param.rules_id;
		paraMap["service_type"] = param.service_type;
		paraMap["order_quantity"] = param.order_quantity;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 咨询产品购买 (1000233)
	 * @param :user_id 用户编号
	 * @param :product_id	产品编号
	 * @param :rules_id	价格规则编号
	 * @param :service_type	服务规则
	 * @param :order_quantity  数量
	 */
    mobileService.infoBuy = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000233";
		paraMap["user_id"] = param.user_id;
		paraMap["product_id"] = param.product_id;
		paraMap["rules_id"] = param.rules_id;
		paraMap["service_type"] = param.service_type;
		paraMap["order_quantity"] = param.order_quantity;
		paraMap["order_channel"] = param.order_channel;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 非金融产品交易时间校准 (1000301)
	 * @param :data 时间
	 */
    mobileService.dealTimeSyn = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000301";
		paraMap["data"] = param.data;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Title 填写电话邮箱 (1000253)
	 * @param order_id 订单编号
	 * @param user_mail 邮箱
	 * @param mobile_phone 电话
	 */
    mobileService.mobile_phoneOrUser_mailInfo = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000253";
		paraMap["order_id"] = param.order_id;
		paraMap["user_mail"] = param.user_mail;
		paraMap["mobile_phone"] = param.mobile_phone;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Author:黎志勇
	 * @Title 查询基金产品(基金对比时用) (1000330)
	 * @param product_code 产品编号
	 * @param product_name 产品名称
	 * @param product_shelf 产品上架状态
	 */
    mobileService.queryFundList = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000330";
		paraMap["product_code"] = param.product_code;
		paraMap["product_name"] = param.product_name;
		paraMap["product_shelf"] = param.product_shelf;
		paraMap["product_sub_type"] = param.product_sub_type;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Author:黎志勇
	 * @Title 退出登入 (1000001)
	 */
    mobileService.loginOut = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1000001";
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * @Author:黎志勇
	 * @Title 基金分红 (1001602)
	 */
    mobileService.setFh = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "1001602";
		paraMap["fund_account"] = param.fund_account;
		paraMap["product_id"] = param.product_id;
		paraMap["product_code"] = param.product_code;
		paraMap["operation_type"] = param.operation_type;
		paraMap["fenhong_type"] = param.fenhong_type;
		paraMap["phone"] = getPhone();
		paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
	 * 短信验证码发送(501600)
	 * @param op_way 访问接口来源标识(0：pc,2：pad,3：手机)
	 * @param mobile_no 手机号码
	 * @param ip 客户IP地址
	 * @param mac 设备mac地址
	 * @param callback 回调函数
	 * @param isLastReq 是否最后一次请求
	 * @param isShowWait 是否显示等待层
	 */
    mobileService.getSmsCode = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "501600";
		paraMap["op_way"] = param.op_way;
		paraMap["verify_code"] = param.verify_code;
		paraMap["mobile_no"] = param.mobile_no;
		paraMap["ip"] = param.ip;
		paraMap["mac"] = param.mac;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
 	 * 登录短信验证码校验(501521)
 	 * @param mobile_no 手机号码
 	 * @param mobile_code 手机验证码
 	 * @param login_flag 登录业务标准
 	 * @param callback 回调函数
 	 */
    mobileService.checkSmsCode = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "501521";
 		paraMap["mobile_no"] = param.mobile_no;
 		paraMap["mobile_code"] = param.mobile_code;
 		paraMap["login_flag"] = param.login_flag;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 手机绑定(901930)
     * @param phone 手机号码
     * @param hardsn 硬件信息
     * @param callback 回调函数
     */
    mobileService.bindMobile = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"] = "901930";
	  	paraMap["phone"] = param.phone;
	  	paraMap["hardsn"] = param.hardsn;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 增加推荐人(1001901)
     * @param order_id 订单编号
     * @param referrer_name 推荐人姓名
     * @param referrer_code 推荐人代码
     * @param callback 回调函数
     */
    mobileService.addReferrer = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="1001901";
    	paraMap["order_id"]=param.order_id;
    	paraMap["referrer_name"]=param.referrer_name;
    	paraMap["referrer_code"]=param.referrer_code;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
	
    /********************************应用接口结束********************************/
    
    
    /**
     * 1002000：知识问卷内容查询   
     * 
     */
    mobileService.questionnaireSurvey = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="1002000";
    	  paraMap["productCode"]=param.productCode;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    
    /**
     * 1002001：知识问卷测评提交
     * 
     */
    mobileService.assessmentSubmitted = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="1002001";
    	  paraMap["productCode"]=param.productCode;
    	  paraMap["ass_answers"]=param.ass_answers;
    	  paraMap["account"]=param.account;
    	  paraMap["item_id"]=param.item_id;
    	  paraMap["question_id"]=param.question_id;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 1002002：知识问卷测评查询
     * 
     */
    mobileService.justEvaluation = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="1002002";
    	  paraMap["productCode"]=param.productCode;
    	  paraMap["account"]=param.account;
    	  
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /********************************20150723应用接口开始********************************/
    
    /**
     * 2000005：OTC推荐产品查询
     * 
     */
    mobileService.getOTCProduct = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="2000005";
    	  paraMap["rec_type"]=param.rec_type;
    	  paraMap["rownum"]=param.rownum;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     *3000001：推荐产品查询
     *@fufx
     * 
     */
    mobileService.getProduct = function(param,callback,ctrlParam)
    {
    	var paraMap = {};
    	paraMap["funcNo"]="3000001";
     	paraMap["assortment_id"]=param.assortment_id;   
   //  	paraMap["id"]=param.id;   

    	
    	var reqParamVo = new service.ReqParamVo();
    	reqParamVo.setUrl(global.serverPath);
    	commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    /**
     *3000002：推荐产品模块数查询
     *@fufx
     * 
     */
    mobileService.getProductNO = function(param,callback,ctrlParam)
    {
    	var paraMap = {};
    	paraMap["funcNo"]="3000002";
  //  	paraMap["assortment_id"]=param.assortment_id;   
    	//  	paraMap["id"]=param.id;   
    	var reqParamVo = new service.ReqParamVo();
    	reqParamVo.setUrl(global.serverPath);
    	commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 200018：客户电子协议签署查询
     * 
     */
    mobileService.queryOTCAgreement = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="200018";
    	  paraMap["cust_code"]=param.cust_code;
    	  paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 200015：otc风险测评提交
     * 
     */
    mobileService.submitOTCAnswer = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="200015";
    	paraMap["cust_code"]=param.cust_code;
    	paraMap["content"]=param.content;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 200016：客户电子协议签署
     * 
     */
    mobileService.signOTCAgreement = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="200016";
    	  paraMap["cust_code"]=param.cust_code;
    	  paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 200017：风险测评结果
     * 
     */
    mobileService.otcRiskResult = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="200017";
    	paraMap["cust_code"]=param.cust_code;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 200005：OTC支付账户开户
     * 
     */
    mobileService.otcOpenAcco = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="200005";
    	paraMap["cust_code"]=param.cust_code;
    	paraMap["int_org"]=param.int_org;
    	paraMap["cuacct_code"]=param.cuacct_code;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     *开户(500010)
     * 
     */
 /*   mobileService.OpenAcco = function(param,callback,ctrlParam)
    {
    	var paraMap = {};
    	paraMap["funcNo"]="500010";
    	paraMap["product_code"]=param.product_code;
    	paraMap["fund_account"]=param.fund_account;
    	paraMap["entrust_way"]=param.entrust_way;
    	paraMap["mac"]=param.mac;
    	
    	var reqParamVo = new service.ReqParamVo();
    	reqParamVo.setUrl(global.serverPath);
    	commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };*/
    
    /**
     * 2000001：查询otc理财产品信息列表
     * 
     */
    mobileService.findOTC = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="2000001";
	    paraMap["cust_code"]=param.cust_code;
    	paraMap["product_shelf"]=param.product_shelf;
    	paraMap["is_hot_sale"]=param.is_hot_sale;
    	paraMap["inst_type"]=param.inst_type;
    	paraMap["inst_code"]=param.inst_code;
    	paraMap["iss_stat"]=param.iss_stat;
    	paraMap["otherpro"]=param.otherpro;
    	paraMap["risk_lvl"]=param.risk_lvl;
    	paraMap["est_yield"]=param.est_yield;
    	paraMap["pro_deadline"]=param.pro_deadline;
    	paraMap["iss_bgn_date"]=param.iss_bgn_date;
    	paraMap["iss_end_date"]=param.iss_end_date;
    	paraMap["ent_buy_limit"]=param.ent_buy_limit;
    	paraMap["ent_add_buy"]=param.ent_add_buy;
    	paraMap["last_net"]=param.last_net;
    	paraMap["page"]=param.page;
    	paraMap["numPerPage"]=param.numPerPage;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 2000003：根据产品id查询otc理财产品信息
     * 
     */
    mobileService.OTCInfo = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="2000003";
    	paraMap["product_id"]=param.product_id;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 300041：产品购买权限判断
     * 
     */
    mobileService.buyRight = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="300041";
    	paraMap["product_id"]=param.product_id;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 300037：OTC理财产品协议签署
     * 
     */
    mobileService.otcAgreementSign= function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="300037";
    	paraMap["cust_code"]=param.cust_code;
    	paraMap["product_id"]=param.product_id;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 300030：OTC理财产品协议内容
     * 
     */
    mobileService.otcAgreementContent = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="300030";
    	paraMap["cust_code"]=param.cust_code;
    	paraMap["product_id"]=param.product_id;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 2000004：购买OTC理财产品（下订单）
     * 
     */
    mobileService.otcBuy = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="2000004";
    	paraMap["cust_code"]=param.cust_code;
    	paraMap["product_id"]=param.product_id;
    	paraMap["cuacct_code"]=param.cuacct_code;
    	paraMap["trd_amt"]=param.trd_amt;
    	paraMap["risk_reveal_method"]=param.risk_reveal_method;
    	paraMap["order_channel"]=param.order_channel;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 300010：客户风险等级匹配查询
     * 
     */
    mobileService.riskLevelMatch = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="300010";
    	paraMap["cust_code"]=param.cust_code;
    	paraMap["ta_code"]=param.ta_code;
    	paraMap["iss_code"]=param.iss_code;
    	paraMap["inst_code"]=param.inst_code;
    	paraMap["inst_id"]=param.inst_id;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 300027：OTC订单查询
     * 
     */
    mobileService.getOTCOrder = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="300027";
    	paraMap["order_id"]=param.order_id;
    	paraMap["ticket"]=param.ticket;
    	/*paraMap["user_id"]=param.user_id;*/
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 300002：申购（输入交易密码确认）订单
     * 
     */
    mobileService.otcOrderPayment = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="300002";
    	paraMap["order_id"]=param.order_id;
    	paraMap["trade_pwd"]=param.trade_pwd;
    	paraMap["fund_account"]=param.fund_account;
    	paraMap["entrust_way"]="SJWT";
    	paraMap["order_channel"]=param.order_channel;
    	paraMap["mobile"]=param.mobile;
    	paraMap["mobile_num"]=param.mobile_num;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 200004：OTC支付账户信息查询
     * 
     */
    mobileService.otcAccoInfo = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="200004";
    	paraMap["cust_code"]=param.cust_code;
    	paraMap["cuacct_code"]=param.cuacct_code;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 200003：OTC交易账户信息查询
     * 
     */
    mobileService.otcTradeAccoInfo = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="200003";
    	paraMap["cust_code"]=param.cust_code;
    	paraMap["ta_code"]=param.ta_code;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 300032：我的订单查询
     * 
     */
    mobileService.otcOrderInfo = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="300032";
    	paraMap["user_code"]=param.user_code;
    	/*paraMap["order_id"]=param.order_id;*/
    	paraMap["page"]=param.page;
    	paraMap["numPerPage"]=param.numPerPage;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 300035：otc订单取消
     * 
     */
    mobileService.otcCancelOrder = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="300035";
    	paraMap["order_id"]=param.order_id;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 300006：otc订单撤单
     * 
     */
    mobileService.otcUndoOrder = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="300006";
    	paraMap["order_id"]=param.order_id;
    	paraMap["trade_pwd"]=param.trade_pwd;
    	paraMap["fund_account"]=param.fund_account;
    	paraMap["entrust_way"]="SJWT";
    	paraMap["order_channel"]="7";
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 300031：产品份额汇总查询(我的产品)
     * 
     */
    mobileService.otcProduct = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="300031";
    	paraMap["user_code"]=param.user_code;
    	paraMap["page_recnum"]=param.page_recnum;
    	paraMap["page_reccnt"]=param.page_reccnt;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 300023：三方存管可用资金查询
     * 
     */
    mobileService.useableMoney = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="300023";
	    paraMap["cust_code"]=param.cust_code;
    	paraMap["order_channel"]="7";
    	paraMap["mobile"]=param.mobile;
    	paraMap["mobile_num"]=param.mobile_num;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 300033：otc赎回
     * 
     */
    mobileService.otcRedemption = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="300033";
    	paraMap["cust_code"]=param.cust_code;
    	paraMap["cuacct_code"]=param.cuacct_code;
    	paraMap["ta_code"]=param.ta_code;
    	paraMap["ta_acct"]=param.ta_acct;
    	paraMap["trans_acct"]=param.trans_acct;
    	paraMap["iss_code"]=param.iss_code;
    	paraMap["inst_code"]=param.inst_code;
    	paraMap["trd_qty"]=param.trd_qty;
    	paraMap["inst_id"]=param.inst_id;
    	paraMap["trade_pwd"]=param.trade_pwd;
    	paraMap["entrust_way"]="SJWT";
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 300008：产品分红业务设置
     * 
     */
    mobileService.otcFH = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="300008";
    	paraMap["cust_code"]=param.cust_code;
    	paraMap["cuacct_code"]=param.cuacct_code;
    	paraMap["ta_code"]=param.ta_code;
    	paraMap["ta_acct"]=param.ta_acct;
    	paraMap["trans_acct"]=param.trans_acct;
    	paraMap["inst_code"]=param.inst_code;
    	paraMap["inst_id"]=param.inst_id;
    	paraMap["div_method"]=param.div_method;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 300025：OTC交易账户开户
     * 
     */
    mobileService.otcTradeOpenAcco = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="300025";
    	paraMap["user_code"]=param.cust_code;
    	paraMap["int_org"]=param.int_org;
    	paraMap["dft_cuacct_code"]=param.dft_cuacct_code;
    	paraMap["ta_code"]=param.ta_code;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 300022：查询柜台电子合同信息
     * 
     */
    mobileService.queryEleContract = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="300022";
	    paraMap["cust_code"]=param.cust_code;
    	paraMap["iss_code"]=param.iss_code;
    	paraMap["inst_code"]=param.inst_code;
    	paraMap["inst_id"]=param.inst_id;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 500001：获取调查问卷题目
     * 
     */
    mobileService.queryWj = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="500001";
	    paraMap["survey_sn"]=param.survey_sn;
    	paraMap["ticket"]=param.ticket;
    	paraMap["cust_code"]=param.cust_code;

		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 500012：查询现金宝电子合同
     * 
     */
    mobileService.queryxjb_pros = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="500012";

		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
/*    *//**
     * 200020：获取调查问卷题目
     * 
     *//*
    mobileService.queryWj = function(param,callback,ctrlParam)
    {
    	var paraMap = {};
    	paraMap["funcNo"]="200020";
    	paraMap["survey_sn"]=param.survey_sn;
    	paraMap["ticket"]=param.ticket;
    	
    	var reqParamVo = new service.ReqParamVo();
    	reqParamVo.setUrl(global.serverPath);
    	commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
*/    /**
     *500002：提交调查问卷信息
     * 
     */
    mobileService.submitWj = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="500002";
	    paraMap["cust_code"]=param.cust_code;
    	paraMap["content"]=param.content;
	    paraMap["survey_sn"]=param.survey_sn;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
      /**
    * 200021：提交调查问卷信息
    * 
    *//*
    mobileService.submitWj = function(param,callback,ctrlParam)
    {
    	var paraMap = {};
    	paraMap["funcNo"]="200021";
    	paraMap["cust_code"]=param.cust_code;
    	paraMap["content"]=param.content;
    	paraMap["survey_sn"]=param.survey_sn;
    	paraMap["ticket"]=param.ticket;
    	
    	var reqParamVo = new service.ReqParamVo();
    	reqParamVo.setUrl(global.serverPath);
    	commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };*/
    
    /********************************20150723应用接口结束********************************/
    
    /********************************20151126应用适当性接口开始********************************/
    /**
     * 500001：试题题库查询
     *  @param survey_sn 登记机构（默认1001）
     *  @param number 分页起始记录号
     *  @param survey_col 分页起始记录号
     */
    mobileService.queryTestQuestion = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="500001";
	    paraMap["cust_code"]=param.cust_code;
	    paraMap["survey_sn"]=param.survey_sn;
    	paraMap["ticket"]=param.ticket;
    	paraMap["number"]=param.number;
    	paraMap["survey_col"]=param.survey_col;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 500002：客户问卷作答录入
     * @param cust_code 客户代码
	 * @param survey_sn 调查表编码
	 * @param cust_status	客户状态
	 * @param	 content  作答明细 
	 *	@param survey_col 题目编码
	 *	@param survey_cells 答案编号
	 *	@param ticket 票据
	 *	@param cust_type 0：个人 ； 1：机构
     */
    mobileService.submitQuestionAnswer = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="500002";
	    paraMap["cust_code"]=param.cust_code;
    	paraMap["content"]=param.content;
	    paraMap["survey_sn"]=param.survey_sn;
    	paraMap["ticket"]=param.ticket;
    	paraMap["cust_status"]=param.cust_status;
    	paraMap["survey_col"]=param.survey_col;
    	paraMap["survey_cells"]=param.survey_cells;
    	paraMap["user_type"]=param.user_type;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 500003：客户风险测评结果查询
     * 
     */
    mobileService.newRiskResult = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="500003";
	    paraMap["cust_code"]=param.cust_code;
	    paraMap["survey_sn"]=param.survey_sn;
    	paraMap["ticket"]=param.ticket;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 500004：客户已经签署的协议查询
     * @param pro_type 0:业务开通协议书,1:理财协议,2:电子约定书,3:电子合同,4:风险揭示书；5：柜台市场客户协议；6：委托方式协议书,7:资讯免责说明书；8：权限开通协议书
     * @param pro_code 协议编号
     */
    mobileService.querySingedAgreement = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="500004";
	    paraMap["cust_code"]=param.cust_code;
	    paraMap["pro_type"]=param.pro_type;
	    paraMap["pro_code"]=param.pro_code;
    	paraMap["ticket"]=param.ticket;
    	paraMap["entrust_way"] = "SJWT";
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    /**OTC签署的协议查询
     * @param pro_type 0:业务开通协议书,1:理财协议,2:电子约定书,3:电子合同,4:风险揭示书；5：柜台市场客户协议；6：委托方式协议书,7:资讯免责说明书；8：权限开通协议书
     * @param pro_code 协议编号
     */
    mobileService.OTCquerySingedAgreement = function(param,callback,ctrlParam)
    {
    	var paraMap = {};
    	paraMap["funcNo"]="500004";
    	paraMap["cust_code"]=param.cust_code;
    	paraMap["pro_type"]="3";
    	paraMap["pro_code"]=param.pro_code;
    	paraMap["ticket"]=param.ticket;
    	paraMap["entrust_way"] = "SJWT";
    	
    	var reqParamVo = new service.ReqParamVo();
    	reqParamVo.setUrl(global.serverPath);
    	commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    
    /**
     * 500100：协议签署
     * @param query_type 签署类型  otclc  -otc理财  otckh  -otc开户
     * @param pro_code 协议编号
     * @param risk_uncover 风险是否揭示  0否，1是
     * @param com_sign 强制签署   是否强制签署 0：非强制签署 1：强制签署
     * @param com_sign 签署类型   0：文本；1：电子
     */
    mobileService.signNewAgreement = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="500100";
	    paraMap["cust_code"]=param.cust_code;
	    paraMap["query_type"]=param.query_type;
	    paraMap["product_id"]=param.product_id;
    	paraMap["ticket"]=param.ticket;
    	paraMap["risk_uncover"]=param.risk_uncover;
    	paraMap["com_sign"]=param.com_sign;
    	paraMap["sign_mode"]=param.sign_mode;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    /**
     * 500008：协议属性查询
     */
    mobileService.agreementProperty = function(param,callback,ctrlParam)
    {
    	var paraMap = {};
    	paraMap["funcNo"]="500008";
 //   	paraMap["pro_type"]=param.pro_type;
    	paraMap["pro_code"]=param.pro_code;
    	paraMap["entrust_way"] = "SJWT";

    	var reqParamVo = new service.ReqParamVo();
    	reqParamVo.setUrl(global.serverPath);
    	commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    /**
     * 500009：协议内容获取
     
     */
    mobileService.agreementContent = function(param,callback,ctrlParam)
    {
    	var paraMap = {};
    	paraMap["funcNo"]="500009";
    	paraMap["pro_content"]=param.pro_content;
    	paraMap["pro_code"]=param.pro_code;
    	paraMap["file_name"]=param.file_name;
    	paraMap["entrust_way"] = "SJWT";

    	var reqParamVo = new service.ReqParamVo();
    	reqParamVo.setUrl(global.serverPath);
    	commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    /********************************20151126应用适当性接口结束********************************/
    
    /********************************20160121应用接口开始********************************/
    /**
     * 300039：理财产品白名单
     * 
     */
    mobileService.whiteList = function(param,callback,ctrlParam)
    {
	    var paraMap = {};
	    paraMap["funcNo"]="300039";
	    paraMap["cust_code"]=param.cust_code;
    	paraMap["inst_code"]=param.inst_code;
		
		var reqParamVo = new service.ReqParamVo();
		reqParamVo.setUrl(global.serverPath);
		commonInvoke(paraMap, callback, ctrlParam, reqParamVo);
    };
    /********************************20160121应用接口结束********************************/
    
});